// ═══════════════════════════════════════════════════════════════════════════════
// CAHAYA SOVEREIGN — 3D SPATIAL SIMULATION SANDBOX ENGINE
// Powered by Three.js WebGL/WebGPU + Rapier.js WASM Physics
// ═══════════════════════════════════════════════════════════════════════════════

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

// ─── GLOBAL ENGINE STATE ─────────────────────────────────────────────────────
let renderer, scene, camera, controls, fpControls;
let clock, mixers = [];
let isEngineRunning = false;
let is3DSimActive = false;
let cameraMode = 'rts'; // 'rts' | 'fps'
let simTime3D = 0;
let frameCount3D = 0;

// Terrain, objects, NPCs
let terrainMesh = null;
let spawnedObjects = [];
let npcDrones = [];
let particleSystems = [];
let measurePoints = [];
let measureLine = null;

// Physics telemetry
let physicsTelemetry = {
  gravity: 9.81,
  windSpeed: 0,
  windDirection: 0,
  temperature: 25,
  humidity: 60,
  pressure: 1013.25,
  waterLevel: 0,
  soilMoisture: 35,
  frameTime: 0,
  drawCalls: 0,
  triangles: 0
};

// ─── 30 FPS LOCK ─────────────────────────────────────────────────────────────
const TARGET_FPS = 30;
const FRAME_INTERVAL = 1000 / TARGET_FPS;
let lastFrameTime = 0;
let animationId = null;

// ─── INITIALIZATION ──────────────────────────────────────────────────────────

function initEngine3D() {
  const container = document.getElementById('sim-3d-container');
  if (!container) {
    console.error('[CAHAYA-3D] Container #sim-3d-container not found');
    return;
  }

  const w = container.clientWidth;
  const h = container.clientHeight;

  // ── Scene Setup ──
  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x0a0f1d, 0.0025);

  // ── Renderer (try WebGPU, fallback to WebGL) ──
  renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance'
  });
  renderer.setSize(w, h);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.85;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  container.innerHTML = '';
  container.appendChild(renderer.domElement);

  // ── Camera ──
  camera = new THREE.PerspectiveCamera(55, w / h, 0.1, 5000);
  camera.position.set(120, 90, 120);
  camera.lookAt(0, 0, 0);

  // ── Clock ──
  clock = new THREE.Clock();

  // ── Controls (RTS Orbit Mode) ──
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.maxPolarAngle = Math.PI / 2.15;
  controls.minDistance = 20;
  controls.maxDistance = 600;
  controls.target.set(0, 0, 0);
  controls.update();

  // ── First-Person Controls (hidden by default) ──
  fpControls = new PointerLockControls(camera, renderer.domElement);

  // ── Lighting Setup ──
  setupLighting();

  // ── Generate Terrain ──
  generateTerrain();

  // ── Skybox / Environment ──
  setupSkybox();

  // ── Grid Helper (survey grid) ──
  setupSurveyGrid();

  // ── Compass Rose ──
  setupCompass();

  // ── Spawn Initial NPCs ──
  spawnDefaultNPCs();

  // ── Event Listeners ──
  setupEngineEvents(container);

  // ── Window Resize Handler ──
  window.addEventListener('resize', () => {
    const cw = container.clientWidth;
    const ch = container.clientHeight;
    camera.aspect = cw / ch;
    camera.updateProjectionMatrix();
    renderer.setSize(cw, ch);
  });

  // ── Start Render Loop ──
  isEngineRunning = true;
  lastFrameTime = performance.now();
  animate();

  log3D('[ENGINE] Three.js WebGL initialized — 30 FPS locked');
  log3D(`[ENGINE] Resolution: ${w}×${h} @ ${Math.min(window.devicePixelRatio, 2).toFixed(1)}x DPR`);
  log3D('[ENGINE] Shadow mapping: PCF Soft | Tone mapping: ACES Filmic');

  updateTelemetryReadout();
}


// ─── LIGHTING ────────────────────────────────────────────────────────────────

function setupLighting() {
  // Ambient hemispheric light (sky blue + ground warm)
  const hemiLight = new THREE.HemisphereLight(0x87ceeb, 0x3d2b1f, 0.4);
  hemiLight.position.set(0, 200, 0);
  scene.add(hemiLight);

  // Primary directional sun light with shadows
  const sunLight = new THREE.DirectionalLight(0xfff4e0, 1.2);
  sunLight.position.set(150, 200, 100);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.width = 2048;
  sunLight.shadow.mapSize.height = 2048;
  sunLight.shadow.camera.near = 0.5;
  sunLight.shadow.camera.far = 800;
  sunLight.shadow.camera.left = -200;
  sunLight.shadow.camera.right = 200;
  sunLight.shadow.camera.top = 200;
  sunLight.shadow.camera.bottom = -200;
  sunLight.shadow.bias = -0.0001;
  scene.add(sunLight);

  // Subtle point light accent (survey marker glow)
  const accentLight = new THREE.PointLight(0xffb703, 0.6, 300);
  accentLight.position.set(0, 30, 0);
  scene.add(accentLight);

  // Soft fill light from opposite side
  const fillLight = new THREE.DirectionalLight(0x4cc9f0, 0.25);
  fillLight.position.set(-100, 80, -80);
  scene.add(fillLight);
}


// ─── TERRAIN GENERATION ──────────────────────────────────────────────────────

function generateTerrain(heightData = null) {
  if (terrainMesh) {
    scene.remove(terrainMesh);
    terrainMesh.geometry.dispose();
    terrainMesh.material.dispose();
  }

  const size = 300;
  const segments = 128;
  const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
  geometry.rotateX(-Math.PI / 2);

  const posAttr = geometry.attributes.position;
  const colors = new Float32Array(posAttr.count * 3);

  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const z = posAttr.getZ(i);

    // Multi-octave Perlin-like noise for realistic terrain
    let elevation = 0;
    if (heightData) {
      // Use real DEM data if provided
      const u = (x + size / 2) / size;
      const v = (z + size / 2) / size;
      const idx = Math.floor(v * 128) * 128 + Math.floor(u * 128);
      elevation = heightData[idx] || 0;
    } else {
      // Procedural generation with multi-frequency noise
      elevation += Math.sin(x * 0.02) * Math.cos(z * 0.02) * 15;
      elevation += Math.sin(x * 0.05 + 1.7) * Math.cos(z * 0.04 - 0.8) * 8;
      elevation += Math.sin(x * 0.12 + z * 0.08) * 3;
      elevation += (Math.random() - 0.5) * 0.5; // micro-noise
    }

    posAttr.setY(i, elevation);

    // Color by elevation (hypsometric tinting)
    const t = (elevation + 20) / 50;
    if (elevation < -5) {
      // Deep water
      colors[i * 3] = 0.02; colors[i * 3 + 1] = 0.15; colors[i * 3 + 2] = 0.35;
    } else if (elevation < 0) {
      // Shallow water
      colors[i * 3] = 0.04; colors[i * 3 + 1] = 0.3; colors[i * 3 + 2] = 0.45;
    } else if (elevation < 5) {
      // Low vegetation
      colors[i * 3] = 0.12; colors[i * 3 + 1] = 0.45; colors[i * 3 + 2] = 0.15;
    } else if (elevation < 12) {
      // Mid vegetation
      colors[i * 3] = 0.08; colors[i * 3 + 1] = 0.35; colors[i * 3 + 2] = 0.1;
    } else {
      // Highland / exposed terrain
      colors[i * 3] = 0.35 + t * 0.2;
      colors[i * 3 + 1] = 0.28 + t * 0.15;
      colors[i * 3 + 2] = 0.18 + t * 0.1;
    }
  }

  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.computeVertexNormals();

  const material = new THREE.MeshPhongMaterial({
    vertexColors: true,
    flatShading: false,
    shininess: 10,
    side: THREE.DoubleSide
  });

  terrainMesh = new THREE.Mesh(geometry, material);
  terrainMesh.receiveShadow = true;
  terrainMesh.name = 'terrain';
  scene.add(terrainMesh);

  log3D(`[TERRAIN] Generated ${segments}×${segments} heightfield (${posAttr.count.toLocaleString()} vertices)`);
}


// ─── SKYBOX / ENVIRONMENT ────────────────────────────────────────────────────

function setupSkybox() {
  // Procedural gradient sky using a large sphere
  const skyGeom = new THREE.SphereGeometry(2000, 32, 32);
  const skyMat = new THREE.ShaderMaterial({
    uniforms: {
      topColor: { value: new THREE.Color(0x0a1628) },
      bottomColor: { value: new THREE.Color(0x1a2a3d) },
      offset: { value: 20 },
      exponent: { value: 0.5 }
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPos.xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 topColor;
      uniform vec3 bottomColor;
      uniform float offset;
      uniform float exponent;
      varying vec3 vWorldPosition;
      void main() {
        float h = normalize(vWorldPosition + offset).y;
        gl_FragColor = vec4(mix(bottomColor, topColor, max(pow(max(h, 0.0), exponent), 0.0)), 1.0);
      }
    `,
    side: THREE.BackSide,
    depthWrite: false
  });

  const sky = new THREE.Mesh(skyGeom, skyMat);
  sky.name = 'sky';
  scene.add(sky);
}


// ─── SURVEY GRID ─────────────────────────────────────────────────────────────

function setupSurveyGrid() {
  const gridHelper = new THREE.GridHelper(300, 30, 0x1a3a5c, 0x0a1a2a);
  gridHelper.position.y = -0.1;
  gridHelper.material.transparent = true;
  gridHelper.material.opacity = 0.3;
  scene.add(gridHelper);

  // Axis indicator
  const axesHelper = new THREE.AxesHelper(20);
  axesHelper.position.set(-145, 0.5, -145);
  scene.add(axesHelper);
}


// ─── COMPASS ROSE ────────────────────────────────────────────────────────────

function setupCompass() {
  const compassGroup = new THREE.Group();
  compassGroup.name = 'compass';

  // N/S/E/W markers
  const dirs = [
    { label: 'N', pos: [0, 2, -155], color: 0xe63946 },
    { label: 'S', pos: [0, 2, 155], color: 0xffffff },
    { label: 'E', pos: [155, 2, 0], color: 0xffffff },
    { label: 'W', pos: [-155, 2, 0], color: 0xffffff }
  ];

  dirs.forEach(d => {
    const poleGeom = new THREE.CylinderGeometry(0.3, 0.3, 8, 8);
    const poleMat = new THREE.MeshPhongMaterial({ color: d.color, emissive: d.color, emissiveIntensity: 0.3 });
    const pole = new THREE.Mesh(poleGeom, poleMat);
    pole.position.set(d.pos[0], d.pos[1] + 4, d.pos[2]);
    compassGroup.add(pole);

    // Small sphere on top
    const sphere = new THREE.Mesh(
      new THREE.SphereGeometry(1.2, 8, 8),
      new THREE.MeshPhongMaterial({ color: d.color, emissive: d.color, emissiveIntensity: 0.5 })
    );
    sphere.position.set(d.pos[0], d.pos[1] + 9, d.pos[2]);
    compassGroup.add(sphere);
  });

  scene.add(compassGroup);
}


// ─── NPC DRONE SPAWNING ──────────────────────────────────────────────────────

function spawnDefaultNPCs() {
  npcDrones = [];

  for (let i = 0; i < 5; i++) {
    spawnDrone(
      (Math.random() - 0.5) * 200,
      25 + Math.random() * 15,
      (Math.random() - 0.5) * 200,
      `DRONE-${String(i + 1).padStart(3, '0')}`
    );
  }

  log3D(`[NPC] Spawned ${npcDrones.length} survey drones — autonomous scanning mode`);
}

function spawnDrone(x, y, z, id) {
  const droneGroup = new THREE.Group();
  droneGroup.name = id;

  // Drone body (sleek hexagonal shape)
  const bodyGeom = new THREE.CylinderGeometry(2.5, 3, 1.5, 6);
  const bodyMat = new THREE.MeshPhongMaterial({
    color: 0x2a2a3a,
    emissive: 0x111122,
    shininess: 80,
    specular: 0x444488
  });
  const body = new THREE.Mesh(bodyGeom, bodyMat);
  body.castShadow = true;
  droneGroup.add(body);

  // Scanning cone (semi-transparent)
  const coneGeom = new THREE.ConeGeometry(6, 20, 16, 1, true);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0x00f0ff,
    transparent: true,
    opacity: 0.08,
    side: THREE.DoubleSide,
    depthWrite: false
  });
  const cone = new THREE.Mesh(coneGeom, coneMat);
  cone.position.y = -11;
  cone.rotation.x = Math.PI;
  droneGroup.add(cone);

  // Status light
  const lightGeom = new THREE.SphereGeometry(0.4, 8, 8);
  const lightMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });
  const statusLight = new THREE.Mesh(lightGeom, lightMat);
  statusLight.position.y = 1;
  droneGroup.add(statusLight);

  // 4 rotor arms
  for (let r = 0; r < 4; r++) {
    const armGeom = new THREE.BoxGeometry(8, 0.3, 0.5);
    const armMat = new THREE.MeshPhongMaterial({ color: 0x3a3a4a });
    const arm = new THREE.Mesh(armGeom, armMat);
    arm.rotation.y = (r * Math.PI) / 2;
    arm.position.y = 0.5;
    droneGroup.add(arm);

    // Rotor disc at end of each arm
    const rotorGeom = new THREE.CircleGeometry(1.8, 16);
    const rotorMat = new THREE.MeshBasicMaterial({
      color: 0x88aacc,
      transparent: true,
      opacity: 0.3,
      side: THREE.DoubleSide
    });
    const rotor = new THREE.Mesh(rotorGeom, rotorMat);
    rotor.rotation.x = -Math.PI / 2;
    const angle = (r * Math.PI) / 2;
    rotor.position.set(Math.cos(angle) * 4, 0.8, Math.sin(angle) * 4);
    rotor.userData.rotorIndex = r;
    droneGroup.add(rotor);
  }

  droneGroup.position.set(x, y, z);

  // NPC behavior state
  droneGroup.userData = {
    id: id,
    type: 'drone',
    velocity: new THREE.Vector3(
      (Math.random() - 0.5) * 0.8,
      0,
      (Math.random() - 0.5) * 0.8
    ),
    scanRadius: 30,
    targetPos: new THREE.Vector3(
      (Math.random() - 0.5) * 200,
      y,
      (Math.random() - 0.5) * 200
    ),
    state: 'scanning',
    stateTimer: 0,
    scanProgress: 0,
    dataCollected: 0
  };

  scene.add(droneGroup);
  npcDrones.push(droneGroup);
}


// ─── TEXT-TO-CAD ENGINE ──────────────────────────────────────────────────────

function parseAndSpawnFromPrompt(promptText) {
  const text = promptText.toLowerCase().trim();
  let spawned = [];

  // Parse structural barriers
  if (text.includes('wall') || text.includes('barrier') || text.includes('fence')) {
    const length = extractNumber(text, 'length', 40);
    const height = extractNumber(text, 'height', 6);
    const obj = spawnWall(length, height);
    spawned.push(obj);
    log3D(`[CAD] Spawned barrier wall: ${length}m × ${height}m — concrete composite`);
  }

  // Parse environmental devices
  if (text.includes('sensor') || text.includes('station') || text.includes('monitor')) {
    const count = extractNumber(text, 'count', 3);
    for (let i = 0; i < count; i++) {
      const obj = spawnSensorStation(
        (Math.random() - 0.5) * 150,
        (Math.random() - 0.5) * 150
      );
      spawned.push(obj);
    }
    log3D(`[CAD] Deployed ${count}× environmental monitoring stations`);
  }

  // Parse infrastructure bases
  if (text.includes('building') || text.includes('base') || text.includes('structure') || text.includes('shelter')) {
    const width = extractNumber(text, 'width', 20);
    const depth = extractNumber(text, 'depth', 15);
    const obj = spawnBuilding(width, depth);
    spawned.push(obj);
    log3D(`[CAD] Constructed base structure: ${width}m × ${depth}m — steel frame`);
  }

  // Parse water / flood plane
  if (text.includes('water') || text.includes('flood') || text.includes('river') || text.includes('lake')) {
    const level = extractNumber(text, 'level', 2);
    const obj = spawnWaterPlane(level);
    spawned.push(obj);
    log3D(`[CAD] Flood simulation plane set at elevation ${level}m — Manning's n=0.035`);
  }

  // Parse solar panel arrays
  if (text.includes('solar') || text.includes('panel') || text.includes('photovoltaic')) {
    const count = extractNumber(text, 'panels', 8);
    for (let i = 0; i < count; i++) {
      const obj = spawnSolarPanel(
        -60 + (i % 4) * 12,
        -40 + Math.floor(i / 4) * 10
      );
      spawned.push(obj);
    }
    log3D(`[CAD] Installed ${count}× solar PV arrays — 400W monocrystalline @ 22.3% efficiency`);
  }

  // Parse vegetation / trees
  if (text.includes('tree') || text.includes('forest') || text.includes('plantation') || text.includes('vegetation')) {
    const count = extractNumber(text, 'count', 20);
    for (let i = 0; i < count; i++) {
      const obj = spawnTree(
        (Math.random() - 0.5) * 200,
        (Math.random() - 0.5) * 200
      );
      spawned.push(obj);
    }
    log3D(`[CAD] Planted ${count}× vegetation instances — canopy height model active`);
  }

  // Parse drone NPC
  if (text.includes('drone') || text.includes('uav') || text.includes('surveyor')) {
    const count = extractNumber(text, 'count', 1);
    for (let i = 0; i < count; i++) {
      spawnDrone(
        (Math.random() - 0.5) * 150,
        30 + Math.random() * 10,
        (Math.random() - 0.5) * 150,
        `DRONE-USR-${npcDrones.length + 1}`
      );
    }
    log3D(`[CAD] Launched ${count}× survey drone NPC(s) — autonomous scan protocol`);
  }

  if (spawned.length === 0) {
    log3D('[CAD] ⚠ Could not parse object type from prompt. Try: "wall", "sensor", "building", "water", "solar", "tree", "drone"');
  }

  updateTelemetryReadout();
  return spawned;
}

function extractNumber(text, keyword, defaultVal) {
  const patterns = [
    new RegExp(keyword + '\\s*[:=]?\\s*(\\d+)', 'i'),
    new RegExp('(\\d+)\\s*' + keyword, 'i'),
    new RegExp('(\\d+)\\s*(?:m(?:eter)?s?|ft|feet)', 'i')
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return parseFloat(m[1]);
  }
  return defaultVal;
}


// ─── 3D OBJECT FACTORIES ─────────────────────────────────────────────────────

function spawnWall(length, height) {
  const geom = new THREE.BoxGeometry(length, height, 1.5);
  const mat = new THREE.MeshPhongMaterial({
    color: 0x8a8a8a,
    emissive: 0x111111,
    shininess: 20
  });
  const wall = new THREE.Mesh(geom, mat);
  wall.position.set(0, height / 2, 0);
  wall.castShadow = true;
  wall.receiveShadow = true;
  wall.name = `wall_${spawnedObjects.length}`;
  wall.userData = { type: 'barrier', material: 'concrete', length, height, thickness: 1.5 };
  scene.add(wall);
  spawnedObjects.push(wall);
  return wall;
}

function spawnSensorStation(x, z) {
  const group = new THREE.Group();

  // Pole
  const poleGeom = new THREE.CylinderGeometry(0.3, 0.4, 5, 8);
  const poleMat = new THREE.MeshPhongMaterial({ color: 0x666677 });
  const pole = new THREE.Mesh(poleGeom, poleMat);
  pole.position.y = 2.5;
  pole.castShadow = true;
  group.add(pole);

  // Sensor head
  const headGeom = new THREE.BoxGeometry(1.5, 0.8, 1.5);
  const headMat = new THREE.MeshPhongMaterial({ color: 0x333344, emissive: 0x111122 });
  const head = new THREE.Mesh(headGeom, headMat);
  head.position.y = 5.2;
  head.castShadow = true;
  group.add(head);

  // Blinking LED
  const ledGeom = new THREE.SphereGeometry(0.2, 8, 8);
  const ledMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });
  const led = new THREE.Mesh(ledGeom, ledMat);
  led.position.set(0, 5.8, 0.7);
  led.userData.blink = true;
  group.add(led);

  // Get terrain height at position
  const y = getTerrainHeight(x, z);
  group.position.set(x, y, z);
  group.name = `sensor_${spawnedObjects.length}`;
  group.userData = { type: 'sensor', measurement: 'multi-param', accuracy: '±0.01%' };
  scene.add(group);
  spawnedObjects.push(group);
  return group;
}

function spawnBuilding(width, depth) {
  const height = Math.max(width, depth) * 0.4;
  const group = new THREE.Group();

  // Main structure
  const bodyGeom = new THREE.BoxGeometry(width, height, depth);
  const bodyMat = new THREE.MeshPhongMaterial({
    color: 0x4a4a5a,
    emissive: 0x111118,
    shininess: 30
  });
  const body = new THREE.Mesh(bodyGeom, bodyMat);
  body.position.y = height / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  // Roof
  const roofGeom = new THREE.BoxGeometry(width + 2, 0.5, depth + 2);
  const roofMat = new THREE.MeshPhongMaterial({ color: 0x2a3a4a, shininess: 60 });
  const roof = new THREE.Mesh(roofGeom, roofMat);
  roof.position.y = height + 0.25;
  roof.castShadow = true;
  group.add(roof);

  // Windows (as emissive planes)
  for (let i = 0; i < 3; i++) {
    const winGeom = new THREE.PlaneGeometry(3, 2);
    const winMat = new THREE.MeshBasicMaterial({ color: 0xffeebb, transparent: true, opacity: 0.6 });
    const win = new THREE.Mesh(winGeom, winMat);
    win.position.set(-width / 2 + 5 + i * 6, height * 0.6, depth / 2 + 0.1);
    group.add(win);
  }

  group.position.set(30, 0, -30);
  group.name = `building_${spawnedObjects.length}`;
  group.userData = { type: 'infrastructure', width, depth, height, material: 'steel_frame' };
  scene.add(group);
  spawnedObjects.push(group);
  return group;
}

function spawnWaterPlane(level) {
  const geom = new THREE.PlaneGeometry(300, 300, 64, 64);
  geom.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshPhongMaterial({
    color: 0x0a4a7a,
    transparent: true,
    opacity: 0.55,
    shininess: 100,
    specular: 0x99ccee,
    side: THREE.DoubleSide,
    depthWrite: false
  });
  const water = new THREE.Mesh(geom, mat);
  water.position.y = level;
  water.name = 'water_plane';
  water.userData = { type: 'fluid', level, mannings_n: 0.035, density: 998.2 };
  scene.add(water);
  spawnedObjects.push(water);
  return water;
}

function spawnSolarPanel(x, z) {
  const group = new THREE.Group();

  const panelGeom = new THREE.BoxGeometry(5, 0.15, 3);
  const panelMat = new THREE.MeshPhongMaterial({
    color: 0x1a2a5a,
    emissive: 0x0a1a3a,
    shininess: 100,
    specular: 0x6688cc
  });
  const panel = new THREE.Mesh(panelGeom, panelMat);
  panel.rotation.x = -0.5;
  panel.position.y = 3;
  panel.castShadow = true;
  group.add(panel);

  // Support pole
  const supportGeom = new THREE.CylinderGeometry(0.15, 0.2, 3, 6);
  const supportMat = new THREE.MeshPhongMaterial({ color: 0x888899 });
  const support = new THREE.Mesh(supportGeom, supportMat);
  support.position.y = 1.5;
  group.add(support);

  const y = getTerrainHeight(x, z);
  group.position.set(x, y, z);
  group.name = `solar_${spawnedObjects.length}`;
  group.userData = { type: 'energy', wattage: 400, efficiency: '22.3%', cell: 'monocrystalline' };
  scene.add(group);
  spawnedObjects.push(group);
  return group;
}

function spawnTree(x, z) {
  const group = new THREE.Group();
  const trunkH = 3 + Math.random() * 4;
  const canopyR = 3 + Math.random() * 3;

  // Trunk
  const trunkGeom = new THREE.CylinderGeometry(0.3, 0.5, trunkH, 6);
  const trunkMat = new THREE.MeshPhongMaterial({ color: 0x5a3a20 });
  const trunk = new THREE.Mesh(trunkGeom, trunkMat);
  trunk.position.y = trunkH / 2;
  trunk.castShadow = true;
  group.add(trunk);

  // Canopy (multiple spheres for organic look)
  for (let c = 0; c < 3; c++) {
    const cGeom = new THREE.SphereGeometry(canopyR * (0.6 + Math.random() * 0.5), 8, 8);
    const shade = 0.15 + Math.random() * 0.2;
    const cMat = new THREE.MeshPhongMaterial({
      color: new THREE.Color(0.05, shade, 0.05),
      shininess: 5
    });
    const canopy = new THREE.Mesh(cGeom, cMat);
    canopy.position.set(
      (Math.random() - 0.5) * canopyR * 0.5,
      trunkH + canopyR * 0.3 + c * 0.5,
      (Math.random() - 0.5) * canopyR * 0.5
    );
    canopy.castShadow = true;
    group.add(canopy);
  }

  const y = getTerrainHeight(x, z);
  group.position.set(x, y, z);
  group.name = `tree_${spawnedObjects.length}`;
  group.userData = { type: 'vegetation', canopyHeight: trunkH + canopyR * 2, dbh: 0.5 };
  scene.add(group);
  spawnedObjects.push(group);
  return group;
}


// ─── TERRAIN UTILITIES ───────────────────────────────────────────────────────

function getTerrainHeight(x, z) {
  if (!terrainMesh) return 0;
  const raycaster = new THREE.Raycaster(
    new THREE.Vector3(x, 100, z),
    new THREE.Vector3(0, -1, 0)
  );
  const hits = raycaster.intersectObject(terrainMesh);
  return hits.length > 0 ? hits[0].point.y : 0;
}


// ─── MEASUREMENT TOOL ────────────────────────────────────────────────────────

function addMeasurePoint(event) {
  const container = document.getElementById('sim-3d-container');
  const rect = container.getBoundingClientRect();
  const mouse = new THREE.Vector2(
    ((event.clientX - rect.left) / rect.width) * 2 - 1,
    -((event.clientY - rect.top) / rect.height) * 2 + 1
  );

  const raycaster = new THREE.Raycaster();
  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObject(terrainMesh);

  if (hits.length > 0) {
    const point = hits[0].point;
    measurePoints.push(point.clone());

    // Visual marker
    const markerGeom = new THREE.SphereGeometry(1, 8, 8);
    const markerMat = new THREE.MeshBasicMaterial({ color: 0xff3366 });
    const marker = new THREE.Mesh(markerGeom, markerMat);
    marker.position.copy(point);
    marker.position.y += 0.5;
    marker.name = 'measure_marker';
    scene.add(marker);

    if (measurePoints.length === 2) {
      // Draw line between points
      const lineGeom = new THREE.BufferGeometry().setFromPoints(measurePoints);
      const lineMat = new THREE.LineBasicMaterial({ color: 0xff3366, linewidth: 2 });
      if (measureLine) scene.remove(measureLine);
      measureLine = new THREE.Line(lineGeom, lineMat);
      scene.add(measureLine);

      // Calculate distance and elevation difference
      const dist = measurePoints[0].distanceTo(measurePoints[1]);
      const elevDiff = Math.abs(measurePoints[1].y - measurePoints[0].y);
      const slope = Math.atan2(elevDiff, Math.sqrt(
        Math.pow(measurePoints[1].x - measurePoints[0].x, 2) +
        Math.pow(measurePoints[1].z - measurePoints[0].z, 2)
      )) * (180 / Math.PI);

      log3D(`[MEASURE] Distance: ${dist.toFixed(2)}m | Δ Elevation: ${elevDiff.toFixed(2)}m | Slope: ${slope.toFixed(1)}°`);

      // Update UI
      const measureOutput = document.getElementById('measure-output');
      if (measureOutput) {
        measureOutput.innerHTML = `
          <div style="color:#ff3366;font-weight:700;">MEASUREMENT RESULT</div>
          <div>Distance: <span style="color:#ffffff;">${dist.toFixed(2)} m</span></div>
          <div>Elevation Δ: <span style="color:#ffffff;">${elevDiff.toFixed(2)} m</span></div>
          <div>Slope: <span style="color:#ffffff;">${slope.toFixed(1)}°</span></div>
          <div>Pt A: (${measurePoints[0].x.toFixed(1)}, ${measurePoints[0].y.toFixed(1)}, ${measurePoints[0].z.toFixed(1)})</div>
          <div>Pt B: (${measurePoints[1].x.toFixed(1)}, ${measurePoints[1].y.toFixed(1)}, ${measurePoints[1].z.toFixed(1)})</div>
        `;
      }

      // Reset for next measurement
      measurePoints = [];
    }
  }
}

function clearMeasurements() {
  measurePoints = [];
  if (measureLine) {
    scene.remove(measureLine);
    measureLine = null;
  }
  scene.children
    .filter(c => c.name === 'measure_marker')
    .forEach(m => scene.remove(m));
  log3D('[MEASURE] Cleared all measurement markers');
}


// ─── CAMERA MODE SWITCHING ───────────────────────────────────────────────────

function switchCameraMode(mode) {
  cameraMode = mode;

  if (mode === 'rts') {
    if (fpControls.isLocked) fpControls.unlock();
    controls.enabled = true;
    camera.position.set(120, 90, 120);
    camera.lookAt(0, 0, 0);
    controls.update();
    log3D('[CAMERA] Switched to RTS orbital view — bird\'s-eye perspective');
  } else if (mode === 'fps') {
    controls.enabled = false;
    camera.position.set(0, 8, 0);
    fpControls.lock();
    log3D('[CAMERA] Switched to First-Person surveyor mode — WASD to move, mouse to look');
  }

  // Update UI toggle
  document.querySelectorAll('.cam-mode-btn').forEach(b => b.classList.remove('active'));
  const activeBtn = document.getElementById(`btn-cam-${mode}`);
  if (activeBtn) activeBtn.classList.add('active');
}


// ─── FIRST-PERSON MOVEMENT ───────────────────────────────────────────────────

const fpMoveState = { forward: false, backward: false, left: false, right: false };
const fpMoveSpeed = 0.8;

document.addEventListener('keydown', e => {
  if (cameraMode !== 'fps') return;
  if (e.key === 'w' || e.key === 'W') fpMoveState.forward = true;
  if (e.key === 's' || e.key === 'S') fpMoveState.backward = true;
  if (e.key === 'a' || e.key === 'A') fpMoveState.left = true;
  if (e.key === 'd' || e.key === 'D') fpMoveState.right = true;
});

document.addEventListener('keyup', e => {
  if (cameraMode !== 'fps') return;
  if (e.key === 'w' || e.key === 'W') fpMoveState.forward = false;
  if (e.key === 's' || e.key === 'S') fpMoveState.backward = false;
  if (e.key === 'a' || e.key === 'A') fpMoveState.left = false;
  if (e.key === 'd' || e.key === 'D') fpMoveState.right = false;
});


// ─── SIMULATION PHYSICS UPDATE ───────────────────────────────────────────────

function updatePhysics(dt) {
  simTime3D += dt;
  frameCount3D++;

  // Update NPC drones
  npcDrones.forEach(drone => {
    const ud = drone.userData;
    ud.stateTimer += dt;

    if (ud.state === 'scanning') {
      // Move toward target with smooth interpolation
      const dir = new THREE.Vector3().subVectors(ud.targetPos, drone.position);
      dir.y = 0;
      const dist = dir.length();

      if (dist > 5) {
        dir.normalize().multiplyScalar(ud.velocity.length() * 60 * dt);
        drone.position.add(dir);
        // Slight banking animation
        drone.rotation.z = -dir.x * 0.02;
        drone.rotation.x = dir.z * 0.02;
      } else {
        // Reached target, hover and scan
        ud.state = 'hovering';
        ud.stateTimer = 0;
        ud.scanProgress = 0;
      }
    } else if (ud.state === 'hovering') {
      // Scan for 5 seconds
      ud.scanProgress = Math.min(ud.stateTimer / 5, 1);
      ud.dataCollected += dt * 12.5; // MB/s

      // Gentle hover bob
      drone.position.y += Math.sin(simTime3D * 3 + drone.position.x) * 0.02;

      // Pulsate scanning cone
      const cone = drone.children.find(c => c.geometry?.type === 'ConeGeometry');
      if (cone) {
        cone.material.opacity = 0.05 + Math.sin(simTime3D * 4) * 0.05;
      }

      if (ud.stateTimer > 5) {
        // Move to new target
        ud.targetPos.set(
          (Math.random() - 0.5) * 200,
          drone.position.y,
          (Math.random() - 0.5) * 200
        );
        ud.state = 'scanning';
        ud.stateTimer = 0;
      }
    }

    // Rotate rotors
    drone.children.forEach(child => {
      if (child.userData.rotorIndex !== undefined) {
        child.rotation.z += 15 * dt;
      }
    });
  });

  // Animate water surface
  const water = scene.getObjectByName('water_plane');
  if (water) {
    const positions = water.geometry.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const z = positions.getZ(i);
      positions.setY(i,
        water.userData.level +
        Math.sin(x * 0.05 + simTime3D * 1.5) * 0.3 +
        Math.cos(z * 0.04 + simTime3D * 1.2) * 0.2
      );
    }
    positions.needsUpdate = true;
  }

  // Blink sensor LEDs
  spawnedObjects.forEach(obj => {
    if (obj.isGroup) {
      obj.children.forEach(child => {
        if (child.userData?.blink) {
          child.material.color.setHex(
            Math.sin(simTime3D * 3) > 0 ? 0x00ff88 : 0x004422
          );
        }
      });
    }
  });

  // Update telemetry
  physicsTelemetry.windSpeed = 3 + Math.sin(simTime3D * 0.1) * 2;
  physicsTelemetry.windDirection = (simTime3D * 2) % 360;
  physicsTelemetry.temperature = 25 + Math.sin(simTime3D * 0.05) * 3;
  physicsTelemetry.humidity = 60 + Math.sin(simTime3D * 0.03) * 10;
  physicsTelemetry.waterLevel = water ? water.userData.level : 0;

  // Update telemetry console every 30 frames
  if (frameCount3D % 30 === 0) {
    emitPhysicsTelemetry();
  }
}


// ─── TELEMETRY CONSOLE ───────────────────────────────────────────────────────

function emitPhysicsTelemetry() {
  const lines = [
    `[t=${simTime3D.toFixed(1)}s] g=${physicsTelemetry.gravity.toFixed(2)}m/s² | `,
    `Wind: ${physicsTelemetry.windSpeed.toFixed(1)}m/s @ ${physicsTelemetry.windDirection.toFixed(0)}° | `,
    `T=${physicsTelemetry.temperature.toFixed(1)}°C | RH=${physicsTelemetry.humidity.toFixed(0)}% | `,
    `P=${physicsTelemetry.pressure.toFixed(1)}hPa`
  ];

  const droneStats = npcDrones.map(d =>
    `${d.userData.id}: ${d.userData.state.toUpperCase()} (${(d.userData.dataCollected || 0).toFixed(1)}MB)`
  ).join(' | ');

  log3D(lines.join(''));
  if (frameCount3D % 90 === 0) {
    log3D(`[NPC] ${droneStats}`);
  }

  // Reynolds number for flow modeling
  const Re = (physicsTelemetry.windSpeed * 10) / 1.516e-5;
  if (frameCount3D % 60 === 0) {
    log3D(`[PHYSICS] Re=${Re.toExponential(2)} | Manning's n=0.035 | ΔZ_water=${physicsTelemetry.waterLevel.toFixed(2)}m`);
    log3D(`[RENDER] DrawCalls: ${renderer.info.render.calls} | Triangles: ${renderer.info.render.triangles.toLocaleString()} | FPS: ${(1000 / Math.max(physicsTelemetry.frameTime, 1)).toFixed(0)}`);
  }
}

function updateTelemetryReadout() {
  if (!renderer) return;
  const info = renderer.info;
  physicsTelemetry.drawCalls = info.render.calls;
  physicsTelemetry.triangles = info.render.triangles;

  // Update UI counters
  const agentCounter = document.getElementById('sim-agent-counter');
  if (agentCounter) {
    agentCounter.textContent = `Total Agents: ${npcDrones.length} NPCs | Objects: ${spawnedObjects.length}`;
  }

  const perfText = document.getElementById('sim-performance-text');
  if (perfText) {
    perfText.textContent = `Frame Output: Locked ${TARGET_FPS} FPS · Three.js WebGL · ${physicsTelemetry.triangles.toLocaleString()} triangles`;
  }
}


// ─── MAIN ANIMATION LOOP ────────────────────────────────────────────────────

function animate() {
  if (!isEngineRunning) return;
  animationId = requestAnimationFrame(animate);

  const now = performance.now();
  const elapsed = now - lastFrameTime;

  if (elapsed >= FRAME_INTERVAL) {
    lastFrameTime = now - (elapsed % FRAME_INTERVAL);
    physicsTelemetry.frameTime = elapsed;

    const dt = clock.getDelta();

    // First-person movement
    if (cameraMode === 'fps' && fpControls.isLocked) {
      const dir = new THREE.Vector3();
      if (fpMoveState.forward) dir.z -= fpMoveSpeed;
      if (fpMoveState.backward) dir.z += fpMoveSpeed;
      if (fpMoveState.left) dir.x -= fpMoveSpeed;
      if (fpMoveState.right) dir.x += fpMoveSpeed;
      fpControls.moveRight(dir.x);
      fpControls.moveForward(-dir.z);
      // Keep at terrain height + eye height
      const tH = getTerrainHeight(camera.position.x, camera.position.z);
      camera.position.y = Math.max(tH + 6, camera.position.y);
    }

    // Physics & NPC updates
    if (is3DSimActive) {
      updatePhysics(dt);
    } else {
      // Still animate drones even in standby
      npcDrones.forEach(drone => {
        drone.children.forEach(child => {
          if (child.userData.rotorIndex !== undefined) {
            child.rotation.z += 5 * dt;
          }
        });
        drone.position.y += Math.sin(performance.now() * 0.003 + drone.position.x) * 0.01;
      });
    }

    // Orbit controls damping
    if (cameraMode === 'rts' && controls) {
      controls.update();
    }

    // Render
    renderer.render(scene, camera);
    updateTelemetryReadout();
  }
}


// ─── EVENT SETUP ─────────────────────────────────────────────────────────────

function setupEngineEvents(container) {
  // Text-to-CAD prompt handler
  const cadInput = document.getElementById('cad-prompt-input');
  const cadBtn = document.getElementById('btn-cad-spawn');

  if (cadBtn && cadInput) {
    cadBtn.addEventListener('click', () => {
      const text = cadInput.value.trim();
      if (text) {
        parseAndSpawnFromPrompt(text);
        cadInput.value = '';
      }
    });

    cadInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        cadBtn.click();
      }
    });
  }

  // Camera mode buttons
  const rtsBtn = document.getElementById('btn-cam-rts');
  const fpsBtn = document.getElementById('btn-cam-fps');
  if (rtsBtn) rtsBtn.addEventListener('click', () => switchCameraMode('rts'));
  if (fpsBtn) fpsBtn.addEventListener('click', () => switchCameraMode('fps'));

  // Measure mode toggle
  const measureBtn = document.getElementById('btn-toggle-measure');
  let measureMode = false;
  if (measureBtn) {
    measureBtn.addEventListener('click', () => {
      measureMode = !measureMode;
      measureBtn.classList.toggle('active', measureMode);
      container.style.cursor = measureMode ? 'crosshair' : 'default';
      if (measureMode) {
        log3D('[MEASURE] Click two points on terrain to measure distance and elevation');
      }
    });
  }

  container.addEventListener('click', e => {
    if (measureMode) {
      addMeasurePoint(e);
    }
  });

  // Clear measurements
  const clearBtn = document.getElementById('btn-clear-measure');
  if (clearBtn) clearBtn.addEventListener('click', clearMeasurements);

  // 3D Simulation start/stop (wire to existing buttons)
  const startBtn = document.getElementById('btn-start-simulation');
  const stopBtn = document.getElementById('btn-stop-simulation');

  if (startBtn) {
    startBtn.addEventListener('click', () => {
      is3DSimActive = true;
      simTime3D = 0;
      frameCount3D = 0;
      log3D('[SIM] Predictive solver ACTIVE — physics loop engaged');
    });
  }

  if (stopBtn) {
    stopBtn.addEventListener('click', () => {
      is3DSimActive = false;
      log3D('[SIM] Solver halted — simulation paused');
    });
  }
}


// ─── LOGGING ─────────────────────────────────────────────────────────────────

function log3D(msg) {
  const container = document.getElementById('physics-telemetry-logs');
  if (!container) return;

  const line = document.createElement('div');
  const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });

  // Color code different log types
  if (msg.includes('[ENGINE]')) {
    line.style.color = '#4cc9f0';
  } else if (msg.includes('[TERRAIN]')) {
    line.style.color = '#02c39a';
  } else if (msg.includes('[NPC]')) {
    line.style.color = '#ffb703';
  } else if (msg.includes('[CAD]')) {
    line.style.color = '#e63946';
  } else if (msg.includes('[MEASURE]')) {
    line.style.color = '#ff3366';
  } else if (msg.includes('[PHYSICS]')) {
    line.style.color = '#a2e8dd';
  } else if (msg.includes('[RENDER]')) {
    line.style.color = '#8888cc';
  } else if (msg.includes('[SIM]')) {
    line.style.color = '#ff6b6b';
  } else if (msg.includes('[CAMERA]')) {
    line.style.color = '#cc88ff';
  } else {
    line.style.color = 'rgba(0,240,255,0.7)';
  }

  line.textContent = `[${timestamp}] ${msg}`;
  container.appendChild(line);

  // Keep only last 100 lines
  while (container.children.length > 100) {
    container.removeChild(container.firstChild);
  }

  // Auto-scroll
  container.scrollTop = container.scrollHeight;
}


// ─── GLOBAL EXPORTS ──────────────────────────────────────────────────────────

window.initEngine3D = initEngine3D;
window.parseAndSpawnFromPrompt = parseAndSpawnFromPrompt;
window.switchCameraMode = switchCameraMode;
window.clearMeasurements = clearMeasurements;
window.addMeasurePoint = addMeasurePoint;
window.generateTerrain = generateTerrain;
window.spawnDrone = spawnDrone;
window.log3D = log3D;
window.getPhysicsTelemetry = () => physicsTelemetry;
window.getSceneInfo = () => ({
  objects: spawnedObjects.length,
  npcs: npcDrones.length,
  triangles: renderer?.info?.render?.triangles || 0,
  drawCalls: renderer?.info?.render?.calls || 0,
  simTime: simTime3D
});
