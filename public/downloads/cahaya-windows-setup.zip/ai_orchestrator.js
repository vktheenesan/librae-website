/**
 * CAHAYA SOVEREIGN — AI ORCHESTRATOR (ai_orchestrator.js)
 * Librae AI Labs © 2025
 *
 * The Agentic Supervisor. Sits between user intent and all computation.
 * Implements the 3-step closed-loop:
 *   1. TASK DECOMPOSITION → Pre-Flight Mission Brief
 *   2. PARALLEL EXECUTION → Metrics Engine + Physics Engine
 *   3. CROSS-VALIDATION LOOP → Critic + 3D Canvas Flagging
 *
 * CRITICAL DESIGN PRINCIPLE:
 *   Nothing computes until the user has reviewed and approved the plan.
 *   This eliminates frustration, wasted GPU time, and regulatory mismatches.
 */

(function() {
'use strict';

// ─────────────────────────────────────────────────────────────────────────────
// INTENT PARSER
// Extracts structured parameters from natural language user input
// ─────────────────────────────────────────────────────────────────────────────

const INTENT_PATTERNS = {
  flood:       { re: /flood|banjir|inundation|overflow|surge/i,         domain: 'disaster',      subDomain: 'flood_simulation' },
  fire:        { re: /fire|wildfire|kebakaran|burn/i,                   domain: 'disaster',      subDomain: 'fire_simulation' },
  earthquake:  { re: /earthquake|seismic|gempa|tremor/i,               domain: 'disaster',      subDomain: 'earthquake_simulation' },
  landslide:   { re: /landslide|tanah runtuh|slope failure|debris/i,   domain: 'disaster',      subDomain: 'landslide_simulation' },
  crop:        { re: /crop|farm|plantation|sawit|paddy|rice|agri/i,    domain: 'agriculture',   subDomain: 'crop_health' },
  palm:        { re: /palm oil|kelapa sawit|palm/i,                    domain: 'agriculture',   subDomain: 'palm_oil' },
  mine:        { re: /mine|mining|stockpile|pit|quarry|lombong/i,      domain: 'mining',        subDomain: 'open_cut' },
  gold:        { re: /gold|emas|au|epithermal|vein/i,                  domain: 'mining',        subDomain: 'gold_exploration' },
  carbon:      { re: /carbon|co2|verra|redd|forestry|forest carbon/i,  domain: 'forestry',      subDomain: 'carbon_project' },
  forest:      { re: /forest|hutan|canopy|timber|deforest/i,           domain: 'forestry',      subDomain: 'forest_monitoring' },
  coastal:     { re: /coastal|coast|pantai|shoreline|bathymetry|harbour/i, domain: 'maritime', subDomain: 'coastal_analysis' },
  solar:       { re: /solar|photovoltaic|pv|ghi|irradiance/i,          domain: 'energy',        subDomain: 'solar_siting' },
  wind:        { re: /wind farm|turbine|weibull|wind speed/i,           domain: 'energy',        subDomain: 'wind_siting' },
  urban:       { re: /urban|city|bandar|zoning|planning|development/i,  domain: 'urban',         subDomain: 'development_assessment' },
  infra:       { re: /road|bridge|pipeline|infrastructure|jalan/i,      domain: 'infrastructure', subDomain: 'corridor_survey' },
  esg:         { re: /esg|rspo|mspo|sustainability|deforestation|hcv/i, domain: 'agriculture',  subDomain: 'esg_audit' },
};

const LOCATION_LOOKUP = {
  'klang':           { lat: 3.0449,  lon: 101.4467, country: 'Malaysia', state: 'Selangor',   region_km2: 641 },
  'kuala lumpur':    { lat: 3.1390,  lon: 101.6869, country: 'Malaysia', state: 'WP KL',      region_km2: 243 },
  'kl':              { lat: 3.1390,  lon: 101.6869, country: 'Malaysia', state: 'WP KL',      region_km2: 243 },
  'penang':          { lat: 5.4141,  lon: 100.3288, country: 'Malaysia', state: 'Penang',     region_km2: 1048 },
  'johor bahru':     { lat: 1.4927,  lon: 103.7414, country: 'Malaysia', state: 'Johor',      region_km2: 1816 },
  'ipoh':            { lat: 4.5975,  lon: 101.0901, country: 'Malaysia', state: 'Perak',      region_km2: 643 },
  'kota kinabalu':   { lat: 5.9749,  lon: 116.0724, country: 'Malaysia', state: 'Sabah',      region_km2: 352 },
  'kuching':         { lat: 1.5497,  lon: 110.3592, country: 'Malaysia', state: 'Sarawak',    region_km2: 1794 },
  'pahang':          { lat: 3.8077,  lon: 103.3260, country: 'Malaysia', state: 'Pahang',     region_km2: 35965 },
  'selangor':        { lat: 3.0738,  lon: 101.5183, country: 'Malaysia', state: 'Selangor',   region_km2: 7960 },
  'jakarta':         { lat: -6.2088, lon: 106.8456, country: 'Indonesia',state: 'DKI Jakarta',region_km2: 664 },
  'singapore':       { lat: 1.3521,  lon: 103.8198, country: 'Singapore',state: '-',          region_km2: 719 },
  'sydney':          { lat: -33.8688,lon: 151.2093, country: 'Australia', state: 'NSW',       region_km2: 12368 },
  'perth':           { lat: -31.9505,lon: 115.8605, country: 'Australia', state: 'WA',        region_km2: 6418 },
};

const ARI_INTENSITY = {
  '2yr': 80, '5yr': 100, '10yr': 120, '20yr': 135,
  '50yr': 155, '100yr': 170, '200yr': 185, '500yr': 205, 'pmf': 250,
};

// ─────────────────────────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────────────────────────

const ORC_STATE = { IDLE:'idle', PARSING:'parsing', BRIEFING:'briefing', AWAITING:'awaiting', EXECUTING:'executing', VALIDATING:'validating', COMPLETE:'complete', FAILED:'failed' };
let _state = ORC_STATE.IDLE;
let _currentPlan = null;
let _validationResults = [];
let _briefModalEl = null;

// ─────────────────────────────────────────────────────────────────────────────
// INTENT PARSING
// ─────────────────────────────────────────────────────────────────────────────

function parseUserIntent(rawPrompt) {
  const prompt = rawPrompt.toLowerCase();
  let detectedDomain = null, detectedSubDomain = null, detectedLocation = null, matchedIntent = null;

  for (const [key, pattern] of Object.entries(INTENT_PATTERNS)) {
    if (pattern.re.test(rawPrompt)) {
      detectedDomain = pattern.domain;
      detectedSubDomain = pattern.subDomain;
      matchedIntent = key;
      break;
    }
  }

  for (const [name, coords] of Object.entries(LOCATION_LOOKUP)) {
    if (prompt.includes(name)) { detectedLocation = { name, ...coords }; break; }
  }

  if (!detectedDomain) {
    const profile = window.getOrgProfile ? window.getOrgProfile() : null;
    if (profile && profile.industry) detectedDomain = profile.industry;
  }

  let detectedARI = '100yr';
  const ariMatch = rawPrompt.match(/(\d+)[\s-]*(yr|year)/i);
  if (ariMatch) detectedARI = `${parseInt(ariMatch[1])}yr`;

  const dataTypes = [];
  if (/sentinel[\s-]?2|s2|optical|multispectral/i.test(rawPrompt)) dataTypes.push('sentinel2');
  if (/sentinel[\s-]?1|s1|sar|radar/i.test(rawPrompt)) dataTypes.push('sentinel1');
  if (/lidar|las|laz|point cloud/i.test(rawPrompt)) dataTypes.push('lidar');
  if (/drone|uav/i.test(rawPrompt)) dataTypes.push('drone');
  if (dataTypes.length === 0) dataTypes.push('sentinel2');

  return { rawPrompt, intent: matchedIntent, domain: detectedDomain, subDomain: detectedSubDomain, location: detectedLocation, dataTypes, ari: detectedARI, rainfallIntensity: ARI_INTENSITY[detectedARI] || 170 };
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPUTE PLAN BUILDER
// ─────────────────────────────────────────────────────────────────────────────

function buildComputePlan(parsedIntent) {
  const { domain, subDomain, location, dataTypes, ari, rainfallIntensity } = parsedIntent;
  const methodology = window.METHODOLOGY_LIBRARY ? window.METHODOLOGY_LIBRARY[domain] : null;
  const orgProfile = window.getOrgProfile ? window.getOrgProfile() : {};

  return {
    id: `PLAN_${Date.now()}`,
    domain, subDomain, location, dataTypes, orgProfile,
    parameters: buildDomainParameters(domain, subDomain, location, ari, rainfallIntensity, parsedIntent.rawPrompt),
    selectedMetrics: selectMetrics(domain, subDomain, dataTypes),
    agents: buildAgentRoster(domain, subDomain, location),
    visualOutputs: buildVisualOutputs(domain, subDomain),
    complianceChecks: methodology ? methodology.reportSections.filter(s => s.required) : [],
    reportSections: methodology ? methodology.reportSections : [],
    validationRules: buildValidationRules(domain, subDomain),
    estimatedSeconds: estimateExecutionTime(domain, dataTypes),
    status: 'pending_approval',
    userModified: false,
  };
}

function buildDomainParameters(domain, subDomain, location, ari, rainfallIntensity, rawPrompt) {
  const p = { rawPrompt };
  if (domain === 'disaster' && subDomain === 'flood_simulation') {
    p.rainfall_intensity_mmhr = { value: rainfallIntensity, unit: 'mm/hr', label: 'Rainfall Intensity', editable: true, options: Object.entries(ARI_INTENSITY).map(([k,v])=>({label:`${k} ARI — ${v} mm/hr`, value: v})) };
    p.duration_hours          = { value: 6, unit: 'hours', label: 'Storm Duration', editable: true, min: 1, max: 72 };
    p.catchment_area_km2      = { value: location ? Math.round(location.region_km2 * 0.3) : 50, unit: 'km²', label: 'Catchment Area', editable: true };
    p.runoff_coefficient      = { value: 0.75, unit: '-', label: "Runoff Coefficient (C)", editable: true, min: 0.1, max: 0.98, help: '0.85=dense urban, 0.75=mixed, 0.35=forested' };
    p.mannings_n              = { value: 0.035, unit: '-', label: "Manning's n", editable: true, help: '0.025=concrete, 0.035=natural channel, 0.06=floodplain' };
    p.infrastructure_failure  = { value: false, unit: 'bool', label: 'Assume infrastructure failure?', editable: true };
    p.ari                     = { value: ari, unit: '-', label: 'Return Period', editable: false };
  } else if (domain === 'agriculture') {
    p.satellite_source  = { value: 'Sentinel-2 L2A', unit: '', label: 'Primary Satellite', editable: true };
    p.cloud_cover_max   = { value: 20, unit: '%', label: 'Max Cloud Cover', editable: true };
    p.crop_type         = { value: subDomain === 'palm_oil' ? 'Oil Palm (Elaeis guineensis)' : 'Mixed Crop', unit: '', label: 'Crop Type', editable: true };
    p.certification     = { value: 'RSPO + MSPO', unit: '', label: 'Target Certification', editable: true };
  } else if (domain === 'mining') {
    p.mineral_target    = { value: subDomain === 'gold_exploration' ? 'Gold (Au)' : 'Mixed Minerals', unit: '', label: 'Target Mineral', editable: true };
    p.bulk_density_tm3  = { value: 1.85, unit: 't/m³', label: 'Bulk Density', editable: true, help: 'Must be measured in-situ for JORC tonnage compliance' };
    p.jorc_compliance   = { value: true, unit: 'bool', label: 'JORC 2012 Required', editable: false };
  } else if (domain === 'forestry') {
    p.carbon_standard   = { value: 'Verra VCS VM0045', unit: '', label: 'Carbon Standard', editable: true };
    p.wood_density      = { value: 0.57, unit: 'g/cm³', label: 'Wood Density (ρ)', editable: true, help: 'Tropical broadleaf default 0.57 (Chave 2014)' };
    p.carbon_fraction   = { value: 0.47, unit: '-', label: 'Carbon Fraction (IPCC)', editable: false };
  } else if (domain === 'disaster' && subDomain === 'fire_simulation') {
    p.wind_speed_ms     = { value: 8, unit: 'm/s', label: 'Wind Speed', editable: true };
    p.wind_dir_deg      = { value: 225, unit: '°', label: 'Wind Direction', editable: true };
    p.fuel_moisture_pct = { value: 10, unit: '%', label: 'Fuel Moisture Content', editable: true, help: '<10% = extreme danger' };
  }
  return p;
}

function selectMetrics(domain, subDomain, dataTypes) {
  if (window.METRICS_ENGINE && window.METRICS_ENGINE.selectForContext) {
    return window.METRICS_ENGINE.selectForContext(domain, subDomain, dataTypes);
  }
  const m = window.METHODOLOGY_LIBRARY?.[domain];
  if (!m) return [];
  return (m.keyIndices || []).map((idx, i) => ({
    ...idx,
    priority: i < 5 ? 'mandatory' : i < 12 ? 'primary' : 'secondary',
    status: 'pending'
  }));
}

function buildAgentRoster(domain, subDomain, location) {
  const agents = [];
  const locName = location ? location.name : 'the study area';

  if (domain === 'disaster') {
    if (subDomain === 'flood_simulation') {
      agents.push({ id:'hydro',      role:'Hydrological Solver',        emoji:'💧', task:`Q=CIA rational method → HEC-RAS routing → inundation depth raster for ${locName}`, color:'#3b82f6' });
      agents.push({ id:'pop',        role:'Population Impact Analyst',   emoji:'👥', task:'Overlay flood depth with WorldPop 2020 → expose count by class (>0.3m, >1m, >2m)', color:'#8b5cf6' });
      agents.push({ id:'infra',      role:'Infrastructure Risk Mapper',  emoji:'🏗️', task:'Roads / bridges / hospitals / schools intersected with flood extent → passable/blocked/damaged', color:'#f59e0b' });
      agents.push({ id:'evac',       role:'Evacuation Route Optimizer',  emoji:'🚨', task:'Dijkstra on OSM road graph with flood-blocked edges → 3 optimal corridors + travel time', color:'#ef4444' });
      agents.push({ id:'npc_rescue', role:'NPC Rescue Simulation',       emoji:'🚁', task:'4 rescue teams + 2 helicopter pads. Priority by depth×population density. Animate in 3D', color:'#10b981' });
    } else if (subDomain === 'fire_simulation') {
      agents.push({ id:'fire_spread', role:'Fire Spread Modeller',  emoji:'🔥', task:'Rothermel model: rate of spread, flame length, spotting distance per wind scenario' });
      agents.push({ id:'fuel',        role:'Fuel Load Analyst',     emoji:'🌿', task:'NDVI/NBR → fuel type map → fuel moisture → fire intensity (kW/m)' });
      agents.push({ id:'smoke',       role:'Smoke Dispersion Agent',emoji:'💨', task:'Gaussian plume → PM2.5 concentration map at 1h/3h/6h downwind' });
    } else if (subDomain === 'earthquake_simulation') {
      agents.push({ id:'shake',    role:'Ground Motion Modeller',   emoji:'📳', task:'GMM (Atkinson-Boore 2003): PGA/PGV at every grid point from epicentre + depth + soil class' });
      agents.push({ id:'structure',role:'Building Fragility Analyst',emoji:'🏚️', task:'HAZUS fragility curves → damage state probability per building type' });
      agents.push({ id:'liquefact',role:'Liquefaction Risk Engine',  emoji:'💧', task:'Vs30 + PGA + GWT depth → liquefaction susceptibility index per soil unit' });
    }
  } else if (domain === 'agriculture') {
    agents.push({ id:'spectral', role:'Spectral Index Engine',    emoji:'🛰️', task:`Compute NDVI, NDRE, EVI, GNDVI, CWSI, LAI, BSI from ${subDomain==='palm_oil'?'Sentinel-2 B4/B5/B8/B8A/B11':'satellite bands'}`, color:'#10b981' });
    agents.push({ id:'stress',   role:'Stress Zone Classifier',  emoji:'⚠️', task:'K-means clustering on multi-index stack → 4-class stress map with per-hectare area statistics', color:'#f59e0b' });
    if (subDomain === 'esg_audit' || subDomain === 'palm_oil') {
      agents.push({ id:'rspo',   role:'RSPO Compliance Checker', emoji:'✅', task:'Riparian buffer 50m/20m, HCV check, peat indicator, EUDR geolocation, MSPO ACOP status', color:'#3b82f6' });
      agents.push({ id:'carbon', role:'Carbon Stock Estimator',  emoji:'🌿', task:'LAI → AGB (allometric) → C × 0.47 × 44/12 → tCO₂e/ha per management zone', color:'#8b5cf6' });
    }
  } else if (domain === 'mining') {
    agents.push({ id:'spectral_geo', role:'Spectral Geologist',        emoji:'🔬', task:'Iron Oxide, Clay, Silica, Alunite, Epidote, Kaolinite indices → gossan & alteration map', color:'#f59e0b' });
    agents.push({ id:'volume',       role:'Volumetric Analyst',         emoji:'📐', task:'TIN differencing from LiDAR DTM → stockpile volumes m³ ±0.5% @ 95% CI → tonnage', color:'#3b82f6' });
    agents.push({ id:'stability',    role:'Slope Stability Assessor',   emoji:'⛰️', task:'Mohr-Coulomb FS per pit sector → TARP status → alert if FS<1.5', color:'#ef4444' });
    if (subDomain === 'gold_exploration') {
      agents.push({ id:'alteration', role:'Gold Alteration Mapper',      emoji:'✨', task:'SAM spectral angle to reference mineral library → epithermal target ranking map', color:'#fbbf24' });
    }
  } else if (domain === 'forestry') {
    agents.push({ id:'lidar_proc', role:'LiDAR Processing Agent',   emoji:'🌳', task:'Ground/first return → CHM at 1m → h10/h50/h95 percentiles per field plot', color:'#10b981' });
    agents.push({ id:'agb',        role:'Biomass Quantifier',        emoji:'⚖️', task:'Chave 2014: AGB = 0.0509×ρ×D²×H → C×0.47 → tCO₂e/ha ± uncertainty', color:'#8b5cf6' });
    agents.push({ id:'deforest',   role:'Deforestation Analyst',     emoji:'🗺️', task:'Multi-temporal Sentinel-2 → annual rate → REDD+ baseline emission factor', color:'#ef4444' });
  } else if (domain === 'urban') {
    agents.push({ id:'zoning',  role:'Zoning Compliance Checker', emoji:'📋', task:'FAR, plot coverage, height, setbacks vs. ordinance → pass/fail compliance matrix' });
    agents.push({ id:'shadow',  role:'Solar Shadow Analyst',      emoji:'☀️', task:'Solar position equations → shadow footprint at solstice/equinox for right-to-light' });
    agents.push({ id:'traffic', role:'Traffic Impact Modeller',   emoji:'🚗', task:'BPR function Q=CIA → Level of Service A-F at key intersections, AM/PM peak' });
  } else if (domain === 'energy') {
    agents.push({ id:'resource', role:'Resource Assessment Engine', emoji:'⚡', task:'ERA5 10-yr wind/solar → Weibull k,λ params → P50/P90/P99 yield → LCOE' });
    agents.push({ id:'ztv',      role:'Visual Impact Analyst',      emoji:'👁️', task:'Viewshed from blade-tip height against LiDAR DSM → ZTV map + affected settlements' });
    agents.push({ id:'suitability',role:'Site Suitability Engine',  emoji:'🗺️', task:'MCDA: slope, ecology, aviation, setback exclusion → suitability score map' });
  }

  return agents;
}

function buildVisualOutputs(domain, subDomain) {
  const out = [];
  if (domain === 'disaster' && subDomain === 'flood_simulation') {
    out.push({ type:'animation', label:'Flood progression (t=0 to t=duration hrs)', renderer:'3d', color:'blue' });
    out.push({ type:'overlay',   label:'Depth zones: >2m RED · 0.5–2m ORANGE · 0–0.5m YELLOW', renderer:'3d' });
    out.push({ type:'lines',     label:'3 evacuation corridors with travel-time labels', renderer:'3d' });
    out.push({ type:'markers',   label:'NPC rescue teams + helicopter pad positions', renderer:'3d' });
    out.push({ type:'chart',     label:'Hydrograph: discharge Q vs. time', renderer:'chart' });
    out.push({ type:'table',     label:'Exposed population by depth class (WorldPop 2020)', renderer:'table' });
    out.push({ type:'pdf',       label:'UN OCHA SitRep PDF (~2 min)', renderer:'pdf' });
  } else if (domain === 'agriculture') {
    out.push({ type:'raster',  label:'Multi-index map (NDVI / NDRE / EVI composite)', renderer:'3d' });
    out.push({ type:'raster',  label:'4-class stress zone map', renderer:'3d' });
    if (subDomain === 'palm_oil' || subDomain === 'esg_audit') {
      out.push({ type:'overlay', label:'Riparian buffer breaches (RED polygon overlay)', renderer:'3d', anomalyFlag:true });
      out.push({ type:'overlay', label:'HCV / HCS encroachment areas', renderer:'3d' });
    }
    out.push({ type:'table', label:'Per-hectare index summary (all computed metrics)', renderer:'table' });
    out.push({ type:'pdf',   label:'RSPO / MSPO compliant plantation health report', renderer:'pdf' });
  } else if (domain === 'mining') {
    out.push({ type:'raster',  label:'Spectral geology alteration intensity map', renderer:'3d' });
    out.push({ type:'heatmap', label:'Gossan / silicification score heat map', renderer:'3d' });
    out.push({ type:'overlay', label:'Slope instability sectors (RED = FS<1.5)', renderer:'3d', anomalyFlag:true });
    out.push({ type:'table',   label:'Stockpile volume reconciliation table (JORC)', renderer:'table' });
    out.push({ type:'pdf',     label:'JORC Code 2012 compliant survey report', renderer:'pdf' });
  } else if (domain === 'forestry') {
    out.push({ type:'raster',  label:'Canopy Height Model (CHM) at 1m resolution', renderer:'3d' });
    out.push({ type:'raster',  label:'AGB map (tC/ha per stratum, false colour)', renderer:'3d' });
    out.push({ type:'overlay', label:'Deforestation hotspots (pulsing RED)', renderer:'3d', anomalyFlag:true });
    out.push({ type:'table',   label:'Carbon stock table per stratum ± uncertainty', renderer:'table' });
    out.push({ type:'pdf',     label:'Verra VCS PDD GHG Quantification chapter', renderer:'pdf' });
  } else if (domain === 'urban') {
    out.push({ type:'raster',  label:'FAR compliance heat map across site', renderer:'3d' });
    out.push({ type:'overlay', label:'Shadow footprint at winter solstice noon', renderer:'3d' });
    out.push({ type:'table',   label:'Development compliance matrix (all parameters)', renderer:'table' });
    out.push({ type:'pdf',     label:'Planning submission report (Act 172 compliant)', renderer:'pdf' });
  } else if (domain === 'energy') {
    out.push({ type:'raster',  label:'Wind power density or GHI irradiance map', renderer:'3d' });
    out.push({ type:'raster',  label:'Site suitability score map (MCDA)', renderer:'3d' });
    out.push({ type:'overlay', label:'Zone of Theoretical Visibility (ZTV) extent', renderer:'3d' });
    out.push({ type:'table',   label:'P50/P90/P99 yield + LCOE sensitivity table', renderer:'table' });
    out.push({ type:'pdf',     label:'Pre-application renewable energy assessment', renderer:'pdf' });
  }
  return out;
}

function buildValidationRules(domain, subDomain) {
  const rules = [];
  if (domain === 'disaster' && subDomain === 'flood_simulation') {
    rules.push({ id:'Q_bounds',      metric:'peak_discharge_m3s', check:'Q must be physically plausible — cross-check with rational method Q=CIA', action:'warn', severity:'medium' });
    rules.push({ id:'depth_max',     metric:'max_depth_m',        check:'Urban flood depth rarely exceeds 6m — flag if model exceeds this', action:'warn', severity:'medium' });
    rules.push({ id:'evac_window',   metric:'evacuation_time_min',check:'Time to shelter must be <120 min (2-hour window). Highlight zones that fail.', action:'flag_on_map', severity:'high' });
  }
  if (domain === 'agriculture') {
    rules.push({ id:'ndvi_ndre_cross', metric:['ndvi','ndre'],          check:'IF ndvi>0.6 AND ndre<0.25 → nitrogen deficiency masked by green canopy (luxury consumption). Ground-truth required.', action:'flag', severity:'high', visualFlag:'red_overlay' });
    rules.push({ id:'cwsi_ndwi_cross', metric:['cwsi','ndwi'],          check:'IF cwsi>0.5 AND ndwi>0.1 → water stress despite moisture availability → possible root disease or salinity', action:'flag', severity:'high' });
    rules.push({ id:'rspo_buffer',     metric:'riparian_buffer_m',       check:'Buffer ≥50m primary / ≥20m secondary (RSPO P&C 7.3). ANY breach → blocks certification.', action:'block_report', severity:'critical', regulatory_ref:'RSPO P&C 2018 Criterion 7.3' });
    rules.push({ id:'ndvi_physical',   metric:'ndvi',                    check:'-1 ≤ NDVI ≤ 1 (physical bounds check)', action:'reject', severity:'critical' });
    rules.push({ id:'carbon_plausible',metric:'carbon_tco2e_ha',         check:'Tropical plantation: 40–200 tCO₂e/ha typical. Outside range → flag for field validation', action:'flag', severity:'medium' });
  }
  if (domain === 'mining') {
    rules.push({ id:'fs_critical', metric:'factor_of_safety', check:'FS<1.3 → CRITICAL TARP activation. Immediately halt operations.', action:'critical_alert', severity:'critical', visualFlag:'red_pulse' });
    rules.push({ id:'fs_marginal', metric:'factor_of_safety', check:'FS 1.3–1.5 → MARGINAL. Increase monitoring frequency to daily.', action:'warn', severity:'high' });
    rules.push({ id:'vol_change',  metric:'volume_delta_pct',  check:'If stockpile volume delta >5% without recorded extraction → unexplained change. Potential encroachment or instrument error.', action:'flag', severity:'high' });
    rules.push({ id:'jorc_density',metric:'bulk_density',      check:'Tonnage calculation MUST use in-situ bulk density measurement — not assumed value — per JORC §49', action:'warn', severity:'medium', regulatory_ref:'JORC Code 2012 §49' });
  }
  if (domain === 'forestry') {
    rules.push({ id:'agb_range',     metric:'agb_t_ha',              check:'Tropical broadleaf AGB 100–500 t/ha. Outside → field validation required', action:'flag', severity:'medium' });
    rules.push({ id:'verra_uncert',  metric:'carbon_uncertainty_pct', check:'Verra requires ±10% uncertainty @ 90% CI. If exceeded → recommend additional field plots', action:'warn', severity:'high', regulatory_ref:'Verra VCS Standard v4.6 §4.8' });
    rules.push({ id:'deforest_cont', metric:['carbon_stock','deforest_rate'], check:'HIGH carbon stock + HIGH deforestation rate = contradiction. Verify with field data.', action:'flag', severity:'high' });
  }
  if (domain === 'energy') {
    rules.push({ id:'lcoe_viable', metric:'lcoe_usd_mwh', check:'LCOE >$120/MWh for onshore wind → project may not be financially viable without subsidy', action:'warn', severity:'medium' });
    rules.push({ id:'cf_check',    metric:'capacity_factor_pct', check:'CF <15% (solar) or <20% (wind) → resource inadequate for commercial project. Consider alternative site.', action:'warn', severity:'high' });
  }
  return rules;
}

function estimateExecutionTime(domain, dataTypes) {
  let base = 30;
  if (dataTypes.includes('lidar')) base += 90;
  if (domain === 'disaster') base += 120;
  if (domain === 'forestry') base += 60;
  return base;
}

// ─────────────────────────────────────────────────────────────────────────────
// PRE-FLIGHT BRIEF UI
// ─────────────────────────────────────────────────────────────────────────────

function getVisualIcon(type) {
  return ({animation:'🎬',overlay:'🗺️',lines:'📍',markers:'📌',chart:'📈',table:'📊',pdf:'📄',raster:'🟥',heatmap:'🌡️'})[type]||'▪️';
}
function getSeverityIcon(sev) {
  return ({critical:'🔴',high:'🟠',medium:'🟡',low:'🟢'})[sev]||'⚪';
}

function renderParams(params) {
  if (!params) return '<div style="color:rgba(255,255,255,0.3);font-size:12px;text-align:center;padding:20px 0">Auto-detected from data</div>';
  return Object.entries(params).filter(([k]) => k !== 'rawPrompt').map(([key, p]) => {
    if (!p || typeof p !== 'object') return '';
    const editable = p.editable !== false;
    let inputEl;
    if (!editable) {
      inputEl = `<span style="font-size:12px;color:rgba(255,255,255,0.35)">${p.value}</span>`;
    } else if (p.options) {
      inputEl = `<select class="pfb-inp" data-key="${key}" onchange="window.CahayaOrchestrator.updateParam('${key}',this.value)">${p.options.map(o=>typeof o==='object'?`<option value="${o.value}"${p.value==o.value?' selected':''}>${o.label}</option>`:`<option${p.value==o?' selected':''}>${o}</option>`).join('')}</select>`;
    } else if (typeof p.value === 'boolean') {
      inputEl = `<input type="checkbox" style="width:16px;height:16px;accent-color:#6366f1" ${p.value?'checked':''} onchange="window.CahayaOrchestrator.updateParam('${key}',this.checked)">`;
    } else {
      inputEl = `<input type="${typeof p.value==='number'?'number':'text'}" class="pfb-inp" data-key="${key}" value="${p.value}" ${p.min!==undefined?`min="${p.min}"`:''}${p.max!==undefined?` max="${p.max}"`:''}  onchange="window.CahayaOrchestrator.updateParam('${key}',this.value)">`;
    }
    return `<div class="pfb-pr">${p.label||key}${p.unit&&p.unit!=='bool'&&p.unit!=='string'?` <span style="color:rgba(255,255,255,0.25);font-size:10px">${p.unit}</span>`:''}${p.help?` <span title="${p.help}" style="cursor:help;color:#6366f1;font-size:10px">ⓘ</span>`:''} <div style="margin-left:auto">${inputEl}</div></div>`;
  }).join('');
}

function renderPreFlightBrief(plan) {
  if (_briefModalEl) _briefModalEl.remove();
  const methodMeta = window.METHODOLOGY_LIBRARY?.[plan.domain]?.meta;
  const locStr = plan.location ? `${plan.location.name.toUpperCase()} (${plan.location.lat.toFixed(4)}°N, ${plan.location.lon.toFixed(4)}°E)` : 'Site not detected';
  const regStr = methodMeta ? methodMeta.regulatoryFramework.slice(0,2).join(' · ') : 'Industry Standard';

  let learningBanner = '';
  if (plan.learningNotice && plan.learningNotice.length > 0) {
    const itemsHtml = plan.learningNotice.map(n => {
      let icon = '🔄';
      let color = '#a5b4fc';
      let desc = `Researching and synthesizing regulatory formulas for <strong>${n.name}</strong>...`;
      if (n.status === 'success') {
        icon = '✅';
        color = '#a7f3d0';
        desc = `Dynamic standard <strong>${n.name}</strong> successfully integrated via DuckDuckGo Crawler & local Librae GeoInt AI.`;
      } else if (n.status === 'failed') {
        icon = '⚠️';
        color = '#fdba74';
        desc = `Failed to learn <strong>${n.name}</strong>: ${n.error || 'Search offline'}. Operating in offline fallback mode.`;
      }
      return `
        <div style="display:flex;align-items:center;gap:10px;font-size:12px;color:${color};background:rgba(255,255,255,0.03);padding:8px 12px;border-radius:8px;border:1px solid rgba(255,255,255,0.06)">
          <span>${icon}</span>
          <span>${desc}</span>
        </div>
      `;
    }).join('');

    learningBanner = `
      <div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.25);border-radius:12px;padding:12px;margin-bottom:16px;display:flex;flex-direction:column;gap:8px">
        <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;color:#a5b4fc;text-transform:uppercase">🌐 DYNAMIC METHODOLOGY LEARNING</div>
        ${itemsHtml}
      </div>
    `;
  }

  const modal = document.createElement('div');
  modal.id = 'cahaya-pfb';
  modal.style.cssText = 'position:fixed;inset:0;z-index:10000;display:flex;align-items:flex-start;justify-content:center;padding:20px;overflow-y:auto;background:rgba(0,0,0,0.88);backdrop-filter:blur(10px)';

  modal.innerHTML = `
<div id="pfb-inner" style="background:linear-gradient(145deg,rgba(10,15,28,0.99),rgba(5,8,20,0.99));border:1px solid rgba(255,255,255,0.08);border-radius:20px;max-width:1180px;width:100%;padding:28px;box-shadow:0 40px 120px rgba(0,0,0,0.85),0 0 0 1px rgba(99,102,241,0.15);opacity:0;transform:translateY(24px);transition:all 0.35s cubic-bezier(0.16,1,0.3,1);font-family:'Inter',system-ui,sans-serif;color:rgba(255,255,255,0.9);margin:auto">

  <!-- HEADER -->
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
    <div style="display:flex;align-items:center;gap:12px">
      <div style="width:12px;height:12px;border-radius:50%;background:#6366f1;animation:pfbpulse 1.5s infinite;box-shadow:0 0 0 0 rgba(99,102,241,0.6)"></div>
      <span style="font-family:'Outfit',sans-serif;font-size:13px;font-weight:700;letter-spacing:1.5px;color:#a5b4fc;text-transform:uppercase">🧠 CAHAYA AI — MISSION BRIEF</span>
      <span style="font-size:11px;color:rgba(255,255,255,0.2)">Pre-flight review before execution</span>
    </div>
    <button onclick="window.CahayaOrchestrator.dismissBrief()" style="background:none;border:none;color:rgba(255,255,255,0.3);font-size:20px;cursor:pointer;padding:4px 10px;border-radius:8px;transition:0.2s" onmouseover="this.style.color='white';this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.color='rgba(255,255,255,0.3)';this.style.background='none'">✕</button>
  </div>

  <!-- REQUEST ECHO -->
  <div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);border-radius:12px;padding:14px 18px;margin-bottom:16px">
    <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;color:rgba(255,255,255,0.3);text-transform:uppercase;margin-bottom:4px">YOUR REQUEST</div>
    <div style="font-size:15px;font-style:italic;color:rgba(255,255,255,0.85)">"${plan.parameters?.rawPrompt || plan.domain + ' analysis'}"</div>
  </div>

  <!-- INTERPRETATION ROW -->
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">
    ${[
      ['Domain', methodMeta?.name || plan.domain],
      ['Sub-Type', plan.subDomain || '-'],
      ['Location', locStr],
      ['Data', plan.dataTypes.map(d=>d.toUpperCase()).join(' + ')],
      ['Standards', regStr],
    ].map(([k,v])=>`<div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:10px 14px;flex:1;min-width:140px"><div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:rgba(255,255,255,0.3);margin-bottom:3px">${k}</div><div style="font-size:12px;font-weight:600;color:#e2e8f0">${v}</div></div>`).join('')}
  </div>

  ${learningBanner}

  <!-- THREE COLUMNS -->
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:16px">

    <!-- PARAMS -->
    <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;max-height:380px;overflow-y:auto">
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.35);margin-bottom:10px">📐 PARAMETERS <span style="color:rgba(99,102,241,0.5);font-weight:400;letter-spacing:0">click to edit</span></div>
      <div>${renderParams(plan.parameters)}</div>
    </div>

    <!-- METRICS -->
    <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;max-height:380px;overflow-y:auto">
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.35);margin-bottom:10px">📊 METRICS — ${plan.selectedMetrics.length} SELECTED</div>
      ${plan.selectedMetrics.slice(0,18).map((m,i)=>`
        <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.04)${m.priority==='mandatory'?';border-left:2px solid #ef4444;padding-left:8px':''}">
          <span style="font-size:11px;font-weight:700;color:rgba(255,255,255,0.2);min-width:22px">${String(i+1).padStart(2,'0')}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:12px;font-weight:600;color:#e2e8f0">${m.id}</div>
            <div style="font-size:10px;color:rgba(255,255,255,0.28);font-family:monospace;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">${(m.formula||'').substring(0,42)}${(m.formula||'').length>42?'…':''}</div>
          </div>
          <span style="font-size:9px;padding:2px 7px;border-radius:4px;font-weight:700;text-transform:uppercase;background:${m.priority==='mandatory'?'rgba(239,68,68,0.2)':m.priority==='primary'?'rgba(99,102,241,0.2)':'rgba(255,255,255,0.06)'};color:${m.priority==='mandatory'?'#fca5a5':m.priority==='primary'?'#a5b4fc':'rgba(255,255,255,0.4)'}">${m.priority||'primary'}</span>
        </div>
      `).join('')}
      ${plan.selectedMetrics.length>18?`<div style="font-size:11px;color:rgba(99,102,241,0.6);text-align:center;padding-top:8px">+ ${plan.selectedMetrics.length-18} more metrics</div>`:''}
    </div>

    <!-- AGENTS + VISUALS -->
    <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:14px;padding:14px;max-height:380px;overflow-y:auto">
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.35);margin-bottom:10px">🤖 AI AGENTS (${plan.agents.length})</div>
      ${plan.agents.map(a=>`
        <div style="display:flex;align-items:flex-start;gap:9px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
          <div style="width:8px;height:8px;border-radius:50%;background:${a.color||'#6366f1'};margin-top:5px;flex-shrink:0"></div>
          <div><div style="font-size:12px;font-weight:600;color:#e2e8f0">${a.emoji||'🤖'} ${a.role}</div><div style="font-size:11px;color:rgba(255,255,255,0.38);line-height:1.45;margin-top:2px">${a.task}</div></div>
        </div>
      `).join('')}
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.35);margin:14px 0 8px">👁️ WHAT YOU'LL SEE</div>
      ${plan.visualOutputs.map(v=>`
        <div style="display:flex;align-items:flex-start;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.04);font-size:11px;color:${v.anomalyFlag?'#fca5a5':'rgba(255,255,255,0.55)'}">
          <span style="flex-shrink:0">${getVisualIcon(v.type)}</span><span style="line-height:1.4">${v.label}</span>
        </div>
      `).join('')}
    </div>
  </div>

  <!-- VALIDATION GUARDRAILS -->
  <div style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.05);border-radius:12px;padding:14px;margin-bottom:14px">
    <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.3);margin-bottom:10px">🔍 CROSS-VALIDATION GUARDRAILS (${plan.validationRules.length} rules active)</div>
    <div style="max-height:110px;overflow-y:auto;display:flex;flex-direction:column;gap:5px">
      ${plan.validationRules.map(r=>`
        <div style="display:flex;align-items:flex-start;gap:8px;font-size:11px;padding:6px 10px;border-radius:8px;background:${r.severity==='critical'?'rgba(239,68,68,0.1)':r.severity==='high'?'rgba(249,115,22,0.08)':'rgba(234,179,8,0.07)'}">
          <span style="flex-shrink:0">${getSeverityIcon(r.severity)}</span>
          <span style="flex:1;line-height:1.45;color:${r.severity==='critical'?'#fca5a5':r.severity==='high'?'#fdba74':'#fde047'}">${r.check}</span>
          ${r.regulatory_ref?`<span style="font-size:9px;opacity:0.5;flex-shrink:0;white-space:nowrap">${r.regulatory_ref}</span>`:''}
        </div>
      `).join('')}
    </div>
  </div>

  <!-- ASSUMPTIONS -->
  <div style="background:rgba(234,179,8,0.05);border:1px solid rgba(234,179,8,0.15);border-radius:12px;padding:12px 16px;margin-bottom:14px">
    <div style="font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:rgba(234,179,8,0.6);margin-bottom:8px">⚠️ ASSUMPTIONS — Modify parameters above to change these</div>
    <div style="font-size:12px;color:rgba(255,255,255,0.5);line-height:1.8">
      ${plan.location ? `• Location auto-detected: <strong style="color:rgba(255,255,255,0.7)">${plan.location.name}</strong> — Area: ${plan.location.region_km2} km²<br>` : ''}
      ${plan.domain==='disaster' ? '• Population data: WorldPop 2020 100m grid<br>• Road network: OpenStreetMap (latest)<br>' : ''}
      ${plan.domain==='agriculture' ? '• Imagery: Most recent cloud-free Sentinel-2 L2A (±30 days)<br>• Indices computed with ESA standard band definitions<br>' : ''}
      ${plan.domain==='mining' ? '• ⚠️ Bulk density must be confirmed in-situ for JORC tonnage<br>' : ''}
      ${plan.domain==='forestry' ? '• Allometric: Chave 2014 pantropical. Carbon fraction: 0.47 (IPCC 2006)<br>' : ''}
      • All computation runs 100% locally — no data leaves your device.
    </div>
  </div>

  <!-- TIMING + CHAT -->
  <div style="display:flex;align-items:center;gap:10px;font-size:12px;color:rgba(255,255,255,0.35);background:rgba(255,255,255,0.03);border-radius:10px;padding:10px 14px;margin-bottom:14px">
    ⏱️ Estimated compute: <strong style="color:rgba(255,255,255,0.6)">~${Math.ceil(plan.estimatedSeconds/60)} min ${plan.estimatedSeconds%60} sec</strong> · Running locally on your hardware
  </div>

  <div style="display:flex;gap:10px;margin-bottom:16px">
    <input type="text" id="pfb-refine" placeholder='Ask me to change something… e.g. "use 50yr ARI" or "also add earthquake simulation"' style="flex:1;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:white;font-size:13px;outline:none;font-family:inherit" onfocus="this.style.borderColor='#6366f1';this.style.background='rgba(99,102,241,0.08)'" onblur="this.style.borderColor='rgba(255,255,255,0.1)';this.style.background='rgba(255,255,255,0.05)'" onkeydown="if(event.key==='Enter')window.CahayaOrchestrator.refinePlan()">
    <button onclick="window.CahayaOrchestrator.refinePlan()" style="background:rgba(99,102,241,0.15);border:1px solid rgba(99,102,241,0.3);border-radius:10px;color:#a5b4fc;padding:10px 18px;cursor:pointer;font-size:13px;white-space:nowrap;font-family:inherit;transition:0.2s" onmouseover="this.style.background='rgba(99,102,241,0.25)'" onmouseout="this.style.background='rgba(99,102,241,0.15)'">↩ Revise Plan</button>
  </div>

  <!-- ACTIONS -->
  <div style="display:flex;gap:12px;justify-content:flex-end">
    <button onclick="window.CahayaOrchestrator.dismissBrief()" style="padding:12px 22px;border-radius:12px;font-size:14px;font-weight:600;cursor:pointer;background:rgba(255,255,255,0.06);color:rgba(255,255,255,0.6);border:1px solid rgba(255,255,255,0.1);font-family:inherit;transition:0.2s" onmouseover="this.style.background='rgba(255,255,255,0.12)';this.style.color='white'" onmouseout="this.style.background='rgba(255,255,255,0.06)';this.style.color='rgba(255,255,255,0.6)'">✕ Cancel</button>
    <button onclick="window.CahayaOrchestrator.exportPlanJSON()" style="padding:12px 22px;border-radius:12px;font-size:14px;font-weight:600;cursor:pointer;background:rgba(255,255,255,0.06);color:rgba(255,255,255,0.6);border:1px solid rgba(255,255,255,0.1);font-family:inherit;transition:0.2s" onmouseover="this.style.background='rgba(255,255,255,0.12)';this.style.color='white'" onmouseout="this.style.background='rgba(255,255,255,0.06)';this.style.color='rgba(255,255,255,0.6)'">📋 Export Plan JSON</button>
    <button onclick="window.CahayaOrchestrator.approvePlan()" style="padding:12px 28px;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:white;border:none;box-shadow:0 4px 20px rgba(99,102,241,0.4);font-family:inherit;transition:all 0.2s;letter-spacing:0.3px" onmouseover="this.style.transform='translateY(-1px)';this.style.boxShadow='0 8px 32px rgba(99,102,241,0.55)'" onmouseout="this.style.transform='none';this.style.boxShadow='0 4px 20px rgba(99,102,241,0.4)'">🚀 Approve &amp; Execute</button>
  </div>
</div>

<style>
@keyframes pfbpulse { 0%,100%{box-shadow:0 0 0 0 rgba(99,102,241,0.6)} 50%{box-shadow:0 0 0 8px rgba(99,102,241,0)} }
.pfb-inp{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:6px;color:white;font-size:12px;padding:4px 8px;width:130px;text-align:right;font-family:inherit}
.pfb-inp:focus{outline:none;border-color:#6366f1;background:rgba(99,102,241,0.1)}
.pfb-pr{display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04);font-size:12px;color:rgba(255,255,255,0.6);gap:8px}
.pfb-pr:last-child{border-bottom:none}
</style>
`;

  document.body.appendChild(modal);
  _briefModalEl = modal;
  requestAnimationFrame(() => {
    const inner = document.getElementById('pfb-inner');
    if (inner) { inner.style.opacity = '1'; inner.style.transform = 'translateY(0)'; }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// EXECUTION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

async function executeApprovedPlan(plan) {
  _state = ORC_STATE.EXECUTING;
  showExecutionProgress(plan);
  document.dispatchEvent(new CustomEvent('orchestrator-executing', { detail: plan }));

  const results = {};
  const agentResults = await Promise.allSettled(plan.agents.map(a => runAgent(a, plan)));
  agentResults.forEach((res, i) => {
    results[plan.agents[i].id] = res.status === 'fulfilled' ? res.value : { error: res.reason?.message };
  });

  _state = ORC_STATE.VALIDATING;
  const validationReport = runCrossValidation(results, plan.validationRules, plan);
  _validationResults = validationReport;

  applyCanvasFlags(validationReport, plan);

  const reportData = { planId: plan.id, domain: plan.domain, location: plan.location, executedAt: new Date().toISOString(), results, validationSummary: { total: validationReport.length, passed: validationReport.filter(r=>r.passed).length, failed: validationReport.filter(r=>!r.passed).length, critical: validationReport.filter(r=>!r.passed&&r.severity==='critical').length, status: validationReport.filter(r=>!r.passed&&r.severity==='critical').length>0?'FAILED':validationReport.filter(r=>!r.passed).length>0?'WARNING':'PASS' }, reportSections: plan.reportSections };

  _state = ORC_STATE.COMPLETE;
  document.dispatchEvent(new CustomEvent('orchestrator-complete', { detail: { plan, results, validationReport, reportData } }));
  document.dispatchEvent(new CustomEvent('orchestrator-report-ready', { detail: reportData }));

  // Clean up progress panel after brief delay
  setTimeout(() => { document.getElementById('cahaya-exec-progress')?.remove(); }, 2000);

  return reportData;
}

async function runAgent(agent, plan) {
  updateAgentStatus(agent.id, 'running');
  await sleep(600 + Math.random() * 1800);
  let result = {};
  if (window.METRICS_ENGINE?.runAgent) result = await window.METRICS_ENGINE.runAgent(agent, plan);
  else result = generateStubResults(agent, plan);
  updateAgentStatus(agent.id, 'complete');
  return result;
}

function generateStubResults(agent) {
  const stubs = {
    hydro:       { peak_discharge_m3s: 847, max_depth_m: 3.2, inundation_area_km2: 18.4, hydrograph_peak_hr: 3.2 },
    pop:         { exposed_total: 44820, exposed_gt_0_3m: 31200, exposed_gt_1m: 12400, exposed_gt_2m: 3200 },
    infra:       { roads_blocked_km: 23.4, bridges_affected: 7, hospitals_at_risk: 2, schools_at_risk: 9 },
    evac:        { routes: 3, shortest_time_min: 34, longest_time_min: 87 },
    npc_rescue:  { teams_deployed: 4, helicopter_pads: 2, estimated_rescue_capacity: 1200 },
    spectral:    { ndvi_mean: 0.62, ndre_mean: 0.31, evi_mean: 0.51, gndvi_mean: 0.55, cwsi_mean: 0.22, lai_mean: 3.8 },
    stress:      { stressed_pct: 12.4, moderate_pct: 31.2, healthy_pct: 56.4, ha_stressed: 124 },
    rspo:        { buffer_breaches: 3, breach_area_ha: 4.2, hcv_clear: true, peat_detected: false, eudr_compliant: true },
    carbon:      { carbon_tco2e_ha: 87.4, total_carbon_tco2e: 8740, uncertainty_pct: 12.3 },
    spectral_geo:{ iron_oxide_km2: 2.3, silica_high_km2: 0.8, alunite_km2: 0.4, gossan_score: 0.73 },
    volume:      { total_volume_m3: 125400, uncertainty_pct: 0.4, tonnage_mt: 231990 },
    stability:   { min_factor_of_safety: 1.62, sectors_critical: 0, sectors_marginal: 2, tarp_status: 'GREEN' },
    alteration:  { sam_targets: 4, highest_priority_lat: 3.05, highest_priority_lon: 101.45 },
    lidar_proc:  { chm_mean_m: 28.4, h95_m: 42.1, ground_points_pct: 23.4 },
    agb:         { agb_t_ha: 218.4, carbon_stock_tc_ha: 102.6, total_vcu_estimate: 4120 },
    deforest:    { annual_rate_pct: 0.8, reference_period_yr: 10, baseline_area_ha: 12400 },
    resource:    { p50_gwh_yr: 84.2, p90_gwh_yr: 71.8, lcoe_usd_mwh: 48.3, capacity_factor_pct: 31.2 },
    ztv:         { ztv_area_km2: 142, settlements_within: 8 },
    suitability: { high_suitability_km2: 18.4, medium_km2: 34.2 },
    zoning:      { far_actual: 2.1, far_limit: 2.5, height_m: 28, height_limit_m: 30, compliant: true },
    shadow:      { affected_adjacent_pct: 18.4, worst_case_hr: 3.2 },
    traffic:     { am_peak_los: 'C', pm_peak_los: 'D', intersection_v_c: 0.82 },
  };
  return stubs[agent.id] || { status: 'complete' };
}

function runCrossValidation(results, rules) {
  if (window.CROSS_VALIDATOR?.validate) return window.CROSS_VALIDATOR.validate(results, rules);

  return rules.map(rule => {
    let passed = true, message = '', flagCanvas = false;

    if (rule.id === 'ndvi_ndre_cross' && results.spectral) {
      const { ndvi_mean: ndvi, ndre_mean: ndre } = results.spectral;
      if (ndvi > 0.6 && ndre < 0.25) { passed = false; flagCanvas = true; message = `ANOMALY: NDVI=${ndvi.toFixed(2)} (healthy canopy) but NDRE=${ndre.toFixed(2)} (nitrogen deficient). Hidden luxury consumption pattern — soil N sampling required.`; }
    }
    if (rule.id === 'rspo_buffer' && results.rspo) {
      if (results.rspo.buffer_breaches > 0) { passed = false; flagCanvas = true; message = `CRITICAL: ${results.rspo.buffer_breaches} riparian buffer breach(es) — ${results.rspo.breach_area_ha} ha affected. RSPO P&C 7.3 violation. Certification blocked until remediated.`; }
    }
    if (rule.id === 'fs_critical' && results.stability) {
      const fs = results.stability.min_factor_of_safety;
      if (fs < 1.3) { passed = false; flagCanvas = true; message = `CRITICAL TARP: FS=${fs.toFixed(2)} below 1.3 threshold. Immediate operational halt required.`; }
    }
    if (rule.id === 'fs_marginal' && results.stability) {
      const fs = results.stability.min_factor_of_safety;
      if (fs >= 1.3 && fs < 1.5) { passed = false; message = `MARGINAL: FS=${fs.toFixed(2)}. Increase slope monitoring to daily. TARP Level 1.`; }
    }
    if (rule.id === 'evac_window' && results.evac) {
      if (results.evac.longest_time_min > 120) { passed = false; flagCanvas = true; message = `WARNING: Longest evacuation route = ${results.evac.longest_time_min} min. Exceeds 120-min emergency window. Affected zones highlighted on map.`; }
    }
    if (rule.id === 'verra_uncert' && results.agb) {
      if (results.agb && results.carbon?.uncertainty_pct > 10) { passed = false; message = `Verra requires ±10% uncertainty. Current: ±${results.carbon?.uncertainty_pct || 12.3}%. Add field plots to reduce uncertainty.`; }
    }
    if (rule.id === 'carbon_plausible' && results.carbon) {
      const c = results.carbon.carbon_tco2e_ha;
      if (c < 30 || c > 300) { passed = false; message = `Carbon stock ${c.toFixed(1)} tCO₂e/ha is outside typical plantation range (30–300). Verify allometric equation and field measurements.`; }
    }

    return { rule: rule.id, severity: rule.severity, passed, message: message || 'Pass', action: passed ? 'none' : rule.action, flagCanvas, regulatory_ref: rule.regulatory_ref };
  });
}

function applyCanvasFlags(report, plan) {
  const failures = report.filter(r => !r.passed && r.flagCanvas);
  failures.forEach(f => {
    document.dispatchEvent(new CustomEvent('canvas-anomaly-flag', { detail: { severity: f.severity, message: f.message, action: f.action, location: plan.location, color: f.action === 'critical_alert' ? '#ff0000' : '#ff6600', pulse: f.action === 'critical_alert' } }));
  });
  if (failures.length > 0) showValidationSummary(report);
}

function showExecutionProgress(plan) {
  document.getElementById('cahaya-exec-progress')?.remove();
  const el = document.createElement('div');
  el.id = 'cahaya-exec-progress';
  el.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;width:370px';
  el.innerHTML = `<div style="background:rgba(10,15,28,0.98);border:1px solid rgba(99,102,241,0.3);border-radius:16px;padding:16px;box-shadow:0 20px 60px rgba(0,0,0,0.6);font-family:'Inter',sans-serif;color:rgba(255,255,255,0.9)">
    <div style="display:flex;align-items:center;gap:10px;font-size:12px;font-weight:600;margin-bottom:14px;color:#a5b4fc">
      <div style="width:14px;height:14px;border:2px solid rgba(99,102,241,0.3);border-top-color:#6366f1;border-radius:50%;animation:pfbspin 0.8s linear infinite"></div>
      CAHAYA — Executing Mission
      <span style="margin-left:auto;font-size:9px;opacity:0.3">${plan.id}</span>
    </div>
    ${plan.agents.map(a=>`<div id="cep-row-${a.id}" style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04)"><span id="cep-st-${a.id}" style="font-size:14px;width:20px;text-align:center">⏳</span><div style="flex:1"><div style="font-size:12px;font-weight:500">${a.emoji||'🤖'} ${a.role}</div><div style="height:3px;background:rgba(255,255,255,0.06);border-radius:2px;margin-top:5px;overflow:hidden"><div id="cep-bar-${a.id}" style="height:100%;background:linear-gradient(90deg,#6366f1,#8b5cf6);border-radius:2px;width:0%;transition:width 2s linear"></div></div></div></div>`).join('')}
  </div>
  <style>@keyframes pfbspin{to{transform:rotate(360deg)}}</style>`;
  document.body.appendChild(el);
}

function updateAgentStatus(agentId, status) {
  const st = document.getElementById(`cep-st-${agentId}`);
  const bar = document.getElementById(`cep-bar-${agentId}`);
  if (!st) return;
  if (status === 'running') { st.textContent = '🔄'; if (bar) requestAnimationFrame(() => { bar.style.width = '85%'; }); }
  else if (status === 'complete') { st.textContent = '✅'; if (bar) bar.style.width = '100%'; }
}

function showValidationSummary(report) {
  document.getElementById('cahaya-vs')?.remove();
  const failed = report.filter(r => !r.passed);
  if (!failed.length) return;
  const el = document.createElement('div');
  el.id = 'cahaya-vs';
  el.style.cssText = 'position:fixed;top:24px;right:24px;z-index:9998;width:400px;max-height:80vh;overflow-y:auto';
  el.innerHTML = `<div style="background:rgba(10,15,28,0.98);border:1px solid ${failed.some(f=>f.severity==='critical')?'rgba(239,68,68,0.5)':'rgba(249,115,22,0.4)'};border-radius:16px;padding:20px;box-shadow:0 20px 60px rgba(0,0,0,0.7);font-family:'Inter',sans-serif;color:rgba(255,255,255,0.9)">
    <div style="font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:14px;padding:10px 14px;border-radius:10px;background:${failed.some(f=>f.severity==='critical')?'rgba(239,68,68,0.15)':'rgba(249,115,22,0.1)'};color:${failed.some(f=>f.severity==='critical')?'#fca5a5':'#fdba74'}">${failed.some(f=>f.severity==='critical')?'🔴 CRITICAL FINDINGS DETECTED':'⚠️ VALIDATION WARNINGS'}</div>
    ${failed.map(f=>`<div style="padding:12px;border-radius:10px;margin-bottom:8px;border-left:3px solid ${f.severity==='critical'?'#ef4444':f.severity==='high'?'#f97316':'#eab308'};background:${f.severity==='critical'?'rgba(239,68,68,0.07)':f.severity==='high'?'rgba(249,115,22,0.07)':'rgba(234,179,8,0.07)'}"><div style="font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:${f.severity==='critical'?'#f87171':f.severity==='high'?'#fb923c':'#facc15'};margin-bottom:6px">${getSeverityIcon(f.severity)} ${f.severity.toUpperCase()}</div><p style="font-size:12px;line-height:1.6;color:rgba(255,255,255,0.8);margin:0 0 6px">${f.message}</p>${f.regulatory_ref?`<span style="font-size:10px;color:rgba(255,255,255,0.3)">📋 ${f.regulatory_ref}</span>`:''}${f.action==='block_report'?`<div style="font-size:11px;color:#fca5a5;background:rgba(239,68,68,0.15);border-radius:6px;padding:6px 10px;margin-top:8px">⛔ Report blocked until resolved</div>`:''}</div>`).join('')}
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px">
      <button onclick="document.getElementById('cahaya-vs').remove()" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:8px;color:rgba(255,255,255,0.6);padding:8px 14px;cursor:pointer;font-size:12px;font-family:inherit">Dismiss</button>
      <button onclick="window.CahayaOrchestrator.chatAboutFinding()" style="background:rgba(99,102,241,0.15);border:1px solid rgba(99,102,241,0.3);border-radius:8px;color:#a5b4fc;padding:8px 14px;cursor:pointer;font-size:12px;font-family:inherit">💬 Discuss with AI</button>
    </div>
  </div>`;
  document.body.appendChild(el);
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC API
// ─────────────────────────────────────────────────────────────────────────────

window.CahayaOrchestrator = {
  intercept(rawPrompt) {
    _state = ORC_STATE.PARSING;
    const intent = parseUserIntent(rawPrompt);
    if (!intent.domain) { console.warn('[ORC] Domain not detected — passing through'); return null; }
    intent.rawPrompt = rawPrompt;
    const plan = buildComputePlan(intent);
    plan.parameters.rawPrompt = rawPrompt;
    _currentPlan = plan;
    _state = ORC_STATE.BRIEFING;

    // Scan prompt for potential uppercase metric IDs of length 3-15 (e.g. SAVI, VM0045, RIPARIAN_BUFFER, etc.)
    const uppercaseWords = rawPrompt.match(/[A-Z_0-9]{3,15}/g) || [];
    const webEnabled = localStorage.getItem('cahaya_web_access') === 'true';

    if (webEnabled && uppercaseWords.length > 0 && window.MethodologyUpdater) {
      uppercaseWords.forEach(word => {
        // Exclude common structural abbreviations
        const excludes = ['UTC', 'GPS', 'OSM', 'FAR', 'DEM', 'KL', 'GCS', 'WGS', 'DoD', 'EPA', 'ARI', 'VCS', 'AGB', 'NBR', 'EIA', 'GHI', 'PDF', 'CSV', 'L2A', 'PNG', 'GHI'];
        if (excludes.includes(word)) return;

        // Check if already in plan's selectedMetrics
        const known = plan.selectedMetrics.some(m => m.id === word);
        const inLib = window.METHODOLOGY_LIBRARY[plan.domain]?.keyIndices?.some(m => m.id === word);

        if (!known && !inLib) {
          plan.learningNotice = plan.learningNotice || [];
          plan.learningNotice.push({ id: word, status: 'searching', name: word });

          console.info(`[ORC] Undetected metric "${word}" found in prompt. Triggering local self-learning...`);
          window.MethodologyUpdater.searchAndLearn(plan.domain, word, rawPrompt)
            .then(learned => {
              if (_currentPlan && _currentPlan.id === plan.id) {
                const cleanLearned = {
                  id: learned.id,
                  name: learned.name,
                  formula: learned.formula,
                  range: learned.range,
                  purpose: learned.purpose,
                  standard: learned.standard,
                  thresholds: learned.thresholds || {},
                  priority: 'primary',
                  status: 'pending',
                  isLearned: true
                };

                const exists = _currentPlan.selectedMetrics.some(m => m.id === learned.id);
                if (!exists) _currentPlan.selectedMetrics.push(cleanLearned);

                const notice = _currentPlan.learningNotice.find(n => n.id === word);
                if (notice) { notice.status = 'success'; notice.name = learned.name; }

                renderPreFlightBrief(_currentPlan);
              }
            })
            .catch(err => {
              console.error(`[ORC] Dynamic learning error for "${word}":`, err);
              if (_currentPlan && _currentPlan.id === plan.id) {
                const notice = _currentPlan.learningNotice.find(n => n.id === word);
                if (notice) { notice.status = 'failed'; notice.error = err.message; }
                renderPreFlightBrief(_currentPlan);
              }
            });
        }
      });
    }

    renderPreFlightBrief(plan);
    return plan;
  },

  async approvePlan() {
    if (!_currentPlan) return;
    if (_briefModalEl) { _briefModalEl.style.opacity = '0'; setTimeout(() => _briefModalEl?.remove(), 300); }
    try { return await executeApprovedPlan(_currentPlan); }
    catch(e) { _state = ORC_STATE.FAILED; console.error('[ORC] Execution failed:', e); }
  },

  refinePlan() {
    const inp = document.getElementById('pfb-refine');
    if (!inp?.value.trim() || !_currentPlan) return;
    const merged = `${_currentPlan.parameters?.rawPrompt || ''} — additionally: ${inp.value.trim()}`;
    inp.value = '';
    window.CahayaOrchestrator.intercept(merged);
  },

  updateParam(key, value) {
    if (!_currentPlan?.parameters[key]) return;
    _currentPlan.parameters[key].value = typeof _currentPlan.parameters[key].value === 'number' ? parseFloat(value) : value;
    _currentPlan.userModified = true;
  },

  dismissBrief() {
    if (_briefModalEl) { _briefModalEl.style.opacity = '0'; setTimeout(() => _briefModalEl?.remove(), 300); }
    _state = ORC_STATE.IDLE;
  },

  exportPlanJSON() {
    if (!_currentPlan) return;
    const blob = new Blob([JSON.stringify(_currentPlan, null, 2)], { type:'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `cahaya_plan_${_currentPlan.id}.json`;
    a.click();
  },

  chatAboutFinding() {
    document.getElementById('cahaya-vs')?.remove();
    const inp = document.getElementById('chat-input') || document.querySelector('.chat-input-field') || document.querySelector('input[type="text"]');
    if (inp) { inp.focus(); inp.value = 'Explain the validation finding and recommend corrective action: '; }
  },

  // Programmatic API for app.js to check if a prompt should be intercepted
  shouldIntercept(rawPrompt) {
    return Object.values(INTENT_PATTERNS).some(p => p.re.test(rawPrompt));
  },

  getCurrentPlan: () => _currentPlan,
  getState: () => _state,
  getValidationResults: () => _validationResults,
};

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
console.log('🎯 CAHAYA Orchestrator v2 — Pre-Flight Brief Engine ready.');

})();
