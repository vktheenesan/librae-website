// LENUDA Premium - 30 FPS Physics & Agent Simulator Engine

// Global engine states
let simCanvas = document.getElementById("sim-canvas");
let simCtx = simCanvas.getContext("2d");
let isSimRunning = false;
let simTime = 0.0;
let simFrameCount = 0;
let simLoopId = null;
let activeScenario = null;
let simAgents = [];
let simParticles = [];
let simGridCells = [];

// 3D Simulated Camera Variables
let simCameraPitch = 0;
let simCameraYaw = 0;
let simCameraZoom = 1.0;

// Video playback states
let isWatchingVideo = false;
let isVideoPlaying = false;
let videoTime = 0.0;
const videoDuration = 30.0; // 30-second forensic recording

// Chart references
let stressChart = null;
let computeChart = null;
let stressChartData = [];
let computeChartData = [];
let chartLabels = [];

// 30 FPS Lock Variables
const targetFPS = 30;
const frameInterval = 1000 / targetFPS;
let then = Date.now();

// 1. Initialize Simulator UI handlers
document.addEventListener("DOMContentLoaded", () => {
  setupSimulatorEvents();
  initCharts();
});

function setupSimulatorEvents() {
  document.getElementById("btn-start-simulation").onclick = startSimulation;
  document.getElementById("btn-stop-simulation").onclick = stopSimulation;

  if (simCanvas) {
    // Scroll to zoom
    simCanvas.addEventListener("wheel", e => {
      e.preventDefault();
      if (e.deltaY < 0) {
        simCameraZoom = Math.min(simCameraZoom + 0.05, 2.5);
      } else {
        simCameraZoom = Math.max(simCameraZoom - 0.05, 0.4);
      }
      if (!isSimRunning) {
        renderSimulationCanvas();
      }
    });

    // Left click + Drag to rotate/pitch camera
    let isDraggingSim = false;
    let lastMouseX = 0;
    let lastMouseY = 0;
    
    simCanvas.addEventListener("mousedown", e => {
      isDraggingSim = true;
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
    });
    
    window.addEventListener("mouseup", () => {
      isDraggingSim = false;
    });
    
    simCanvas.addEventListener("mousemove", e => {
      if (!isDraggingSim) return;
      const dx = e.clientX - lastMouseX;
      const dy = e.clientY - lastMouseY;
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
      
      simCameraYaw += dx * 0.01;
      simCameraPitch = Math.max(0, Math.min(45, simCameraPitch + dy * 0.5));
      
      if (!isSimRunning) {
        renderSimulationCanvas();
      }
    });
  }
}

window.adjustSimCamera = function(action) {
  if (action === 'pitch') {
    simCameraPitch = (simCameraPitch + 15) % 60;
    logConsole(`🎥 Simulator camera pitch adjusted to ${simCameraPitch}°`);
  } else if (action === 'yaw') {
    simCameraYaw = (simCameraYaw + Math.PI / 12) % (Math.PI * 2);
    logConsole(`🎥 Simulator camera yaw rotated to ${Math.round(simCameraYaw * 180 / Math.PI)}°`);
  } else if (action === 'reset') {
    simCameraPitch = 0;
    simCameraYaw = 0;
    simCameraZoom = 1.0;
    logConsole(`🎥 Simulator camera view reset to default.`);
  }
  renderSimulationCanvas();
};

// 2. Start Simulation Loop
function startSimulation() {
  if (isSimRunning) return;
  isSimRunning = true;
  simTime = 0.0;
  simFrameCount = 0;
  
  // Set UI Buttons
  document.getElementById("btn-start-simulation").disabled = true;
  document.getElementById("btn-stop-simulation").disabled = false;
  document.getElementById("sim-instructions-overlay").style.display = "none";
  
  const statusBadge = document.getElementById("sim-status-badge");
  statusBadge.textContent = "SOLVING";
  statusBadge.className = "badge badge-pulse";
  
  logConsole(`Initiated predictive simulation scenario: ${activeScenario.name}`);
  
  // Reset simulation datasets
  spawnAgentsAndAssets();
  resetChartData();
  
  then = Date.now();
  tickSim();
}

function stopSimulation() {
  if (!isSimRunning) return;
  isSimRunning = false;
  cancelAnimationFrame(simLoopId);
  
  document.getElementById("btn-start-simulation").disabled = false;
  document.getElementById("btn-stop-simulation").disabled = true;
  document.getElementById("sim-instructions-overlay").style.display = "flex";
  
  const statusBadge = document.getElementById("sim-status-badge");
  statusBadge.textContent = "STANDBY";
  statusBadge.className = "badge";
  
  const physStatus = document.getElementById("physics-status");
  if (physStatus) {
    physStatus.textContent = "READY";
    physStatus.style.color = "#a2e8dd";
  }
  
  // Clean up video indicators
  isWatchingVideo = false;
  isVideoPlaying = false;
  const videoTimeline = document.getElementById("sim-video-timeline-container");
  const forensicBadge = document.getElementById("forensic-recording-badge");
  if (videoTimeline) videoTimeline.style.display = "none";
  if (forensicBadge) forensicBadge.style.display = "none";
  
  logConsole(`Halted active simulation runner.`);
}

// 3. Locked 30 FPS Main Tick
function tickSim() {
  if (!isSimRunning) return;
  simLoopId = requestAnimationFrame(tickSim);
  
  const now = Date.now();
  const elapsed = now - then;
  
  if (elapsed >= frameInterval) {
    then = now - (elapsed % frameInterval);
    
    // Update logic
    if (!isWatchingVideo || isVideoPlaying) {
      updateSimulationState();
    }
    
    // Render Canvas
    renderSimulationCanvas();
    
    // Periodically update Charts (every 10 frames = ~0.33 sec)
    if (simFrameCount % 10 === 0 && (!isWatchingVideo || isVideoPlaying)) {
      updateLiveCharts();
    }
  }
}

// 4. Set active scenario config
window.resetSimulation = function(scen) {
  activeScenario = scen;
  if (isSimRunning) {
    stopSimulation();
  }
  
  // Clear canvas
  simCanvas.width = simCanvas.parentNode.clientWidth;
  simCanvas.height = simCanvas.parentNode.clientHeight;
  simCtx.fillStyle = "#020306";
  simCtx.fillRect(0, 0, simCanvas.width, simCanvas.height);
};

window.updateSimParam = function(vIdx, val) {
  if (activeScenario && activeScenario.variables[vIdx]) {
    activeScenario.variables[vIdx].val = val;
    logConsole(`Adjusted parameters: ${activeScenario.variables[vIdx].name} -> ${val}`);
  }
};

// 5. Physics & Agent Logic Updates
function spawnAgentsAndAssets() {
  simAgents = [];
  simParticles = [];
  simGridCells = [];
  
  const w = simCanvas.width;
  const h = simCanvas.height;
  
  // Spawn variables
  let agentCount = 0;
  if (activeScenario.name.includes("Evacuation") || activeScenario.name.includes("Pedestrian") || activeScenario.name.includes("Triage") || activeScenario.name.includes("Exit")) {
    agentCount = activeScenario.variables[0] ? Math.min(Math.floor(activeScenario.variables[0].val / 15), 180) : 80;
  } else {
    agentCount = Math.floor(Math.random() * 20) + 10;
  }
  
  // Spawn Agents (evacuees, vehicles, trees, grid assets)
  for (let i = 0; i < agentCount; i++) {
    simAgents.push({
      x: Math.random() * (w - 60) + 30,
      y: Math.random() * (h - 60) + 30,
      vx: (Math.random() - 0.5) * 2.5,
      vy: (Math.random() - 0.5) * 2.5,
      radius: Math.random() * 3 + 2,
      health: 100,
      type: activeScenario.name.includes("Evacuation") ? "civilian" : "particle",
      state: "normal"
    });
  }
  
  // Set up environmental grids
  for (let x = 0; x < w; x += 30) {
    for (let y = 0; y < h; y += 30) {
      simGridCells.push({
        x: x, y: y, size: 30,
        val: Math.random() * 0.3,
        glow: 0
      });
    }
  }
  
  document.getElementById("sim-agent-counter").textContent = `Total Agents: ${simAgents.length} NPCs`;
}

function updateSimulationState() {
  simTime += 0.033; // 30 FPS = ~33ms per frame
  simFrameCount++;
  
  if (simFrameCount % 15 === 0) {
    updatePhysicsTelemetryLogs();
  }
  
  if (isWatchingVideo) {
    videoTime += 0.033;
    if (videoTime >= videoDuration) {
      videoTime = 0.0;
      simTime = 0.0;
      spawnAgentsAndAssets();
    }
    
    // Update timeline slider
    const slider = document.getElementById("sim-video-timeline");
    if (slider) {
      slider.value = (videoTime / videoDuration) * 100;
    }
    const timeDisp = document.getElementById("sim-video-time-display");
    if (timeDisp) {
      timeDisp.textContent = `${formatVideoTime(videoTime)} / ${formatVideoTime(videoDuration)}`;
    }
    
    // Orbit camera yaw/pitch automatically
    simCameraYaw += 0.003;
    simCameraPitch = 15 + Math.sin(simTime * 0.5) * 8;
  }
  
  const timerDisplay = document.getElementById("sim-timer-display");
  if (timerDisplay) {
    timerDisplay.textContent = `Sim Duration: ${simTime.toFixed(1)}s`;
  }
  
  const w = simCanvas.width;
  const h = simCanvas.height;
  
  // Update agents position
  simAgents.forEach(agent => {
    agent.x += agent.vx;
    agent.y += agent.vy;
    
    // Boundary bounce
    if (agent.x < 10 || agent.x > w - 10) agent.vx *= -1;
    if (agent.y < 10 || agent.y > h - 10) agent.vy *= -1;
    
    // Custom logic per scenario
    if (activeScenario.name.includes("Evacuation") || activeScenario.name.includes("Exit")) {
      // Evacuate towards safety center (e.g. coordinate w/2, h/2)
      let dx = w/2 - agent.x;
      let dy = h/2 - agent.y;
      let dist = Math.sqrt(dx*dx + dy*dy);
      if (dist > 30) {
        agent.vx = (dx / dist) * 1.8 + (Math.random() - 0.5) * 0.5;
        agent.vy = (dy / dist) * 1.8 + (Math.random() - 0.5) * 0.5;
      } else {
        agent.state = "safe";
        agent.vx = 0;
        agent.vy = 0;
      }
    }
  });
  
  // Update particles (smoke, chemical dispersion, fire spread)
  if (simFrameCount % 2 === 0) {
    if (activeScenario.name.includes("Fire") || activeScenario.name.includes("Smoke") || activeScenario.name.includes("Gas") || activeScenario.name.includes("Plume")) {
      // Spawn particles from center bottom
      simParticles.push({
        x: w / 2 + (Math.random() - 0.5) * 40,
        y: h - 20,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -Math.random() * 2.5 - 1.0,
        size: Math.random() * 8 + 4,
        alpha: 0.8,
        life: 1.0 // 100% life
      });
    }
  }
  
  // Age and move particles
  simParticles.forEach((part, idx) => {
    part.x += part.vx;
    part.y += part.vy;
    part.life -= 0.015;
    part.size += 0.2;
    if (part.life <= 0) {
      simParticles.splice(idx, 1);
    }
  });
  
  // Trigger billing updates in Bayu on major checkpoints
  if (simFrameCount % 90 === 0 && window.bayuLogTransaction) {
    window.bayuLogTransaction({
      action: `Predictive Solver Run: ${activeScenario.name}`,
      satellites: domainsData[activeDomainIndex].satellites.length,
      agents: simAgents.length,
      volume: 0.45
    });
  }
}

// 6. Draw Simulation Visual Canvas (Layer 3)
function renderSimulationCanvas() {
  const w = simCanvas.width;
  const h = simCanvas.height;
  
  // Clear with dark transparent black for motion blur trail effect
  simCtx.fillStyle = "rgba(2, 3, 6, 0.25)";
  simCtx.fillRect(0, 0, w, h);
  
  const themeColor = getComputedStyle(document.body).getPropertyValue("--accent-color").trim();
  
  // Apply 3D simulated camera translation and rotations
  simCtx.save();
  simCtx.translate(w/2, h/2);
  simCtx.scale(simCameraZoom, simCameraZoom);
  simCtx.rotate(simCameraYaw);
  
  const pitchRad = (simCameraPitch * Math.PI) / 180;
  const pitchScale = Math.cos(pitchRad);
  simCtx.scale(1.0, pitchScale);
  simCtx.translate(-w/2, -h/2);

  // Draw nice grid lines background
  simCtx.strokeStyle = "rgba(255, 255, 255, 0.015)";
  simCtx.lineWidth = 1;
  const grid = 20;
  for (let x = 0; x < w; x += grid) {
    simCtx.beginPath(); simCtx.moveTo(x, 0); simCtx.lineTo(x, h); simCtx.stroke();
  }
  for (let y = 0; y < h; y += grid) {
    simCtx.beginPath(); simCtx.moveTo(0, y); simCtx.lineTo(w, y); simCtx.stroke();
  }
  
  // Scenario-specific environment graphics
  if (activeScenario.name.includes("Flash Flood") || activeScenario.name.includes("Tsunami") || activeScenario.name.includes("Aquifer")) {
    // Draw rising water wave mesh
    let waveHeight = Math.sin(simTime * 2.5) * 15 + (simTime * 4);
    if (waveHeight > h - 50) waveHeight = h - 50;
    
    simCtx.fillStyle = "rgba(0, 180, 216, 0.15)";
    simCtx.strokeStyle = "#00b4d8";
    simCtx.lineWidth = 1.5;
    simCtx.beginPath();
    simCtx.moveTo(0, h);
    for (let x = 0; x <= w; x += 10) {
      let y = h - waveHeight + Math.cos(x*0.02 + simTime*4.0) * 10;
      simCtx.lineTo(x, y);
    }
    simCtx.lineTo(w, h);
    simCtx.fill();
    simCtx.stroke();
  }
  
  if (activeScenario.name.includes("Earthquake") || activeScenario.name.includes("Collapse") || activeScenario.name.includes("Wall Failure")) {
    // Draw geological fault lines cracking
    simCtx.strokeStyle = "#e63946";
    simCtx.lineWidth = 2;
    simCtx.beginPath();
    simCtx.moveTo(50, 80);
    // Introduce jitter shaking
    let shake = Math.sin(simTime * 30.0) * (activeScenario.variables[0].val * 0.4);
    simCtx.lineTo(w/3 + shake, h/3 + shake);
    simCtx.lineTo(w/2 + shake, h/2 + shake);
    simCtx.lineTo(w*0.8 + shake, h*0.7 + shake);
    simCtx.stroke();
  }
  
  // Draw particles (smoke, fire, gas)
  simParticles.forEach(part => {
    simCtx.fillStyle = `rgba(${activeScenario.name.includes("Fire") ? '230, 57, 70' : '139, 148, 158'}, ${part.life * 0.4})`;
    simCtx.beginPath();
    simCtx.arc(part.x, part.y, part.size, 0, Math.PI * 2);
    simCtx.fill();
  });
  
  // Draw Agents / NPCs
  simAgents.forEach(agent => {
    simCtx.beginPath();
    simCtx.arc(agent.x, agent.y, agent.radius, 0, Math.PI * 2);
    
    if (agent.state === "safe") {
      simCtx.fillStyle = "#70e000";
      simCtx.shadowColor = "#70e000";
      simCtx.shadowBlur = 4;
    } else {
      simCtx.fillStyle = themeColor;
      simCtx.shadowColor = themeColor;
      simCtx.shadowBlur = 3;
    }
    simCtx.fill();
    simCtx.shadowBlur = 0; // Reset
    
    // Draw velocity vector lines
    simCtx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    simCtx.lineWidth = 1;
    simCtx.beginPath();
    simCtx.moveTo(agent.x, agent.y);
    simCtx.lineTo(agent.x + agent.vx * 3, agent.y + agent.vy * 3);
    simCtx.stroke();
  });
  
  // Draw safety target boundaries for evacuation centers
  if (activeScenario.name.includes("Evacuation") || activeScenario.name.includes("Exit")) {
    simCtx.strokeStyle = "#70e000";
    simCtx.lineWidth = 1.5;
    simCtx.fillStyle = "rgba(112, 224, 0, 0.03)";
    simCtx.beginPath();
    simCtx.arc(w/2, h/2, 35, 0, Math.PI * 2);
    simCtx.stroke();
    simCtx.fill();
    
    simCtx.fillStyle = "#70e000";
    simCtx.font = "8px JetBrains Mono";
    simCtx.fillText("REFUGE SECTOR", w/2 - 32, h/2 + 3);
  }

  // Draw radar / scanner features if in watching video mode
  if (isWatchingVideo) {
    // Draw green scan boxes around each active agent
    simCtx.strokeStyle = "rgba(0, 255, 102, 0.6)";
    simCtx.lineWidth = 1;
    simAgents.forEach((agent, index) => {
      if (agent.state !== "safe") {
        const size = agent.radius + 5;
        // Draw brackets
        simCtx.beginPath();
        // Top Left
        simCtx.moveTo(agent.x - size, agent.y - size/2);
        simCtx.lineTo(agent.x - size, agent.y - size);
        simCtx.lineTo(agent.x - size/2, agent.y - size);
        // Top Right
        simCtx.moveTo(agent.x + size/2, agent.y - size);
        simCtx.lineTo(agent.x + size, agent.y - size);
        simCtx.lineTo(agent.x + size, agent.y - size/2);
        // Bottom Left
        simCtx.moveTo(agent.x - size, agent.y + size/2);
        simCtx.lineTo(agent.x - size, agent.y + size);
        simCtx.lineTo(agent.x - size/2, agent.y + size);
        // Bottom Right
        simCtx.moveTo(agent.x + size/2, agent.y + size);
        simCtx.lineTo(agent.x + size, agent.y + size);
        simCtx.lineTo(agent.x + size, agent.y + size/2);
        simCtx.stroke();

        // Label
        if (index % 5 === 0) {
          simCtx.fillStyle = "#00ff66";
          simCtx.font = "6px JetBrains Mono, monospace";
          simCtx.fillText(`NPC_${index}`, agent.x + size + 2, agent.y + 2);
        }
      }
    });

    // Draw vertical scanning laser sweep
    let sweepX = (simTime * 120) % w;
    simCtx.strokeStyle = "rgba(0, 255, 102, 0.35)";
    simCtx.lineWidth = 1.5;
    
    // Add subtle glow
    simCtx.shadowColor = "#00ff66";
    simCtx.shadowBlur = 6;
    simCtx.beginPath();
    simCtx.moveTo(sweepX, 0);
    simCtx.lineTo(sweepX, h);
    simCtx.stroke();
    simCtx.shadowBlur = 0; // reset
  }

  // Restore drawing context
  simCtx.restore();
}

// 7. Dynamic Performance Charts (Chart.js)
function initCharts() {
  const ctxStress = document.getElementById("stress-chart").getContext("2d");
  const ctxCompute = document.getElementById("compute-chart").getContext("2d");
  
  // Standard labels for scrolling x-axis
  chartLabels = Array.from({length: 12}, (_, i) => `${i*3}s`);
  stressChartData = Array(12).fill(0);
  computeChartData = Array(12).fill(10);
  
  // Tailored line styling helper
  stressChart = new Chart(ctxStress, {
    type: 'line',
    data: {
      labels: chartLabels,
      datasets: [{
        label: 'Stress Indicator (%)',
        data: stressChartData,
        borderColor: '#e63946',
        backgroundColor: 'rgba(230, 57, 70, 0.06)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255, 255, 255, 0.02)' }, ticks: { color: '#57606a', font: { size: 9 } } },
        y: { min: 0, max: 100, grid: { color: 'rgba(255, 255, 255, 0.02)' }, ticks: { color: '#57606a', font: { size: 9 } } }
      }
    }
  });
  
  computeChart = new Chart(ctxCompute, {
    type: 'line',
    data: {
      labels: chartLabels,
      datasets: [{
        label: 'Compute Allocation',
        data: computeChartData,
        borderColor: '#ffd166',
        backgroundColor: 'rgba(255, 183, 3, 0.06)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255, 255, 255, 0.02)' }, ticks: { color: '#57606a', font: { size: 9 } } },
        y: { min: 0, max: 100, grid: { color: 'rgba(255, 255, 255, 0.02)' }, ticks: { color: '#57606a', font: { size: 9 } } }
      }
    }
  });
}

function resetChartData() {
  stressChartData = Array(12).fill(0);
  computeChartData = Array(12).fill(25);
  stressChart.data.datasets[0].data = stressChartData;
  computeChart.data.datasets[0].data = computeChartData;
  stressChart.update();
  computeChart.update();
}

function updateLiveCharts() {
  if (!isSimRunning) return;
  
  // Calculate stress based on scenario characteristics
  let stress = 0;
  if (activeScenario.name.includes("Drought") || activeScenario.name.includes("Depletion") || activeScenario.name.includes("Aquifer")) {
    // Rise in depletion
    stress = Math.min(15 + simTime * 3.5, 95);
  } else if (activeScenario.name.includes("Evacuation") || activeScenario.name.includes("Exit")) {
    // Evacuation completion curve: drops down to zero stress as people exit
    let remaining = simAgents.filter(a => a.state !== "safe").length;
    stress = (remaining / simAgents.length) * 100;
  } else if (activeScenario.name.includes("Earthquake") || activeScenario.name.includes("Strike") || activeScenario.name.includes("Shock")) {
    // Heavy spikes
    stress = 30 + Math.sin(simTime * 2) * 10 + (Math.random() - 0.5) * 5;
  } else {
    stress = 10 + Math.cos(simTime) * 8 + 5;
  }
  
  // Compute cores load percentage
  let compute = 30 + Math.sin(simTime * 1.5) * 8 + (simAgents.length * 0.2);
  if (compute > 98) compute = 98;
  
  // Push values and slide arrays
  stressChartData.push(stress);
  stressChartData.shift();
  
  computeChartData.push(compute);
  computeChartData.shift();
  
  // Update Charts
  stressChart.data.datasets[0].data = stressChartData;
  
  // Style according to body theme accent color
  const themeColor = getComputedStyle(document.body).getPropertyValue("--accent-color").trim();
  computeChart.data.datasets[0].borderColor = themeColor;
  computeChart.data.datasets[0].backgroundColor = `${themeColor}11`;
  computeChart.data.datasets[0].data = computeChartData;
  
  stressChart.update('none'); // Update without animation transitions to save CPU
  computeChart.update('none');
}

// --- 3D FORENSIC VIDEO PLAYBACK CONTROLLER ---
window.watchForensicVideo = function() {
  // If no scenario is active, choose the first one
  if (!activeScenario) {
    const defaultScen = {
      name: "Emergency Evacuation Simulation",
      variables: [
        { name: "NPC Density", val: 120 },
        { name: "Evacuation Exit Width", val: 15 },
        { name: "Panic Factor Coefficient", val: 35 }
      ]
    };
    activeScenario = defaultScen;
  }

  isWatchingVideo = true;
  isVideoPlaying = true;
  videoTime = 0.0;
  simTime = 0.0;
  
  // Set UI elements
  const instructions = document.getElementById("sim-instructions-overlay");
  if (instructions) instructions.style.display = "none";
  
  const videoTimeline = document.getElementById("sim-video-timeline-container");
  if (videoTimeline) videoTimeline.style.display = "flex";
  
  const forensicBadge = document.getElementById("forensic-recording-badge");
  if (forensicBadge) forensicBadge.style.display = "flex";
  
  const statusBadge = document.getElementById("sim-status-badge");
  if (statusBadge) {
    statusBadge.textContent = "PLAYBACK";
    statusBadge.className = "badge badge-pulse";
  }
  
  const startBtn = document.getElementById("btn-start-simulation");
  const stopBtn = document.getElementById("btn-stop-simulation");
  if (startBtn) startBtn.disabled = true;
  if (stopBtn) stopBtn.disabled = false;
  
  // Reset simulation and start
  isSimRunning = true;
  spawnAgentsAndAssets();
  resetChartData();
  
  // Set play/pause icon to pause
  const icon = document.getElementById("video-play-pause-icon");
  if (icon) icon.setAttribute("data-lucide", "pause");
  if (window.lucide) window.lucide.createIcons();
  
  then = Date.now();
  tickSim();
  logConsole("🎥 Initiated hyper-realistic 3D Forensic Video Report.");
};

window.toggleVideoPlayback = function() {
  isVideoPlaying = !isVideoPlaying;
  const icon = document.getElementById("video-play-pause-icon");
  if (icon) {
    icon.setAttribute("data-lucide", isVideoPlaying ? "pause" : "play");
    if (window.lucide) window.lucide.createIcons();
  }
  logConsole(isVideoPlaying ? "▶️ Video playback resumed." : "⏸️ Video playback paused.");
};

function formatVideoTime(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

function updateSimulationStateQuiet() {
  const w = simCanvas.width;
  const h = simCanvas.height;
  
  simAgents.forEach(agent => {
    agent.x += agent.vx;
    agent.y += agent.vy;
    
    if (agent.x < 10 || agent.x > w - 10) agent.vx *= -1;
    if (agent.y < 10 || agent.y > h - 10) agent.vy *= -1;
    
    if (activeScenario && activeScenario.name && (activeScenario.name.includes("Evacuation") || activeScenario.name.includes("Exit"))) {
      let dx = w/2 - agent.x;
      let dy = h/2 - agent.y;
      let dist = Math.sqrt(dx*dx + dy*dy);
      if (dist > 30) {
        agent.vx = (dx / dist) * 1.8 + (Math.random() - 0.5) * 0.5;
        agent.vy = (dy / dist) * 1.8 + (Math.random() - 0.5) * 0.5;
      } else {
        agent.state = "safe";
        agent.vx = 0;
        agent.vy = 0;
      }
    }
  });
  
  simParticles.forEach((part, idx) => {
    part.x += part.vx;
    part.y += part.vy;
    part.life -= 0.015;
    part.size += 0.2;
    if (part.life <= 0) {
      simParticles.splice(idx, 1);
    }
  });
}

window.scrubVideoToTime = function(targetTime) {
  videoTime = targetTime;
  simTime = targetTime;
  
  // Repopulate and fast-forward
  spawnAgentsAndAssets();
  
  const frames = Math.floor(targetTime / 0.033);
  for (let i = 0; i < frames; i++) {
    updateSimulationStateQuiet();
  }
  
  const timeDisp = document.getElementById("sim-video-time-display");
  if (timeDisp) {
    timeDisp.textContent = `${formatVideoTime(videoTime)} / ${formatVideoTime(videoDuration)}`;
  }
  
  renderSimulationCanvas();
};

// Bind range slider event
document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("sim-video-timeline");
  if (slider) {
    slider.addEventListener("input", (e) => {
      if (isWatchingVideo) {
        const targetPct = parseFloat(e.target.value);
        const targetTime = (targetPct / 100) * videoDuration;
        scrubVideoToTime(targetTime);
      }
    });
  }
});

function updatePhysicsTelemetryLogs() {
  const logContainer = document.getElementById("physics-telemetry-logs");
  if (!logContainer) return;
  
  const statusBadge = document.getElementById("physics-status");
  if (statusBadge) {
    statusBadge.textContent = "SOLVING";
    statusBadge.style.color = "#00f0ff";
  }
  
  const name = activeScenario ? activeScenario.name : "";
  let formula = "";
  let detail = "";
  
  if (name.includes("Evacuation") || name.includes("Exit") || name.includes("Triage") || name.includes("Pedestrian")) {
    const formulas = [
      "F_social = m * dV/dt + f_ij + f_w",
      "w_i = A_i * exp((r_ij - d_ij)/B_i) * n_ij",
      "g_i(t) = argmin ||x_i(t) - x_goal||_2",
      "Path solved via A* heuristic: h(n) = |x - x_goal| + |y - y_goal|",
      "Agent boundary contact force: f_c = k * g(r_ij - d_ij) * n_ij"
    ];
    formula = formulas[Math.floor(Math.random() * formulas.length)];
    detail = `[Evacuation Solver] Active NPCs: ${simAgents.length} | Target Exit: Center Area | Safe corridor threshold: ${(Math.random()*5+90).toFixed(1)}%`;
  } else if (name.includes("Flash Flood") || name.includes("Tsunami") || name.includes("Aquifer") || name.includes("Water")) {
    const formulas = [
      "dh/dt + d(uh)/dx + d(vh)/dy = R - I",
      "du/dt + u*du/dx + v*du/dy = -g*dh/dx - g*n^2*u*sqrt(u^2+v^2)/h^(4/3)",
      "Navier-Stokes: du/dt + (u.grad)u = -1/rho*grad(p) + nu*del^2(u)",
      "Manning coefficient n = 0.035 (Rough channels friction)",
      "Darcy-Weisbach flow: h_f = f * (L/D) * (v^2 / 2g)"
    ];
    formula = formulas[Math.floor(Math.random() * formulas.length)];
    detail = `[Hydrodynamics] Fluid grid size: 120x120 | Water Height Peak: ${(Math.random()*2+1.5).toFixed(2)}m | Flow rate: ${(Math.random()*1.5+1.0).toFixed(2)}m/s`;
  } else if (name.includes("Fire") || name.includes("Smoke") || name.includes("Gas") || name.includes("Plume")) {
    const formulas = [
      "dC/dt + u*dC/dx + v*dC/dy = D*(d^2C/dx^2 + d^2C/dy^2) + S",
      "F_buoyancy = g * (1 - T_ambient / T_plume) * k",
      "Gaussian plume dispersion: C(x,y,z) = (Q / (2*pi*u*sigma_y*sigma_z)) * exp(-y^2/(2*sigma_y^2))",
      "Froude number: Fr = U / sqrt(g * L * Delta_T / T)",
      "Eddy diffusivity: D_e = 0.1 * l_m * sqrt(k_turb)"
    ];
    formula = formulas[Math.floor(Math.random() * formulas.length)];
    detail = `[Plume Solver] Turbulence model active | Dispersion vector: [${(Math.random()*2-1).toFixed(2)}, ${(Math.random()*1.5-3).toFixed(2)}] | Active WASM particles: ${simParticles.length}`;
  } else if (name.includes("Earthquake") || name.includes("Collapse") || name.includes("Wall Failure") || name.includes("Structural")) {
    const formulas = [
      "M*d^2x/dt^2 + C*dx/dt + K*x = F_seismic(t)",
      "Stress tensor: sigma_ij = lambda * delta_ij * epsilon_kk + 2 * mu * epsilon_ij",
      "Shear wall load capacity: V_n = A_cv * (alpha_c * sqrt(f'_c) + rho_t * f_y)",
      "Rayleigh damping matrix: C = alpha * M + beta * K",
      "Peak ground acceleration: PGA = ${(Math.random()*0.15+0.1).toFixed(3)}g (Rayleigh frequencies)"
    ];
    formula = formulas[Math.floor(Math.random() * formulas.length)];
    detail = `[FEA Structural] Grid elements: 840 nodes | Deformation: ${(Math.random()*4+2).toFixed(1)}mm | Shear capacity ratio: ${(Math.random()*0.2+0.8).toFixed(2)}`;
  } else {
    const formulas = [
      "NDVI = (NIR - RED) / (NIR + RED) = ${(Math.random()*0.1+0.72).toFixed(3)}",
      "GeoArrow coordinate transform: [x_utm, y_utm] = Proj4(WGS84, UTM47N)",
      "Savitzky-Golay filtering: Y_j = sum(c_i * y_j+i) / N",
      "Local WebGPU inference: ONNX model weights quantized to 4-bit (turbovec)",
      "SHA-256 Merkle Leaf: Hash = h(action_index | timestamp)"
    ];
    formula = formulas[Math.floor(Math.random() * formulas.length)];
    detail = `[GIS Engine] Reprojecting nodes... | Coordinate system: UTM Zone 47N | WebGPU engine status: ACTIVE`;
  }
  
  const logDiv = document.createElement("div");
  logDiv.style.marginBottom = "4px";
  
  logDiv.innerHTML = `
    <span style="color: rgba(255,255,255,0.4)">[${new Date().toLocaleTimeString()}]</span>
    <span style="color: #ffb703; font-weight:700;">math_solve:</span>
    <code style="color: #00f0ff;">${formula}</code><br>
    <span style="color: rgba(255,255,255,0.7); padding-left: 12px;">↳ ${detail}</span>
  `;
  
  logContainer.appendChild(logDiv);
  
  while (logContainer.children.length > 50) {
    logContainer.removeChild(logContainer.firstChild);
  }
  
  logContainer.scrollTop = logContainer.scrollHeight;
}
