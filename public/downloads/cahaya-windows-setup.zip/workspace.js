/**
 * CAHAYA SOVEREIGN — WORKSPACE SHELL (workspace.js)
 * Librae AI Labs © 2025
 *
 * Builds the 3-panel workspace layout:
 *   LEFT  — Conversation history + active chat (Claude-style sidebar)
 *   CENTER — Existing canvas (GEE / Ingest / Sim tabs)
 *   RIGHT  — Collapsible settings/files/library/connections panel
 *
 * Runs AFTER gateway.js has confirmed activation.
 * Moves existing app-container content into the new shell.
 */

(function () {
  'use strict';

  let _activeConvId = null;
  let _domain = localStorage.getItem('cahaya_domain') || 'agriculture';
  let _searchDebounce = null;

  const DOMAIN_META = {
    agriculture:      { label: 'Agriculture / ESG',     color: '#22c55e', icon: '🌾' },
    mining:           { label: 'Mining & Resources',     color: '#f59e0b', icon: '⛏️' },
    urban:            { label: 'Urban Planning',         color: '#3b82f6', icon: '🏙️' },
    defense:          { label: 'Defense & Security',     color: '#8b5cf6', icon: '🛡️' },
    maritime:         { label: 'Maritime & Coastal',     color: '#06b6d4', icon: '🚢' },
    environmental:    { label: 'Environmental',          color: '#10b981', icon: '🌊' },
    energy:           { label: 'Energy & Renewables',    color: '#f97316', icon: '⚡' },
    infrastructure:   { label: 'Infrastructure',         color: '#64748b', icon: '🏗️' },
    forestry:         { label: 'Forestry & Carbon',      color: '#16a34a', icon: '🌳' },
    emergency:        { label: 'Emergency Response',     color: '#ef4444', icon: '🚨' },
  };

  /* ─── WORKSPACE STYLES ───────────────────────────────────────────────────── */
  const WS_STYLES = `
    /* ─── WORKSPACE SHELL ─── */
    #cahaya-workspace {
      display: flex; flex-direction: column;
      height: 100vh; width: 100vw;
      overflow: hidden;
      font-family: 'Inter', system-ui, sans-serif;
      background: #060a14;
      color: rgba(255,255,255,0.9);
    }

    /* ─── WORKSPACE HEADER ─── */
    #ws-header {
      display: flex; align-items: center; gap: 12px;
      height: 52px; min-height: 52px;
      padding: 0 16px;
      background: rgba(10,15,28,0.96);
      border-bottom: 1px solid rgba(255,255,255,0.07);
      z-index: 100; flex-shrink: 0;
      backdrop-filter: blur(20px);
    }
    #ws-logo {
      display: flex; align-items: center; gap: 10px;
      font-family: 'Outfit', sans-serif;
      font-size: 15px; font-weight: 800;
      letter-spacing: 0.5px;
      color: white; flex-shrink: 0;
      text-decoration: none;
    }
    #ws-logo .ws-logo-badge {
      font-size: 9px; background: #e63946; color: white;
      padding: 2px 6px; border-radius: 4px; font-weight: 700;
      letter-spacing: 1px; text-transform: uppercase;
    }
    #ws-domain-chip {
      display: flex; align-items: center; gap: 7px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.09);
      border-radius: 8px; padding: 5px 12px;
      font-size: 12px; font-weight: 600;
      color: rgba(255,255,255,0.7); flex-shrink: 0;
    }
    #ws-domain-chip .ws-domain-dot {
      width: 7px; height: 7px; border-radius: 50%;
      animation: ws-pulse 2s infinite;
    }
    @keyframes ws-pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }

    /* Telemetry pills */
    #ws-telemetry {
      display: flex; align-items: center; gap: 8px;
      flex: 1; justify-content: center;
      overflow: hidden;
    }
    .ws-tel-item {
      display: flex; align-items: center; gap: 6px;
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.06);
      border-radius: 7px; padding: 4px 10px;
      font-size: 10px; white-space: nowrap;
    }
    .ws-tel-label { color: rgba(255,255,255,0.3); text-transform: uppercase; letter-spacing: 0.5px; }
    .ws-tel-val { color: rgba(255,255,255,0.75); font-family: 'JetBrains Mono', monospace; font-weight: 600; }
    .ws-tel-val.green { color: #4ade80; }
    .ws-tel-val.blue  { color: #60a5fa; }

    /* Header actions */
    #ws-actions { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
    .ws-header-btn {
      display: flex; align-items: center; gap: 6px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.09);
      border-radius: 8px; padding: 6px 12px;
      color: rgba(255,255,255,0.6); font-size: 12px;
      cursor: pointer; font-family: inherit; transition: 0.2s;
      white-space: nowrap;
    }
    .ws-header-btn:hover { background: rgba(255,255,255,0.1); color: white; }
    .ws-header-btn.ws-btn-primary {
      background: linear-gradient(135deg, rgba(99,102,241,0.4), rgba(139,92,246,0.3));
      border-color: rgba(99,102,241,0.4); color: #c7d2fe;
    }
    .ws-header-btn.ws-btn-primary:hover { background: linear-gradient(135deg, rgba(99,102,241,0.6), rgba(139,92,246,0.5)); color: white; }
    #ws-web-toggle-btn.active { background: rgba(16,185,129,0.15); border-color: rgba(16,185,129,0.3); color: #6ee7b7; }

    /* ─── BODY: 3 PANELS ─── */
    #ws-body {
      display: flex; flex: 1; overflow: hidden;
    }

    /* ─── LEFT SIDEBAR ─── */
    #ws-left {
      display: flex; flex-direction: column;
      width: 280px; min-width: 200px; max-width: 380px;
      background: rgba(8,12,22,0.97);
      border-right: 1px solid rgba(255,255,255,0.06);
      overflow: hidden; flex-shrink: 0;
      position: relative;
    }

    /* Sidebar top bar */
    #ws-sidebar-top {
      padding: 10px 12px 6px;
      border-bottom: 1px solid rgba(255,255,255,0.05);
      flex-shrink: 0;
    }
    #ws-new-conv-btn {
      width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px;
      background: rgba(99,102,241,0.12); border: 1px solid rgba(99,102,241,0.25);
      border-radius: 10px; padding: 8px 14px; color: #a5b4fc;
      font-size: 12px; font-weight: 600; cursor: pointer; font-family: inherit;
      transition: 0.2s; margin-bottom: 8px;
    }
    #ws-new-conv-btn:hover { background: rgba(99,102,241,0.22); border-color: rgba(99,102,241,0.4); color: white; }
    #ws-conv-search {
      width: 100%; box-sizing: border-box;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 8px; padding: 7px 12px;
      color: rgba(255,255,255,0.8); font-size: 12px;
      font-family: inherit; outline: none;
      transition: 0.2s;
    }
    #ws-conv-search:focus { border-color: rgba(99,102,241,0.4); background: rgba(99,102,241,0.06); }
    #ws-conv-search::placeholder { color: rgba(255,255,255,0.2); }

    /* Conversation list */
    #ws-conv-list {
      flex: 0 0 auto;
      max-height: 38%;
      overflow-y: auto;
      padding: 6px 8px;
    }
    #ws-conv-list::-webkit-scrollbar { width: 3px; }
    #ws-conv-list::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 2px; }

    .ws-conv-group-label {
      font-size: 9px; font-weight: 700; letter-spacing: 1.5px;
      text-transform: uppercase; color: rgba(255,255,255,0.2);
      padding: 10px 6px 4px; display: block;
    }
    .ws-conv-item {
      display: flex; align-items: center;
      padding: 8px 10px; border-radius: 10px;
      cursor: pointer; transition: background 0.15s;
      gap: 8px; margin-bottom: 2px;
      border-left: 3px solid transparent;
    }
    .ws-conv-item:hover { background: rgba(255,255,255,0.05); }
    .ws-conv-item.active {
      background: rgba(99,102,241,0.13);
      border-left-color: #6366f1;
    }
    .ws-conv-item.pinned .ws-conv-title::before { content: '📌 '; font-size: 10px; }
    .ws-conv-icon { font-size: 14px; flex-shrink: 0; }
    .ws-conv-info { flex: 1; min-width: 0; }
    .ws-conv-title { font-size: 12px; font-weight: 500; color: rgba(255,255,255,0.75); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }
    .ws-conv-time  { font-size: 10px; color: rgba(255,255,255,0.25); display: block; margin-top: 1px; }
    .ws-conv-menu  { opacity: 0; font-size: 14px; color: rgba(255,255,255,0.3); background: none; border: none; cursor: pointer; padding: 2px 4px; border-radius: 4px; transition: 0.15s; flex-shrink: 0; }
    .ws-conv-item:hover .ws-conv-menu { opacity: 1; }
    .ws-conv-menu:hover { background: rgba(255,255,255,0.1); color: white; }

    /* ─── CHAT DIVIDER ─── */
    #ws-chat-divider {
      height: 1px; background: rgba(255,255,255,0.05);
      margin: 0; flex-shrink: 0;
      position: relative; display: flex; align-items: center; justify-content: center;
    }
    #ws-chat-divider::after {
      content: 'ACTIVE CONVERSATION'; font-size: 8px; letter-spacing: 1.5px;
      text-transform: uppercase; color: rgba(255,255,255,0.15); font-weight: 700;
      background: rgba(8,12,22,0.97); padding: 0 10px; position: absolute;
    }

    /* ─── CHAT MESSAGES ─── */
    #ws-chat-messages {
      flex: 1; overflow-y: auto; padding: 12px 10px;
      display: flex; flex-direction: column; gap: 10px;
    }
    #ws-chat-messages::-webkit-scrollbar { width: 3px; }
    #ws-chat-messages::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 2px; }

    .ws-msg { max-width: 100%; }
    .ws-msg-meta {
      font-size: 9px; letter-spacing: 1px; text-transform: uppercase;
      font-weight: 700; margin-bottom: 4px; display: block;
    }
    .ws-msg-user .ws-msg-meta { color: rgba(99,102,241,0.8); }
    .ws-msg-ai .ws-msg-meta { color: rgba(255,183,3,0.8); }
    .ws-msg-bubble {
      font-size: 12px; line-height: 1.6; padding: 10px 12px;
      border-radius: 12px; color: rgba(255,255,255,0.85);
    }
    .ws-msg-user .ws-msg-bubble {
      background: rgba(99,102,241,0.12); border: 1px solid rgba(99,102,241,0.2);
      border-bottom-left-radius: 4px;
    }
    .ws-msg-ai .ws-msg-bubble {
      background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
      border-bottom-left-radius: 4px;
    }

    /* Report card inside chat */
    .ws-report-card {
      background: rgba(16,185,129,0.07); border: 1px solid rgba(16,185,129,0.2);
      border-radius: 10px; padding: 10px 12px; margin-top: 8px;
      display: flex; align-items: center; gap: 10px;
    }
    .ws-report-icon { font-size: 22px; }
    .ws-report-info { flex: 1; }
    .ws-report-name { font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.85); }
    .ws-report-sub  { font-size: 10px; color: rgba(255,255,255,0.4); }
    .ws-report-dl   { background: rgba(16,185,129,0.2); border: 1px solid rgba(16,185,129,0.3); border-radius: 6px; color: #6ee7b7; padding: 4px 10px; font-size: 10px; cursor: pointer; text-decoration: none; font-family: inherit; }

    /* Welcome state */
    #ws-chat-welcome {
      display: flex; flex-direction: column; align-items: center;
      justify-content: center; height: 100%; gap: 12px; padding: 20px;
      text-align: center;
    }
    .ws-welcome-icon { font-size: 36px; }
    .ws-welcome-title { font-size: 14px; font-weight: 600; color: rgba(255,255,255,0.7); }
    .ws-welcome-sub { font-size: 11px; color: rgba(255,255,255,0.3); line-height: 1.6; }
    .ws-welcome-chips { display: flex; flex-wrap: wrap; gap: 6px; justify-content: center; margin-top: 8px; }
    .ws-chip {
      background: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.2);
      border-radius: 20px; padding: 5px 12px; font-size: 11px; color: #a5b4fc;
      cursor: pointer; transition: 0.2s;
    }
    .ws-chip:hover { background: rgba(99,102,241,0.2); }

    /* ─── CHAT INPUT ─── */
    #ws-chat-input-area {
      padding: 10px;
      border-top: 1px solid rgba(255,255,255,0.05);
      flex-shrink: 0;
    }
    #ws-chat-input-row {
      display: flex; align-items: flex-end; gap: 8px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 12px; padding: 8px 8px 8px 12px;
      transition: 0.2s;
    }
    #ws-chat-input-row:focus-within {
      border-color: rgba(99,102,241,0.4);
      background: rgba(99,102,241,0.06);
    }
    #ws-chat-textarea {
      flex: 1; background: none; border: none; outline: none;
      color: rgba(255,255,255,0.9); font-size: 12px;
      font-family: inherit; resize: none;
      min-height: 20px; max-height: 100px;
      line-height: 1.5;
    }
    #ws-chat-textarea::placeholder { color: rgba(255,255,255,0.2); }
    .ws-chat-action {
      background: none; border: none; cursor: pointer;
      color: rgba(255,255,255,0.3); font-size: 16px; padding: 4px;
      border-radius: 6px; transition: 0.2s; flex-shrink: 0;
    }
    .ws-chat-action:hover { color: rgba(255,255,255,0.7); background: rgba(255,255,255,0.08); }
    #ws-send-btn {
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      border: none; border-radius: 8px; width: 30px; height: 30px;
      cursor: pointer; color: white; font-size: 14px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0; transition: 0.2s;
    }
    #ws-send-btn:hover { transform: scale(1.08); box-shadow: 0 4px 12px rgba(99,102,241,0.4); }
    #ws-send-btn:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }

    /* Attach preview */
    #ws-attach-preview { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 6px; }
    .ws-attach-chip {
      display: flex; align-items: center; gap: 5px;
      background: rgba(99,102,241,0.12); border: 1px solid rgba(99,102,241,0.2);
      border-radius: 6px; padding: 3px 8px; font-size: 10px; color: #a5b4fc;
    }
    .ws-attach-chip button { background: none; border: none; color: inherit; cursor: pointer; font-size: 11px; padding: 0; }

    /* ─── CENTER CANVAS ─── */
    #ws-center {
      flex: 1; display: flex; flex-direction: column; overflow: hidden;
    }

    /* ─── RESIZE HANDLE ─── */
    .ws-resize-handle {
      width: 4px; background: transparent; cursor: col-resize;
      flex-shrink: 0; transition: background 0.2s; position: relative;
    }
    .ws-resize-handle::after {
      content: ''; position: absolute; top: 50%; left: 50%;
      transform: translate(-50%, -50%);
      width: 2px; height: 40px; background: rgba(255,255,255,0.08);
      border-radius: 1px; transition: 0.2s;
    }
    .ws-resize-handle:hover::after, .ws-resize-handle.dragging::after {
      background: rgba(99,102,241,0.6);
    }

    /* Context menu */
    #ws-ctx-menu {
      position: fixed; z-index: 20000;
      background: rgba(10,15,28,0.98); border: 1px solid rgba(255,255,255,0.1);
      border-radius: 10px; padding: 6px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.6);
      min-width: 160px; display: none;
      font-family: 'Inter', sans-serif;
    }
    .ws-ctx-item {
      display: flex; align-items: center; gap: 8px;
      padding: 8px 12px; border-radius: 7px; font-size: 12px;
      color: rgba(255,255,255,0.7); cursor: pointer; transition: 0.15s;
    }
    .ws-ctx-item:hover { background: rgba(255,255,255,0.07); color: white; }
    .ws-ctx-item.danger { color: #fca5a5; }
    .ws-ctx-item.danger:hover { background: rgba(239,68,68,0.12); }
    .ws-ctx-sep { height: 1px; background: rgba(255,255,255,0.07); margin: 4px 0; }
  `;

  /* ─── BUILD WORKSPACE ────────────────────────────────────────────────────── */
  function buildWorkspace() {
    const domainInfo = DOMAIN_META[_domain] || DOMAIN_META.agriculture;

    const ws = document.createElement('div');
    ws.id = 'cahaya-workspace';
    ws.innerHTML = `
      <!-- WORKSPACE HEADER -->
      <header id="ws-header">
        <div id="ws-logo">
          ✦ CAHAYA <span class="ws-logo-badge">SOVEREIGN</span>
        </div>

        <div id="ws-domain-chip">
          <span class="ws-domain-dot" style="background:${domainInfo.color}"></span>
          <span>${domainInfo.icon} ${domainInfo.label}</span>
        </div>

        <!-- Live telemetry (reused from original header) -->
        <div id="ws-telemetry">
          <div class="ws-tel-item">
            <span class="ws-tel-label">Memory</span>
            <span class="ws-tel-val" id="ws-tel-memory">—</span>
          </div>
          <div class="ws-tel-item">
            <span class="ws-tel-label">FPS</span>
            <span class="ws-tel-val blue" id="ws-tel-fps">—</span>
          </div>
          <div class="ws-tel-item">
            <span class="ws-tel-label">Savings</span>
            <span class="ws-tel-val green" id="ws-tel-savings">—</span>
          </div>
          <div class="ws-tel-item">
            <span class="ws-tel-label">Core</span>
            <span class="ws-tel-val" id="ws-tel-core">LOCAL</span>
          </div>
        </div>

        <div id="ws-actions">
          <button class="ws-header-btn ws-btn-primary" id="ws-new-project-top" onclick="window.CahayaWorkspace.newConversation()">
            + New Project
          </button>
          <button class="ws-header-btn" id="ws-web-toggle-btn" onclick="window.CahayaWorkspace.toggleWebAccess()" title="Toggle internet access for AI">
            🌐 Web Off
          </button>
          <button class="ws-header-btn" id="crp-toggle-btn" onclick="window.CahayaRightPanel && window.CahayaRightPanel.toggle()" title="Workspace settings, files & connections">
            ⚙️ Workspace
          </button>
        </div>
      </header>

      <!-- BODY -->
      <div id="ws-body">

        <!-- LEFT SIDEBAR: Chat History + Active Chat -->
        <aside id="ws-left">
          <!-- Top controls -->
          <div id="ws-sidebar-top">
            <button id="ws-new-conv-btn" onclick="window.CahayaWorkspace.newConversation()">
              ✦ New Project
            </button>
            <input id="ws-conv-search" type="search" placeholder="Search conversations…"
                   oninput="window.CahayaWorkspace.searchConversations(this.value)">
          </div>

          <!-- Conversation history list -->
          <div id="ws-conv-list">
            <div style="font-size:11px;color:rgba(255,255,255,0.2);text-align:center;padding:16px">Loading projects…</div>
          </div>

          <!-- Divider between history and active chat -->
          <div id="ws-chat-divider"></div>

          <!-- Active chat messages -->
          <div id="ws-chat-messages">
            <div id="ws-chat-welcome">
              <div class="ws-welcome-icon">${domainInfo.icon}</div>
              <div class="ws-welcome-title">Start a new project</div>
              <div class="ws-welcome-sub">Type a prompt, run an analysis,<br>or load a file to get started.</div>
              <div class="ws-welcome-chips">
                <span class="ws-chip" onclick="window.CahayaWorkspace.quickPrompt(this.textContent)">🛰️ Analyse satellite data</span>
                <span class="ws-chip" onclick="window.CahayaWorkspace.quickPrompt(this.textContent)">📊 Generate compliance report</span>
                <span class="ws-chip" onclick="window.CahayaWorkspace.quickPrompt(this.textContent)">🔬 Run simulation</span>
                <span class="ws-chip" onclick="window.CahayaWorkspace.quickPrompt(this.textContent)">📄 Upload & analyse file</span>
              </div>
            </div>
          </div>

          <!-- Attach file preview -->
          <div id="ws-attach-preview"></div>

          <!-- Chat input -->
          <div id="ws-chat-input-area">
            <div id="ws-chat-input-row">
              <button class="ws-chat-action" title="Attach file" onclick="document.getElementById('ws-file-attach').click()">📎</button>
              <input type="file" id="ws-file-attach" style="display:none" multiple onchange="window.CahayaWorkspace.handleAttach(this.files)">
              <textarea id="ws-chat-textarea" rows="1" placeholder="Ask anything, run analysis, generate report…"
                        onkeydown="window.CahayaWorkspace.handleKeydown(event)"
                        oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'"></textarea>
              <button class="ws-chat-action" title="Voice input" id="ws-voice-btn">🎤</button>
              <button id="ws-send-btn" onclick="window.CahayaWorkspace.sendMessage()" title="Send">↑</button>
            </div>
          </div>
        </aside>

        <!-- RESIZE HANDLE -->
        <div class="ws-resize-handle" id="ws-resize-left"
             onmousedown="window.CahayaWorkspace.startResize(event, 'left')"></div>

        <!-- CENTER: Existing App Canvas (moved here) -->
        <main id="ws-center" data-placeholder="app-container-goes-here"></main>

        <!-- RESIZE HANDLE -->
        <div class="ws-resize-handle" id="ws-resize-right"></div>

      </div>

      <!-- Context menu -->
      <div id="ws-ctx-menu">
        <div class="ws-ctx-item" onclick="window.CahayaWorkspace.ctxAction('rename')">✏️ Rename</div>
        <div class="ws-ctx-item" onclick="window.CahayaWorkspace.ctxAction('pin')">📌 Pin / Unpin</div>
        <div class="ws-ctx-item" onclick="window.CahayaWorkspace.ctxAction('export')">📤 Export</div>
        <div class="ws-ctx-sep"></div>
        <div class="ws-ctx-item danger" onclick="window.CahayaWorkspace.ctxAction('delete')">🗑 Delete</div>
      </div>
    `;
    return ws;
  }

  /* ─── CONVERSATION RENDERING ─────────────────────────────────────────────── */
  function groupByDate(conversations) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today - 86400000);
    const thisWeek = new Date(today - 7 * 86400000);

    const groups = { pinned: [], today: [], yesterday: [], thisWeek: [], earlier: [] };
    conversations.forEach(c => {
      if (c.pinned) { groups.pinned.push(c); return; }
      const d = new Date(c.updatedAt);
      if (d >= today) groups.today.push(c);
      else if (d >= yesterday) groups.yesterday.push(c);
      else if (d >= thisWeek) groups.thisWeek.push(c);
      else groups.earlier.push(c);
    });
    return groups;
  }

  function formatRelTime(isoStr) {
    const d = new Date(isoStr);
    const diff = Date.now() - d.getTime();
    if (diff < 60000) return 'just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return d.toLocaleDateString();
  }

  function renderConversationList(conversations) {
    const el = document.getElementById('ws-conv-list');
    if (!el) return;

    if (!conversations || conversations.length === 0) {
      el.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,0.2);text-align:center;padding:16px">No projects yet.<br>Start a new one above.</div>';
      return;
    }

    const groups = groupByDate(conversations);
    const domainInfo = DOMAIN_META[_domain] || DOMAIN_META.agriculture;
    let html = '';

    const groupLabels = {
      pinned: '📌 Pinned',
      today: '📅 Today',
      yesterday: '📅 Yesterday',
      thisWeek: '📅 This Week',
      earlier: '📅 Earlier',
    };

    for (const [key, label] of Object.entries(groupLabels)) {
      const items = groups[key];
      if (!items.length) continue;
      html += `<span class="ws-conv-group-label">${label}</span>`;
      items.forEach(conv => {
        const isActive = conv.id === _activeConvId;
        html += `
          <div class="ws-conv-item ${isActive ? 'active' : ''} ${conv.pinned ? 'pinned' : ''}"
               data-conv-id="${conv.id}"
               onclick="window.CahayaWorkspace.selectConversation('${conv.id}')">
            <span class="ws-conv-icon">${domainInfo.icon}</span>
            <div class="ws-conv-info">
              <span class="ws-conv-title">${conv.title || 'Untitled Project'}</span>
              <span class="ws-conv-time">${formatRelTime(conv.updatedAt)}</span>
            </div>
            <button class="ws-conv-menu" onclick="event.stopPropagation();window.CahayaWorkspace.showConvMenu(event,'${conv.id}')" title="Options">⋯</button>
          </div>
        `;
      });
    }

    el.innerHTML = html;
  }

  /* ─── CHAT RENDERING ─────────────────────────────────────────────────────── */
  function renderMessages(messages) {
    const container = document.getElementById('ws-chat-messages');
    if (!container) return;

    const welcome = document.getElementById('ws-chat-welcome');
    if (welcome) welcome.remove();

    const existing = container.querySelectorAll('.ws-msg');
    existing.forEach(el => el.remove());

    messages.forEach(msg => appendMessageEl(msg, false));
    container.scrollTop = container.scrollHeight;
  }

  function appendMessageEl(msg, animate = true) {
    const container = document.getElementById('ws-chat-messages');
    if (!container) return;

    const welcome = document.getElementById('ws-chat-welcome');
    if (welcome) welcome.style.display = 'none';

    const el = document.createElement('div');
    el.className = `ws-msg ws-msg-${msg.role === 'user' ? 'user' : 'ai'}`;
    if (animate) { el.style.opacity = '0'; el.style.transform = 'translateY(8px)'; }

    const content = msg.content || '';
    const hasReport = content.includes('[REPORT:') || msg.reportCard;

    el.innerHTML = `
      <span class="ws-msg-meta">${msg.role === 'user' ? 'YOU' : '🧠 CAHAYA AI'}</span>
      <div class="ws-msg-bubble">${content.replace(/\n/g, '<br>')}</div>
      ${hasReport && msg.reportCard ? `
        <div class="ws-report-card">
          <span class="ws-report-icon">📄</span>
          <div class="ws-report-info">
            <div class="ws-report-name">${msg.reportCard.name}</div>
            <div class="ws-report-sub">${msg.reportCard.sub}</div>
          </div>
          <a class="ws-report-dl" href="${msg.reportCard.url || '#'}" download>⬇ Download</a>
        </div>
      ` : ''}
    `;

    container.appendChild(el);

    if (animate) {
      requestAnimationFrame(() => {
        el.style.transition = 'all 0.25s ease';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      });
    }

    container.scrollTop = container.scrollHeight;
    return el;
  }

  function showTypingIndicator() {
    const el = document.createElement('div');
    el.id = 'ws-typing';
    el.className = 'ws-msg ws-msg-ai';
    el.innerHTML = `
      <span class="ws-msg-meta">🧠 CAHAYA AI</span>
      <div class="ws-msg-bubble" style="display:flex;align-items:center;gap:6px;min-height:20px">
        <span style="width:6px;height:6px;border-radius:50%;background:#6366f1;animation:ws-dot 1.2s 0s infinite both"></span>
        <span style="width:6px;height:6px;border-radius:50%;background:#6366f1;animation:ws-dot 1.2s 0.2s infinite both"></span>
        <span style="width:6px;height:6px;border-radius:50%;background:#6366f1;animation:ws-dot 1.2s 0.4s infinite both"></span>
      </div>
    `;
    document.getElementById('ws-chat-messages')?.appendChild(el);
    document.getElementById('ws-chat-messages').scrollTop = 9999;
    return el;
  }

  /* ─── RESIZE LOGIC ───────────────────────────────────────────────────────── */
  let _resizing = null;
  let _resizeStart = 0;
  let _resizeStartWidth = 0;

  function startResize(e, side) {
    _resizing = side;
    _resizeStart = e.clientX;
    const panel = document.getElementById('ws-left');
    _resizeStartWidth = panel ? panel.offsetWidth : 280;
    document.body.style.cursor = 'col-resize';
    document.getElementById('ws-resize-left')?.classList.add('dragging');
    e.preventDefault();
  }

  function onMouseMove(e) {
    if (!_resizing) return;
    if (_resizing === 'left') {
      const panel = document.getElementById('ws-left');
      if (!panel) return;
      const newW = Math.max(200, Math.min(500, _resizeStartWidth + (e.clientX - _resizeStart)));
      panel.style.width = `${newW}px`;
    }
  }

  function onMouseUp() {
    if (!_resizing) return;
    _resizing = null;
    document.body.style.cursor = '';
    document.getElementById('ws-resize-left')?.classList.remove('dragging');
  }

  /* ─── PENDING ATTACHMENTS ────────────────────────────────────────────────── */
  let _pendingAttachments = [];

  function handleAttach(files) {
    Array.from(files).forEach(f => {
      _pendingAttachments.push(f);
      const preview = document.getElementById('ws-attach-preview');
      if (preview) {
        const chip = document.createElement('span');
        chip.className = 'ws-attach-chip';
        chip.dataset.fname = f.name;
        chip.innerHTML = `📎 ${f.name.substring(0, 20)} <button onclick="window.CahayaWorkspace.removeAttach('${f.name}')">✕</button>`;
        preview.appendChild(chip);
      }
    });
  }

  /* ─── PUBLIC API ─────────────────────────────────────────────────────────── */
  window.CahayaWorkspace = {
    async init() {
      if (!document.getElementById('ws-styles')) {
        const s = document.createElement('style');
        s.id = 'ws-styles';
        s.textContent = WS_STYLES + `@keyframes ws-dot{0%,80%,100%{opacity:0.2}40%{opacity:1}}`;
        document.head.appendChild(s);
      }

      const ws = buildWorkspace();
      // Move the existing app-container INTO the workspace center
      const appContainer = document.getElementById('app-container');
      const center = ws.querySelector('#ws-center');
      if (appContainer && center) {
        center.appendChild(appContainer);
        // Hide original app-container's body scroll
        document.body.style.overflow = 'hidden';
      }
      document.body.insertBefore(ws, document.body.firstChild);

      // Wire resize handles
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);

      // Context menu dismiss
      document.addEventListener('click', e => {
        const menu = document.getElementById('ws-ctx-menu');
        if (menu && !menu.contains(e.target)) menu.style.display = 'none';
      });

      // Sync telemetry from existing elements
      this._syncTelemetry();

      // Init conversation manager
      if (window.ConversationManager) {
        await window.ConversationManager.init();
        const convs = await window.ConversationManager.listConversations(_domain);
        renderConversationList(convs);

        // Auto-select or create first conversation
        if (convs.length > 0) {
          await this.selectConversation(convs[0].id, false);
        } else {
          await this.newConversation(false);
        }
      }

      // Wire orchestrator complete event
      document.addEventListener('orchestrator-complete', e => {
        const { reportData } = e.detail || {};
        if (reportData && _activeConvId && window.ConversationManager) {
          const summary = `Mission complete. Computed ${Object.keys(reportData.results || {}).length} agent outputs. Validation: ${reportData.validationSummary?.status || 'PASS'}.`;
          window.ConversationManager.saveMessage(_activeConvId, {
            role: 'assistant', content: summary, timestamp: new Date().toISOString(),
          });
          appendMessageEl({ role: 'assistant', content: summary });
        }
      });

      // Web access sync
      document.addEventListener('web-access-changed', e => {
        const btn = document.getElementById('ws-web-toggle-btn');
        if (btn) {
          btn.textContent = e.detail.enabled ? '🌐 Web On' : '🌐 Web Off';
          btn.classList.toggle('active', e.detail.enabled);
        }
      });

      console.log('🏗️ CAHAYA Workspace shell initialised.');
    },

    async newConversation(scrollToIt = true) {
      if (!window.ConversationManager) return;
      const id = await window.ConversationManager.createConversation(_domain);
      _activeConvId = id;
      if (window.CahayaRightPanel) window.CahayaRightPanel.setActiveConversation(id);

      // Clear chat UI
      const msgs = document.getElementById('ws-chat-messages');
      if (msgs) msgs.innerHTML = document.getElementById('ws-chat-welcome')?.outerHTML || `
        <div id="ws-chat-welcome" style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:12px;padding:20px;text-align:center">
          <div style="font-size:36px">${(DOMAIN_META[_domain]||DOMAIN_META.agriculture).icon}</div>
          <div style="font-size:14px;font-weight:600;color:rgba(255,255,255,0.7)">New project started</div>
          <div style="font-size:11px;color:rgba(255,255,255,0.3);line-height:1.6">Type your first message or use the quick actions below.</div>
        </div>`;

      // Refresh list
      const convs = await window.ConversationManager.listConversations(_domain);
      renderConversationList(convs);

      // Highlight new
      document.querySelectorAll('.ws-conv-item').forEach(el => el.classList.remove('active'));
      const newEl = document.querySelector(`[data-conv-id="${id}"]`);
      if (newEl) newEl.classList.add('active');

      document.getElementById('ws-chat-textarea')?.focus();
    },

    async selectConversation(id, animate = true) {
      if (!window.ConversationManager) return;
      _activeConvId = id;
      if (window.CahayaRightPanel) window.CahayaRightPanel.setActiveConversation(id);

      // Update active state in list
      document.querySelectorAll('.ws-conv-item').forEach(el => {
        el.classList.toggle('active', el.dataset.convId === id);
      });

      const conv = await window.ConversationManager.getConversation(id);
      if (conv) renderMessages(conv.messages || []);
    },

    async sendMessage() {
      const textarea = document.getElementById('ws-chat-textarea');
      if (!textarea) return;
      const text = textarea.value.trim();
      if (!text) return;
      textarea.value = '';
      textarea.style.height = 'auto';

      // Ensure active conversation exists
      if (!_activeConvId && window.ConversationManager) {
        _activeConvId = await window.ConversationManager.createConversation(_domain);
      }

      // Save user message
      const userMsg = { role: 'user', content: text, timestamp: new Date().toISOString(), attachments: _pendingAttachments.map(f => f.name) };
      if (window.ConversationManager && _activeConvId) {
        await window.ConversationManager.saveMessage(_activeConvId, userMsg);
      }
      appendMessageEl(userMsg);
      _pendingAttachments = [];
      document.getElementById('ws-attach-preview').innerHTML = '';

      // Check orchestrator intercept
      if (window.CahayaOrchestrator?.shouldIntercept(text)) {
        const typing = showTypingIndicator();
        setTimeout(() => {
          typing?.remove();
          const plan = window.CahayaOrchestrator.intercept(text);
          if (plan) {
            const aiMsg = { role: 'assistant', content: `Mission brief prepared. I've selected **${plan.selectedMetrics.length} metrics** and **${plan.agents.length} specialist agents** for your request.\n\nReview the pre-flight brief and approve to begin execution.`, timestamp: new Date().toISOString() };
            appendMessageEl(aiMsg);
            if (window.ConversationManager && _activeConvId) {
              window.ConversationManager.saveMessage(_activeConvId, aiMsg);
              window.ConversationManager.autoTitle(_activeConvId, text);
            }
          }
        }, 800);
        return;
      }

      // Standard AI handler — delegate to existing sendContextualChat if available
      const typing = showTypingIndicator();
      if (window.sendContextualChat) {
        // Inject into existing system and intercept response via event
        const inputEl = document.getElementById('gis-chat-input') || document.getElementById('cahaya-chat-input');
        if (inputEl) {
          inputEl.value = text;
          // Get AI library context
          const libCtx = window.ConversationManager ? await window.ConversationManager.buildAIContext() : '';
          if (libCtx && inputEl) inputEl.dataset.libContext = libCtx;
          window.sendContextualChat('gis');
        }
        // Watch for response in the original chat panel and mirror it
        setTimeout(async () => {
          typing?.remove();
          const lastAiMsg = document.querySelector('#gis-chat-messages .ai-msg:last-child p');
          const responseText = lastAiMsg?.textContent || 'Analysis complete. Check the canvas for results.';
          const aiMsg = { role: 'assistant', content: responseText, timestamp: new Date().toISOString() };
          appendMessageEl(aiMsg);
          if (window.ConversationManager && _activeConvId) {
            await window.ConversationManager.saveMessage(_activeConvId, aiMsg);
            await window.ConversationManager.autoTitle(_activeConvId, responseText);
            const convs = await window.ConversationManager.listConversations(_domain);
            renderConversationList(convs);
          }
        }, 3500);
      } else {
        setTimeout(() => { typing?.remove(); appendMessageEl({ role: 'assistant', content: 'AI engine loading…', timestamp: new Date().toISOString() }); }, 1000);
      }
    },

    handleKeydown(e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.sendMessage(); }
    },

    handleAttach(files) { handleAttach(files); },

    removeAttach(fname) {
      _pendingAttachments = _pendingAttachments.filter(f => f.name !== fname);
      const chip = document.querySelector(`.ws-attach-chip[data-fname="${fname}"]`);
      if (chip) chip.remove();
    },

    quickPrompt(text) {
      const ta = document.getElementById('ws-chat-textarea');
      if (ta) { ta.value = text; ta.focus(); }
    },

    async searchConversations(query) {
      clearTimeout(_searchDebounce);
      _searchDebounce = setTimeout(async () => {
        if (!window.ConversationManager) return;
        const results = query.trim()
          ? await window.ConversationManager.searchConversations(query, _domain)
          : await window.ConversationManager.listConversations(_domain);
        renderConversationList(results);
      }, 200);
    },

    _ctxTargetConvId: null,
    showConvMenu(e, convId) {
      this._ctxTargetConvId = convId;
      const menu = document.getElementById('ws-ctx-menu');
      if (!menu) return;
      menu.style.display = 'block';
      menu.style.left = `${e.clientX}px`;
      menu.style.top = `${e.clientY}px`;
    },

    async ctxAction(action) {
      const id = this._ctxTargetConvId;
      document.getElementById('ws-ctx-menu').style.display = 'none';
      if (!id || !window.ConversationManager) return;
      if (action === 'rename') {
        const name = prompt('Rename project:');
        if (name) { await window.ConversationManager.renameConversation(id, name); }
      } else if (action === 'pin') {
        const conv = await window.ConversationManager.getConversation(id);
        await window.ConversationManager.pinConversation(id, !conv.pinned);
      } else if (action === 'export') {
        await window.ConversationManager.exportConversation(id);
      } else if (action === 'delete') {
        if (confirm('Delete this project? This cannot be undone.')) {
          await window.ConversationManager.deleteConversation(id);
          if (id === _activeConvId) await this.newConversation();
        }
      }
      const convs = await window.ConversationManager.listConversations(_domain);
      renderConversationList(convs);
    },

    toggleWebAccess() {
      const enabled = !JSON.parse(localStorage.getItem('cahaya_web_access') || 'false');
      localStorage.setItem('cahaya_web_access', JSON.stringify(enabled));
      const btn = document.getElementById('ws-web-toggle-btn');
      if (btn) { btn.textContent = enabled ? '🌐 Web On' : '🌐 Web Off'; btn.classList.toggle('active', enabled); }
      document.dispatchEvent(new CustomEvent('web-access-changed', { detail: { enabled } }));
      if (window.CahayaRightPanel) {
        const cb = document.getElementById('crp-web-toggle-cb');
        if (cb) cb.checked = enabled;
      }
    },

    startResize,

    _syncTelemetry() {
      // Mirror values from existing DOM elements
      setInterval(() => {
        const mem = document.getElementById('memory-profile');
        const fps = document.getElementById('fps-meter');
        const sav = document.getElementById('compute-savings');
        const dep = document.getElementById('deployment-profile');
        if (mem) document.getElementById('ws-tel-memory').textContent = mem.textContent;
        if (fps) document.getElementById('ws-tel-fps').textContent = fps.textContent;
        if (sav) document.getElementById('ws-tel-savings').textContent = sav.textContent.split(' ')[0];
        if (dep) document.getElementById('ws-tel-core').textContent = dep.textContent;
      }, 2000);
    },
  };

  // Auto-init after gateway activates
  document.addEventListener('gateway-activated', () => {
    _domain = localStorage.getItem('cahaya_domain') || 'agriculture';
    window.CahayaWorkspace.init();
  });

  // If already activated, init on DOM ready
  if (localStorage.getItem('cahaya_activated') === 'true') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => window.CahayaWorkspace.init());
    else setTimeout(() => window.CahayaWorkspace.init(), 200);
  }

  console.log('🏗️ CAHAYA Workspace module loaded.');
})();
