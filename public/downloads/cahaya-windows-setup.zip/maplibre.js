// LENUDA Premium - MapLibre GL JS Integration Module
// Provides real map rendering with polygon drawing, GEE overlays, and geocoding.
// Falls back to existing canvas-based map if MapLibre fails to load.

(function() {
  'use strict';

  // ============================================================
  // GLOBAL LenudaMap OBJECT
  // ============================================================
  const LenudaMap = {
    map: null,
    isReady: false,
    isFallback: false,
    polygonVertices: [],
    polygonLayerId: 'lenuda-polygon-fill',
    polygonSourceId: 'lenuda-polygon',
    geeLayerIds: [],
    markers: [],
    drawingMode: false,
    currentDomain: 'agriculture',

    // Default center coordinates per domain
    domainCenters: {
      agriculture: { lng: 101.6869, lat: 3.1390, zoom: 10 },
      mining: { lng: 117.7510, lat: -22.7509, zoom: 11 },
      disaster: { lng: 100.5018, lat: 13.7563, zoom: 10 },
      urban: { lng: 103.8198, lat: 1.3521, zoom: 12 },
      utilities: { lng: -0.1278, lat: 51.5074, zoom: 11 },
      logistics: { lng: 114.1694, lat: 22.3193, zoom: 12 },
      defense: { lng: 101.6869, lat: 3.1390, zoom: 9 },
      environmental: { lng: 110.0, lat: 0.0, zoom: 8 },
      infrastructure: { lng: 2.3522, lat: 48.8566, zoom: 12 },
      emergency: { lng: 139.6503, lat: 35.6762, zoom: 11 }
    },

    // Domain-specific GEE layer color schemes
    domainColors: {
      agriculture: { fill: 'rgba(2, 195, 154, 0.25)', stroke: '#02c39a', highlight: '#70e000' },
      mining: { fill: 'rgba(114, 9, 183, 0.25)', stroke: '#7209b7', highlight: '#f72585' },
      disaster: { fill: 'rgba(0, 119, 182, 0.25)', stroke: '#0077b6', highlight: '#00b4d8' },
      urban: { fill: 'rgba(76, 201, 240, 0.25)', stroke: '#4cc9f0', highlight: '#4895ef' },
      utilities: { fill: 'rgba(255, 183, 3, 0.25)', stroke: '#ffb703', highlight: '#fb8500' },
      logistics: { fill: 'rgba(2, 195, 154, 0.25)', stroke: '#02c39a', highlight: '#ffb703' },
      defense: { fill: 'rgba(230, 57, 70, 0.25)', stroke: '#e63946', highlight: '#d62828' },
      environmental: { fill: 'rgba(2, 195, 154, 0.25)', stroke: '#02c39a', highlight: '#40916c' },
      infrastructure: { fill: 'rgba(255, 183, 3, 0.25)', stroke: '#ffb703', highlight: '#e85d04' },
      emergency: { fill: 'rgba(230, 57, 70, 0.25)', stroke: '#e63946', highlight: '#ff6b6b' }
    },

    // ============================================================
    // INITIALIZATION
    // ============================================================

    /**
     * Initialize the MapLibre GL map in the given container.
     * @param {string} containerId - DOM element ID for the map container
     * @param {object} options - Optional: { domain, center, zoom }
     */
    initMap: function(containerId, options = {}) {
      const container = document.getElementById(containerId);
      if (!container) {
        console.error('[LenudaMap] Container not found:', containerId);
        this.isFallback = true;
        return;
      }

      // Check if MapLibre GL JS is available
      if (typeof maplibregl === 'undefined') {
        console.warn('[LenudaMap] MapLibre GL JS not loaded. Falling back to canvas renderer.');
        this.isFallback = true;
        this._initFallbackCanvas(container);
        return;
      }

      const domain = options.domain || this.currentDomain;
      const center = this.domainCenters[domain] || this.domainCenters.agriculture;

      try {
        this.map = new maplibregl.Map({
          container: containerId,
          style: {
            version: 8,
            name: 'LENUDA Dark Satellite',
            sources: {
              'osm-raster': {
                type: 'raster',
                tiles: [
                  'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
                ],
                tileSize: 256,
                attribution: '&copy; OpenStreetMap contributors'
              },
              'satellite': {
                type: 'raster',
                tiles: [
                  'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
                ],
                tileSize: 256,
                attribution: '&copy; Esri World Imagery'
              }
            },
            layers: [
              {
                id: 'satellite-base',
                type: 'raster',
                source: 'satellite',
                layout: { visibility: 'none' },
                paint: { 'raster-opacity': 0.85 }
              },
              {
                id: 'osm-base',
                type: 'raster',
                source: 'osm-raster',
                layout: { visibility: 'visible' },
                paint: {
                  'raster-opacity': 0.6,
                  'raster-saturation': -0.8,
                  'raster-brightness-max': 0.3
                }
              }
            ],
            glyphs: 'https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf'
          },
          center: [center.lng, center.lat],
          zoom: options.zoom || center.zoom,
          pitch: 0,
          bearing: 0,
          maxZoom: 18,
          minZoom: 2
        });

        // Navigation controls
        this.map.addControl(new maplibregl.NavigationControl({
          showCompass: true,
          showZoom: false // we have custom zoom buttons
        }), 'top-right');

        // Scale bar
        this.map.addControl(new maplibregl.ScaleControl({
          maxWidth: 150,
          unit: 'metric'
        }), 'bottom-left');

        // When map loads, set up polygon source + layers
        this.map.on('load', () => {
          this.isReady = true;
          this._setupPolygonLayer();
          this._setupClickDrawing();
          console.log('[LenudaMap] Map initialized successfully.');

          // Notify app.js
          if (typeof window.onMapReady === 'function') {
            window.onMapReady();
          }
        });

        this.map.on('error', (e) => {
          console.warn('[LenudaMap] Map error:', e.error?.message || e);
        });

      } catch (err) {
        console.error('[LenudaMap] Failed to initialize MapLibre:', err);
        this.isFallback = true;
        this._initFallbackCanvas(container);
      }
    },

    // ============================================================
    // POLYGON DRAWING
    // ============================================================

    /**
     * Setup the polygon GeoJSON source and layers
     */
    _setupPolygonLayer: function() {
      if (!this.map || this.isFallback) return;

      this.map.addSource(this.polygonSourceId, {
        type: 'geojson',
        data: this._emptyPolygonGeoJSON()
      });

      // Polygon fill
      this.map.addLayer({
        id: this.polygonLayerId,
        type: 'fill',
        source: this.polygonSourceId,
        paint: {
          'fill-color': this.domainColors[this.currentDomain]?.fill || 'rgba(2, 195, 154, 0.25)',
          'fill-opacity': 0.6
        },
        filter: ['==', '$type', 'Polygon']
      });

      // Polygon outline
      this.map.addLayer({
        id: 'lenuda-polygon-outline',
        type: 'line',
        source: this.polygonSourceId,
        paint: {
          'line-color': this.domainColors[this.currentDomain]?.stroke || '#02c39a',
          'line-width': 2,
          'line-dasharray': [2, 1]
        },
        filter: ['==', '$type', 'Polygon']
      });

      // Vertex circles
      this.map.addLayer({
        id: 'lenuda-polygon-vertices',
        type: 'circle',
        source: this.polygonSourceId,
        paint: {
          'circle-radius': 6,
          'circle-color': '#ffb703',
          'circle-stroke-color': '#ffffff',
          'circle-stroke-width': 2
        },
        filter: ['==', '$type', 'Point']
      });
    },

    /**
     * Add a polygon from an array of [lng, lat] coordinate pairs
     * @param {Array} coords - Array of [lng, lat] pairs
     */
    addPolygon: function(coords) {
      if (!coords || coords.length < 3) return;
      this.polygonVertices = coords.slice();

      if (this.isFallback || !this.map) return;

      const geojson = this._polygonToGeoJSON(coords);
      const source = this.map.getSource(this.polygonSourceId);
      if (source) {
        source.setData(geojson);
      }
    },

    /**
     * Clear all polygon drawings
     */
    clearPolygons: function() {
      this.polygonVertices = [];
      if (this.isFallback || !this.map) return;

      const source = this.map.getSource(this.polygonSourceId);
      if (source) {
        source.setData(this._emptyPolygonGeoJSON());
      }
    },

    /**
     * Enable click-to-draw polygon mode
     */
    startDrawing: function() {
      this.drawingMode = true;
      this.polygonVertices = [];
      if (this.map) {
        this.map.getCanvas().style.cursor = 'crosshair';
      }
    },

    /**
     * Finish drawing and close the polygon
     */
    finishDrawing: function() {
      this.drawingMode = false;
      if (this.map) {
        this.map.getCanvas().style.cursor = '';
      }
      if (this.polygonVertices.length >= 3) {
        this.addPolygon(this.polygonVertices);
      }
    },

    /**
     * Setup click handler for polygon drawing
     */
    _setupClickDrawing: function() {
      if (!this.map) return;
      const self = this;

      this.map.on('click', (e) => {
        if (!self.drawingMode) return;

        const coord = [e.lngLat.lng, e.lngLat.lat];
        self.polygonVertices.push(coord);

        // Update the preview on map
        const geojson = self._polygonToGeoJSON(self.polygonVertices);
        const source = self.map.getSource(self.polygonSourceId);
        if (source) {
          source.setData(geojson);
        }
      });

      // Double-click to close polygon
      this.map.on('dblclick', (e) => {
        if (!self.drawingMode) return;
        e.preventDefault();
        self.finishDrawing();
      });

      // Enable vertex dragging
      this._setupVertexDragging();
    },

    /**
     * Enable dragging polygon vertices to reshape
     */
    _setupVertexDragging: function() {
      if (!this.map) return;
      const self = this;
      let dragIdx = -1;

      this.map.on('mousedown', 'lenuda-polygon-vertices', (e) => {
        if (self.drawingMode) return;
        e.preventDefault();
        const features = self.map.queryRenderedFeatures(e.point, { layers: ['lenuda-polygon-vertices'] });
        if (features.length > 0) {
          dragIdx = features[0].properties.vertexIndex;
          self.map.getCanvas().style.cursor = 'grabbing';

          const onMove = (moveE) => {
            if (dragIdx === -1) return;
            self.polygonVertices[dragIdx] = [moveE.lngLat.lng, moveE.lngLat.lat];
            const source = self.map.getSource(self.polygonSourceId);
            if (source) {
              source.setData(self._polygonToGeoJSON(self.polygonVertices));
            }
          };

          const onUp = () => {
            dragIdx = -1;
            self.map.getCanvas().style.cursor = '';
            self.map.off('mousemove', onMove);
            self.map.off('mouseup', onUp);
          };

          self.map.on('mousemove', onMove);
          self.map.on('mouseup', onUp);
        }
      });

      this.map.on('mouseenter', 'lenuda-polygon-vertices', () => {
        if (!self.drawingMode) self.map.getCanvas().style.cursor = 'pointer';
      });

      this.map.on('mouseleave', 'lenuda-polygon-vertices', () => {
        if (!self.drawingMode) self.map.getCanvas().style.cursor = '';
      });
    },

    // ============================================================
    // FLY TO / GEOCODING
    // ============================================================

    /**
     * Fly the map to a specific location
     * @param {number} lng - Longitude
     * @param {number} lat - Latitude
     * @param {number} zoom - Optional zoom level
     */
    flyTo: function(lng, lat, zoom) {
      if (this.isFallback || !this.map) return;
      this.map.flyTo({
        center: [lng, lat],
        zoom: zoom || 12,
        speed: 1.2,
        curve: 1.4,
        essential: true
      });
    },

    /**
     * Geocode an address string and fly to the result
     * Uses Nominatim (OpenStreetMap) free geocoding API
     * @param {string} address - Address or place name
     * @returns {Promise<{lng: number, lat: number}|null>}
     */
    geocode: async function(address) {
      if (!address) return null;
      try {
        const encoded = encodeURIComponent(address);
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encoded}&format=json&limit=1`,
          { headers: { 'Accept': 'application/json' } }
        );
        const results = await response.json();
        if (results && results.length > 0) {
          const lng = parseFloat(results[0].lon);
          const lat = parseFloat(results[0].lat);
          this.flyTo(lng, lat, 13);
          return { lng, lat };
        }
        console.warn('[LenudaMap] Geocoding returned no results for:', address);
        return null;
      } catch (err) {
        console.warn('[LenudaMap] Geocoding failed:', err);
        return null;
      }
    },

    // ============================================================
    // GEE LAYER MANAGEMENT
    // ============================================================

    /**
     * Add a GEE analysis result layer overlay to the map
     * @param {object} data - GEE scan result data from backend
     *   Expected shape: { layer_id, geojson, style?, type? }
     *   or: { tiles_url, bounds? }
     */
    addGeeLayer: function(data) {
      if (this.isFallback || !this.map || !this.isReady) return;

      const layerId = data.layer_id || `gee-layer-${Date.now()}`;
      const sourceId = `gee-source-${layerId}`;

      // Remove previous layer if it exists
      this._removeLayerSafe(layerId);
      this._removeLayerSafe(`${layerId}-outline`);
      this._removeSourceSafe(sourceId);

      if (data.tiles_url) {
        // Raster tile layer from GEE
        this.map.addSource(sourceId, {
          type: 'raster',
          tiles: [data.tiles_url],
          tileSize: 256
        });

        this.map.addLayer({
          id: layerId,
          type: 'raster',
          source: sourceId,
          paint: {
            'raster-opacity': data.opacity || 0.7
          }
        });

      } else if (data.geojson) {
        // Vector GeoJSON layer
        this.map.addSource(sourceId, {
          type: 'geojson',
          data: data.geojson
        });

        const colors = this.domainColors[this.currentDomain] || this.domainColors.agriculture;
        const style = data.style || {};

        this.map.addLayer({
          id: layerId,
          type: 'fill',
          source: sourceId,
          paint: {
            'fill-color': style.fillColor || colors.fill,
            'fill-opacity': style.fillOpacity || 0.5
          }
        });

        this.map.addLayer({
          id: `${layerId}-outline`,
          type: 'line',
          source: sourceId,
          paint: {
            'line-color': style.strokeColor || colors.stroke,
            'line-width': style.strokeWidth || 2
          }
        });
      }

      this.geeLayerIds.push(layerId);

      // Fit bounds if provided
      if (data.bounds) {
        this.map.fitBounds(data.bounds, { padding: 40 });
      } else if (data.geojson && data.geojson.bbox) {
        this.map.fitBounds([
          [data.geojson.bbox[0], data.geojson.bbox[1]],
          [data.geojson.bbox[2], data.geojson.bbox[3]]
        ], { padding: 40 });
      }
    },

    /**
     * Remove all GEE overlay layers
     */
    clearGeeLayers: function() {
      if (this.isFallback || !this.map) return;

      this.geeLayerIds.forEach(layerId => {
        this._removeLayerSafe(layerId);
        this._removeLayerSafe(`${layerId}-outline`);
        this._removeSourceSafe(`gee-source-${layerId}`);
      });
      this.geeLayerIds = [];
    },

    // ============================================================
    // SATELLITE VIEW TOGGLE
    // ============================================================

    /**
     * Toggle satellite basemap view
     * @param {boolean} show - true to show satellite, false for dark OSM
     */
    showSatelliteView: function(show) {
      if (this.isFallback || !this.map) return;

      if (show) {
        this.map.setLayoutProperty('satellite-base', 'visibility', 'visible');
        this.map.setPaintProperty('osm-base', 'raster-opacity', 0.15);
      } else {
        this.map.setLayoutProperty('satellite-base', 'visibility', 'none');
        this.map.setPaintProperty('osm-base', 'raster-opacity', 0.6);
      }
    },

    // ============================================================
    // DOMAIN INTEGRATION
    // ============================================================

    /**
     * Update map for a new domain (new center, colors, etc.)
     * @param {string} domainId - The domain identifier
     */
    setDomain: function(domainId) {
      this.currentDomain = domainId;
      if (this.isFallback || !this.map || !this.isReady) return;

      const center = this.domainCenters[domainId];
      if (center) {
        this.flyTo(center.lng, center.lat, center.zoom);
      }

      // Update polygon colors
      const colors = this.domainColors[domainId] || this.domainColors.agriculture;
      try {
        this.map.setPaintProperty(this.polygonLayerId, 'fill-color', colors.fill);
        this.map.setPaintProperty('lenuda-polygon-outline', 'line-color', colors.stroke);
      } catch (e) {
        // Layer may not exist yet
      }
    },

    /**
     * Add a marker to the map
     * @param {number} lng
     * @param {number} lat
     * @param {object} options - { color, popup }
     */
    addMarker: function(lng, lat, options = {}) {
      if (this.isFallback || !this.map) return null;

      const marker = new maplibregl.Marker({
        color: options.color || '#ffb703'
      }).setLngLat([lng, lat]);

      if (options.popup) {
        const popup = new maplibregl.Popup({ offset: 25 })
          .setHTML(options.popup);
        marker.setPopup(popup);
      }

      marker.addTo(this.map);
      this.markers.push(marker);
      return marker;
    },

    /**
     * Clear all markers
     */
    clearMarkers: function() {
      this.markers.forEach(m => m.remove());
      this.markers = [];
    },

    /**
     * Resize the map (call after container size changes)
     */
    resize: function() {
      if (this.map && !this.isFallback) {
        this.map.resize();
      }
    },

    /**
     * Destroy the map instance
     */
    destroy: function() {
      if (this.map && !this.isFallback) {
        this.map.remove();
        this.map = null;
      }
      this.isReady = false;
    },

    // ============================================================
    // HELPER / PRIVATE METHODS
    // ============================================================

    _emptyPolygonGeoJSON: function() {
      return {
        type: 'FeatureCollection',
        features: []
      };
    },

    _polygonToGeoJSON: function(coords) {
      const features = [];

      // Build polygon feature if we have at least 3 vertices
      if (coords.length >= 3) {
        const ring = coords.map(c => [c[0], c[1]]);
        ring.push(ring[0]); // Close the ring
        features.push({
          type: 'Feature',
          geometry: {
            type: 'Polygon',
            coordinates: [ring]
          },
          properties: {}
        });
      }

      // Add vertex point features for dragging handles
      coords.forEach((c, i) => {
        features.push({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [c[0], c[1]]
          },
          properties: { vertexIndex: i }
        });
      });

      return {
        type: 'FeatureCollection',
        features: features
      };
    },

    _removeLayerSafe: function(layerId) {
      if (!this.map) return;
      try {
        if (this.map.getLayer(layerId)) {
          this.map.removeLayer(layerId);
        }
      } catch (e) { /* layer might not exist */ }
    },

    _removeSourceSafe: function(sourceId) {
      if (!this.map) return;
      try {
        if (this.map.getSource(sourceId)) {
          this.map.removeSource(sourceId);
        }
      } catch (e) { /* source might not exist */ }
    },

    /**
     * Fallback canvas initialization when MapLibre is unavailable.
     * This just renders a placeholder message in the container.
     */
    _initFallbackCanvas: function(container) {
      console.log('[LenudaMap] Using canvas fallback mode.');
      // The existing canvas-based GIS map in app.js will continue to work
      // We just mark ourselves as fallback so all LenudaMap calls are no-ops
      this.isFallback = true;
      this.isReady = true;
    }
  };

  // ============================================================
  // EXPOSE GLOBALLY
  // ============================================================
  window.LenudaMap = LenudaMap;

})();
