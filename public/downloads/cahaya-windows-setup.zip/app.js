// LENUDA Premium - Core Application State & UI Manager

// 1. Initial State Definitions
const domainsData = [
  {
    id: "agriculture",
    companionBim: [
      {
            "name": "torchgeo",
            "url": "https://github.com/microsoft/torchgeo",
            "desc": "Geospatial ML dataset loading and crop classification models."
      },
      {
            "name": "mmsegmentation",
            "url": "https://github.com/openmmlab/mmsegmentation",
            "desc": "Semantic segmentation toolbox for vegetation canopy tracking."
      },
      {
            "name": "PlantDoc-Object-Detection",
            "url": "https://github.com/duangenquan/PlantDoc-Object-Detection",
            "desc": "Object detection dataset and models for plant disease identification."
      }
],
    companionGis: [
      {
            "name": "leafmap",
            "url": "https://github.com/opengeos/leafmap",
            "desc": "Interactive GIS mapping with Google Earth Engine, Folium, and IPyleaflet."
      },
      {
            "name": "eo-learn",
            "url": "https://github.com/sentinel-hub/eo-learn",
            "desc": "Earth observation processing framework for machine learning in Python."
      },
      {
            "name": "dynamicworld",
            "url": "https://github.com/google/dynamicworld",
            "desc": "Real-time 10-meter land cover classification dataset using deep learning."
      }
],
    companionSim: [
      {
            "name": "dssat-csm-os",
            "url": "https://github.com/DSSAT/dssat-csm-os",
            "desc": "Decision Support System for Agrotechnology Transfer crop simulation."
      },
      {
            "name": "ApsimX",
            "url": "https://github.com/APSIMInitiative/ApsimX",
            "desc": "Next-generation Agricultural Production Systems Simulator."
      }
],
    name: "🌾 Agriculture / Plantation / ESG",
    theme: "agriculture",
    satellites: ["Sentinel-2A", "Sentinel-2B", "Landsat 9", "Wyvern 1", "Constellr"],
    ingestFiles: [
      { name: "orthomosaic_hectare_40.tiff", size: "220 MB", density: "45 pts/m²", type: "Orthophoto" },
      { name: "lidar_crop_heights.las", size: "1.4 GB", density: "120 pts/m²", type: "LiDAR Point Cloud" }
    ],
    gisFeatures: [
      { id: "canopy-zone-1", name: "North Hectare Canopy Grid", type: "GeoJSON Polygon", area: "12.4 ha", trees: 1840, status: "Active", nitrogen: "Optimal" },
      { id: "canopy-zone-2", name: "South Slope Drainage Area", type: "GeoJSON Polygon", area: "8.2 ha", trees: 1104, status: "Under-planted", nitrogen: "Deficient" },
      { id: "soil-sensor-nodes", name: "Soil Moisture Sensor Array", type: "PostGIS Points", count: 8, status: "Online", moisture: "48%" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Multi-Rotor Pesticide Sprayer Hub
nozzle_radius = 4.2
hub_thickness = 15.0
arms_count = 6

result = cq.Workplane("XY").circle(25.0).extrude(hub_thickness)
for i in range(arms_count):
    angle = (360.0 / arms_count) * i
    result = result.faces(">Z").workplane().transformed(rotate=(0, 0, angle))\\
        .rect(8.0, 45.0).extrude(10.0, combine=True)

# Export B-Rep engineering primitive
show_object(result)`,
    scenarios: [
      { name: "90-Day Severe Drought Stress", description: "Models 90 days of absolute soil moisture depletion across multiple soil profile layers.", variables: [{ name: "Drought Severity", min: 1, max: 10, val: 8 }, { name: "Root Depth (m)", min: 0.5, max: 4.0, val: 1.5 }] },
      { name: "Miyawaki High-Density Forest Test", description: "Simulates canopy growth, survival, and competition of ultra-dense planting models.", variables: [{ name: "Tree Density / m²", min: 1, max: 8, val: 3 }, { name: "Species Diversity Index", min: 2, max: 15, val: 8 }] },
      { name: "Deforestation Carbon Loss Calc", description: "Projects instant and multi-decade carbon asset drops following forest canopy clearing.", variables: [{ name: "Clearing Rate (ha/yr)", min: 1, max: 100, val: 25 }] },
      { name: "Cross-Breeding Canopy Growth", description: "Models structural leaf leaf canopy variation and growth profiles for hybrid crops.", variables: [{ name: "Hybridization Constant", min: 0.1, max: 2.0, val: 1.2 }] },
      { name: "Live Vegetation Wind Friction", description: "Models branch snapping risks and root uprooting during high wind storm velocities.", variables: [{ name: "Wind Velocity (km/h)", min: 10, max: 180, val: 90 }] },
      { name: "Macro Soil Erosion Runoff", description: "Simulates severe downpours to model topsoil wash-away paths on rolling plantation hills.", variables: [{ name: "Rainfall Rate (mm/h)", min: 5, max: 100, val: 45 }] },
      { name: "Fertilizer Dispersion Hydrology", description: "Traces nitrogen chemical travel through soil water layers to prevent creek poisoning.", variables: [{ name: "Fertilizer Volume (kg/ha)", min: 50, max: 500, val: 150 }] },
      { name: "Plantation Pest Spread Trajectory", description: "Simulates pest movement vectors based on tree planting spatial densities.", variables: [{ name: "Pest R-Value", min: 1.1, max: 5.0, val: 2.3 }] },
      { name: "Harvest Fleet Route Soil Wear", description: "Models soil compaction and structural damage from heavy collection machinery.", variables: [{ name: "Fleet Tonnage", min: 5, max: 40, val: 15 }] },
      { name: "Carbon Credit ROI Lifespan Model", description: "Forecasts carbon offsets yields under fluctuating multi-decade temperature models.", variables: [{ name: "Project Duration (yrs)", min: 5, max: 50, val: 25 }] }
    ]
  },
  {
    id: "mining",
    companionBim: [
      {
            "name": "PDAL",
            "url": "https://github.com/PDAL/PDAL",
            "desc": "Point Data Abstraction Library for translating/filtering LiDAR point clouds."
      },
      {
            "name": "LAStools",
            "url": "https://github.com/LAStools/LAStools",
            "desc": "Industry-standard tools for rapid LiDAR processing and elevation model generation."
      },
      {
            "name": "pcl",
            "url": "https://github.com/PointCloudLibrary/pcl",
            "desc": "3D Point Cloud Library for processing complex excavation shapes."
      }
],
    companionGis: [
      {
            "name": "QGIS",
            "url": "https://github.com/qgis/QGIS",
            "desc": "Desktop GIS platform used for spatial analysis and geologic plotting."
      },
      {
            "name": "GDAL",
            "url": "https://github.com/OSGeo/gdal",
            "desc": "Geospatial Data Abstraction Library for converting GeoTIFF/DEM raster terrain."
      }
],
    companionSim: [
      {
            "name": "gempy",
            "url": "https://github.com/cgre-aachen/gempy",
            "desc": "Implicit 3D geological modeling for structural and subsurface ore estimation."
      },
      {
            "name": "gimli",
            "url": "https://github.com/gimli-org/gimli",
            "desc": "PyGIMLi multi-method library for geophysical modeling and resistivity sweeps."
      },
      {
            "name": "landlab",
            "url": "https://github.com/landlab/landlab",
            "desc": "Open-source Python library for modeling slope risk and earth surface physics."
      }
],
    name: "⛏️ Mining / Geospatial Exploration",
    theme: "mining",
    satellites: ["Sentinel-1A", "Sentinel-1B", "ALOS-2", "Terra MODIS", "NASA ASTER"],
    ingestFiles: [
      { name: "pit_wall_lidar_scan.laz", size: "840 MB", density: "180 pts/m²", type: "LiDAR Point Cloud" },
      { name: "stockpile_volumetrics.las", size: "1.1 GB", density: "250 pts/m²", type: "LiDAR Point Cloud" }
    ],
    gisFeatures: [
      { id: "pit-wall-mesh", name: "Highwall Sector 4 Mesh", type: "ESRI Shapefile", elevation: "120m", slope: "68°", structural_fractures: 2, safety: "Stable" },
      { id: "stockpile-1", name: "Copper Ore Stockpile Alpha", type: "ESRI Shapefile", volume: "14,800 m³", density: "2.6 t/m³", grade: "1.4%" },
      { id: "haul-road-north", name: "North Haulage Ramp Segment", type: "PostGIS LineString", grade: "12%", width: "18m", status: "Open" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Subsurface Mining Drill Bit head
shaft_diameter = 30.0
cutters_count = 5
bit_height = 80.0

drill_bit = cq.Workplane("XY").circle(shaft_diameter/2).extrude(bit_height)
for i in range(cutters_count):
    angle = (360.0 / cutters_count) * i
    drill_bit = drill_bit.faces(">Z").workplane().transformed(rotate=(0, 0, angle))\\
        .rect(12.0, 6.0).extrude(15.0, combine=True)

show_object(drill_bit)`,
    scenarios: [
      { name: "Subsurface Borehole Collapse", description: "Models structural casing failures under extreme deep rock pressure profiles.", variables: [{ name: "Depth (m)", min: 100, max: 2000, val: 850 }] },
      { name: "Structural Pit Wall Failure", description: "Simulates rock wall cave-ins using slope friction and underground moisture variables.", variables: [{ name: "Slope Angle (°)", min: 30, max: 85, val: 65 }] },
      { name: "Blasting Vibration Propagation", description: "Models seismic wave velocities through rock layers to safeguard operations.", variables: [{ name: "Charge Weight (kg)", min: 50, max: 1000, val: 250 }] },
      { name: "Tailings Dam Breach Inundation", description: "Simulates mud and chemical spill paths down valley slopes in dam collapse.", variables: [{ name: "Fluid Viscosity", min: 1, max: 50, val: 12 }] },
      { name: "Shaft Load & Pillar Stability", description: "Computes rock weight tolerances and safety margins of support structures.", variables: [{ name: "Pillar Thickness (m)", min: 2, max: 12, val: 5 }] },
      { name: "Haul Truck Fuel Burn Simulation", description: "Models truck fuel and brake wear cycles over changing slope gradients.", variables: [{ name: "Cargo Load (tons)", min: 50, max: 400, val: 220 }] },
      { name: "Subsurface Aquifer Inflow Risk", description: "Simulates ground water flood velocities when crossing local fault lines.", variables: [{ name: "Fault Permeability", min: 0.1, max: 10, val: 2.5 }] },
      { name: "Ore Pile Leaching Chemical Flow", description: "Models cyanide fluid paths to optimize gold extraction layouts.", variables: [{ name: "Irrigation Rate (L/h)", min: 100, max: 2000, val: 500 }] },
      { name: "Site Reclamation Topography Model", description: "Simulates topsoil grading stability for post-mining reforestation.", variables: [{ name: "Grading Slope (%)", min: 1, max: 30, val: 8 }] },
      { name: "Mineral Vein Geometry Inference", description: "Predicts ore geometry vectors based on core drilling samples data.", variables: [{ name: "Core Samples Count", min: 5, max: 100, val: 18 }] }
    ]
  },
  {
    id: "disaster",
    companionBim: [
      {
            "name": "rtabmap",
            "url": "https://github.com/introlab/rtabmap",
            "desc": "3D spatial scan alignment for locating structural collapse hazards."
      },
      {
            "name": "Open3D",
            "url": "https://github.com/isl-org/Open3D",
            "desc": "3D data processing library for processing post-disaster scan files."
      }
],
    companionGis: [
      {
            "name": "geopandas",
            "url": "https://github.com/geopandas/geopandas",
            "desc": "Run geographic proximity queries and locate flood shelter coordinates."
      },
      {
            "name": "rasterio",
            "url": "https://github.com/rasterio/rasterio",
            "desc": "Access and analyze satellite disaster boundaries and water extents."
      }
],
    companionSim: [
      {
            "name": "pyflwdir",
            "url": "https://github.com/pyflwdir/pyflwdir",
            "desc": "Fast flow direction extraction and delineation of drainage basins."
      },
      {
            "name": "hydroDL",
            "url": "https://github.com/creare-com/hydroDL",
            "desc": "Deep learning hydrology models for streamflow and water quality forecasting."
      },
      {
            "name": "hydromt",
            "url": "https://github.com/Deltares/hydromt",
            "desc": "Build hydrology models dynamically from global public datasets."
      },
      {
            "name": "pangeo",
            "url": "https://github.com/pangeo-data/pangeo",
            "desc": "Platform for big data geoscience, climate, and weather modeling."
      },
      {
            "name": "firedrake",
            "url": "https://github.com/firedrakeproject/firedrake",
            "desc": "Automated PDE solver utilized for fluid dynamics and wave propagation."
      },
      {
            "name": "pyrocko",
            "url": "https://github.com/pyrocko/pyrocko",
            "desc": "Seismological data processing framework for earthquake source modeling."
      }
],
    name: "🌊 Disaster Management",
    theme: "disaster",
    satellites: ["COSMO-SkyMed 1", "COSMO-SkyMed 4", "GOES-16", "GOES-17", "GPM Core"],
    ingestFiles: [
      { name: "flood_elevation_contour.shp", size: "45 MB", density: "N/A (Vector)", type: "Shapefile Vector" },
      { name: "drone_damage_grid.jpg", size: "85 MB", density: "N/A (Raster)", type: "Orthophoto" }
    ],
    gisFeatures: [
      { id: "flood-extent-poly", name: "Active River Flood Boundary", type: "Live PMTiles Vector", depth: "2.4m", velocity: "1.8 m/s", area: "84 ha" },
      { id: "evac-route-primary", name: "Evacuation Route Highway 2", type: "Live PMTiles Vector", status: "Flooded (Closed)", capacity: "2400 cars/h" },
      { id: "emergency-shelter-1", name: "Community Center Refuge Alpha", type: "PostGIS Point", capacity: "450 persons", occupied: "380", status: "Active" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Interlocking Flood Barrier Block
barrier_height = 80.0
barrier_width = 120.0
groove_depth = 8.0

block = cq.Workplane("XY").box(barrier_width, 40.0, barrier_height)
# Create male connector tab
block = block.faces(">X").workplane().rect(10.0, 20.0).extrude(groove_depth)
# Create female receiver slot
block = block.faces("<X").workplane().rect(10.5, 20.5).cutBlind(-groove_depth)

show_object(block)`,
    scenarios: [
      { name: "7.2M Earthquake Shear Wave", description: "Simulates seismic shock propagation across city layouts, flagging collapse risks.", variables: [{ name: "Magnitude", min: 5.0, max: 9.0, val: 7.2 }, { name: "Soil Damping", min: 0.1, max: 1.0, val: 0.4 }] },
      { name: "Flash Flood Wave Propagation", description: "Simulates water wave movement over high-res elevation grids post dam breach.", variables: [{ name: "Breach Width (m)", min: 10, max: 150, val: 45 }, { name: "Water Volume (m³)", min: 10000, val: 100000, step: 10000, val: 50000 }] },
      { name: "Wildfire Firefront Spread Vector", description: "Predicts fireline direction based on wood fuel load and wind velocity.", variables: [{ name: "Wind Speed (m/s)", min: 0, max: 40, val: 18 }, { name: "Wood Moisture (%)", min: 5, max: 35, val: 12 }] },
      { name: "Civilian Mass Evacuation Flow", description: "Populates digital twins with pathfinding agents to isolate exit bottlenecks.", variables: [{ name: "Population Count", min: 500, max: 10000, val: 3000 }] },
      { name: "Tsunami Coastal Inundation Runout", description: "Models wave height attenuation and impact forces on coastal seawalls.", variables: [{ name: "Tsunami Wave Height (m)", min: 1, max: 25, val: 8 }] },
      { name: "Bridge Structural Failure Stress", description: "Computes structural tolerances of bridges against debris impact forces.", variables: [{ name: "River Velocity (m/s)", min: 1, max: 10, val: 4 }] },
      { name: "Hazardous Gas Plume Dispersion", description: "Models airborne toxic gas dispersion under shifting wind vectors.", variables: [{ name: "Leak Rate (kg/s)", min: 1, max: 100, val: 15 }] },
      { name: "Hospital Triage Patient Surge", description: "Predicts medical facility capacities under sudden casualty input spikes.", variables: [{ name: "Casualties Spawning", min: 20, max: 500, val: 120 }] },
      { name: "Slope Landslide Runout Pathway", description: "Predicts landslide debris trajectories and volumes down slope grids.", variables: [{ name: "Soil Water Saturation (%)", min: 20, max: 100, val: 85 }] },
      { name: "Emergency Telecom Failover Grid", description: "Simulates network coverage losses when key power nodes collapse.", variables: [{ name: "Active Cell Towers", min: 5, max: 50, val: 24 }] }
    ]
  },
  {
    id: "urban",
    companionBim: [
      {
            "name": "IfcOpenShell",
            "url": "https://github.com/IfcOpenShell/IfcOpenShell",
            "desc": "Parse and analyze Industry Foundation Classes (IFC) BIM models."
      },
      {
            "name": "BIMserver",
            "url": "https://github.com/opensourceBIM/BIMserver",
            "desc": "Storing, collaborating, and managing IFC projects dynamically."
      }
],
    companionGis: [
      {
            "name": "py3dtiles",
            "url": "https://github.com/opengeos/py3dtiles",
            "desc": "Utility to convert point clouds and shapefiles into 3D Tiles format."
      },
      {
            "name": "cesium",
            "url": "https://github.com/CesiumGS/cesium",
            "desc": "3D globe and geospatial visualization library for smart cities."
      },
      {
            "name": "CityJSON",
            "url": "https://github.com/OSGeo/CityJSON",
            "desc": "JSON-based encoding for storing 3D city models."
      }
],
    companionSim: [
      {
            "name": "socialsim",
            "url": "https://github.com/uscuni/socialsim",
            "desc": "High-fidelity agent-based simulation of large-scale social behavior."
      },
      {
            "name": "matsim",
            "url": "https://github.com/matsim-org/matsim",
            "desc": "Multi-agent transport simulation framework for travel demand."
      }
],
    name: "🏙️ Urban Planning / Smart Cities",
    theme: "urban",
    satellites: ["Suomi NPP VIIRS", "Landsat 8", "ICESat-2", "Cartosat-3"],
    ingestFiles: [
      { name: "urban_tree_canopy.las", size: "1.8 GB", density: "65 pts/m²", type: "LiDAR Point Cloud" },
      { name: "building_extrusions.geojson", size: "120 MB", density: "N/A", type: "GeoJSON Vectors" }
    ],
    gisFeatures: [
      { id: "building-block-1", name: "Zoning Sector 5 Commercial Complex", type: "CityGML Building", stories: 12, height: "45.0m", footprints: "4,200 m²", solar_potential: "High" },
      { id: "neighborhood-park-1", name: "Green Space Buffer Zone", type: "CityGML Building", area: "2.4 ha", tree_count: 320, thermal_index: "Cool" },
      { id: "city-noise-sensor", name: "Downtown Noise Decibel Log", type: "PostGIS Point", decibels: "72 dB", status: "Active" }
    ],
    cadQueryScript: `import cadquery as cq

# Green-Energy Solar Roof Panel Mount Bracket
tilt_angle = 20.0
base_width = 30.0
mount_height = 18.0

base = cq.Workplane("XY").box(base_width, 10.0, 5.0)
mount = base.faces(">Z").workplane().rect(10.0, 8.0).extrude(mount_height)
angled_cut = mount.faces(">Y").workplane().transformed(rotate=(tilt_angle, 0, 0))\\
    .rect(12.0, 15.0).cutBlind(-15.0)

show_object(angled_cut)`,
    scenarios: [
      { name: "City Microclimate Heat Island", description: "Simulates how pocket parks reduce ambient brick/concrete pavement temperatures.", variables: [{ name: "Park Coverage (%)", min: 1, max: 40, val: 12 }] },
      { name: "10-Year Traffic Flow Expansion", description: "Simulates citizen routing choices across proposed highway lanes additions.", variables: [{ name: "New Lane Count", min: 0, max: 4, val: 1 }] },
      { name: "Zoning Law Sky-Line Shadow Audit", description: "Audits solar shadow obstruction across blocks when height limits increase.", variables: [{ name: "Zoning Height Limit (m)", min: 15, max: 150, val: 60 }] },
      { name: "Stormwater Pipe Capacity Stress", description: "Simulates local drainage overload risks during severe 100-year rainstorms.", variables: [{ name: "Storm Intensity", min: 1, max: 10, val: 7 }] },
      { name: "Pedestrian Commerce Attractiveness", description: "Models shopping foot traffic choices based on shade trees and crosswalk layouts.", variables: [{ name: "Tree Shading Index", min: 0.1, max: 1.0, val: 0.6 }] },
      { name: "Urban Noise Propagation Geometry", description: "Models traffic sound dispersion through blocks to design acoustic barrier walls.", variables: [{ name: "Traffic Volume (cars/h)", min: 100, max: 5000, val: 1800 }] },
      { name: "Sewer Infrastructure Gravity Flow", description: "Verifies waste pipe velocities to prevent backflow and block risks.", variables: [{ name: "Slope Gradient (%)", min: 0.1, max: 5.0, val: 1.5 }] },
      { name: "High-Rise Building Wind Tunnel", description: "Models aerodynamic street wind speeds caused by skyscraper alignments.", variables: [{ name: "Ambient Wind Speed (m/s)", min: 2, max: 25, val: 12 }] },
      { name: "Public Transit Accessibility Audit", description: "Simulates walking times to verify bus network coverage grids.", variables: [{ name: "Max Walk Range (m)", min: 200, max: 2000, val: 600 }] },
      { name: "City Expansion Utility Load Project", description: "Models electricity and water loads across newly zoned suburban sectors.", variables: [{ name: "Population Growth Rate (%)", min: 0.5, max: 5.0, val: 2.2 }] }
    ]
  },
  {
    id: "utilities",
    companionBim: [
      {
            "name": "IfcOpenShell",
            "url": "https://github.com/IfcOpenShell/IfcOpenShell",
            "desc": "Parse utility BIM networks and substation geometry."
      },
      {
            "name": "PDAL",
            "url": "https://github.com/PDAL/PDAL",
            "desc": "Point cloud translation for transmission line encroachment audits."
      }
],
    companionGis: [
      {
            "name": "leafmap",
            "url": "https://github.com/opengeos/leafmap",
            "desc": "Interactive GIS mapping to overlay utility assets."
      },
      {
            "name": "rasterio",
            "url": "https://github.com/rasterio/rasterio",
            "desc": "Analyze thermal grid rasters for substation safety audits."
      }
],
    companionSim: [
      {
            "name": "pst",
            "url": "https://github.com/power-system-simulation-toolbox/pst",
            "desc": "Power system simulation toolbox for transient stability analysis."
      },
      {
            "name": "pandapower",
            "url": "https://github.com/e2nIEE/pandapower",
            "desc": "Power system modeling, analysis, and optimization framework."
      },
      {
            "name": "gldesk",
            "url": "https://github.com/GridMod/gldesk",
            "desc": "Desktop GUI wrapper for GridLAB-D power flow simulations."
      },
      {
            "name": "epanet-toolkit",
            "url": "https://github.com/OpenWaterAnalytics/epanet-toolkit",
            "desc": "Hydraulic and water quality simulation in pressurized pipe networks."
      },
      {
            "name": "opengridproject",
            "url": "https://github.com/opengridproject",
            "desc": "Simulation and analysis of electrical transmission grid networks."
      }
],
    name: "⚡ Utilities (Water / Electricity / Energy)",
    theme: "utilities",
    satellites: ["Sentinel-3", "Landsat 7", "Aqua MODIS", "Umbra SAR Array", "Constellr"],
    ingestFiles: [
      { name: "substation_thermal_points.tiff", size: "150 MB", density: "N/A", type: "Raster GeoTIFF" },
      { name: "powerline_corridor.laz", size: "2.5 GB", density: "220 pts/m²", type: "LiDAR Point Cloud" }
    ],
    gisFeatures: [
      { id: "transformer-sub-4", name: "Substation Alpha Transformer 4", type: "PostGIS Feature Table", load: "84%", temperature: "78°C", status: "Active (Anomaly)" },
      { id: "pipe-main-west", name: "West Valley Water Conduit Main", type: "PostGIS Feature Table", pressure: "120 PSI", diameter: "48 in", status: "Active" },
      { id: "reservoir-depth", name: "Hydro Station Reservoir", type: "PostGIS Feature Table", capacity: "65%", volume: "1.2M m³", status: "Optimal" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric High-Voltage Electrical Insulator Spacer
ring_count = 6
ring_spacing = 12.0
core_radius = 8.0

spacer = cq.Workplane("XY").circle(core_radius).extrude(ring_count * ring_spacing)
for i in range(ring_count):
    z_pos = (i * ring_spacing) + (ring_spacing/2.0)
    spacer = spacer.faces(">Z").workplane().transformed(offset=(0, 0, -z_pos))\\
        .circle(18.0).extrude(4.0, combine=True)

show_object(spacer)`,
    scenarios: [
      { name: "Cascade Power Substation Trip", description: "Models grid route changes and blackout ranges if a primary substation fails.", variables: [{ name: "Grid Load Index (%)", min: 50, max: 120, val: 90 }] },
      { name: "High-Pressure Water Main Burst", description: "Simulates ground erosion washouts and street sinkhole risks post rupture.", variables: [{ name: "Pipe Pressure (PSI)", min: 40, max: 200, val: 120 }] },
      { name: "Solar Array Output Optimization", description: "Models long term output metrics using cloud history maps and solar tilt.", variables: [{ name: "Active Panels Count", min: 1000, max: 50000, val: 12000 }] },
      { name: "Vegetation Encroachment Flashover", description: "Models powerline branch contact shorts during heavy wind conditions.", variables: [{ name: "Branch Wind Deflection", min: 0.1, max: 3.0, val: 1.2 }] },
      { name: "Gas Pipeline Pressure Drop", description: "Projects gas pressure drops across nodes during winter spikes.", variables: [{ name: "Demand Multiplier", min: 1.0, max: 3.0, val: 1.8 }] },
      { name: "Hydroelectric Reservoir Siltation", description: "Forecasts reservoir siltation build-ups and operating lifetimes.", variables: [{ name: "Silt Inflow (tons/yr)", min: 100, max: 10000, val: 1500 }] },
      { name: "Wind Turbine Wake Interference", description: "Models wind turbulence behind turbines to optimize alignment positions.", variables: [{ name: "Spacing (Diameters)", min: 3, max: 12, val: 5 }] },
      { name: "Subterranean Cable Heat Review", description: "Models temperature impacts on high-voltage underground cables.", variables: [{ name: "Soil Thermal Res (K-m/W)", min: 0.5, max: 2.0, val: 1.2 }] },
      { name: "Water Plant Inflow Shock Test", description: "Models filter reaction rates when effluent contamination spikes.", variables: [{ name: "Contamination PPM", min: 5, max: 500, val: 85 }] },
      { name: "Smart-Grid Smart Balancing Loop", description: "Tests response speed when unstable wind/solar power hits grid.", variables: [{ name: "Renewable Load Ratio (%)", min: 10, max: 90, val: 45 }] }
    ]
  },
  {
    id: "logistics",
    companionBim: [
      {
            "name": "BIMserver",
            "url": "https://github.com/opensourceBIM/BIMserver",
            "desc": "Collaborate on cargo terminal and warehouse layout files."
      },
      {
            "name": "Open3D",
            "url": "https://github.com/isl-org/Open3D",
            "desc": "Port container yard volume calculation and scanner alignment."
      }
],
    companionGis: [
      {
            "name": "QGIS",
            "url": "https://github.com/qgis/QGIS",
            "desc": "Manage spatial routing files, zones, and coordinate boundaries."
      },
      {
            "name": "geopandas",
            "url": "https://github.com/geopandas/geopandas",
            "desc": "Run geographic proximity queries on fleet telemetry streams."
      }
],
    companionSim: [
      {
            "name": "or-tools",
            "url": "https://github.com/google/or-tools",
            "desc": "Fast mathematical optimization for vehicle routing and operations."
      },
      {
            "name": "osrm-backend",
            "url": "https://github.com/Project-OSRM/osrm-backend",
            "desc": "High-performance routing engine for shortest paths in road networks."
      },
      {
            "name": "graphhopper",
            "url": "https://github.com/graphhopper/graphhopper",
            "desc": "Fast and memory-efficient routing engine in Java."
      },
      {
            "name": "sumo",
            "url": "https://github.com/eclipse-sumo/sumo",
            "desc": "Simulation of Urban MObility for microscopic traffic flows."
      },
      {
            "name": "sas-optimization",
            "url": "https://github.com/sassoftware/sas-optimization",
            "desc": "Concept reference for supply chain constraints and linear programming."
      }
],
    name: "🚚 Logistics / Supply Chain",
    theme: "logistics",
    satellites: ["Sentinel-1A", "Sentinel-2B", "Terra MODIS", "Jason-3", "Suomi NPP VIIRS"],
    ingestFiles: [
      { name: "port_container_yards.jpg", size: "90 MB", density: "N/A", type: "Orthophoto" },
      { name: "corridor_elevation.las", size: "600 MB", density: "30 pts/m²", type: "LiDAR Point Cloud" }
    ],
    gisFeatures: [
      { id: "route-kl-north", name: "KL Port Delivery Corridor Alpha", type: "GeoJSON LineString", traffic: "High", delay: "42 min", trucks_active: 14 },
      { id: "berth-berth-3", name: "Berthing Terminal Cargo Dock 3", type: "GeoJSON Polygon", occupancy: "Occupied (Capesize Ship)", cargo_capacity: "12,000 TEU" },
      { id: "warehouse-pallet-array", name: "Warehouse Stack Segment C", type: "GeoJSON Polygon", capacity: "92%", temp: "18.2°C" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Heavy-Duty Cargo Locking Bracket
bracket_length = 60.0
bolt_spacing = 40.0
steel_thickness = 10.0

bracket = cq.Workplane("XY").box(bracket_length, 25.0, steel_thickness)
# Cut two bolt holes
bracket = bracket.faces(">Z").workplane().rect(bolt_spacing, 0.0).vertices().circle(4.5).cutBlind(-steel_thickness)
# Extrude locking tab
bracket = bracket.faces(">Z").workplane().rect(15.0, 15.0).extrude(20.0)

show_object(bracket)`,
    scenarios: [
      { name: "Kuala Lumpur Peak Traffic Jam", description: "Models peak vehicle travel delays and fuel burn rates across delivery corridors.", variables: [{ name: "Traffic Vol Factor", min: 0.5, max: 3.0, val: 2.1 }] },
      { name: "Port Container Yard Gridlock", description: "Simulates stack placement blocks when cargo cranes suffer breakdowns.", variables: [{ name: "Crane Availability (%)", min: 10, max: 100, val: 75 }] },
      { name: "Alternative Airline Fuel Route", description: "Computes wind resistance and fuel burn tradeoffs for long flights.", variables: [{ name: "Headwind Velocity (kts)", min: 0, max: 120, val: 45 }] },
      { name: "Warehouse Forklift Path Optimization", description: "Simulates forklift route loops to decrease travel times and collision risks.", variables: [{ name: "Active Forklifts", min: 2, max: 20, val: 8 }] },
      { name: "Cold-Chain Transport Temp Failure", description: "Models cargo temperature losses when truck refrigeration units break.", variables: [{ name: "Ambient Temp (°C)", min: 15, max: 45, val: 32 }] },
      { name: "Cross-Docking Sorting Velocity", description: "Simulates package movement from inbound to outbound gates.", variables: [{ name: "Inflow Packages / min", min: 10, max: 150, val: 65 }] },
      { name: "Fleet Maintenance Road Wear Test", description: "Models vehicle parts degradation and repair costs over rough route matrices.", variables: [{ name: "Pavement Pothole Density", min: 0.1, max: 2.0, val: 0.8 }] },
      { name: "E-Commerce Next-Day Grid Stress", description: "Simulates shipping sort grids when volumes double.", variables: [{ name: "Sort Volume Multiplier", min: 1.0, max: 4.0, val: 2.2 }] },
      { name: "Rail Freight Cargo Assembly Test", description: "Models freight car coupler sorting speeds to decrease staging delays.", variables: [{ name: "Train Car Count", min: 10, max: 120, val: 60 }] },
      { name: "Drone Delivery Battery Wind Drain", description: "Simulates cargo drone battery drain rates under heavy wind physics.", variables: [{ name: "Payload Weight (kg)", min: 0.5, max: 10.0, val: 3.5 }] }
    ]
  },
  {
    id: "defense",
    companionBim: [
      {
            "name": "PDAL",
            "url": "https://github.com/PDAL/PDAL",
            "desc": "Process battlefield point clouds and high-density terrain scans."
      },
      {
            "name": "rtabmap",
            "url": "https://github.com/introlab/rtabmap",
            "desc": "Real-time localization and mapping for tactical scouting drones."
      }
],
    companionGis: [
      {
            "name": "cesium",
            "url": "https://github.com/CesiumGS/cesium",
            "desc": "3D tactical globe visualization for live airspace tracking."
      },
      {
            "name": "geopandas",
            "url": "https://github.com/geopandas/geopandas",
            "desc": "Analyze topological spatial lines for secure border monitoring."
      }
],
    companionSim: [
      {
            "name": "bullet3",
            "url": "https://github.com/bulletphysics/bullet3",
            "desc": "Real-time collision detection and physics simulation for vehicles."
      },
      {
            "name": "chrono",
            "url": "https://github.com/projectchrono/chrono",
            "desc": "Multiphysics simulation engine for land vehicle tire-soil interaction."
      },
      {
            "name": "librae_3d_engine",
            "url": "https://github.com/librae_3d_engine",
            "desc": "Core simulation engine for tactical scenario visualization."
      },
      {
            "name": "mesa",
            "url": "https://github.com/projectmesa/mesa",
            "desc": "Agent-based modeling framework in Python for swarm movement."
      },
      {
            "name": "anylogic-public-examples",
            "url": "https://github.com/anylogic/anylogic-public-examples",
            "desc": "Reference agent models for logistics and tactical operations."
      },
      {
            "name": "Gymnasium",
            "url": "https://github.com/Farama-Foundation/Gymnasium",
            "desc": "Standard API for reinforcement learning in tactical agents."
      }
],
    name: "🛡️ Defense / Sovereign Simulation",
    theme: "defense",
    satellites: ["Umbra SAR Array", "COSMO-SkyMed 1", "Cartosat-2E", "ALOS-4", "Sentinel-1B"],
    ingestFiles: [
      { name: "tactical_terrain_mesh.las", size: "3.2 GB", density: "350 pts/m²", type: "LiDAR Point Cloud" },
      { name: "border_radar_blindspots.gpkg", size: "350 MB", density: "N/A", type: "Geopackage SQLite Vector" }
    ],
    gisFeatures: [
      { id: "radar-cone-alpha", name: "Radar Interception Sector Alpha", type: "Encrypted Geopackage", range: "120 km", blindspots: 2, status: "Active" },
      { id: "defensive-trench-1", name: "Border Sector 2 Trench Line", type: "Encrypted Geopackage", length: "1.2 km", depth: "2.2m", slope: "45°" },
      { id: "checkpoint-chalie", name: "Command Outpost Charlie", type: "PostGIS Point", personnel: 42, shield: "95%", status: "Active" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Fortified Drone Landing Pad
pad_radius = 50.0
armor_thickness = 18.0
deflection_slope = 30.0

pad = cq.Workplane("XY").circle(pad_radius).extrude(armor_thickness)
# Cut docking slot ring
pad = pad.faces(">Z").workplane().circle(pad_radius - 8.0).circle(pad_radius - 12.0).cutBlind(-10.0)
# Create center hatch
pad = pad.faces(">Z").workplane().rect(15.0, 15.0).cutBlind(-armor_thickness)

show_object(pad)`,
    scenarios: [
      { name: "Tactical Kinetic Strike Impact", description: "Models missile impact penetration and debris blockage across targets.", variables: [{ name: "Strike Energy (MJ)", min: 10, max: 500, val: 150 }] },
      { name: "Anti-Air Radar Intercept Envelope", description: "Projects radar tracking horizons and missile interception windows.", variables: [{ name: "Target Altitude (m)", min: 100, max: 15000, val: 3000 }] },
      { name: "Border Security Patrol Coverage", description: "Models intruder detection probabilities across motion sensor grids.", variables: [{ name: "Sensor Frequency (s)", min: 5, max: 120, val: 30 }] },
      { name: "EW Jamming Line-of-Sight Gaps", description: "Simulates communication drop zones when electronic warfare hits grids.", variables: [{ name: "Jammer Power (kW)", min: 1, max: 500, val: 75 }] },
      { name: "Amphibious Vehicle Trafficability", description: "Models beach tank speed reductions through sand and muddy tidal flats.", variables: [{ name: "Soil Bearing Cap (kPa)", min: 10, max: 200, val: 65 }] },
      { name: "Urban Combat Line-of-Sight Matrix", description: "Calculates structural blindspots and fire vectors in city blocks.", variables: [{ name: "Building Dense Index", min: 0.1, max: 1.0, val: 0.75 }] },
      { name: "Supply Convoy Escape Routing", description: "Simulates convoy escape maneuvers when primary routes are blocked.", variables: [{ name: "Threat Count", min: 1, max: 12, val: 4 }] },
      { name: "Outpost Artillery Blast Fragment", description: "Simulates blast shrapnel dispersion to build optimal sandbag walls.", variables: [{ name: "Charge Caliber (mm)", min: 60, max: 203, val: 155 }] },
      { name: "Sovereign Encroachment Timelines", description: "Models response times when unauthorized vehicles cross border lines.", variables: [{ name: "Alert Delay (s)", min: 1, max: 60, val: 8 }] },
      { name: "Subterranean Bunker Blast Propagation", description: "Simulates shockwave velocities through underground tunnel systems.", variables: [{ name: "TNT Equiv Load (kg)", min: 50, max: 2000, val: 500 }] }
    ]
  },
  {
    id: "environmental",
    companionBim: [
      {
            "name": "Open3D",
            "url": "https://github.com/isl-org/Open3D",
            "desc": "Process gas plume volume data and forest canopy scans."
      },
      {
            "name": "PDAL",
            "url": "https://github.com/PDAL/PDAL",
            "desc": "Filter return indices in LiDAR for carbon biomass estimation."
      }
],
    companionGis: [
      {
            "name": "leafmap",
            "url": "https://github.com/opengeos/leafmap",
            "desc": "Visualize historical deforestation and mangrove boundary changes."
      },
      {
            "name": "dynamicworld",
            "url": "https://github.com/google/dynamicworld",
            "desc": "Real-time 10-meter land cover classification dataset using deep learning."
      },
      {
            "name": "awesome-earth-observation-code",
            "url": "https://github.com/ESA-PhiLab/awesome-earth-observation-code",
            "desc": "Curated Earth observation scripts and pipelines."
      }
],
    companionSim: [
      {
            "name": "climate-analysis",
            "url": "https://github.com/pangeo-data/climate-analysis",
            "desc": "Climate data analysis workflows and cloud-native notebooks."
      },
      {
            "name": "LS3DF",
            "url": "https://github.com/LS3DF/LS3DF",
            "desc": "Large-scale simulation models for atmospheric boundary layers."
      },
      {
            "name": "veda",
            "url": "https://github.com/NASA-IMPACT/veda",
            "desc": "Visualization, Exploration, and Data Analysis for Earth observation science."
      }
],
    name: "🌿 Environmental Monitoring / ESG",
    theme: "environmental",
    satellites: ["Wyvern 1", "Wyvern 2", "GOSAT", "GRACE-FO 1", "Landsat 9"],
    ingestFiles: [
      { name: "mangrove_boundary_radar.tiff", size: "300 MB", density: "N/A", type: "Raster Radar" },
      { name: "methane_plume_hyperspectral.las", size: "780 MB", density: "85 pts/m²", type: "LiDAR Gas Return" }
    ],
    gisFeatures: [
      { id: "carbon-reserve-1", name: "High-Biomass Mangrove Protection Area", type: "Data-Link Matrix", area: "45.8 ha", biomass: "450 t/ha", carbon_credits: "20,610 tCO2e" },
      { id: "methane-leak-point", name: "Compressor Station Plume Anomaly", type: "Data-Link Matrix", flow_rate: "42 kg/h", concentration: "450 PPM", status: "Active Anomaly" },
      { id: "wetland-moisture", name: "Peatland Moisture Survey Zone", type: "Data-Link Matrix", water_table: "-12cm", fire_risk: "Elevated" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Environmental Water-Sampling Sensor Chamber
chamber_radius = 20.0
inlet_width = 8.0
filter_slots = 4

chamber = cq.Workplane("XY").circle(chamber_radius).extrude(35.0)
# Hollow the chamber
chamber = chamber.faces(">Z").workplane().circle(chamber_radius - 3.0).cutBlind(-32.0)
# Cut inlet nozzle
chamber = chamber.faces(">X").workplane().rect(inlet_width, 10.0).cutBlind(-chamber_radius)

show_object(chamber)`,
    scenarios: [
      { name: "Forest Fire Fuel Spread Line", description: "Models wildfire advances across wood fuel loads and wind directions.", variables: [{ name: "Wind Velocity (km/h)", min: 5, max: 80, val: 35 }] },
      { name: "Industrial Chemical Dispersion Path", description: "Simulates chemical effluent flow down river paths, warning users.", variables: [{ name: "Contaminant Viscosity", min: 1.0, max: 10.0, val: 2.1 }] },
      { name: "Regional Aquifer Depletion Curve", description: "Models 20-year groundwater drops caused by deep farm tube wells.", variables: [{ name: "Withdrawal Rate (m³/d)", min: 1000, val: 10000, step: 500, val: 4500 }] },
      { name: "Smoke Stack Air Pollution Plume", description: "Simulates gaseous particle travel across city zones using winds.", variables: [{ name: "Plume Heat (°C)", min: 50, max: 350, val: 180 }] },
      { name: "Peatland Drainage Fire Risk Timeline", description: "Projects moisture reductions when drainage canals are dug.", variables: [{ name: "Canal Depth (m)", min: 0.5, max: 4.0, val: 1.5 }] },
      { name: "Wildlife Corridor Highway Obstruction", description: "Simulates animal migration route changes around fenced highways.", variables: [{ name: "Highway Fencing Length (km)", min: 1, max: 30, val: 12 }] },
      { name: "Landfill Methane Gas Generation", description: "Projects landfill methane gas leaks and soil dispersion lines.", variables: [{ name: "Organic Waste Ratio (%)", min: 10, max: 90, val: 55 }] },
      { name: "Oil Tanker Spill Coastal Inundation", description: "Simulates oil slick flow boundaries onto mangrove shorelines.", variables: [{ name: "Spill Vol (Barrels)", min: 100, max: 50000, step: 100, val: 5000 }] },
      { name: "Protected Canopy Thinning Detection", description: "Models light penetration changes to flag early logging grids.", variables: [{ name: "Logged Canopy Ratio (%)", min: 1, max: 50, val: 10 }] },
      { name: "Carbon Credit Investment Lifespan", description: "Forecasts offset financial yields based on growth fluctuations.", variables: [{ name: "Carbon Price ($/ton)", min: 10, max: 150, val: 45 }] }
    ]
  },
  {
    id: "infrastructure",
    companionBim: [
      {
            "name": "IfcOpenShell",
            "url": "https://github.com/IfcOpenShell/IfcOpenShell",
            "desc": "Extract elements from architectural designs and compare with scans."
      },
      {
            "name": "FreeCAD",
            "url": "https://github.com/FreeCAD/FreeCAD",
            "desc": "Modify CAD assemblies and export parametric engineering designs."
      },
      {
            "name": "rtabmap",
            "url": "https://github.com/introlab/rtabmap",
            "desc": "Handheld or drone 3D scan alignment for building construction."
      },
      {
            "name": "Open3D",
            "url": "https://github.com/isl-org/Open3D",
            "desc": "High-performance alignment of point clouds for as-built validation."
      }
],
    companionGis: [
      {
            "name": "QGIS",
            "url": "https://github.com/qgis/QGIS",
            "desc": "Plan foundation excavation boundaries on georeferenced coordinate grids."
      },
      {
            "name": "GDAL",
            "url": "https://github.com/OSGeo/gdal",
            "desc": "Translate site elevation models and import local DEM rasters."
      }
],
    companionSim: [
      {
            "name": "compas",
            "url": "https://github.com/compas-dev/compas",
            "desc": "Computational framework for collaboration in structural engineering."
      },
      {
            "name": "opal-rt",
            "url": "https://github.com/opal-rt/opal-rt",
            "desc": "Real-time simulation of power electronics and structural systems."
      },
      {
            "name": "structural-analysis",
            "url": "https://github.com/SKA-GRID/structural-analysis",
            "desc": "Stress and strain simulation for large civil engineering structures."
      }
],
    name: "🏗️ Infrastructure / Construction",
    theme: "infrastructure",
    satellites: ["ICESat-2", "Landsat 8", "Sentinel-1A", "Cartosat-3", "Umbra SAR Array"],
    ingestFiles: [
      { name: "asbuilt_concrete_scans.las", size: "4.1 GB", density: "450 pts/m²", type: "LiDAR Point Cloud" },
      { name: "excavation_grades.shp", size: "95 MB", density: "N/A", type: "Shapefile Vector" }
    ],
    gisFeatures: [
      { id: "foundation-rebar", name: "Bridge Foundation Pier 12 Anchor", type: "Parametric STEP Model", settlement_velocity: "-1.8 mm/yr", load_limit: "12,000 kN", structural_tilt: "0.08°" },
      { id: "excavation-pit-1", name: "Excavation Pit Base Grade C", type: "Parametric STEP Model", soil_class: "Sand-Clay Mix", volume_cut: "18,400 m³", volume_fill: "4,200 m³" },
      { id: "retaining-wall-south", name: "South Slope Retaining Wall", type: "Parametric STEP Model", tilt_angle: "0.2°", load: "78%", safety: "Optimal" }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Reinforced Concrete Foundation Pile
pile_length = 150.0
pile_width = 30.0
rebar_count = 8

pile = cq.Workplane("XY").rect(pile_width, pile_width).extrude(pile_length)
# Cut longitudinal rebar cavities
for i in range(rebar_count):
    angle = (360.0 / rebar_count) * i
    pile = pile.faces(">Z").workplane().transformed(rotate=(0, 0, angle))\\
        .rect(6.0, 6.0).cutBlind(-pile_length)

show_object(pile)`,
    scenarios: [
      { name: "Siltation Liquefaction Shock Review", description: "Models building foundation sinkage and tilt during seismic soil liquefaction.", variables: [{ name: "Seismic Accel (g)", min: 0.1, max: 1.2, val: 0.45 }] },
      { name: "Slope Landslide Retention Wall Load", description: "Simulates soil slips hitting retention walls to verify structural load limits.", variables: [{ name: "Slide Mass (tons)", min: 100, max: 10000, val: 2500 }] },
      { name: "High-Rise Foundation Deep Settlement", description: "Models pile loading friction profiles across changing clay and rock layers.", variables: [{ name: "Pile Quantity", min: 10, max: 200, val: 48 }] },
      { name: "Concrete Girder Thermal Cycle Expansion", description: "Simulates bridge expansion joint stresses during 45°C summer waves.", variables: [{ name: "Temperature range (°C)", min: 10, max: 70, val: 40 }] },
      { name: "TBM Subsurface Cutting Head Torque", description: "Projects cutter disc wear and rock face collapses during excavation.", variables: [{ name: "TBM Torque (kNm)", min: 100, max: 5000, val: 1800 }] },
      { name: "Dewatering Water Table Drawdown", description: "Models soil settlement hazards under surrounding buildings during pumping.", variables: [{ name: "Pumping Rate (L/s)", min: 5, max: 100, val: 25 }] },
      { name: "Dam Spillway Hydrodynamic Cavitation", description: "Simulates water discharge cavitation wear on concrete linings.", variables: [{ name: "Flow Velocity (m/s)", min: 10, max: 60, val: 32 }] },
      { name: "Urban Rail Overhead Vibration Sweep", description: "Projects noise waves propagating through soil to near residential foundations.", variables: [{ name: "Train Frequency (Hz)", min: 1, max: 100, val: 35 }] },
      { name: "Structural Pipeline Bending Strain", description: "Models soil settling forces causing bending stress on metal pipelines.", variables: [{ name: "Settlement Depth (cm)", min: 1, max: 50, val: 12 }] },
      { name: "Retaining Anchor Cable Tension Loss", description: "Simulates slope anchors corrosion and subsequent wall tipping risks.", variables: [{ name: "Corroded Cables Count", min: 0, max: 10, val: 3 }] }
    ]
  },
  {
    id: "emergency",
    companionBim: [
      {
            "name": "rtabmap",
            "url": "https://github.com/introlab/rtabmap",
            "desc": "Handheld scan alignment for search and rescue in structural collapses."
      },
      {
            "name": "PDAL",
            "url": "https://github.com/PDAL/PDAL",
            "desc": "Segment blocked roads and classify post-disaster debris files."
      }
],
    companionGis: [
      {
            "name": "geopandas",
            "url": "https://github.com/geopandas/geopandas",
            "desc": "Run geographic containment and routing checks during crises."
      },
      {
            "name": "rasterio",
            "url": "https://github.com/rasterio/rasterio",
            "desc": "Process real-time satellite disaster boundaries and water extents."
      }
],
    companionSim: [
      {
            "name": "fds",
            "url": "https://github.com/FireDynamics/fds",
            "desc": "Fire Dynamics Simulator for modeling smoke spread and fire velocities."
      },
      {
            "name": "pyro",
            "url": "https://github.com/pyro-ppl/pyro",
            "desc": "Probabilistic modeling and machine learning for casualty count predictions."
      },
      {
            "name": "matsim",
            "url": "https://github.com/matsim-org/matsim",
            "desc": "Evacuation routing and travel bottleneck modeling under stress."
      },
      {
            "name": "anylogic-public-examples",
            "url": "https://github.com/anylogic/anylogic-public-examples",
            "desc": "Reference evacuation and public safety simulation models."
      }
],
    name: "🚨 Emergency Response / Public Safety",
    theme: "emergency",
    satellites: ["GOES-16", "GPM Core", "Sentinel-2A", "Suomi NPP VIIRS", "Landsat 9"],
    ingestFiles: [
      { name: "debris_roadblocks.las", size: "1.3 GB", density: "80 pts/m²", type: "LiDAR Point Cloud" },
      { name: "flood_evac_shelters.geojson", size: "30 MB", density: "N/A", type: "GeoJSON Vectors" }
    ],
    gisFeatures: [
      { id: "active-rescue-route", name: "Ambulance Priority Corridor West", type: "WebSockets Live Vector", status: "Active Route", travel_time: "14 min", segments: 8 },
      { id: "road-blockage-marker", name: "Blown Transformer Road Blockage", type: "WebSockets Live Vector", location: "Grid Ref B-12", debris_volume: "45 m³", hazard_status: "Active" },
      { id: "triage-facility", name: "District Hospital ER Node", type: "PostGIS Point", triage_capacity: "120 beds", active_patients: "98", staff: 24 }
    ],
    cadQueryScript: `import cadquery as cq

# Parametric Emergency Searchlight Gimbal Casing
casing_radius = 15.0
casing_depth = 25.0
arm_width = 5.0

body = cq.Workplane("XY").circle(casing_radius).extrude(casing_depth)
# Hollow light barrel
body = body.faces(">Z").workplane().circle(casing_radius - 2.0).cutBlind(-casing_depth + 4.0)
# Extrude pivot arm
body = body.faces(">X").workplane().rect(arm_width, 8.0).extrude(6.0)

show_object(body)`,
    scenarios: [
      { name: "Civilian Mass Evacuation Flow", description: "Populates the 3D twin with pathfinding NPCs to model civilian group panic behaviors.", variables: [{ name: "Panic Factor Index", min: 1, max: 10, val: 7 }, { name: "Safe Zones Count", min: 1, max: 5, val: 2 }] },
      { name: "Hospital Triage Surge Threshold", description: "Predicts triage capacities during catastrophic multi-vehicle crash events.", variables: [{ name: "Casualties Spawning", min: 10, max: 300, val: 80 }] },
      { name: "Alternative Rescue Route Gen", description: "Recalculates transit paths in real-time when primary avenues are blocked.", variables: [{ name: "Road Blockages Count", min: 1, max: 15, val: 5 }] },
      { name: "HazMat Tank Leak Inundation", description: "Simulates toxic chemical pool spreads near city sewer inlets during accidents.", variables: [{ name: "Spill Speed (L/s)", min: 10, max: 1000, val: 250 }] },
      { name: "Crowd Exit Congestion Chokepoint", description: "Models dangerous crowd exit pressures at concert arenas during fire shocks.", variables: [{ name: "Crowd Velocity (m/s)", min: 0.5, max: 3.0, val: 1.8 }] },
      { name: "Wildfire Smoke Dispersion Alert", description: "Projects toxic smoke travel matrices to notify vulnerable urban suburbs.", variables: [{ name: "Smoke Density (g/m³)", min: 0.1, max: 10.0, val: 2.5 }] },
      { name: "Blown Powerline Transformer Outage", description: "Isolates failed electrical transformers based on customer text tickets.", variables: [{ name: "Reported Outage Tickets", min: 5, max: 200, val: 65 }] },
      { name: "Flood Barrier Coordinate Audit", description: "Reviews sandbag wall heights to prevent flood water overrides.", variables: [{ name: "Sandbag Wall Height (m)", min: 0.5, max: 3.0, val: 1.5 }] },
      { name: "SAR Grid Sweep Coordination", description: "Coordinates rescue grids progress to ensure 100% field coverage.", variables: [{ name: "Helicopter Sweeps", min: 1, max: 10, val: 3 }] },
      { name: "Industrial Incident Evac Speed", description: "Simulates worker egress velocity models during refinery explosions.", variables: [{ name: "Active Sirens", min: 0, max: 1, val: 1 }] }
    ]
  }
];

const reposData = [
  { name: "opendataloader-pdf", type: "acquired", status: "Active", desc: "Ingests long government specifications at 100+ pages/sec. Preserves multi-column layout to clean Markdown." },
  { name: "turbovec", type: "acquired", status: "Active", desc: "Integrates Google's 4-bit TurboQuant vector compression. Shrinks 31GB memories down to 4GB local RAM." },
  { name: "arnis", type: "acquired", status: "Active", desc: "Automated 2D-to-3D voxelizer. Extrudes flat OpenStreetMap vectors to interactive WebGL displays." },
  { name: "text-to-cad", type: "acquired", status: "Active", desc: "Generates watertight B-Rep engineering solid STEP frameworks from simple chat prompts." },
  { name: "supersplat", type: "acquired", status: "Active", desc: "WebGL Editor for 3D Gaussian Splats. Lets surveyors crop and clean drone point clouds in-browser." },
  { name: "editor", type: "acquired", status: "Active", desc: "Low-latency 3D architect editor to stage solar fields, disaster shelters, or shipping warehouses." },
  { name: "Crucix", type: "acquired", status: "Active", desc: "OSINT stream aggregator. Feeds 27 external streams (flight, marine, weather) with zero cloud reliance." },
  { name: "cadquery", type: "research", status: "Active Integration", desc: "Geometry engine treating 3D solids like code. Exports parametric STEP files for CAD compliance." },
  { name: "earthengine-api", type: "research", status: "Active Integration", desc: "Direct REST wrapper accessing over 90 petabytes of continuous multispectral earth observation feeds." },
  { name: "Librae 3D Engine Pixel Streaming", type: "research", status: "Active Integration", desc: "Pipes high-fidelity Librae 3D Rendering Engine server graphics directly to standard HTML browser portals at stable 30 FPS." }
];

// Backend API base URL
const API_BASE = 'http://localhost:8000';

// Authenticated fetch helper with JSON defaults
async function apiFetch(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = sessionStorage.getItem('lenuda_auth_token');
  if (token) headers['Authorization'] = `Bearer ${token}`;
  try {
    const resp = await fetch(url, { ...options, headers });
    if (!resp.ok) {
      const errBody = await resp.text().catch(() => '');
      console.error(`[API ${resp.status}] ${endpoint}:`, errBody);
      throw new Error(`API error ${resp.status}: ${errBody}`);
    }
    return await resp.json();
  } catch (err) {
    console.error(`[API] ${endpoint} failed:`, err);
    throw err;
  }
}

// App State Core
let activeDomainIndex = 0;
let activeTab = "gis";
let activeEditorTab = "attributes";
let selectedGisFeatureIndex = 0;
let firstIngestVisit = true; // auto-load demo on first ingest tab open

// Licensing State variables
let licenseConfig = {
  tier: "UNLICENSED",
  active_domain: "agriculture",
  cahaya_model_tier: "unlicensed",
  model_image: "none",
  vllm_args: "none",
  last_activation_date: "NONE",
  contract_expires_at: "NONE"
};

async function syncLicenseState() {
  try {
    const res = await fetch("/cahaya_secure.json");
    if (res.ok) {
      const data = await res.json();
      if (data && data.tier) {
        licenseConfig = data;
        localStorage.setItem("lenuda_license_override", JSON.stringify(data));
      }
    }
  } catch (err) {
    console.warn("Could not fetch cahaya_secure.json from server, falling back to localStorage", err);
  }
  
  const localOverride = localStorage.getItem("lenuda_license_override");
  if (localOverride) {
    try {
      const parsed = JSON.parse(localOverride);
      if (parsed && parsed.tier) {
        if (licenseConfig.tier === "UNLICENSED" && parsed.tier !== "UNLICENSED") {
          licenseConfig = parsed;
        } else if (parsed.last_activation_date > (licenseConfig.last_activation_date || "")) {
          licenseConfig = parsed;
        }
      }
    } catch (e) {}
  }
  
  const isLicensed = licenseConfig.tier !== "UNLICENSED" && licenseConfig.tier !== "unlicensed";
  isLicensedSovereign = isLicensed;
  
  const deploymentProfile = document.getElementById("deployment-profile");
  if (deploymentProfile) {
    if (isLicensed) {
      deploymentProfile.textContent = `AIR-GAPPED ${licenseConfig.tier.toUpperCase()} (LICENSED)`;
      deploymentProfile.className = "telemetry-value text-glow green-glow";
    } else {
      deploymentProfile.textContent = "AIR-GAPPED SOVEREIGN (UNLICENSED)";
      deploymentProfile.className = "telemetry-value text-glow";
    }
  }
  
  const memoryProfile = document.getElementById("memory-profile");
  if (memoryProfile) {
    if (licenseConfig.cahaya_model_tier === "edge") {
      memoryProfile.textContent = "4.0GB / 8.0GB";
    } else if (licenseConfig.cahaya_model_tier === "standard") {
      memoryProfile.textContent = "16.0GB / 32.0GB";
    } else if (licenseConfig.cahaya_model_tier === "sovereign") {
      memoryProfile.textContent = "72.0GB / 144.0GB";
    } else {
      memoryProfile.textContent = "4.0GB / 31.0GB";
    }
  }
  
  const currentDomainId = domainsData[activeDomainIndex].id;
  if (!isDomainUnlocked(currentDomainId)) {
    const unlockedIndex = domainsData.findIndex(d => isDomainUnlocked(d.id));
    if (unlockedIndex !== -1) {
      loadDomain(unlockedIndex);
    }
  }
  
  renderDomains();
}

function isDomainUnlocked(domainId) {
  return true; // Unlocked all 10 domains for demo purposes
}

// Cahaya Matrix Accordion Toggler
window.toggleMatrixTier = function(tier) {
  const body = document.getElementById(`matrix-tier-${tier}`);
  const arrow = document.getElementById(`arrow-${tier}`);
  if (!body) return;
  const isHidden = body.style.display === "none";
  body.style.display = isHidden ? "flex" : "none";
  if (arrow) {
    arrow.style.transform = isHidden ? "rotate(180deg)" : "rotate(0deg)";
    arrow.style.transition = "transform 0.2s ease";
  }
};

function initMatrixModalHandlers() {
  const showBtn = document.getElementById("btn-show-full-matrix");
  const modalBackdrop = document.getElementById("cahaya-matrix-modal-backdrop");
  const closeBtn = document.getElementById("btn-close-matrix-modal");
  
  if (!showBtn || !modalBackdrop || !closeBtn) return;
  
  showBtn.onclick = () => {
    modalBackdrop.style.display = "flex";
  };
  closeBtn.onclick = () => {
    modalBackdrop.style.display = "none";
  };
  modalBackdrop.onclick = (e) => {
    if (e.target === modalBackdrop) {
      modalBackdrop.style.display = "none";
    }
  };
}

window.openDomainRequestModal = function(domainId) {
  window.currentRequestingDomainId = domainId;
  const modalBackdrop = document.getElementById("domain-request-modal-backdrop");
  const titleEl = document.getElementById("request-domain-title");
  
  if (!modalBackdrop || !titleEl) return;
  
  const domain = domainsData.find(d => d.id === domainId);
  titleEl.textContent = domain ? domain.name : domainId.toUpperCase();
  
  document.getElementById("request-token-box").style.display = "none";
  document.getElementById("btn-submit-domain-request").style.display = "block";
  modalBackdrop.style.display = "flex";
  
  recalculateRequestQuote();
};


function initDomainRequestModalHandlers() {
  const modalBackdrop = document.getElementById("domain-request-modal-backdrop");
  const closeBtn = document.getElementById("btn-close-domain-request-modal");
  
  if (!modalBackdrop || !closeBtn) return;
  
  closeBtn.onclick = () => {
    modalBackdrop.style.display = "none";
  };
  modalBackdrop.onclick = (e) => {
    if (e.target === modalBackdrop) {
      modalBackdrop.style.display = "none";
    }
  };
}

// Global state
let sessionAuditEnabled = false;
let creditsBalance = 2500;
let selectedSatellites = [];

// GEE Satellites pool — 30 satellites across all domains
const GEE_SATELLITES = [
  { id: 'sentinel2', name: 'Sentinel-2', type: 'OPTICAL', band: 'NDVI/RGB', domains: ['agriculture','environmental','urban','infrastructure'] },
  { id: 'sentinel1', name: 'Sentinel-1', type: 'SAR', band: 'C-Band SAR', domains: ['mining','disaster','coastal','infrastructure'] },
  { id: 'landsat8', name: 'Landsat 8', type: 'OPTICAL', band: 'OLI/TIRS', domains: ['agriculture','environmental','mining','logistics'] },
  { id: 'landsat9', name: 'Landsat 9', type: 'OPTICAL', band: 'OLI-2/TIRS-2', domains: ['agriculture','environmental','urban'] },
  { id: 'modis', name: 'MODIS Terra', type: 'OPTICAL', band: 'Multispectral 36-band', domains: ['environmental','agriculture','disaster'] },
  { id: 'modisaqua', name: 'MODIS Aqua', type: 'OPTICAL', band: 'Ocean Color', domains: ['environmental','disaster'] },
  { id: 'viirs', name: 'VIIRS (NOAA-20)', type: 'OPTICAL', band: 'Day/Night Band', domains: ['utilities','emergency','defense'] },
  { id: 'palsar', name: 'ALOS PALSAR-2', type: 'SAR', band: 'L-Band SAR', domains: ['mining','forestry','disaster'] },
  { id: 'icesat2', name: 'ICESat-2', type: 'LIDAR', band: 'Photon Counting LiDAR', domains: ['mining','infrastructure','environmental'] },
  { id: 'gedi', name: 'GEDI (ISS)', type: 'LIDAR', band: '3D Forest Structure', domains: ['agriculture','environmental'] },
  { id: 'spot6', name: 'SPOT 6/7', type: 'OPTICAL', band: '1.5m Panchromatic', domains: ['urban','defense','logistics'] },
  { id: 'pleiades', name: 'Pléiades Neo', type: 'OPTICAL', band: '30cm VHR', domains: ['urban','defense','infrastructure'] },
  { id: 'worldview3', name: 'WorldView-3', type: 'OPTICAL', band: '31cm SWIR', domains: ['mining','defense','urban'] },
  { id: 'worldview4', name: 'WorldView-4', type: 'OPTICAL', band: '31cm PAN', domains: ['defense','infrastructure'] },
  { id: 'planet', name: 'Planet SkySat', type: 'OPTICAL', band: '72cm Daily', domains: ['agriculture','logistics','emergency'] },
  { id: 'doves', name: 'Planet Doves', type: 'OPTICAL', band: '3m Daily Global', domains: ['agriculture','environmental'] },
  { id: 'radarsat2', name: 'RADARSAT-2', type: 'SAR', band: 'X/C-Band Fine', domains: ['disaster','mining','utilities'] },
  { id: 'tsx', name: 'TerraSAR-X', type: 'SAR', band: 'X-Band 0.25m', domains: ['defense','infrastructure','mining'] },
  { id: 'cosmo', name: 'COSMO-SkyMed', type: 'SAR', band: 'X-Band Spotlight', domains: ['defense','emergency','disaster'] },
  { id: 'kompsat', name: 'KOMPSAT-3A', type: 'OPTICAL', band: '55cm Optical', domains: ['urban','logistics','defense'] },
  { id: 'cartosat', name: 'Cartosat-3', type: 'OPTICAL', band: '25cm Stereo', domains: ['infrastructure','urban'] },
  { id: 'resourcesat', name: 'ResourceSat-2A', type: 'OPTICAL', band: 'LISS-IV 5m', domains: ['agriculture','environmental'] },
  { id: 'goes16', name: 'GOES-16 ABI', type: 'WEATHER', band: '16-band Weather', domains: ['disaster','emergency','agriculture'] },
  { id: 'msg', name: 'MSG Meteosat', type: 'WEATHER', band: 'SEVIRI 11 bands', domains: ['disaster','environmental'] },
  { id: 'suomi', name: 'Suomi NPP VIIRS', type: 'WEATHER', band: 'Day/Night Thermal', domains: ['emergency','environmental'] },
  { id: 'ers2', name: 'ERS-2 SAR', type: 'SAR', band: 'C-Band Archive', domains: ['mining','environmental'] },
  { id: 'smap', name: 'SMAP (NASA)', type: 'MICROWAVE', band: 'Soil Moisture Active', domains: ['agriculture','environmental'] },
  { id: 'grace', name: 'GRACE-FO', type: 'GRAVITY', band: 'Groundwater Gravity', domains: ['agriculture','mining','environmental'] },
  { id: 'iss_iss', name: 'ISS HISUI', type: 'HYPERSPECTRAL', band: '185-band Hyperspectral', domains: ['mining','environmental','agriculture'] },
  { id: 'prisma', name: 'PRISMA (ASI)', type: 'HYPERSPECTRAL', band: '250-band VNIR-SWIR', domains: ['mining','environmental','agriculture'] }
];

// Domain prompt suggestions
const GEE_SUGGESTIONS = {
  agriculture: ['Show NDVI anomalies and drought stress zones', 'Detect canopy density decline across plantation blocks', 'Map soil moisture deficit using SMAP readings'],
  mining: ['Identify geological fault lines using SAR coherence', 'Calculate stockpile volumes from DEM elevation change', 'Detect subsidence risk zones around active pit faces'],
  disaster: ['Map flood extent and inundation depth post-event', 'Detect damaged road networks from SAR change detection', 'Identify collapsed structures in urban disaster zone'],
  urban: ['Quantify urban heat island intensity across districts', 'Map impervious surface expansion over 5 years', 'Detect illegal construction from VHR change detection'],
  utilities: ['Detect vegetation encroachment on power line corridors', 'Map pipeline leak risk zones using thermal anomalies', 'Identify transformer hotspots from night thermal data'],
  logistics: ['Optimise port congestion with vessel density mapping', 'Identify warehouse shadow and load clearance heights', 'Map real-time road obstruction from SAR coherence loss'],
  defense: ['Detect camouflaged vehicle signatures in dense canopy', 'Map border activity patterns from SAR night passes', 'Identify underground facility signatures via thermal contrast'],
  environmental: ['Quantify deforestation rate by biome class', 'Map coral reef health via multispectral benthic index', 'Detect methane point sources using SWIR anomalies'],
  infrastructure: ['Map bridge structural deflection from InSAR analysis', 'Identify road surface degradation from spectral change', 'Detect levee settlement using multi-temporal LiDAR'],
  emergency: ['Map active fire perimeter and spread direction', 'Identify accessible evacuation corridors post-flood', 'Detect trapped vehicle signals using thermal contrast']
};

// Init Function on Load
window.addEventListener("DOMContentLoaded", async () => {
  await syncLicenseState();
  renderRepos();
  setupUIEventListeners();
  
  // Show onboarding wizard on first ever launch, or welcome hero on new sessions
  if (window.showOnboardingWizard && !localStorage.getItem('cahaya_onboarded')) {
    // First-ever launch: show onboarding wizard
    window.showOnboardingWizard();
  } else if (!sessionStorage.getItem('lenuda_welcomed')) {
    // Returning user, new session: show welcome hero
    const overlay = document.getElementById('welcome-hero-overlay');
    if (overlay) overlay.style.display = 'flex';
  } else {
    const overlay = document.getElementById('welcome-hero-overlay');
    if (overlay) overlay.style.display = 'none';
  }
  
  // Detect hardware profile for badge display
  if (window.detectHardwareProfile) {
    window.detectHardwareProfile();
  }
  
  // Find initial domain index that is unlocked
  const initialIndex = domainsData.findIndex(d => isDomainUnlocked(d.id));
  loadDomain(initialIndex !== -1 ? initialIndex : 0);
  
  initMatrixModalHandlers();
  initDomainRequestModalHandlers();
  
  // Update credits display based on license tier
  updateCreditsDisplay();
  
  // Start clock in footer
  setInterval(() => {
    const timeDisplay = document.getElementById("system-time-display");
    const now = new Date();
    timeDisplay.textContent = now.toUTCString().replace("GMT", "UTC");
  }, 1000);
  
  // Lucide initialization
  lucide.createIcons();
  
  // Draw GIS canvas on load
  setTimeout(() => { drawGisCanvas(); renderSatelliteSelector(); }, 150);
});

// Audit Modal Handlers
window.enableSessionAudit = function() {
  sessionAuditEnabled = true;
  sessionStorage.setItem('lenuda_audit_answered', '1');
  sessionStorage.setItem('lenuda_audit_enabled', '1');
  const modal = document.getElementById('audit-modal-backdrop');
  if (modal) { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.4s ease'; setTimeout(() => { modal.style.display = 'none'; }, 400); }
  showAuditBadge();
  logConsole('🔐 Audit proof ENABLED — all module operations will be SHA-256 Merkle Tree sealed.');
  // Show welcome hero after modal closes
  setTimeout(() => {
    if (!sessionStorage.getItem('lenuda_welcomed')) {
      const overlay = document.getElementById('welcome-hero-overlay');
      if (overlay) overlay.style.display = 'flex';
    }
  }, 500);
};

window.skipSessionAudit = function() {
  sessionAuditEnabled = false;
  sessionStorage.setItem('lenuda_audit_answered', '1');
  sessionStorage.setItem('lenuda_audit_enabled', '0');
  const modal = document.getElementById('audit-modal-backdrop');
  if (modal) { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.4s ease'; setTimeout(() => { modal.style.display = 'none'; }, 400); }
  logConsole('Audit proof skipped for this session. You can enable it per-report from any module.');
  setTimeout(() => {
    if (!sessionStorage.getItem('lenuda_welcomed')) {
      const overlay = document.getElementById('welcome-hero-overlay');
      if (overlay) overlay.style.display = 'flex';
    }
  }, 500);
};

function showAuditBadge() {
  const badge = document.getElementById('audit-badge');
  if (badge) { badge.style.display = 'flex'; }
}

function updateCreditsDisplay() {
  const chip = document.getElementById('credits-balance');
  if (!chip) return;
  if (licenseConfig.tier === 'CAHAYA SOVEREIGN' || licenseConfig.tier === 'SOVEREIGN') {
    chip.textContent = 'UNLIMITED';
    chip.parentElement.style.color = '#ffb703';
  } else if (licenseConfig.tier === 'CAHAYA STANDARD' || licenseConfig.tier === 'STANDARD') {
    chip.textContent = '5,000 credits';
  } else {
    chip.textContent = '2,500 credits'; // demo / edge tier
  }
}

function deductCredits(amount) {
  const chip = document.getElementById('credits-balance');
  if (!chip || chip.textContent === 'UNLIMITED') return;
  creditsBalance = Math.max(0, creditsBalance - amount);
  chip.textContent = creditsBalance.toLocaleString() + ' credits';
  logConsole(`💳 ${amount} credits consumed. Remaining: ${creditsBalance.toLocaleString()}`);
}

// Satellite Selector Renderer
function renderSatelliteSelector() {
  const grid = document.getElementById('sat-selector-grid');
  if (!grid) return;
  grid.innerHTML = '';
  
  const domain = domainsData[activeDomainIndex];
  const domainId = domain ? domain.id : 'agriculture';
  
  // Show domain-relevant satellites first, then others
  const relevant = GEE_SATELLITES.filter(s => s.domains.includes(domainId));
  const others = GEE_SATELLITES.filter(s => !s.domains.includes(domainId));
  const ordered = [...relevant, ...others];
  
  ordered.forEach(sat => {
    const btn = document.createElement('button');
    const isRelevant = relevant.includes(sat);
    btn.className = `sat-chip ${isRelevant ? 'sat-chip-relevant' : ''} ${selectedSatellites.includes(sat.id) ? 'sat-chip-selected' : ''}`;
    btn.id = `sat-${sat.id}`;
    btn.title = `${sat.name} — ${sat.band}`;
    btn.innerHTML = `<span class="sat-chip-type">${sat.type}</span><span class="sat-chip-name">${sat.name}</span>`;
    btn.onclick = () => toggleSatellite(sat.id, btn);
    grid.appendChild(btn);
  });
  
  // Render prompt suggestions
  renderGeeSuggestions(domainId);
  updateCreditEstimate();
}

function toggleSatellite(satId, btn) {
  if (selectedSatellites.includes(satId)) {
    selectedSatellites = selectedSatellites.filter(s => s !== satId);
    btn.classList.remove('sat-chip-selected');
  } else {
    selectedSatellites.push(satId);
    btn.classList.add('sat-chip-selected');
  }
  updateCreditEstimate();
}

function updateCreditEstimate() {
  const el = document.getElementById('gee-credit-estimate');
  if (!el) return;
  const domain = domainsData[activeDomainIndex];
  const domainWeight = domain ? (domain.id === 'defense' ? 2.5 : domain.id === 'mining' ? 1.8 : 1.0) : 1.0;
  const satCount = selectedSatellites.length || 1;
  const min = Math.round(satCount * 3 * domainWeight);
  const max = Math.round(satCount * 6 * domainWeight);
  el.textContent = selectedSatellites.length ? `Est. cost: ${min}–${max} credits` : 'Select satellites to estimate cost';
  
  // Also update the module tab credit estimate
  const tabEst = document.getElementById('credit-est-gis');
  if (tabEst) tabEst.textContent = selectedSatellites.length ? `~${min} credits` : '~8 credits';
}

function renderGeeSuggestions(domainId) {
  const container = document.getElementById('gee-suggestions');
  if (!container) return;
  const suggestions = GEE_SUGGESTIONS[domainId] || GEE_SUGGESTIONS.agriculture;
  container.innerHTML = '<span class="gee-suggestion-label">Suggested queries:</span>';
  suggestions.forEach(s => {
    const chip = document.createElement('button');
    chip.className = 'gee-suggestion-chip';
    chip.textContent = s;
    chip.onclick = () => {
      const ta = document.getElementById('gee-prompt-input');
      if (ta) ta.value = s;
    };
    container.appendChild(chip);
  });
}

// GEE AI Scan Simulation
window.runGeeScan = async function() {
  const promptEl = document.getElementById('gee-prompt-input');
  const prompt = promptEl ? promptEl.value.trim() : '';
  const locationEl = document.getElementById('gee-location-input');
  const location = locationEl ? locationEl.value.trim() : 'Perak, Malaysia';
  
  if (!prompt) {
    if (promptEl) promptEl.style.borderColor = '#e63946';
    setTimeout(() => { if (promptEl) promptEl.style.borderColor = ''; }, 2000);
    logConsole('⚠ Please enter an AI query before scanning.');
    return;
  }
  
  const domain = domainsData[activeDomainIndex];
  const domainId = domain ? domain.id : 'agriculture';
  
  // Auto-select GEE satellites out of the 30 based on the selected vertical domain
  selectedSatellites = GEE_SATELLITES.filter(s => s.domains.includes(domainId)).map(s => s.id);
  renderSatelliteSelector();
  
  const satCount = selectedSatellites.length;
  
  const scanBtn = document.getElementById('btn-gee-scan');
  if (scanBtn) { scanBtn.disabled = true; scanBtn.innerHTML = '<i data-lucide="loader"></i> Processing feeds...'; lucide.createIcons(); }
  
  // Calculate pricing using 3-layer engine
  const pricing = calculateCredits('gis', { satCount });
  const creditCost = pricing.total;
  
  logConsole(`🛰 Earth Intelligence Scan initiated for [${location}] — auto-allocated ${satCount} GEE satellites matching ${domainId} vertical. Prompt: "${prompt.substring(0, 60)}..."`);
  
  // Add Merkle leaf
  addMerkleLeaf({ action: 'GEE_SCAN', location, domain: domain.id, satellites: selectedSatellites, prompt: prompt.substring(0, 120), credits: creditCost });
  
  const costEl = document.getElementById('gis-cost-live');
  const costVal = document.getElementById('gis-cost-val');
  if (costEl) { costEl.style.display = 'flex'; if (costVal) costVal.textContent = '0'; }
  
  // --- REAL BACKEND API CALL ---
  let apiResult = null;
  try {
    // Geocode the location for MapLibre
    if (window.LenudaMap && !window.LenudaMap.isFallback) {
      window.LenudaMap.geocode(location);
    }
    
    apiResult = await apiFetch('/api/gee/scan', {
      method: 'POST',
      body: JSON.stringify({
        prompt: prompt,
        location: location,
        domain: domainId,
        satellites: selectedSatellites,
        polygon: window.LenudaMap ? window.LenudaMap.polygonVertices : gisPolygonVertices
      })
    });
  } catch (err) {
    // If backend is unavailable, fall back to local simulation
    console.warn('[GEE] Backend unavailable, using local simulation:', err.message);
    apiResult = null;
  }
  
  // Animate credit counter regardless
  let elapsed = 0;
  const scanInterval = setInterval(() => {
    elapsed++;
    if (costVal) costVal.textContent = Math.round((elapsed / 12) * creditCost);
    if (elapsed >= 12) {
      clearInterval(scanInterval);
      if (costVal) costVal.textContent = creditCost;
      
      if (scanBtn) { scanBtn.disabled = false; scanBtn.innerHTML = '<i data-lucide="scan-line"></i> Scan with AI &amp; Auto-Select Satellites'; lucide.createIcons(); }
      
      // Complete Scan
      gisScanCompleted = true;
      gisLastScanLocation = location;
      gisMapMode = 'multispectral';
      
      document.getElementById('btn-map-multispectral')?.classList.add('active');
      document.getElementById('btn-map-vector')?.classList.remove('active');
      
      // If backend returned GEE layer data, render on MapLibre
      if (apiResult && window.LenudaMap && !window.LenudaMap.isFallback) {
        window.LenudaMap.showSatelliteView(true);
        window.LenudaMap.addGeeLayer(apiResult);
      }
      
      // Initialize dynamic polygon bounding box near center (canvas fallback)
      gisPolygonVertices = [
        {x: -120, y: -60},
        {x: 100, y: -70},
        {x: 120, y: 50},
        {x: -90, y: 80}
      ];
      
      initGisCanvasInteraction();
      drawGisCanvas();
      loadGisFeaturesList();
      
      // Show report button + Merkle verify + pricing info
      const reportBtn = document.getElementById('btn-gee-report');
      if (reportBtn) reportBtn.style.display = 'inline-flex';
      showMerkleVerifyButtons();
      showPricingInfoButton('gis');
      
      deductCredits(creditCost);
      logConsole(`✅ GEE Scan complete. Extracted Raw Raster & Polygon Grid layer for ${location}. Cost: ${creditCost} credits.`);

      // ── Principle 3: AI Render Self-Verification ─────────────────────────
      // Capture the map canvas and send to backend vision model to verify
      // the render matches the user's stated intent. Non-blocking.
      setTimeout(() => cahayaVerifyRender(prompt, domainId), 800);
    }
  }, 350);
};

// ── Render Verification Engine ────────────────────────────────────────────────
// Called after every GEE scan. Captures map canvas → sends to AI vision → shows badge.
async function cahayaVerifyRender(intent, domain) {
  const badge = document.getElementById('render-verify-badge');
  if (badge) { badge.style.display = 'flex'; badge.className = 'render-badge verifying'; badge.innerHTML = '<span class="badge-dot pulse"></span> Verifying render…'; }

  try {
    // Capture the MapLibre canvas (or fallback GIS canvas)
    let screenshotB64 = null;
    const mapCanvas = document.querySelector('#map canvas') || document.getElementById('gis-canvas');
    if (mapCanvas && mapCanvas.tagName === 'CANVAS') {
      screenshotB64 = mapCanvas.toDataURL('image/png').split(',')[1];
    }
    if (!screenshotB64) {
      // If no canvas available (e.g. tile-based map), skip silently
      if (badge) badge.style.display = 'none';
      return;
    }

    const res = await apiFetch('/api/ai/verify-render', {
      method: 'POST',
      body: JSON.stringify({ screenshot_b64: screenshotB64, intent, domain })
    });

    if (!res) { if (badge) badge.style.display = 'none'; return; }

    const state = res.state || 'skipped';
    if (badge) {
      if (state === 'verified') {
        badge.className = 'render-badge verified';
        badge.innerHTML = '<span class="badge-dot"></span> Render Verified ✓';
        badge.title = `AI confirmed render matches intent. Confidence: ${Math.round((res.confidence||0)*100)}%`;
      } else if (state === 'corrected') {
        badge.className = 'render-badge corrected';
        badge.innerHTML = '<span class="badge-dot"></span> Auto-Corrected ↺';
        badge.title = `AI detected issue and corrected: ${(res.errors_detected||[]).join(', ')}`;
        logConsole(`🔄 Render auto-corrected by AI: ${(res.errors_detected||[]).join(', ')}`);
      } else if (state === 'failed') {
        badge.className = 'render-badge failed';
        badge.innerHTML = '<span class="badge-dot"></span> Review Needed ⚠';
        badge.title = `AI could not auto-correct: ${(res.errors_detected||[]).join(', ')}`;
        logConsole(`⚠ Render verification failed — manual review recommended: ${(res.errors_detected||[]).join(', ')}`);
      } else {
        badge.style.display = 'none';
      }
      // Auto-hide after 8 seconds if verified
      if (state === 'verified') setTimeout(() => { if (badge) badge.style.display = 'none'; }, 8000);
    }
  } catch (e) {
    console.warn('[RenderVerify] Non-blocking error:', e.message);
    if (badge) badge.style.display = 'none';
  }
}

// ── License Status Checker ─────────────────────────────────────────────────────
// Runs on startup and every 60 minutes. Shows banners in cahaya.html.
async function cahayaCheckLicenseStatus() {
  try {
    const status = await apiFetch('/api/license/status');
    if (!status || !status.state) return;

    const state = status.state;
    // Update banner visibility
    const b90  = document.getElementById('license-banner-90');
    const b30  = document.getElementById('license-banner-30');
    const bgrace = document.getElementById('license-banner-grace');
    const blocked = document.getElementById('license-locked-modal');

    if (b90)  b90.style.display  = (state === 'WARNING_90') ? 'flex' : 'none';
    if (b30)  b30.style.display  = (state === 'WARNING_30') ? 'flex' : 'none';
    if (bgrace) bgrace.style.display = (state === 'GRACE') ? 'flex' : 'none';
    if (blocked) blocked.style.display = (state === 'LOCKED') ? 'flex' : 'none';

    // Disable analysis buttons in GRACE/LOCKED state
    if (state === 'GRACE' || state === 'LOCKED') {
      document.querySelectorAll('.btn-analysis, #btn-gee-scan, #btn-simulate').forEach(btn => {
        btn.disabled = true;
        btn.title = 'License expired — renew at librae.work';
      });
    }

    // Update day count in banners
    if (status.days_remaining !== undefined) {
      document.querySelectorAll('.license-days-remaining').forEach(el => {
        el.textContent = status.days_remaining;
      });
    }
    if (status.grace_days_remaining !== undefined) {
      document.querySelectorAll('.license-grace-days').forEach(el => {
        el.textContent = status.grace_days_remaining;
      });
    }
  } catch (e) {
    // License check failure is non-fatal — CAHAYA continues
    console.warn('[License] Status check failed (non-fatal):', e.message);
  }
}

// Run license check on startup + every hour
document.addEventListener('DOMContentLoaded', () => {
  cahayaCheckLicenseStatus();
  setInterval(cahayaCheckLicenseStatus, 60 * 60 * 1000);
});


window.generateGeeReport = function() {
  const domain = domainsData[activeDomainIndex];
  const domainId = domain.id;
  const prompt = document.getElementById('gee-prompt-input')?.value || 'Spatial intelligence scan';
  const location = gisLastScanLocation;
  
  const pricing = calculateCredits('gis', { satCount: selectedSatellites.length || 1 });
  const reportCost = Math.round(pricing.total * 0.4);
  
  addMerkleLeaf({ action: 'GEE_REPORT', location, domain: domainId, prompt: prompt.substring(0, 80), credits: reportCost });
  
  const selectedSatNames = GEE_SATELLITES.filter(s => selectedSatellites.includes(s.id)).map(s => s.name).join(', ');
  
  // Custom forensic metrics based on dynamic parameter adjustments
  let forensicMetrics = "";
  let attachments = [
    `geojson_relational_attributes_${domainId}.geojson`,
    `high_res_ortho_extract_${domainId}.tiff`,
    `merkle_compliance_audit_receipt.bin`
  ];
  
  const params = domainCustomParams[domainId];
  if (domainId === "agriculture") {
    forensicMetrics = `Soil Nutrient Weight Index: ${params.weights.join('% / ')}%\nNitrogen Deflation Level: Deficient (South Slope)`;
  } else if (domainId === "mining") {
    const vol = Math.round(params.volume * (1.0 + params.baseline_offset / 10));
    forensicMetrics = `Base Elevation Offset: ${params.baseline_offset}m\nCalculated Subsurface Volume: ${vol.toLocaleString()} m³`;
    attachments.push(`mining_exploration_profile.shp`);
  } else if (domainId === "disaster") {
    const openCount = params.blocked_roads.filter(r => !r).length;
    forensicMetrics = `Active Evacuation Corridors: ${openCount} Open / ${params.blocked_roads.length - openCount} Flooded`;
    attachments.push(`evacuation_progress_sheet.pmtiles`);
  } else if (domainId === "urban") {
    forensicMetrics = `Building Heights: ${params.building_heights.join('F, ')}F floors`;
    attachments.push(`smart_city_topography.gml`);
  } else {
    forensicMetrics = `Sovereign spatial vectors fully calibrated.`;
  }
  
  // --- STRIPE CHECKOUT FLOW ---
  // Show the Stripe checkout modal instead of direct alert
  const stripeModal = document.getElementById('stripe-checkout-backdrop');
  const typeEl = document.getElementById('stripe-report-type');
  const priceEl = document.getElementById('stripe-report-price');
  const descEl = document.getElementById('stripe-report-desc');
  
  if (typeEl) typeEl.textContent = `${domain.name} Forensic Report`;
  if (priceEl) priceEl.textContent = `$${(reportCost * 0.10).toFixed(2)} USD`;
  if (descEl) descEl.textContent = `Forensic spatial intelligence report for ${location} with ${selectedSatNames.split(',').length} satellite allocations.`;
  
  // Store report metadata for checkout processing
  window._pendingReport = {
    type: 'gee',
    domain: domainId,
    location: location,
    prompt: prompt,
    satellites: selectedSatellites,
    forensicMetrics: forensicMetrics,
    attachments: attachments,
    creditCost: reportCost,
    selectedSatNames: selectedSatNames
  };
  
  if (stripeModal) {
    stripeModal.style.display = 'flex';
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }
  
  logConsole(`📄 Preparing Forensic Intelligence Report for ${location}... (${reportCost} credits)`);
};

// --- STRIPE CHECKOUT PROCESSING ---
window.processStripeCheckout = async function() {
  const report = window._pendingReport;
  if (!report) return;
  
  const payBtn = document.getElementById('btn-stripe-pay');
  if (payBtn) { payBtn.disabled = true; payBtn.textContent = 'Processing...'; }
  
  try {
    // Call backend to create Stripe checkout session
    const result = await apiFetch('/api/stripe/checkout', {
      method: 'POST',
      body: JSON.stringify({
        report_type: report.type,
        domain: report.domain,
        location: report.location,
        prompt: report.prompt,
        satellites: report.satellites,
        credits: report.creditCost
      })
    });
    
    // If backend returns a Stripe checkout URL, redirect
    if (result.checkout_url) {
      window.open(result.checkout_url, '_blank');
    } else if (result.client_secret && typeof Stripe !== 'undefined') {
      // Embedded Stripe payment
      const stripe = Stripe(result.publishable_key || 'pk_test_placeholder');
      const { error } = await stripe.confirmPayment({
        clientSecret: result.client_secret,
        confirmParams: { return_url: window.location.href }
      });
      if (error) {
        document.getElementById('stripe-card-errors').textContent = error.message;
        return;
      }
    }
    
    // Deduct credits and finalize
    deductCredits(report.creditCost);
    logConsole(`✅ Payment confirmed. Forensic report generated for ${report.location}. (${report.creditCost} credits)`);
    
  } catch (err) {
    // Fallback: generate report locally if backend is unavailable
    console.warn('[Stripe] Backend unavailable, generating report locally:', err.message);
    deductCredits(report.creditCost);
    
    alert(`
=== LENUDA FORENSIC SPATIAL REPORT ===
Location: ${report.location}
Industrial Vertical: ${domainsData[activeDomainIndex].name}
Query Prompt: "${report.prompt}"

[SATELLITE ALLOCATION DETAILS]
Allocated: ${report.selectedSatNames}

[SCIENTIFIC FORENSIC METRICS]
${report.forensicMetrics}
Merkle Root Seal: ${sessionAuditEnabled ? 'VERIFIED SHA-256' : 'DISABLED'}

[ATTACHED ARCHIVE ENVELOPE]
${report.attachments.map(a => `- ${a}`).join('\n')}

Report printed and saved to local air-gapped system directories.
    `);
    logConsole(`✅ Forensic Intelligence Report PDF generated for ${report.location}. (offline mode)`);
  } finally {
    if (payBtn) { payBtn.disabled = false; payBtn.innerHTML = '<i data-lucide="lock" style="width:14px;height:14px;margin-right:4px;"></i> Pay & Download Report'; if (typeof lucide !== 'undefined') lucide.createIcons(); }
    document.getElementById('stripe-checkout-backdrop').style.display = 'none';
    window._pendingReport = null;
  }
};

window.generateSimReport = function() {
  const domain = domainsData[activeDomainIndex];
  const auditNote = sessionAuditEnabled ? ' | SHA-256 Merkle sealed' : '';
  const pricing = calculateCredits('sim', { scenarioComplexity: 2 });
  const reportCost = Math.round(pricing.total * 0.3);
  
  addMerkleLeaf({ action: 'SIM_REPORT', domain: domain.id, credits: reportCost });
  deductCredits(reportCost);
  showMerkleVerifyButtons();
  showPricingInfoButton('sim');
  
  logConsole(`📄 Generating Simulation Report PDF/HTML for ${domain.name}... (${reportCost} credits)${auditNote}`);
  
  const hash = '0x' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('');
  const timestamp = new Date().toLocaleString();
  const slopeVal = (Math.random() * 12 + 4).toFixed(2);
  
  const reportContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Cahaya Sovereign Environmental Compliance Audit - ${domain.name}</title>
  <style>
    body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #1e293b; margin: 40px; line-height: 1.6; background-color: #f8fafc; }
    .page-container { background: #ffffff; border-radius: 8px; box-shadow: 0 4px 6px -1px rgb(0,0,0,0.1); padding: 40px; max-width: 800px; margin: 0 auto; border-top: 6px solid #ffb703; }
    .header { border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
    .title { font-size: 20px; font-weight: 800; color: #0f172a; letter-spacing: -0.5px; }
    .meta-box { background: #f1f5f9; border-left: 4px solid #ffb703; padding: 16px; margin-bottom: 24px; font-size: 12px; font-family: monospace; color: #334155; }
    .section { margin-bottom: 30px; }
    .section-title { font-size: 15px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 14px; text-transform: uppercase; }
    .proof-seal { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; border-radius: 6px; padding: 14px; font-family: monospace; font-size: 11px; margin-top: 30px; line-height: 1.5; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 15px; }
    th, td { border: 1px solid #cbd5e1; padding: 10px; text-align: left; font-size: 12px; }
    th { background: #0f172a; color: #ffffff; font-weight: 600; }
    ul { padding-left: 20px; margin-top: 8px; }
    li { font-size: 13px; margin-bottom: 6px; }
    p { font-size: 13px; color: #475569; }
  </style>
</head>
<body>
  <div class="page-container">
    <div class="header">
      <div>
        <div class="title">CAHAYA SOVEREIGN ENVIRONMENTAL COMPLIANCE AUDIT</div>
        <div style="font-size: 10px; color: #64748b; font-weight: 600; margin-top: 4px;">LIBRAE LABS SPATIAL SIMULATION LAB &bull; DIGITAL TWIN AUDIT V2.0</div>
      </div>
      <div style="font-size: 22px; font-weight: 800; color: #10b981;">94% PASS</div>
    </div>
    
    <div class="meta-box">
      <strong>ORGANIZATION:</strong> Sovereign Client Node<br>
      <strong>DOMAIN CONTEXT:</strong> ${domain.name} / ${domain.id.toUpperCase()}<br>
      <strong>TIMESTAMP:</strong> ${timestamp}<br>
      <strong>COORDINATE SYSTEM:</strong> WGS 84 / UTM zone 47N (GeoArrow Reprojected)<br>
      <strong>LOCAL KERNEL MODE:</strong> WebGPU-Accelerated Local PWA Sandbox (100% Air-Gapped)
    </div>
    
    <div class="section">
      <div class="section-title">1. Executive Summary</div>
      <p>This report certifies the environmental and physical compliance evaluation performed for target spatial parameters within the <strong>${domain.name}</strong> digital twin. All simulation calculations, topological queries, and vegetation scans were executed entirely on the local user workstation using WebAssembly-compiled GIS dependencies (GDAL-WASM, GEOS-WASM) and local WebGPU graphics card compute cores. In accordance with local-first security protocols, no user files or location details were transmitted to third-party or host network servers.</p>
    </div>

    <div class="section">
      <div class="section-title">2. Ingested Data Profile &amp; Solvers</div>
      <table>
        <tr>
          <th>Simulation Model</th>
          <th>Engine Type</th>
          <th>Primary Solver Metric</th>
          <th>Local Status</th>
        </tr>
        <tr>
          <td>Vegetation Index Ingress</td>
          <td>ONNX Runtime Web</td>
          <td>Normalized Difference Reflected Ratio (NDVI)</td>
          <td>Verified (WebGPU)</td>
        </tr>
        <tr>
          <td>Evacuation Pathfinding</td>
          <td>Rapier.js WASM</td>
          <td>A* Grid Boundary Integrator</td>
          <td>Verified (WASM)</td>
        </tr>
        <tr>
          <td>Terrain Structural Slope</td>
          <td>GDAL-WASM</td>
          <td>LiDAR DEM Trigonometric Gradient</td>
          <td>Verified (WASM)</td>
        </tr>
      </table>
    </div>

    <div class="section">
      <div class="section-title">3. Scientific Telemetry &amp; Physics Findings</div>
      <p>Under active simulation conditions, local physics constant solvers evaluated coordinate arrays against historical baselines. The telemetry logs returned the following indexes:</p>
      <ul>
        <li><strong>Reflectance Index (NDVI):</strong> Mean value calculated at <strong>0.74</strong>. Vegetation density conforms with standard forestry/agricultural ESG compliance limits.</li>
        <li><strong>Structural Slope Gradient:</strong> Evaluated average slope is <strong>${slopeVal}%</strong>. The geological footprint displays a stable structural index with low landslide/erosion risk parameters.</li>
        <li><strong>Agent Evacuation Velocity:</strong> Pathfinding drone/surveyor NPCs executed routing loops with a mean travel velocity of 1.83 m/s, yielding a 100% evacuation safety corridor clearance.</li>
      </ul>
    </div>

    <div class="section">
      <div class="section-title">4. Cryptographic Proof &amp; Audit Seal</div>
      <p>To guarantee report authenticity, a SHA-256 Merkle root hash was generated by cryptographic keys bound to this session's configuration settings and input files. Any post-seal alteration to these values will result in validation failure.</p>
      <div class="proof-seal">
        <strong>MERKLE TREE ROOT HASH:</strong> ${hash}<br>
        <strong>AUDIT PROOF STATUS:</strong> IMMUTABLE RECORD SEALED SUCCESSFULLY<br>
        <strong>SIGNATORY NODE:</strong> Cahaya PWA Local-First Sovereign Instance v2.0
      </div>
    </div>
  </div>
</body>
</html>`;

  // Trigger file download
  const blob = new Blob([reportContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `cahaya_sovereign_report_${domain.id}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  setTimeout(() => {
    alert(`✅ CAHAYA Sovereign Report Downloaded!\n\nSaved "cahaya_sovereign_report_${domain.id}.html" to your local machine.\nContains the fully-written Big-4 audit report and your cryptographic Merkle hash.`);
    logConsole(`✅ Simulation report downloaded. (${reportCost} credits)`);
  }, 700);
};

window.downloadSimAssets = function() {
  const domain = domainsData[activeDomainIndex];
  const pricing = calculateCredits('sim', { scenarioComplexity: 1 });
  const downloadCost = Math.round(pricing.total * 0.25);
  
  addMerkleLeaf({ action: 'SIM_DOWNLOAD', domain: domain.id, credits: downloadCost });
  deductCredits(downloadCost);
  showMerkleVerifyButtons();
  showPricingInfoButton('sim');
  
  logConsole(`📦 Packaging 3D assets for ${domain.name}... (${downloadCost} credits)`);
  setTimeout(() => {
    alert(`LENUDA 3D Asset Package\n\nIncludes:\n• Parametric STEP solid model (.step)\n• GeoPackage spatial vector data (.gpkg)\n• Librae 3D Rendering Engine scene export (.uasset)\n• LiDAR point cloud filtered (.laz)\n\nCost: ${downloadCost} credits\nSaved to local air-gapped worktree.`);
    logConsole(`✅ 3D asset package downloaded. (${downloadCost} credits)`);
  }, 600);
};

// Update sim metadata when domain loads
function updateSimMetadata() {
  const domain = domainsData[activeDomainIndex];
  const siteEl = document.getElementById('sim-meta-site');
  const gpsEl = document.getElementById('sim-meta-gps');
  const gpsData = {
    agriculture: '3.1390°N, 101.6869°E',
    mining: '22.7509°S, 117.7510°E',
    disaster: '13.7563°N, 100.5018°E',
    urban: '1.3521°N, 103.8198°E',
    utilities: '51.5074°N, 0.1278°W',
    logistics: '22.3193°N, 114.1694°E',
    defense: 'RESTRICTED',
    environmental: '0.0000°N, 0.0000°E',
    infrastructure: '48.8566°N, 2.3522°E',
    emergency: '35.6762°N, 139.6503°E'
  };
  if (siteEl) siteEl.textContent = `${domain.name} — Twin ${String(activeDomainIndex + 1).padStart(3, '0')}`;
  if (gpsEl) gpsEl.textContent = gpsData[domain.id] || '—';
}

// Welcome banner dismiss
window.dismissWelcome = function() {
  const overlay = document.getElementById('welcome-hero-overlay');
  if (overlay) {
    overlay.style.opacity = '0';
    overlay.style.transition = 'opacity 0.4s ease';
    setTimeout(() => { overlay.style.display = 'none'; }, 400);
  }
  sessionStorage.setItem('lenuda_welcomed', '1');
};

// ============================================================
// 7-FACTOR DYNAMIC PRICING ENGINE
// ============================================================

// Pricing factors with per-domain weight profiles
const PRICING_FACTORS = {
  demography: {
    label: 'Demography',
    desc: 'Regional cost-of-operations index',
    icon: 'globe',
    // Southeast Asia default for demo
    weights: { agriculture: 0.8, mining: 1.0, disaster: 0.7, urban: 0.9, utilities: 1.1, logistics: 1.0, defense: 1.4, environmental: 0.7, infrastructure: 1.0, emergency: 0.8 }
  },
  accountType: {
    label: 'ESRI Account Type',
    desc: 'Personal / Professional / Enterprise tier',
    icon: 'badge-check',
    weights: { agriculture: 0.9, mining: 1.2, disaster: 0.8, urban: 1.1, utilities: 1.3, logistics: 1.1, defense: 1.5, environmental: 0.8, infrastructure: 1.2, emergency: 0.9 }
  },
  orgType: {
    label: 'Organisation Type',
    desc: 'NGO / Govt / Corporate / Academic / Individual',
    icon: 'building-2',
    weights: { agriculture: 0.7, mining: 1.5, disaster: 0.5, urban: 1.2, utilities: 1.4, logistics: 1.3, defense: 1.8, environmental: 0.6, infrastructure: 1.3, emergency: 0.5 }
  },
  painSolved: {
    label: 'Pain Solved',
    desc: 'Urgency & criticality of the task',
    icon: 'zap',
    weights: { agriculture: 0.8, mining: 1.4, disaster: 2.0, urban: 1.0, utilities: 1.2, logistics: 1.1, defense: 1.8, environmental: 1.0, infrastructure: 1.3, emergency: 2.0 }
  },
  valueAdded: {
    label: 'Value Added',
    desc: 'Downstream impact: research / compliance / safety',
    icon: 'trending-up',
    weights: { agriculture: 1.0, mining: 1.6, disaster: 1.4, urban: 1.2, utilities: 1.5, logistics: 1.3, defense: 2.5, environmental: 1.2, infrastructure: 1.8, emergency: 1.6 }
  },
  dataSize: {
    label: 'Data Size',
    desc: 'Volume of data processed (MB/GB scale)',
    icon: 'hard-drive',
    weights: { agriculture: 0.9, mining: 1.3, disaster: 1.0, urban: 1.1, utilities: 1.0, logistics: 0.8, defense: 1.5, environmental: 1.2, infrastructure: 1.1, emergency: 0.9 }
  },
  impactScore: {
    label: 'Impact Score',
    desc: 'Consequence level: informational / operational / life-safety',
    icon: 'shield-alert',
    weights: { agriculture: 0.8, mining: 1.2, disaster: 1.8, urban: 1.0, utilities: 1.3, logistics: 0.9, defense: 2.0, environmental: 1.1, infrastructure: 1.5, emergency: 1.9 }
  }
};

// Module base costs
const MODULE_BASE_COSTS = {
  gis: 8,
  ingest: 5,
  sim: 20
};

// Last calculated breakdown (cached for popover)
let lastBreakdowns = { gis: null, ingest: null, sim: null };

// Domain Package Intelligence mappings
const DOMAIN_PACKAGES = {
  agriculture: ['NDVI Crop Health', 'Carbon Accounting', 'MSPO Compliance', 'EUDR Export Regulation', 'Yield Prediction'],
  mining: ['SAR Coherence', 'Terrain Analysis', 'Anomaly Detection', 'Stockpile DEM', 'Subsidence Monitor'],
  disaster: ['Flood Modelling', 'Population Density Overlay', 'Infrastructure Stress', 'Evacuation Routing'],
  urban: ['Heat Island Analysis', 'Impervious Surface', 'Traffic Density Map', 'Zoning Compliance'],
  utilities: ['Vegetation Encroachment', 'Pipeline Thermal Scan', 'Transformer Hotspot', 'Grid Load Balance'],
  logistics: ['Port Congestion Tracker', 'Vessel Density Map', 'Road Obstruction Detector', 'Warehouse Volumetrics'],
  defense: ['Camouflage Detection', 'Border Activity Sensor', 'Underground Signature Radar', 'Restricted Zone Monitor'],
  environmental: ['Deforestation Rate Tracker', 'Coral Health Analytics', 'Methane Emission Radar', 'Biodiversity Index'],
  infrastructure: ['Bridge Deflection Monitor', 'Road Degradation Index', 'Levee Settlement Radar', 'InSAR Landslide Analysis'],
  emergency: ['Fire Perimeter Tracker', 'Flood Extent Mapping', 'Evacuation Corridors', 'Thermal Survivor Detection']
};

/**
 * Score value assessment factors dynamically for Layer 2
 */
function lenudaValueAssess(module, domainId, context = {}) {
  let severity = 40; // Default Operational
  let budget = 40;   // Default Enterprise/Gov
  let expansion = 50; 
  let revenue = 60;
  let criticality = 50;

  if (domainId === 'defense' || domainId === 'emergency' || domainId === 'disaster') {
    severity = 85;
    budget = 80;
    criticality = 90;
    expansion = 75;
  } else if (domainId === 'mining' || domainId === 'infrastructure' || domainId === 'utilities') {
    severity = 65;
    budget = 70;
    criticality = 75;
    expansion = 60;
  } else if (domainId === 'agriculture' || domainId === 'environmental' || domainId === 'urban' || domainId === 'logistics') {
    severity = 45;
    budget = 50;
    criticality = 55;
    expansion = 50;
  }

  if (context.problemSeverity !== undefined) severity = context.problemSeverity;
  if (context.budgetPower !== undefined) budget = context.budgetPower;
  if (context.expansionPotential !== undefined) expansion = context.expansionPotential;
  if (context.revenueOpportunity !== undefined) revenue = context.revenueOpportunity;
  if (context.domainCriticality !== undefined) criticality = context.domainCriticality;

  const avgScore = (severity + budget + expansion + revenue + criticality) / 5;
  const multiplier = Math.round((1.0 + (avgScore / 100) * 4.0) * 10) / 10;

  return {
    severity: { score: severity, label: getLabelForScore(severity, ['Research', 'Operational', 'Compliance', 'Safety Critical', 'National']) },
    budget: { score: budget, label: getLabelForScore(budget, ['Individual', 'SME', 'Enterprise', 'Government', 'Sovereign']) },
    expansion: { score: expansion, label: getLabelForScore(expansion, ['Single User', 'Department', 'Organization', 'Nationwide']) },
    revenue: { score: revenue, label: getLabelForScore(revenue, ['One-Off', 'Annual', 'Multi-Year', 'Enterprise SaaS']) },
    criticality: { score: criticality, label: getLabelForScore(criticality, ['Low', 'Medium', 'High', 'Critical', 'Life Safety']) },
    multiplier: multiplier
  };
}

function getLabelForScore(score, labels) {
  const index = Math.min(Math.floor((score / 100) * labels.length), labels.length - 1);
  return labels[index];
}

function lenudaPackageIntel(domainId) {
  return DOMAIN_PACKAGES[domainId] || DOMAIN_PACKAGES['agriculture'];
}

function buildDecisionLedger(technicalCost, valueAssessment, packages, domainId, module, totalCredits) {
  return {
    quote_id: `LND-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    timestamp: new Date().toISOString(),
    engine: "LENUDA Spatial Brain v2 (GEMINI Value Strategist Layer)",
    buyer_context: {
      domain: domainId,
      module_task: module,
      audit_proof_opt_in: sessionAuditEnabled
    },
    technical_cost_layer_1: {
      raw_base: technicalCost.base,
      factor_average: technicalCost.factorAvg,
      base_credits: Math.round(technicalCost.base * technicalCost.factorAvg)
    },
    value_assessment_layer_2: {
      problem_severity: valueAssessment.severity,
      budget_power: valueAssessment.budget,
      expansion_potential: valueAssessment.expansion,
      revenue_opportunity: valueAssessment.revenue,
      domain_criticality: valueAssessment.criticality,
      value_multiplier: valueAssessment.multiplier
    },
    package_intelligence_layer_3: {
      auto_enabled_features: packages,
      compliance_overlays: domainId === 'defense' ? ['Sovereign Guard', 'Encrypted GeoJSON'] : ['Merkle Proof Audit Ledger']
    },
    final_quote: {
      credits: totalCredits,
      recommended_cahaya_tier: totalCredits > 80 ? 'CAHAYA SOVEREIGN' : totalCredits > 35 ? 'CAHAYA STANDARD' : 'CAHAYA EDGE'
    },
    rationale: [
      `Buyer operating in high-consequence ${domainId} vertical.`,
      `Dynamic problem severity rated as ${valueAssessment.severity.label} with criticality level ${valueAssessment.criticality.label}.`,
      `Multiplied Layer 1 compute credits by value index factor of ${valueAssessment.multiplier}x.`,
      `Auto-provisioned Layer 3 modular package with ${packages.length} active microservices.`
    ]
  };
}

/**
 * Calculate credit cost using the 3-Layer Value Pricing Engine
 * @param {string} module - 'gis', 'ingest', or 'sim'
 * @param {object} context - { satCount, fileSize, scenarioComplexity, ... }
 * @returns {{ total: number, technical: object, valueAssess: object, packageIntel: Array, ledger: object }}
 */
function calculateCredits(module, context = {}) {
  const domain = domainsData[activeDomainIndex];
  const domainId = domain ? domain.id : 'agriculture';
  
  // Layer 1: Technical Cost
  let base = MODULE_BASE_COSTS[module] || 8;
  if (module === 'gis') base += (context.satCount || 1) * 2;
  if (module === 'ingest') base += (context.fileSize || 1) * 3;
  if (module === 'sim') base += (context.scenarioComplexity || 1) * 4;
  
  const factors = [];
  let weightSum = 0;
  const factorKeys = Object.keys(PRICING_FACTORS);
  
  factorKeys.forEach(key => {
    const f = PRICING_FACTORS[key];
    const w = f.weights[domainId] || 1.0;
    factors.push({
      key,
      label: f.label,
      desc: f.desc,
      icon: f.icon,
      weight: w
    });
    weightSum += w;
  });
  
  const factorAvg = weightSum / factorKeys.length;
  const techBaseCost = Math.round(base * factorAvg);
  const technicalLayer = { total: techBaseCost, base, factorAvg: Math.round(factorAvg * 100) / 100, factors };

  // Layer 2: Value Assessment
  const valueAssessLayer = lenudaValueAssess(module, domainId, context);

  // Layer 3: Package Intelligence
  const packageIntelLayer = lenudaPackageIntel(domainId);

  // Combine layers into final price
  const total = Math.round(techBaseCost * valueAssessLayer.multiplier);
  
  // Generate Decision Ledger
  const ledger = buildDecisionLedger(technicalLayer, valueAssessLayer, packageIntelLayer, domainId, module, total);
  
  const breakdown = {
    total,
    technical: technicalLayer,
    valueAssess: valueAssessLayer,
    packageIntel: packageIntelLayer,
    ledger,
    module,
    domainId
  };
  
  lastBreakdowns[module] = breakdown;
  
  // Keep record in session ledgers
  let ledgers = JSON.parse(sessionStorage.getItem('decision_ledgers') || '[]');
  ledgers.push(ledger);
  sessionStorage.setItem('decision_ledgers', JSON.stringify(ledgers));

  return breakdown;
}

/**
 * Show the pricing breakdown popover using 3-layer architecture visualizer
 */
window.showPricingBreakdown = function(module) {
  const breakdown = lastBreakdowns[module];
  if (!breakdown) {
    logConsole('⚠ No pricing data available. Run an operation first.');
    return;
  }
  
  const body = document.getElementById('pricing-popover-body');
  const footer = document.getElementById('pricing-popover-footer');
  if (!body || !footer) return;
  
  // Render Layer 1 (Technical Cost Details)
  let html = `
    <div class="pb-layer-section">
      <div class="pb-layer-title"><i data-lucide="cpu"></i> LAYER 1: TECHNICAL BASE COMPUTE</div>
      <div class="pb-base-row"><span class="pb-label">Base Module Cost</span><span class="pb-val">${breakdown.technical.base.toFixed(1)}</span></div>
      <div class="pb-divider"></div>
      <div class="pb-factors-mini-list">
  `;
  breakdown.technical.factors.forEach(f => {
    const barWidth = Math.round((f.weight / 2.5) * 100);
    const barColor = f.weight > 1.3 ? '#e63946' : f.weight < 0.8 ? '#02c39a' : '#ffb703';
    html += `
      <div class="pb-factor-row">
        <span class="pb-factor-name" style="width: 120px;">${f.label}</span>
        <div class="pb-factor-bar-wrap" style="flex: 1;">
          <div class="pb-factor-bar" style="width:${barWidth}%;background:${barColor};"></div>
        </div>
        <span class="pb-factor-val">&times; ${f.weight.toFixed(1)}</span>
      </div>`;
  });
  html += `
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 10px; margin-top: 6px; color: var(--text-main);">
        <span>Technical Weight Avg:</span>
        <span style="font-family: monospace;">${breakdown.technical.factorAvg}x</span>
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 11px; margin-top: 4px; font-weight: bold; color: #ffb703;">
        <span>Layer 1 Credits:</span>
        <span>${breakdown.technical.total} credits</span>
      </div>
    </div>
    
    <div class="pb-divider" style="margin: 10px 0;"></div>
    
    <!-- Layer 2: Value Assessment -->
    <div class="pb-layer-section">
      <div class="pb-layer-title"><i data-lucide="trending-up"></i> LAYER 2: BUSINESS VALUE MULTIPLIER</div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; font-size: 9px; color: var(--text-dim);">
        <div>Severity: <strong style="color: #ffffff;">${breakdown.valueAssess.severity.label} (${breakdown.valueAssess.severity.score})</strong></div>
        <div>Budget power: <strong style="color: #ffffff;">${breakdown.valueAssess.budget.label} (${breakdown.valueAssess.budget.score})</strong></div>
        <div>Expansion: <strong style="color: #ffffff;">${breakdown.valueAssess.expansion.label} (${breakdown.valueAssess.expansion.score})</strong></div>
        <div>Criticality: <strong style="color: #ffffff;">${breakdown.valueAssess.criticality.label} (${breakdown.valueAssess.criticality.score})</strong></div>
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 11px; margin-top: 8px; font-weight: bold; color: #4cc9f0;">
        <span>Value Assessment Multiplier:</span>
        <span>&times; ${breakdown.valueAssess.multiplier.toFixed(1)}</span>
      </div>
    </div>

    <div class="pb-divider" style="margin: 10px 0;"></div>
    
    <!-- Layer 3: Package Intelligence -->
    <div class="pb-layer-section">
      <div class="pb-layer-title"><i data-lucide="package"></i> LAYER 3: PACKAGE INTELLIGENCE</div>
      <p style="font-size: 9px; color: var(--text-dim); margin-bottom: 6px;">Auto-enabled microservices and integrations for this industry vertical:</p>
      <div style="display: flex; flex-wrap: wrap; gap: 4px;" id="pb-package-chips">
  `;
  breakdown.packageIntel.forEach(chip => {
    html += `<span class="badge" style="background: rgba(2, 195, 154, 0.1); border: 1px solid rgba(2, 195, 154, 0.3); color: #02c39a; font-size: 9px; padding: 2px 6px; border-radius: 4px;">${chip}</span>`;
  });
  html += `
      </div>
    </div>
  `;
  
  body.innerHTML = html;
  
  footer.innerHTML = `
    <div class="pb-total-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
      <span class="pb-total-label" style="font-size: 12px; font-weight: 700; color: #ffffff;">Final Quoted Credits</span>
      <span class="pb-total-val" style="font-size: 18px; font-weight: 800; color: #02c39a; font-family: monospace;">${breakdown.total} CR</span>
    </div>
    <div style="display: flex; gap: 8px; margin-top: 10px;">
      <button class="btn btn-secondary btn-small" style="flex: 1; font-size: 10px; padding: 6px;" onclick="viewQuoteReasoning('${module}')">
        <i data-lucide="file-json" style="width: 10px; height: 10px; margin-right: 4px;"></i> View Quote Reasoning
      </button>
      <button class="btn btn-primary btn-small" style="flex: 1; font-size: 10px; padding: 6px;" onclick="closePricingPopover()">
        Got it
      </button>
    </div>
  `;
  
  const backdrop = document.getElementById('pricing-popover-backdrop');
  if (backdrop) { backdrop.style.display = 'flex'; }
  lucide.createIcons();
};

window.closePricingPopover = function(e) {
  if (e && e.target !== e.currentTarget) return;
  const backdrop = document.getElementById('pricing-popover-backdrop');
  if (backdrop) { backdrop.style.display = 'none'; }
};

/**
 * Global function to show full Decision Ledger JSON Quote
 */
window.viewQuoteReasoning = function(module) {
  const breakdown = lastBreakdowns[module];
  if (!breakdown) return;
  
  closePricingPopover();
  
  const backdrop = document.getElementById('ledger-modal-backdrop');
  const body = document.getElementById('ledger-modal-body');
  if (!backdrop || !body) return;
  
  body.innerHTML = `<pre style="margin: 0; padding: 0; color: #02c39a; font-size: 11px;">${JSON.stringify(breakdown.ledger, null, 2)}</pre>`;
  backdrop.style.display = 'flex';
  
  // Bind close buttons
  const closeBtn = document.getElementById('btn-close-ledger-modal');
  if (closeBtn) {
    closeBtn.onclick = () => { backdrop.style.display = 'none'; };
  }
};


// ============================================================
// MERKLE TREE SHA-256 VERIFICATION
// ============================================================

// Session Merkle leaves (accumulate during operations)
let merkleLeaves = [];

function addMerkleLeaf(data) {
  if (!sessionAuditEnabled) return;
  const leaf = {
    timestamp: new Date().toISOString(),
    data: typeof data === 'string' ? data : JSON.stringify(data),
    index: merkleLeaves.length
  };
  merkleLeaves.push(leaf);
}

// SHA-256 hash using Web Crypto API
async function sha256(message) {
  const msgUint8 = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Build Merkle root from leaf hashes
async function buildMerkleRoot(leaves) {
  if (leaves.length === 0) return '0'.repeat(64);
  let level = [];
  for (const leaf of leaves) {
    level.push(await sha256(leaf.data + leaf.timestamp));
  }
  while (level.length > 1) {
    const next = [];
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left; // duplicate if odd
      next.push(await sha256(left + right));
    }
    level = next;
  }
  return level[0];
}

window.verifyMerkleProof = async function(module) {
  if (!sessionAuditEnabled) {
    logConsole('⚠ Audit proof is not enabled for this session.');
    return;
  }
  
  if (merkleLeaves.length === 0) {
    logConsole('⚠ No operations have been recorded in this session yet.');
    return;
  }
  
  deductCredits(2);
  logConsole('🔐 Verifying cryptographic proof — computing SHA-256 Merkle Tree...');
  
  const root = await buildMerkleRoot(merkleLeaves);
  const verification = {
    status: 'PASS',
    rootHash: root,
    leafCount: merkleLeaves.length,
    timestamp: new Date().toISOString(),
    module: module,
    algorithm: 'SHA-256 Merkle Tree'
  };
  
  // Show in the existing Merkle audit modal
  const modalBody = document.getElementById('merkle-modal-body');
  if (modalBody) {
    modalBody.innerHTML = `
      <div style="margin-bottom:12px;"><strong style="color:#02c39a;font-size:14px;">✅ VERIFICATION STATUS: ${verification.status}</strong></div>
      <div style="margin-bottom:8px;"><span style="color:var(--text-dimmed);">Root Hash:</span><br><span style="color:#ffb703;word-break:break-all;">${verification.rootHash}</span></div>
      <div style="margin-bottom:8px;"><span style="color:var(--text-dimmed);">Algorithm:</span> ${verification.algorithm}</div>
      <div style="margin-bottom:8px;"><span style="color:var(--text-dimmed);">Leaf Count:</span> ${verification.leafCount} operations sealed</div>
      <div style="margin-bottom:8px;"><span style="color:var(--text-dimmed);">Module:</span> ${module.toUpperCase()}</div>
      <div style="margin-bottom:8px;"><span style="color:var(--text-dimmed);">Verified At:</span> ${verification.timestamp}</div>
      <hr style="border:none;border-top:1px dashed rgba(255,255,255,0.1);margin:14px 0;">
      <div style="color:var(--text-dimmed);font-size:10px;">
        <strong>Sealed Operations (${merkleLeaves.length} leaves):</strong><br>
        ${merkleLeaves.map((l,i) => `<div style="margin:4px 0;padding:4px 6px;background:rgba(0,0,0,0.2);border-radius:3px;"><span style="color:#02c39a;">[${i}]</span> ${l.data.substring(0, 80)}${l.data.length > 80 ? '...' : ''}<br><span style="opacity:0.5;">${l.timestamp}</span></div>`).join('')}
      </div>
    `;
  }
  
  const backdrop = document.getElementById('merkle-audit-modal-backdrop');
  if (backdrop) { backdrop.style.display = 'flex'; }
  lucide.createIcons();
  logConsole(`✅ Merkle proof verified — ${verification.leafCount} leaves sealed. Root: ${verification.rootHash.substring(0, 16)}...`);
};

// Show Merkle verify buttons when audit is enabled and operations have run
function showMerkleVerifyButtons() {
  if (!sessionAuditEnabled) return;
  document.querySelectorAll('.btn-merkle-verify').forEach(btn => {
    btn.style.display = 'inline-flex';
  });
}

// Show pricing info buttons after operations
function showPricingInfoButton(module) {
  const btn = document.getElementById(`btn-pricing-info-${module}`);
  if (btn) btn.style.display = 'inline-flex';
}


// 2. Render Functions
function renderDomains() {
  const container = document.getElementById("domain-list");
  if (!container) return;
  container.innerHTML = "";
  
  domainsData.forEach((domain, idx) => {
    const isUnlocked = isDomainUnlocked(domain.id);
    const btn = document.createElement("button");
    btn.className = `domain-item ${idx === activeDomainIndex ? 'active' : ''} ${!isUnlocked ? 'locked' : ''}`;
    btn.id = `domain-btn-${domain.id}`;
    
    if (isUnlocked) {
      btn.onclick = () => loadDomain(idx);
    } else {
      btn.onclick = () => openDomainRequestModal(domain.id);
    }
    
    // Pick icon based on vertical ID
    let iconName = "grid";
    if (domain.id === "agriculture") iconName = "sprout";
    else if (domain.id === "mining") iconName = "pickaxe";
    else if (domain.id === "disaster") iconName = "droplets";
    else if (domain.id === "urban") iconName = "building-2";
    else if (domain.id === "utilities") iconName = "zap";
    else if (domain.id === "logistics") iconName = "truck";
    else if (domain.id === "defense") iconName = "shield";
    else if (domain.id === "environmental") iconName = "leaf";
    else if (domain.id === "infrastructure") iconName = "hard-hat";
    else if (domain.id === "emergency") iconName = "ambulance";
    
    let badgeHtml = `<span class="domain-badge-active"></span>`;
    if (!isUnlocked) {
      badgeHtml = `<i data-lucide="lock" class="domain-lock-icon"></i>`;
    }
    
    btn.innerHTML = `
      <div class="domain-item-label">
        <i data-lucide="${iconName}"></i>
        <span>${domain.name.split(" / ")[0]}</span>
      </div>
      ${badgeHtml}
    `;
    container.appendChild(btn);
  });
  lucide.createIcons();
  // Append any custom extensions after the standard domains
  if (typeof renderDomainExtensions === 'function') renderDomainExtensions();
}

function renderRepos() {
  const container = document.getElementById("repo-list");
  if (!container) return;
  container.innerHTML = "";
  
  reposData.forEach(repo => {
    const div = document.createElement("div");
    div.className = "repo-item";
    div.title = repo.desc;
    
    const statusClass = repo.type === "acquired" ? "status-active" : "status-research";
    const statusText = repo.type === "acquired" ? "Acquired" : "Research";
    
    div.innerHTML = `
      <div class="repo-header">
        <span class="repo-name">${repo.name}</span>
        <span class="repo-badge-status ${statusClass}">${statusText}</span>
      </div>
      <p class="repo-desc">${repo.desc}</p>
    `;
    container.appendChild(div);
  });
}

// 3. Domain Loader Control
function loadDomain(index) {
  // Update State
  activeDomainIndex = index;
  const domain = domainsData[index];
  
  // Update Active navigation item class
  document.querySelectorAll(".domain-nav .domain-item").forEach((btn, idx) => {
    btn.classList.toggle("active", idx === index);
  });
  
  // Dismiss the "Start Here" hint once any domain is clicked
  const startHint = document.getElementById('domain-start-hint');
  if (startHint) {
    startHint.style.opacity = '0';
    startHint.style.transition = 'opacity 0.5s ease';
    setTimeout(() => { startHint.style.display = 'none'; }, 500);
  }
  
  // Reset firstIngestVisit so demo reloads on new domain
  firstIngestVisit = true;
  
  // Update Body Theme
  document.body.setAttribute("data-theme", domain.theme);
  
  // Update Headers
  document.getElementById("active-domain-name").textContent = domain.name;
  
  // Set console message in footer
  logConsole(`🌍 ${domain.name} loaded — select a module engine above to begin your analysis.`);
  
  // Refresh module-specific UI on domain change
  updateSimMetadata();
  renderSatelliteSelector();
  selectedSatellites = []; // Reset satellite selection on domain switch
  updateCreditEstimate();
  
  // Render active satellite systems
  const satGrid = document.getElementById("satellite-status-grid");
  satGrid.innerHTML = "";
  domain.satellites.forEach(sat => {
    const row = document.createElement("div");
    row.className = "satellite-row";
    row.innerHTML = `
      <span>${sat}</span>
      <div class="sat-status-dot"></div>
    `;
    satGrid.innerHTML += row.outerHTML;
  });
  
  // Update Ingest tab samples list
  const sampleContainer = document.getElementById("sample-file-container");
  sampleContainer.innerHTML = "";
  domain.ingestFiles.forEach(file => {
    const btn = document.createElement("button");
    btn.className = "sample-btn";
    btn.onclick = () => simulateFileLoad(file);
    btn.innerHTML = `
      <span class="file-name">${file.name}</span>
      <span class="file-size">${file.size} | ${file.type}</span>
    `;
    sampleContainer.appendChild(btn);
  });
  
  // Reset Ingest Assistant tab outputs
  document.getElementById("extraction-file-badge").textContent = "UNLOADED";
  document.getElementById("extraction-file-badge").className = "badge";
  document.getElementById("point-density-count").textContent = "Density: 0 pts/m²";
  document.getElementById("extraction-timer").textContent = "Scan Duration: 0.0s";
  document.getElementById("btn-export-pdf").style.display = "none";
  const auditProofContainer = document.getElementById("audit-proof-container");
  if (auditProofContainer) auditProofContainer.style.display = "none";
  const extractionAttrs = document.getElementById("extraction-attributes");
  if (extractionAttrs) {
    extractionAttrs.innerHTML = `
      <div class="placeholder-text">Load a raw spatial file to begin feature extraction...</div>
    `;
  }
  
  // Load Default GIS Features
  selectedGisFeatureIndex = 0;
  loadGisFeaturesList();
  
  // Load Default CadQuery Script
  const cqEditor = document.getElementById("cadquery-code-editor");
  if (cqEditor) {
    cqEditor.value = domain.cadQueryScript;
    updateCodeHighlight();
  }
  const cqConsole = document.getElementById("cadquery-console");
  if (cqConsole) {
    cqConsole.innerHTML = `
      <span class="console-line-info">[SYSTEM] Initialized compiler for B-Rep solids. Ready.</span>
    `;
  }
  
  // Load Sim scenarios selection
  loadSimScenarios();
  
  // Switch to correct theme color on header elements
  updateDynamicAccentStyles();
  
  // Re-run icons
  lucide.createIcons();
  
  // Redraw canvases
  triggerCanvasesRedraw();

  // Update map domain if MapLibre is ready
  if (window.LenudaMap && window.LenudaMap.isReady && !window.LenudaMap.isFallback) {
    window.LenudaMap.setDomain(domain.id);
  }

  // Update dynamically populated companion stacks
  const bimCompanion = document.getElementById("bim-companion-list");
  if (bimCompanion) {
    bimCompanion.innerHTML = (domain.companionBim || []).map(repo => `
      <li class="tech-docs-item"><strong>${repo.name}:</strong> ${repo.desc} <a href="${repo.url}" target="_blank" style="color:var(--accent-color);">[GitHub]</a></li>
    `).join("");
  }
  const gisCompanion = document.getElementById("gis-companion-list");
  if (gisCompanion) {
    gisCompanion.innerHTML = (domain.companionGis || []).map(repo => `
      <li class="tech-docs-item"><strong>${repo.name}:</strong> ${repo.desc} <a href="${repo.url}" target="_blank" style="color:var(--accent-color);">[GitHub]</a></li>
    `).join("");
  }
  const simCompanion = document.getElementById("sim-companion-list");
  if (simCompanion) {
    simCompanion.innerHTML = (domain.companionSim || []).map(repo => `
      <li class="tech-docs-item"><strong>${repo.name}:</strong> ${repo.desc} <a href="${repo.url}" target="_blank" style="color:var(--accent-color);">[GitHub]</a></li>
    `).join("");
  }
}

function updateDynamicAccentStyles() {
  const accentColor = getComputedStyle(document.body).getPropertyValue("--accent-color").trim();
  // Modify graph indicators, highlights, etc.
}

let tabStartTime = Date.now();

// Telemetry interval logger
setInterval(() => {
  const duration = Math.round((Date.now() - tabStartTime) / 1000);
  if (duration >= 5) {
    tabStartTime = Date.now();
    const domain = domainsData[activeDomainIndex];
    apiFetch('/api/telemetry/log', {
      method: 'POST',
      body: JSON.stringify({
        user_id: "client_operator_1",
        action: "TAB_TIME_SPENT",
        metadata: {
          tab: activeTab,
          duration_sec: duration,
          domain: domain ? domain.id : 'agriculture'
        }
      })
    }).catch(() => {});
  }
}, 10000);

// 4. Tab Navigation Switches
window.switchTab = function(tabName) {
  window.switchEngineMode(tabName);
};

window.switchLeftSidebarPane = function(paneName) {
  const panes = ['domains', 'tools', 'vault'];
  panes.forEach(p => {
    const paneEl = document.getElementById(`pane-${p}`);
    if (paneEl) {
      paneEl.classList.toggle('active', p === paneName);
    }
    const btnEl = document.getElementById(`tab-btn-${p}`);
    if (btnEl) {
      btnEl.classList.toggle('active', p === paneName);
    }
  });
};

window.switchDrawerTab = function(tabName) {
  activeEditorTab = tabName;
  const tabs = ['attributes', 'diagnostics', 'docs'];
  tabs.forEach(t => {
    const paneEl = document.getElementById(`drawer-pane-${t}`);
    if (paneEl) {
      paneEl.classList.toggle('active', t === tabName);
    }
    const btnEl = document.getElementById(`btn-drawer-${t}`);
    if (btnEl) {
      btnEl.classList.toggle('active', t === tabName);
    }
  });
};

window.triggerReportDownload = function() {
  if (activeTab === 'gis') {
    if (!gisScanCompleted) {
      alert("Please run a GEE scan first before generating a report.");
      return;
    }
    window.generateGeeReport();
  } else if (activeTab === 'ingest') {
    const pdfBtn = document.getElementById("btn-export-pdf");
    if (pdfBtn && pdfBtn.style.display !== "none") {
      pdfBtn.click();
    } else {
      alert("Please ingest a spatial file first before generating a compliance sheet.");
    }
  } else if (activeTab === 'sim') {
    window.generateSimReport();
  } else if (activeTab === 'cahaya') {
    alert("Cahaya Sovereign Tier: License status and configuration report generated successfully.");
  }
};

window.triggerRawDownload = function() {
  if (activeTab === 'gis') {
    if (!gisScanCompleted) {
      alert("Please run a GEE scan first before downloading raw GIS data.");
      return;
    }
    window.downloadEsriShape();
  } else if (activeTab === 'ingest') {
    alert("Downloading raw ingested LiDAR point-cloud coordinates (compressed LAS/LAZ format)...");
  } else if (activeTab === 'sim') {
    window.downloadSimAssets();
  } else if (activeTab === 'cahaya') {
    alert("Downloading local vLLM parameter shards update package (turbovec format)...");
  }
};

window.downloadRawData = function(format) {
  const domain = domainsData[activeDomainIndex];
  if (format === 'csv') {
    alert(`Downloading raw scientific attributes for ${domain.name} as CSV table format.`);
  } else if (format === 'geojson') {
    alert(`Downloading raw spatial feature vectors for ${domain.name} as GeoJSON geometry collection.`);
  }
};

window.switchEngineMode = function(modeName) {
  if (modeName === 'cli') modeName = 'cahaya';
  
  const previousTab = activeTab;
  const duration = Math.round((Date.now() - tabStartTime) / 1000);
  tabStartTime = Date.now();
  
  if (duration >= 2) {
    const domain = domainsData[activeDomainIndex];
    apiFetch('/api/telemetry/log', {
      method: 'POST',
      body: JSON.stringify({
        user_id: "client_operator_1",
        action: "TAB_TIME_SPENT",
        metadata: {
          tab: previousTab,
          duration_sec: duration,
          domain: domain ? domain.id : 'agriculture'
        }
      })
    }).catch(() => {});
  }

  activeTab = modeName;
  
  // 1. Toggle active state of HUD buttons
  const modes = ['gis', 'ingest', 'sim', 'cahaya'];
  modes.forEach(m => {
    const btn = document.getElementById(`hud-tab-${m}`);
    if (btn) btn.classList.toggle('active', m === modeName);
  });
  
  // 2. Toggle active viewport layer
  modes.forEach(m => {
    const id = (m === 'gis') ? 'map-viewport' : `${m}-viewport`;
    const viewport = document.getElementById(id);
    if (viewport) viewport.classList.toggle('active', m === modeName);
  });

  // 3. Toggle active chat panel
  modes.forEach(m => {
    const chatPanel = document.getElementById(`chat-${m}`);
    if (chatPanel) {
      chatPanel.style.display = (m === modeName) ? 'flex' : 'none';
    }
  });

  // 4. Toggle active toolbox inside the Left Sidebar tools pane
  modes.forEach(m => {
    const toolbox = document.getElementById(`tools-${m}`);
    if (toolbox) {
      toolbox.style.display = (m === modeName) ? 'block' : 'none';
    }
  });

  // 5. Update toolbox heading name
  const toolsHeading = document.getElementById("tools-pane-heading");
  if (toolsHeading) {
    const headings = {
      gis: 'GEE SCANNER TOOLS',
      ingest: 'AI INGESTION TOOLS',
      sim: 'SIMULATION SETTINGS',
      cahaya: 'SOVEREIGN LICENSE TOOLS'
    };
    toolsHeading.textContent = headings[modeName] || 'TOOLS';
  }

  // 6. Sync tables in the bottom drawer based on the engine mode
  const gisTable = document.getElementById("gis-attributes-table");
  const ingestTable = document.getElementById("ingest-attributes-table");
  if (modeName === 'ingest') {
    if (gisTable) gisTable.style.display = 'none';
    if (ingestTable) ingestTable.style.display = 'table';
  } else {
    if (gisTable) gisTable.style.display = 'table';
    if (ingestTable) ingestTable.style.display = 'none';
  }

  // Contextual footer guidance messages — module engine language
  const footerGuidance = {
    gis: '🛰 Earth Intelligence Engine — select satellites, describe your query, click Scan with AI to get spatial intelligence.',
    ingest: '🤖 AI Work Engine — load a sample or drag your own file. Our AI will extract and analyse it for you.',
    sim: '🌐 Simulation Lab — select a scenario and run the 3D digital twin physics solver. Download assets or generate a report when done.',
    cahaya: '🏗️ CAHAYA Sovereign Guide — compare deployment tiers, review pricing, activate licensing, and manage the local CLI stack.'
  };
  logConsole(footerGuidance[modeName] || `Module: ${modeName.toUpperCase()}`);
  
  // Update sim metadata when switching to simulation lab
  if (modeName === 'sim') {
    updateSimMetadata();
  }
  
  // Refresh satellite selector when switching to Earth Intelligence
  if (modeName === 'gis') {
    renderSatelliteSelector();
  }
  
  // Auto-load demo on first visit to AI Work Engine tab
  if (modeName === 'ingest' && firstIngestVisit) {
    firstIngestVisit = false;
    setTimeout(() => {
      const files = domainsData[activeDomainIndex].ingestFiles;
      if (files && files.length > 0) {
        simulateFileLoad(files[0]);
        showDemoBanner();
      }
    }, 600);
  }
  
  triggerCanvasesRedraw();
};

function showDemoBanner() {
  const banner = document.getElementById('ingest-guide-banner');
  if (!banner) return;
  // Add a small demo loaded notice at the top of the guide banner
  const notice = banner.querySelector('.demo-notice');
  if (!notice) {
    const div = document.createElement('div');
    div.className = 'demo-notice';
    div.innerHTML = `<i data-lucide="sparkles" style="width:12px;height:12px;margin-right:4px;"></i>Demo dataset loaded automatically. Drag your own file to replace it.`;
    banner.insertBefore(div, banner.firstChild);
    lucide.createIcons();
  }
}

// updateStepTracker — no longer used (step tracker removed), kept as no-op for safety
function updateStepTracker(tabName) { /* module engine architecture replaces step tracker */ }

// 5. Ingestion Assistant Simulator (Layer 2)
let isIngesting = false;
let ingestCanvas = document.getElementById("ingest-canvas");
let ingestCtx = ingestCanvas.getContext("2d");
let ingestAnimationId = null;
let currentIngestedFileName = "";
let currentIngestedFileSize = "";

function simulateFileLoad(file) {
  if (isIngesting) return;
  isIngesting = true;
  currentIngestedFileName = file.name;
  currentIngestedFileSize = file.size;
  
  logConsole(`Initiated raw file ingestion: ${file.name}`);
  
  const progressWrapper = document.getElementById("extraction-progress-wrapper");
  const progressFill = document.getElementById("extraction-progress-fill");
  const percentageTxt = document.getElementById("extraction-percentage");
  const statusTxt = document.getElementById("extraction-status-text");
  const badge = document.getElementById("extraction-file-badge");
  const timerTxt = document.getElementById("extraction-timer");
  const densityTxt = document.getElementById("point-density-count");
  const loaderOverlay = document.getElementById("ingest-loading-overlay");
  const loaderText = document.getElementById("ingest-loader-text");
  const laserLine = document.getElementById("ingest-scanner-laser");
  
  // Reset UI
  progressWrapper.style.display = "block";
  badge.textContent = "INGESTING";
  badge.className = "badge badge-pulse";
  loaderOverlay.style.display = "flex";
  loaderText.textContent = "Loading file block into turbovec compressed buffers...";
  densityTxt.textContent = `Target Density: ${file.density}`;
  
  let progress = 0;
  let startTime = Date.now();
  
  // Animate Laser and points canvas
  laserLine.style.display = "block";
  let scanPoints = [];
  
  // --- REAL BACKEND API CALL (fire-and-forget alongside UI animation) ---
  let backendResult = null;
  apiFetch('/api/ingest/process', {
    method: 'POST',
    body: JSON.stringify({
      filename: file.name,
      filesize: file.size,
      filetype: file.type,
      density: file.density,
      domain: domainsData[activeDomainIndex].id
    })
  }).then(result => {
    backendResult = result;
    console.log('[Ingest] Backend processing complete:', result);
  }).catch(err => {
    console.warn('[Ingest] Backend unavailable, using local simulation:', err.message);
  });
  
  // Ingest simulation loop (UI animation continues regardless)
  const interval = setInterval(() => {
    progress += 4;
    progressFill.style.style = `width: ${progress}%`;
    progressFill.style.width = `${progress}%`;
    percentageTxt.textContent = `${progress}%`;
    
    let duration = ((Date.now() - startTime) / 1000).toFixed(1);
    timerTxt.textContent = `Scan Duration: ${duration}s`;
    
    if (progress < 25) {
      statusTxt.textContent = "Allocating Air-Gapped memory buffers...";
    } else if (progress < 55) {
      loaderText.textContent = "Filtering points and trimming noise in SuperSplat memory layout...";
      statusTxt.textContent = "Applying SuperSplat noise filter...";
    } else if (progress < 85) {
      loaderText.textContent = "Running neural feature-extraction computer-vision filters...";
      statusTxt.textContent = "Running machine-vision palm tree/asset counter...";
      // Generate some mock scanning dots on Canvas
      generateScanPoints(scanPoints);
      drawScanCanvas(scanPoints);
    } else {
      statusTxt.textContent = "Writing cryptographic payload ledger lock...";
    }
    
    if (progress >= 100) {
      clearInterval(interval);
      isIngesting = false;
      progressWrapper.style.display = "none";
      loaderOverlay.style.display = "none";
      laserLine.style.display = "none";
      badge.textContent = "COMPLETED";
      badge.className = "badge status-active";
      
      // Use backend result attributes if available
      if (backendResult && backendResult.attributes) {
        logConsole(`Ingestion complete: ${file.name}. Backend AI extraction applied.`);
        displayExtractedAttributesFromBackend(backendResult.attributes, file);
      } else {
        logConsole(`Ingestion complete: ${file.name}. Feature attributes locked.`);
        displayExtractedAttributes(file);
      }
      drawFinalOrthoCanvas(file);
      
      // Trigger Project Bayu ledger call
      if (window.bayuLogTransaction) {
        window.bayuLogTransaction({
          action: `Layer-2 Data Ingest: ${file.name}`,
          satellites: domainsData[activeDomainIndex].satellites.length,
          agents: file.type.includes("LiDAR") ? 15 : 0,
          volume: parseFloat(file.size) * (file.size.includes("GB") ? 1.0 : 0.001)
        });
      }
    }
  }, 100);
}

// Display extracted attributes from backend API response
function displayExtractedAttributesFromBackend(attrs, file) {
  const container = document.getElementById("extraction-attributes");
  if (container) container.innerHTML = "";
  
  const tableBody = document.getElementById("extraction-attributes-table-body");
  if (tableBody) tableBody.innerHTML = "";
  
  const parsedAttrs = Array.isArray(attrs) ? attrs : Object.entries(attrs).map(([k,v]) => ({name: k, val: v}));
  parsedAttrs.forEach(attr => {
    const attrVal = attr.val || attr.value || "";
    if (container) {
      const row = document.createElement("div");
      row.className = "attribute-row";
      row.innerHTML = `
        <span class="attr-name">${attr.name}</span>
        <span class="attr-val">${attrVal}</span>
      `;
      container.appendChild(row);
    }
    
    if (tableBody) {
      const tr = document.createElement("tr");
      tr.style.borderBottom = "1px solid var(--border-light)";
      tr.innerHTML = `
        <td style="padding:6px 8px; font-weight:700; color:var(--text-main);">${attr.name}</td>
        <td style="padding:6px 8px; color:var(--text-muted); font-family:var(--font-mono);">String</td>
        <td style="padding:6px 8px; color:#ffd166; font-weight:700;">${attrVal}</td>
      `;
      tableBody.appendChild(tr);
    }
  });
  
  // Update badge count
  const badge = document.getElementById("attributes-count-badge");
  if (badge && tableBody) {
    const count = tableBody.querySelectorAll("tr").length;
    badge.textContent = `${count} properties`;
  }
  
  // Show PDF export button
  const pdfBtn = document.getElementById("btn-export-pdf");
  const auditProofContainer = document.getElementById("audit-proof-container");
  if (auditProofContainer) auditProofContainer.style.display = "block";
  if (pdfBtn) {
    pdfBtn.style.display = "block";
    pdfBtn.onclick = async () => {
      const isAuditProofChecked = document.getElementById("audit-proof-checkbox")?.checked;
      if (isAuditProofChecked) {
        await showMerkleAuditReport();
      } else {
        alert(`LENUDA Stack Compliance Auditor:\n\nOfficial audit-ready report PDF generated successfully for workspace context.\nFile saved to local air-gapped system directories.`);
        logConsole("Generated standard compliance PDF verification report sheet.");
      }
    };
  }
}

function generateScanPoints(arr) {
  // Generate random coordinate point particles for pointcloud simulation
  for (let i = 0; i < 20; i++) {
    arr.push({
      x: Math.random() * ingestCanvas.width,
      y: Math.random() * ingestCanvas.height,
      color: `rgba(${Math.floor(Math.random() * 100 + 100)}, 255, ${Math.floor(Math.random() * 100 + 150)}, ${Math.random()})`,
      size: Math.random() * 3 + 1
    });
  }
}

function drawScanCanvas(points) {
  ingestCtx.fillStyle = "#040508";
  ingestCtx.fillRect(0, 0, ingestCanvas.width, ingestCanvas.height);
  
  // Draw points
  points.forEach(pt => {
    ingestCtx.beginPath();
    ingestCtx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
    ingestCtx.fillStyle = pt.color;
    ingestCtx.fill();
  });
  
  // Draw crosshairs
  ingestCtx.strokeStyle = "rgba(255, 255, 255, 0.03)";
  ingestCtx.lineWidth = 1;
  ingestCtx.beginPath();
  ingestCtx.moveTo(ingestCanvas.width / 2, 0);
  ingestCtx.lineTo(ingestCanvas.width / 2, ingestCanvas.height);
  ingestCtx.moveTo(0, ingestCanvas.height / 2);
  ingestCtx.lineTo(ingestCanvas.width, ingestCanvas.height / 2);
  ingestCtx.stroke();
}

function drawFinalOrthoCanvas(file) {
  ingestCtx.fillStyle = "#040508";
  ingestCtx.fillRect(0, 0, ingestCanvas.width, ingestCanvas.height);
  
  const themeColor = getComputedStyle(document.body).getPropertyValue("--accent-color").trim();
  
  // Draw nice grid
  ingestCtx.strokeStyle = "rgba(255, 255, 255, 0.03)";
  ingestCtx.lineWidth = 1;
  const step = 20;
  for (let x = 0; x < ingestCanvas.width; x += step) {
    ingestCtx.beginPath();
    ingestCtx.moveTo(x, 0);
    ingestCtx.lineTo(x, ingestCanvas.height);
    ingestCtx.stroke();
  }
  for (let y = 0; y < ingestCanvas.height; y += step) {
    ingestCtx.beginPath();
    ingestCtx.moveTo(0, y);
    ingestCtx.lineTo(ingestCanvas.width, y);
    ingestCtx.stroke();
  }
  
  // Draw scanned target vectors overlay (Simulated detected assets)
  ingestCtx.strokeStyle = themeColor;
  ingestCtx.lineWidth = 1.5;
  ingestCtx.fillStyle = `${themeColor}22`;
  
  if (activeDomainIndex === 0) { // Agriculture: draws circles around tree targets
    for (let i = 0; i < 24; i++) {
      let x = 50 + (i % 6) * 60 + Math.sin(i) * 10;
      let y = 40 + Math.floor(i / 6) * 60 + Math.cos(i) * 10;
      ingestCtx.beginPath();
      ingestCtx.arc(x, y, 12, 0, Math.PI * 2);
      ingestCtx.stroke();
      ingestCtx.fill();
      
      ingestCtx.fillStyle = themeColor;
      ingestCtx.fillRect(x - 2, y - 2, 4, 4);
      ingestCtx.fillStyle = `${themeColor}22`;
    }
  } else if (activeDomainIndex === 1) { // Mining: draws concentric geological contours
    ingestCtx.beginPath();
    ingestCtx.arc(ingestCanvas.width / 2, ingestCanvas.height / 2, 100, 0, Math.PI * 2);
    ingestCtx.stroke();
    ingestCtx.fill();
    ingestCtx.beginPath();
    ingestCtx.arc(ingestCanvas.width / 2, ingestCanvas.height / 2, 70, 0, Math.PI * 2);
    ingestCtx.stroke();
    ingestCtx.fill();
    ingestCtx.beginPath();
    ingestCtx.arc(ingestCanvas.width / 2, ingestCanvas.height / 2, 40, 0, Math.PI * 2);
    ingestCtx.stroke();
    ingestCtx.fill();
  } else { // Others: draw bounding boxes
    for (let i = 0; i < 6; i++) {
      let w = 40 + Math.random() * 20;
      let h = 30 + Math.random() * 20;
      let x = 30 + Math.random() * (ingestCanvas.width - 100);
      let y = 30 + Math.random() * (ingestCanvas.height - 100);
      ingestCtx.strokeRect(x, y, w, h);
      ingestCtx.fillRect(x, y, w, h);
    }
  }
}

function displayExtractedAttributes(file) {
  const container = document.getElementById("extraction-attributes");
  if (container) container.innerHTML = "";
  
  const tableBody = document.getElementById("extraction-attributes-table-body");
  if (tableBody) tableBody.innerHTML = "";
  
  let attrs = [];
  if (activeDomainIndex === 0) {
    attrs = [
      { name: "Total Trees Scanned", val: "4,821 canopy heads" },
      { name: "Crown Density Mean", val: "68.2%" },
      { name: "Nitrogen Deficit Zone", val: "1.2 hectares" },
      { name: "Stand Spacing Error", val: "4% deviation" },
      { name: "Canopy Biomass Estimate", val: "12,450 tons" }
    ];
  } else if (activeDomainIndex === 1) {
    attrs = [
      { name: "Pit Face Slope Angle", val: "68.4°" },
      { name: "Calculated Stockpile Vol", val: "24,820 m³" },
      { name: "Copper Ore Tonnage Est", val: "64,532 tons" },
      { name: "Pit Wall Fractures", val: "2 active slippages" },
      { name: "Haul Road Grade Max", val: "12.4%" }
    ];
  } else if (activeDomainIndex === 2) {
    attrs = [
      { name: "Debris Volume Roadblocks", val: "840 m³" },
      { name: "Structures Ruined Tally", val: "18 buildings" },
      { name: "Flood Line Elevation", val: "42.8m above datum" },
      { name: "Evac Bottleneck Sectors", val: "Highway 2 / Ramp C" },
      { name: "Refuge Capacity Remaining", val: "220 beds" }
    ];
  } else {
    attrs = [
      { name: "Vector Extrusion Count", val: "148 features" },
      { name: "Coordinate Datum Shift", val: "0.0mm deviation" },
      { name: "Scan Integrity Rate", val: "99.85%" },
      { name: "Computed Asset Volume", val: "420,000 units" },
      { name: "Validation Standard", val: "Compliance Audit Pass" }
    ];
  }
  
  attrs.forEach(attr => {
    if (container) {
      const row = document.createElement("div");
      row.className = "attribute-row";
      row.innerHTML = `
        <span class="attr-name">${attr.name}</span>
        <span class="attr-val">${attr.val}</span>
      `;
      container.appendChild(row);
    }
    
    if (tableBody) {
      const tr = document.createElement("tr");
      tr.style.borderBottom = "1px solid var(--border-light)";
      tr.innerHTML = `
        <td style="padding:6px 8px; font-weight:700; color:var(--text-main);">${attr.name}</td>
        <td style="padding:6px 8px; color:var(--text-muted); font-family:var(--font-mono);">String</td>
        <td style="padding:6px 8px; color:#ffd166; font-weight:700;">${attr.val}</td>
      `;
      tableBody.appendChild(tr);
    }
  });
  
  // Update badge count
  const badge = document.getElementById("attributes-count-badge");
  if (badge && tableBody) {
    const count = tableBody.querySelectorAll("tr").length;
    badge.textContent = `${count} properties`;
  }
  
  // Show PDF export button
  const pdfBtn = document.getElementById("btn-export-pdf");
  const auditProofContainer = document.getElementById("audit-proof-container");
  if (auditProofContainer) auditProofContainer.style.display = "block";
  if (pdfBtn) {
    pdfBtn.style.display = "block";
    pdfBtn.onclick = async () => {
      const isAuditProofChecked = document.getElementById("audit-proof-checkbox")?.checked;
      if (isAuditProofChecked) {
        await showMerkleAuditReport();
      } else {
        alert(`LENUDA Stack Compliance Auditor:\n\nOfficial audit-ready report PDF generated successfully for workspace context.\nFile saved to local air-gapped system directories.`);
        logConsole("Generated standard compliance PDF verification report sheet.");
      }
    };
  }
}

// 6. Layer 1: Parametric GIS Map & Relational Attributes Table
let gisCanvas = document.getElementById("gis-canvas");
let gisCtx = gisCanvas.getContext("2d");
let gisMapMode = "vector"; // or "multispectral"
let gisZoomLevel = 1.0;

// Interactive Polygon State
let gisPolygonVertices = [
  {x: -120, y: -60},
  {x: 100, y: -70},
  {x: 120, y: 50},
  {x: -90, y: 80}
];
let gisDraggedVertex = -1;
let gisScanCompleted = false;
let gisLastScanLocation = "Perak, Malaysia";

// Domain-specific custom interactive outputs parameters
let domainCustomParams = {
  agriculture: { weights: [85, 72, 90, 64], names: ["North Hectare", "South Drainage", "East Flatlands", "West Slope"] },
  mining: { elevation_baseline: 120, baseline_offset: 0.0, volume: 14800 },
  disaster: { blocked_roads: [true, false, true], names: ["Highway 2 Link", "Bridge Bypass B", "Coastal Evac Corridor"] },
  urban: { building_heights: [15, 10, 24], names: ["Sector 4 Block A", "West Plaza Commercial", "East Transit Tower"] },
  utilities: { transformers: [true, false, true], names: ["TX-4 Main Grid", "Stepdown Hub B", "North Substation"] },
  logistics: { waypoints: [{x: -80, y: -20}, {x: -20, y: 10}, {x: 60, y: -10}] },
  defense: { exclusion_zones: [{name: "Threat Zone Delta", radius: 55, x: -30, y: 20}] },
  environmental: { carbon_multipliers: [1.2, 0.85, 2.1], names: ["Wetlands Sync", "Peatland Weight", "Canopy Absorption"] },
  infrastructure: { foundation_depth: 18, concrete_grade: 45 },
  emergency: { responders: [{name: "Ambulance Team Alpha", x: 40, y: -30}, {name: "Fire Unit 2", x: -60, y: 40}] }
};

// Canvas Mouse Interactions
function initGisCanvasInteraction() {
  if (!gisCanvas) return;
  
  gisCanvas.addEventListener("mousedown", (e) => {
    if (!gisScanCompleted) return;
    const rect = gisCanvas.getBoundingClientRect();
    // Compute translated/scaled coordinates matching canvas center
    const mx = (e.clientX - rect.left - gisCanvas.width / 2) / gisZoomLevel;
    const my = (e.clientY - rect.top - gisCanvas.height / 2) / gisZoomLevel;
    
    // Check if clicking near any vertex (12px hit radius)
    let vertexHit = -1;
    for (let i = 0; i < gisPolygonVertices.length; i++) {
      const v = gisPolygonVertices[i];
      if (Math.hypot(v.x - mx, v.y - my) < 12) {
        vertexHit = i;
        break;
      }
    }
    
    if (vertexHit !== -1) {
      gisDraggedVertex = vertexHit;
      gisCanvas.style.cursor = "grabbing";
      return;
    }
    
    // Handle specific interactive items based on domains
    const domainId = domainsData[activeDomainIndex].id;
    if (domainId === "emergency") {
      // Check if clicking responder icons
      const params = domainCustomParams.emergency;
      params.responders.forEach((resp, idx) => {
        if (Math.hypot(resp.x - mx, resp.y - my) < 16) {
          gisDraggedVertex = 100 + idx; // Offset to separate responder index
          gisCanvas.style.cursor = "grabbing";
        }
      });
    } else if (domainId === "logistics") {
      // Drag Logistics waypoints
      const params = domainCustomParams.logistics;
      params.waypoints.forEach((wp, idx) => {
        if (Math.hypot(wp.x - mx, wp.y - my) < 12) {
          gisDraggedVertex = 200 + idx; // Offset for logistics index
          gisCanvas.style.cursor = "grabbing";
        }
      });
    }
  });

  gisCanvas.addEventListener("mousemove", (e) => {
    if (!gisScanCompleted) return;
    const rect = gisCanvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left - gisCanvas.width / 2) / gisZoomLevel;
    const my = (e.clientY - rect.top - gisCanvas.height / 2) / gisZoomLevel;
    
    if (gisDraggedVertex === -1) {
      // Hover effects
      let hoverIdx = -1;
      for (let i = 0; i < gisPolygonVertices.length; i++) {
        if (Math.hypot(gisPolygonVertices[i].x - mx, gisPolygonVertices[i].y - my) < 12) {
          hoverIdx = i;
          break;
        }
      }
      gisCanvas.style.cursor = hoverIdx !== -1 ? "pointer" : "default";
      return;
    }
    
    // Perform Drag Operations
    if (gisDraggedVertex >= 200) {
      const idx = gisDraggedVertex - 200;
      domainCustomParams.logistics.waypoints[idx] = { x: Math.round(mx), y: Math.round(my) };
    } else if (gisDraggedVertex >= 100) {
      const idx = gisDraggedVertex - 100;
      domainCustomParams.emergency.responders[idx] = { x: Math.round(mx), y: Math.round(my) };
    } else {
      gisPolygonVertices[gisDraggedVertex] = { x: Math.round(mx), y: Math.round(my) };
    }
    
    drawGisCanvas();
    loadGisFeaturesList(); // Update parameter inputs live
  });

  gisCanvas.addEventListener("mouseup", () => {
    gisDraggedVertex = -1;
    if (gisCanvas) gisCanvas.style.cursor = "default";
  });
  
  gisCanvas.addEventListener("mouseleave", () => {
    gisDraggedVertex = -1;
  });
}

function loadGisFeaturesList() {
  const domain = domainsData[activeDomainIndex];
  const domainId = domain.id;
  const tableBody = document.getElementById("attributes-table-body");
  if (!tableBody) return;
  tableBody.innerHTML = "";
  
  const sfTitle = document.getElementById("selected-feature-title");
  if (sfTitle) sfTitle.textContent = `Active Workspace: ${gisLastScanLocation}`;

  if (!gisScanCompleted) {
    tableBody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:var(--text-dimmed); padding:20px;">Run GEE scan to extract editable attributes and parameters.</td></tr>`;
    const badge = document.getElementById("attributes-count-badge");
    if (badge) badge.textContent = "0 properties";
    return;
  }
  
  // Render Domain-Specific Interactive Output result panels
  const params = domainCustomParams[domainId];
  
  if (domainId === "agriculture") {
    // 1. Agriculture Canopy cell weights adjusters
    params.names.forEach((name, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">${name} weight</td>
        <td style="color:#02c39a; font-size:10px;">Soil Weight (%)</td>
        <td>
          <input type="range" min="10" max="100" value="${params.weights[idx]}" style="width:100px;" oninput="updateAgriWeight(${idx}, this.value)">
          <span style="font-family:monospace; margin-left:6px; color:#ffffff;">${params.weights[idx]}%</span>
        </td>
      `;
      tableBody.appendChild(row);
    });
  } else if (domainId === "mining") {
    // 2. Mining Elevation Baseline Sliders
    const row = document.createElement("tr");
    row.innerHTML = `
      <td style="color:var(--text-muted); font-weight:600;">Elevation Baseline</td>
      <td style="color:#4cc9f0; font-size:10px;">Datum Offset (m)</td>
      <td>
        <input type="range" min="-10" max="10" step="0.5" value="${params.baseline_offset}" style="width:100px;" oninput="updateMiningBaseline(this.value)">
        <span style="font-family:monospace; margin-left:6px; color:#ffffff;">${params.baseline_offset > 0 ? '+' : ''}${params.baseline_offset}m</span>
      </td>
    `;
    tableBody.appendChild(row);
    
    const row2 = document.createElement("tr");
    const vol = Math.round(params.volume * (1.0 + params.baseline_offset / 10));
    row2.innerHTML = `
      <td style="color:var(--text-muted); font-weight:600;">Subsurface Vol.</td>
      <td style="color:#e63946; font-size:10px;">Calculated Space</td>
      <td style="font-family:monospace; color:#ffffff; font-weight:700;">${vol.toLocaleString()} m³</td>
    `;
    tableBody.appendChild(row2);
  } else if (domainId === "disaster") {
    // 3. Disaster evacuation routes toggles (interactive segment road erasure)
    params.names.forEach((name, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">${name}</td>
        <td style="color:#ffb703; font-size:10px;">Road Status</td>
        <td>
          <button class="btn btn-small" style="background:${params.blocked_roads[idx] ? '#e63946' : '#02c39a'}; padding:2px 8px; font-size:9px;" onclick="toggleRoadStatus(${idx})">
            ${params.blocked_roads[idx] ? 'FLOODED / BLOCK' : 'OPEN / CLEAR'}
          </button>
        </td>
      `;
      tableBody.appendChild(row);
    });
  } else if (domainId === "urban") {
    // 4. Urban CityGML Building Heights scaling
    params.names.forEach((name, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">${name}</td>
        <td style="color:#4cc9f0; font-size:10px;">Floor count</td>
        <td>
          <input type="range" min="2" max="40" value="${params.building_heights[idx]}" style="width:100px;" oninput="updateUrbanHeight(${idx}, this.value)">
          <span style="font-family:monospace; margin-left:6px; color:#ffffff;">${params.building_heights[idx]}F</span>
        </td>
      `;
      tableBody.appendChild(row);
    });
  } else if (domainId === "utilities") {
    // 5. Utilities PostGIS active transformer toggles
    params.names.forEach((name, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">${name}</td>
        <td style="color:#e63946; font-size:10px;">Flow Math Switch</td>
        <td>
          <button class="btn btn-small" style="background:${params.transformers[idx] ? '#02c39a' : '#555'}; padding:2px 8px; font-size:9px;" onclick="toggleTransformer(${idx})">
            ${params.transformers[idx] ? 'ONLINE (ACTIVE)' : 'OFFLINE (CUT)'}
          </button>
        </td>
      `;
      tableBody.appendChild(row);
    });
  } else if (domainId === "logistics") {
    // 6. Logistics waypoints coordination matrix
    params.waypoints.forEach((wp, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">Waypoint ${idx+1}</td>
        <td style="color:#02c39a; font-size:10px;">XY Vector</td>
        <td style="font-family:monospace; color:#ffffff; font-size:11px;">
          X: ${wp.x} px, Y: ${wp.y} px
        </td>
      `;
      tableBody.appendChild(row);
    });
  } else if (domainId === "defense") {
    // 7. Defense high-precision SQLite border exclusion zone adder
    const row = document.createElement("tr");
    row.innerHTML = `
      <td style="color:var(--text-muted); font-weight:600;">Security Overlay</td>
      <td style="color:#e63946; font-size:10px;">Zone Size</td>
      <td>
        <input type="range" min="10" max="150" value="${params.exclusion_zones[0].radius}" style="width:100px;" oninput="updateDefenseZoneSize(this.value)">
        <span style="font-family:monospace; margin-left:6px; color:#ffffff;">${params.exclusion_zones[0].radius}m</span>
      </td>
    `;
    tableBody.appendChild(row);
  } else if (domainId === "environmental") {
    // 8. Environmental sheet matrix multiplier variables
    params.names.forEach((name, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">${name}</td>
        <td style="color:#02c39a; font-size:10px;">Multiplier</td>
        <td>
          <input type="number" step="0.05" value="${params.carbon_multipliers[idx]}" style="width:80px; background:rgba(0,0,0,0.5); border:1px solid var(--border-light); color:#fff; font-size:11px;" onchange="updateEnvironmentalMultiplier(${idx}, this.value)">
        </td>
      `;
      tableBody.appendChild(row);
    });
  } else if (domainId === "infrastructure") {
    // 9. Infrastructure solid STEP model depth/grade
    const row1 = document.createElement("tr");
    row1.innerHTML = `
      <td style="color:var(--text-muted); font-weight:600;">Foundation Depth</td>
      <td style="color:#ffb703; font-size:10px;">Civil Datum (m)</td>
      <td>
        <input type="range" min="5" max="50" value="${params.foundation_depth}" style="width:100px;" oninput="updateInfraDepth(this.value)">
        <span style="font-family:monospace; margin-left:6px; color:#ffffff;">${params.foundation_depth}m</span>
      </td>
    `;
    tableBody.appendChild(row1);
    const row2 = document.createElement("tr");
    row2.innerHTML = `
      <td style="color:var(--text-muted); font-weight:600;">Concrete Grade</td>
      <td style="color:#02c39a; font-size:10px;">Structural (MPa)</td>
      <td>
        <input type="number" value="${params.concrete_grade}" style="width:80px; background:rgba(0,0,0,0.5); border:1px solid var(--border-light); color:#fff; font-size:11px;" onchange="updateInfraGrade(this.value)">
      </td>
    `;
    tableBody.appendChild(row2);
  } else if (domainId === "emergency") {
    // 10. Emergency dispatch responder icons coordinates
    params.responders.forEach((resp, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td style="color:var(--text-muted); font-weight:600;">${resp.name}</td>
        <td style="color:#e63946; font-size:10px;">GPS Vectors</td>
        <td style="font-family:monospace; color:#ffffff; font-size:10px;">
          X: ${resp.x}, Y: ${resp.y} (Drag icon to dispatch)
        </td>
      `;
      tableBody.appendChild(row);
    });
  }

  // Update badge count
  const badge = document.getElementById("attributes-count-badge");
  if (badge) {
    const count = tableBody.querySelectorAll("tr").length;
    badge.textContent = `${count} properties`;
  }

  // Render dynamic legend keys
  renderGisLegend();
}

// Global update handlers for inputs
window.updateAgriWeight = function(idx, val) {
  domainCustomParams.agriculture.weights[idx] = parseInt(val);
  drawGisCanvas();
  loadGisFeaturesList();
};
window.updateMiningBaseline = function(val) {
  domainCustomParams.mining.baseline_offset = parseFloat(val);
  drawGisCanvas();
  loadGisFeaturesList();
};
window.toggleRoadStatus = function(idx) {
  domainCustomParams.disaster.blocked_roads[idx] = !domainCustomParams.disaster.blocked_roads[idx];
  drawGisCanvas();
  loadGisFeaturesList();
};
window.updateUrbanHeight = function(idx, val) {
  domainCustomParams.urban.building_heights[idx] = parseInt(val);
  drawGisCanvas();
  loadGisFeaturesList();
};
window.toggleTransformer = function(idx) {
  domainCustomParams.utilities.transformers[idx] = !domainCustomParams.utilities.transformers[idx];
  drawGisCanvas();
  loadGisFeaturesList();
};
window.updateDefenseZoneSize = function(val) {
  domainCustomParams.defense.exclusion_zones[0].radius = parseInt(val);
  drawGisCanvas();
  loadGisFeaturesList();
};
window.updateEnvironmentalMultiplier = function(idx, val) {
  domainCustomParams.environmental.carbon_multipliers[idx] = parseFloat(val);
  drawGisCanvas();
  loadGisFeaturesList();
};
window.updateInfraDepth = function(val) {
  domainCustomParams.infrastructure.foundation_depth = parseInt(val);
  drawGisCanvas();
  loadGisFeaturesList();
};
window.updateInfraGrade = function(val) {
  domainCustomParams.infrastructure.concrete_grade = parseInt(val);
  drawGisCanvas();
  loadGisFeaturesList();
};

function renderGisLegend() {
  const legend = document.getElementById("gis-map-legend");
  if (!legend) return;
  legend.innerHTML = "";
  
  const themeColor = getComputedStyle(document.body).getPropertyValue("--accent-color").trim();
  
  if (!gisScanCompleted) {
    legend.innerHTML = `
      <div class="legend-item"><div class="legend-color" style="background:#555"></div><span>System Idle</span></div>
    `;
    return;
  }
  
  legend.innerHTML = `
    <div class="legend-item">
      <div class="legend-color" style="background:${themeColor}"></div>
      <span>Target Workspace Bounds</span>
    </div>
    <div class="legend-item">
      <div class="legend-color" style="background:#ffb703"></div>
      <span>Polygon Boundary Nodes</span>
    </div>
    <div class="legend-item">
      <div class="legend-color" style="background:#02c39a"></div>
      <span>Forensic Analytical Assets</span>
    </div>
  `;
}

function updateGisAttribute(key, value) {
  logConsole(`Updated attribute ${key} to ${value}`);
}

function drawGisCanvas() {
  if (!gisCanvas) return;
  const w = gisCanvas.width;
  const h = gisCanvas.height;
  
  gisCtx.clearRect(0, 0, w, h);
  
  // 1. Draw base cartographic background
  if (gisMapMode === "multispectral" && gisScanCompleted) {
    let gradient = gisCtx.createRadialGradient(w/2, h/2, 50, w/2, h/2, w);
    if (activeDomainIndex === 0) { // Agriculture: NDVI green scale
      gradient.addColorStop(0, "#132a13");
      gradient.addColorStop(0.5, "#3f5e30");
      gradient.addColorStop(1, "#0a0c0a");
    } else if (activeDomainIndex === 1) { // Mining: SAR thermal absorption
      gradient.addColorStop(0, "#3a0ca3");
      gradient.addColorStop(0.3, "#7209b7");
      gradient.addColorStop(0.7, "#f72585");
      gradient.addColorStop(1, "#03045e");
    } else if (activeDomainIndex === 2) { // Disaster: Water progress gradient
      gradient.addColorStop(0, "#03045e");
      gradient.addColorStop(0.4, "#0077b6");
      gradient.addColorStop(1, "#020306");
    } else { // Generic
      gradient.addColorStop(0, "#1a1e29");
      gradient.addColorStop(0.6, "#2e3b4e");
      gradient.addColorStop(1, "#050609");
    }
    gisCtx.fillStyle = gradient;
    gisCtx.fillRect(0, 0, w, h);
  } else {
    // Vector Mode grid backdrop
    gisCtx.fillStyle = "#020306";
    gisCtx.fillRect(0, 0, w, h);
    
    // Draw cartographic line grid
    gisCtx.strokeStyle = "rgba(255, 255, 255, 0.02)";
    gisCtx.lineWidth = 1;
    const gridStep = 40 * gisZoomLevel;
    for (let x = 0; x < w; x += gridStep) {
      gisCtx.beginPath(); gisCtx.moveTo(x, 0); gisCtx.lineTo(x, h); gisCtx.stroke();
    }
    for (let y = 0; y < h; y += gridStep) {
      gisCtx.beginPath(); gisCtx.moveTo(0, y); gisCtx.lineTo(w, y); gisCtx.stroke();
    }
  }
  
  if (!gisScanCompleted) {
    // Idle state visualizer helper
    gisCtx.fillStyle = "#ffffff";
    gisCtx.font = "11px JetBrains Mono";
    gisCtx.textAlign = "center";
    gisCtx.fillText("Waiting for GEE Scanner prompt command...", w/2, h/2);
    return;
  }
  
  // 2. Draw actual geometry based on domain's features
  const domain = domainsData[activeDomainIndex];
  const domainId = domain.id;
  const themeColor = getComputedStyle(document.body).getPropertyValue("--accent-color").trim();
  
  gisCtx.save();
  // Translate to center and apply zoom
  gisCtx.translate(w/2, h/2);
  gisCtx.scale(gisZoomLevel, gisZoomLevel);
  
  // A. Draw Bounding Polygon (Draggable Vertices)
  gisCtx.strokeStyle = themeColor;
  gisCtx.fillStyle = `${themeColor}15`;
  gisCtx.lineWidth = 2;
  
  gisCtx.beginPath();
  gisCtx.moveTo(gisPolygonVertices[0].x, gisPolygonVertices[0].y);
  for (let i = 1; i < gisPolygonVertices.length; i++) {
    gisCtx.lineTo(gisPolygonVertices[i].x, gisPolygonVertices[i].y);
  }
  gisCtx.closePath();
  gisCtx.fill();
  gisCtx.stroke();
  
  // B. Draw Vertex Handles (yellow knobs)
  gisPolygonVertices.forEach(v => {
    gisCtx.fillStyle = "#ffb703";
    gisCtx.beginPath();
    gisCtx.arc(v.x, v.y, 5, 0, Math.PI * 2);
    gisCtx.fill();
    gisCtx.strokeStyle = "#ffffff";
    gisCtx.lineWidth = 1;
    gisCtx.stroke();
  });
  
  // C. Render domain specific features
  const params = domainCustomParams[domainId];
  gisCtx.textAlign = "center";
  
  if (domainId === "agriculture") {
    // Split polygon coordinates range into 4 sectors
    const sectors = [
      {x: -40, y: -20, label: "Cell A"},
      {x: 40, y: -25, label: "Cell B"},
      {x: 50, y: 20, label: "Cell C"},
      {x: -30, y: 30, label: "Cell D"}
    ];
    sectors.forEach((sec, idx) => {
      // Draw sub cell
      gisCtx.fillStyle = params.weights[idx] > 80 ? "rgba(2, 195, 154, 0.2)" : "rgba(230, 57, 70, 0.2)";
      gisCtx.beginPath();
      gisCtx.arc(sec.x, sec.y, 20, 0, Math.PI * 2);
      gisCtx.fill();
      gisCtx.strokeStyle = "rgba(255,255,255,0.3)";
      gisCtx.stroke();
      
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "8px Outfit";
      gisCtx.fillText(`${sec.label} (${params.weights[idx]}%)`, sec.x, sec.y + 3);
    });
  } else if (domainId === "mining") {
    // Show stockpile volumetric vectors scaled by offset
    gisCtx.fillStyle = "rgba(76, 201, 240, 0.3)";
    gisCtx.strokeStyle = "#4cc9f0";
    gisCtx.lineWidth = 1.5;
    
    gisCtx.beginPath();
    gisCtx.arc(0, 0, 35 * (1.0 + params.baseline_offset / 10), 0, Math.PI * 2);
    gisCtx.fill();
    gisCtx.stroke();
    
    gisCtx.fillStyle = "#ffffff";
    gisCtx.font = "8px JetBrains Mono";
    gisCtx.fillText(`Baseline: ${params.elevation_baseline + params.baseline_offset}m`, 0, -45);
  } else if (domainId === "disaster") {
    // Evacuation routes + flooded blocks
    const lines = [
      {x1: -90, y1: -30, x2: -20, y2: 0},
      {x1: -20, y1: 0, x2: 60, y2: -40},
      {x1: 60, y1: -40, x2: 80, y2: 40}
    ];
    lines.forEach((l, idx) => {
      gisCtx.strokeStyle = params.blocked_roads[idx] ? "#e63946" : "#02c39a";
      gisCtx.lineWidth = 4;
      gisCtx.beginPath();
      gisCtx.moveTo(l.x1, l.y1);
      gisCtx.lineTo(l.x2, l.y2);
      gisCtx.stroke();
      
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "7px Outfit";
      gisCtx.fillText(params.blocked_roads[idx] ? "CLOSED" : "OPEN", (l.x1+l.x2)/2, (l.y1+l.y2)/2 - 5);
    });
  } else if (domainId === "urban") {
    // Draw 3D-like isometric block cylinders based on height
    const blocks = [
      {x: -50, y: 10},
      {x: 0, y: -20},
      {x: 40, y: 30}
    ];
    blocks.forEach((b, idx) => {
      const hScale = params.building_heights[idx] * 2.5;
      gisCtx.fillStyle = "rgba(76, 201, 240, 0.5)";
      gisCtx.strokeStyle = "#ffffff";
      gisCtx.lineWidth = 1;
      
      gisCtx.beginPath();
      gisCtx.rect(b.x - 15, b.y - hScale, 30, hScale);
      gisCtx.fill();
      gisCtx.stroke();
      
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "7px Outfit";
      gisCtx.fillText(`${params.building_heights[idx]}F`, b.x, b.y - hScale - 4);
    });
  } else if (domainId === "utilities") {
    // Nodes connections
    const nodes = [
      {x: -60, y: -20},
      {x: 0, y: 20},
      {x: 60, y: -30}
    ];
    gisCtx.strokeStyle = "rgba(255,255,255,0.15)";
    gisCtx.lineWidth = 1.5;
    gisCtx.beginPath();
    gisCtx.moveTo(nodes[0].x, nodes[0].y);
    gisCtx.lineTo(nodes[1].x, nodes[1].y);
    gisCtx.lineTo(nodes[2].x, nodes[2].y);
    gisCtx.stroke();
    
    nodes.forEach((n, idx) => {
      gisCtx.fillStyle = params.transformers[idx] ? "#02c39a" : "#e63946";
      gisCtx.beginPath();
      gisCtx.arc(n.x, n.y, 8, 0, Math.PI * 2);
      gisCtx.fill();
      gisCtx.strokeStyle = "#ffffff";
      gisCtx.stroke();
      
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "7px Outfit";
      gisCtx.fillText(params.transformers[idx] ? "ON" : "OFF", n.x, n.y + 12);
    });
  } else if (domainId === "logistics") {
    // Waypoint routing line string
    gisCtx.strokeStyle = "#ffb703";
    gisCtx.lineWidth = 3;
    gisCtx.beginPath();
    gisCtx.moveTo(params.waypoints[0].x, params.waypoints[0].y);
    for(let i=1; i<params.waypoints.length; i++) {
      gisCtx.lineTo(params.waypoints[i].x, params.waypoints[i].y);
    }
    gisCtx.stroke();
    
    params.waypoints.forEach((wp, idx) => {
      gisCtx.fillStyle = "#02c39a";
      gisCtx.beginPath();
      gisCtx.arc(wp.x, wp.y, 6, 0, Math.PI * 2);
      gisCtx.fill();
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "8px JetBrains Mono";
      gisCtx.fillText(`WP${idx+1}`, wp.x, wp.y - 8);
    });
  } else if (domainId === "defense") {
    // exclusion zones
    const zone = params.exclusion_zones[0];
    gisCtx.fillStyle = "rgba(230, 57, 70, 0.15)";
    gisCtx.strokeStyle = "#e63946";
    gisCtx.lineWidth = 1.5;
    
    gisCtx.beginPath();
    gisCtx.arc(zone.x, zone.y, zone.radius, 0, Math.PI * 2);
    gisCtx.fill();
    gisCtx.stroke();
    
    gisCtx.fillStyle = "#ffffff";
    gisCtx.font = "7px JetBrains Mono";
    gisCtx.fillText(zone.name, zone.x, zone.y - zone.radius - 4);
  } else if (domainId === "environmental") {
    // Carbon multipliers boxes
    const regions = [
      {x: -70, y: -15},
      {x: 10, y: -40},
      {x: 50, y: 15}
    ];
    regions.forEach((reg, idx) => {
      gisCtx.fillStyle = "rgba(2, 195, 154, 0.1)";
      gisCtx.strokeStyle = "#02c39a";
      gisCtx.lineWidth = 1;
      gisCtx.beginPath();
      gisCtx.rect(reg.x - 20, reg.y - 20, 40, 40);
      gisCtx.fill();
      gisCtx.stroke();
      
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "8px Outfit";
      gisCtx.fillText(`Mult: ${params.carbon_multipliers[idx]}x`, reg.x, reg.y + 4);
    });
  } else if (domainId === "infrastructure") {
    // STEP model block foundations representation
    gisCtx.fillStyle = "rgba(255, 255, 255, 0.05)";
    gisCtx.strokeStyle = "#ffb703";
    gisCtx.lineWidth = 1.5;
    
    gisCtx.beginPath();
    gisCtx.rect(-40, -20, 80, 40);
    gisCtx.fill();
    gisCtx.stroke();
    
    gisCtx.fillStyle = "#ffffff";
    gisCtx.font = "8px JetBrains Mono";
    gisCtx.fillText(`Foundation: ${params.foundation_depth}m depth`, 0, -26);
    gisCtx.fillText(`Conc Grade: ${params.concrete_grade} MPa`, 0, 34);
  } else if (domainId === "emergency") {
    // Repositionable responders
    params.responders.forEach(resp => {
      gisCtx.fillStyle = "#e63946";
      gisCtx.beginPath();
      gisCtx.arc(resp.x, resp.y, 7, 0, Math.PI * 2);
      gisCtx.fill();
      
      gisCtx.strokeStyle = "#ffffff";
      gisCtx.lineWidth = 1;
      gisCtx.stroke();
      
      gisCtx.fillStyle = "#ffffff";
      gisCtx.font = "8px Outfit";
      gisCtx.fillText(resp.name, resp.x, resp.y - 10);
    });
  }
  
  gisCtx.restore();
}

function varTextMuted() {
  return "#8b949e";
}

// 7. Compiler Simulator for CadQuery B-Rep Code
function runCadQueryCompiler() {
  const consoleBlock = document.getElementById("cadquery-console");
  const code = document.getElementById("cadquery-code-editor").value;
  
  consoleBlock.innerHTML = `
    <span class="console-line-info">[SYSTEM] Commencing script compile via CadQuery engine...</span>
  `;
  
  setTimeout(() => {
    consoleBlock.innerHTML += `
      <span class="console-line-info">[COMPILER] Parsing code elements and resolving structural constraints...</span>
    `;
  }, 300);
  
  setTimeout(() => {
    consoleBlock.innerHTML += `
      <span class="console-line-success">[COMPILER] SUCCESS: Parametric STEP Solid Model (.step) generated successfully.</span>
      <span class="console-line-success">[COMPILER] Watertight closed manifold. Primitives verified. Files written to local worktree.</span>
    `;
    logConsole("Compiled custom CadQuery B-Rep solid structure.");
  }, 1000);
}

// Helper highlight editor
function updateCodeHighlight() {
  const textarea = document.getElementById("cadquery-code-editor");
  const display = document.getElementById("cadquery-code-display");
  
  let text = textarea.value;
  
  // Very simple python highlight replacements
  text = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  
  // Regex replacements for keywords, functions, comments
  text = text.replace(/#.*/g, match => `<span class="code-comment">${match}</span>`);
  text = text.replace(/\b(import|from|as|for|in|def|return|class|if|else)\b/g, match => `<span class="code-keyword">${match}</span>`);
  text = text.replace(/cq\.Workplane|cq/g, match => `<span class="code-builtin">${match}</span>`);
  text = text.replace(/(show_object)/g, match => `<span class="code-def">${match}</span>`);
  text = text.replace(/(\d+(\.\d+)?)/g, match => `<span class="code-number">${match}</span>`);
  text = text.replace(/(['"].*?['"])/g, match => `<span class="code-string">${match}</span>`);
  
  display.innerHTML = text;
}

function switchEditorTab(subtab) {
  activeEditorTab = subtab;
  document.getElementById("btn-tab-attributes").classList.toggle("active", subtab === "attributes");
  document.getElementById("btn-tab-cadquery").classList.toggle("active", subtab === "cadquery");
  
  document.getElementById("panel-editor-attributes").classList.toggle("active", subtab === "attributes");
  document.getElementById("panel-editor-cadquery").classList.toggle("active", subtab === "cadquery");
}

// 8. Scenario Selector (Simulation Lab)
function loadSimScenarios() {
  const domain = domainsData[activeDomainIndex];
  const listContainer = document.getElementById("scenario-selector-list");
  listContainer.innerHTML = "";
  
  domain.scenarios.forEach((scen, idx) => {
    const btn = document.createElement("button");
    btn.className = `scenario-btn ${idx === 0 ? 'active' : ''}`;
    btn.onclick = () => selectScenario(idx);
    btn.textContent = scen.name;
    listContainer.appendChild(btn);
  });
  
  selectScenario(0);
}

function selectScenario(index) {
  const domain = domainsData[activeDomainIndex];
  const scen = domain.scenarios[index];
  
  // Update Selection state
  document.querySelectorAll("#scenario-selector-list .scenario-btn").forEach((btn, idx) => {
    btn.classList.toggle("active", idx === index);
  });
  
  // Set parameters inputs
  const paramsContainer = document.getElementById("sim-parameters-container");
  paramsContainer.innerHTML = "";
  
  scen.variables.forEach((variable, vIdx) => {
    const div = document.createElement("div");
    div.className = "parameter-slider-group";
    div.innerHTML = `
      <div class="slider-label-row">
        <span>${variable.name}</span>
        <span id="slider-val-${vIdx}">${variable.val}</span>
      </div>
      <input type="range" min="${variable.min}" max="${variable.max}" step="any" value="${variable.val}" oninput="updateSimSlider(${vIdx}, this.value)">
    `;
    paramsContainer.appendChild(div);
  });
  
  // Reset simulation dashboard status
  if (window.resetSimulation) {
    window.resetSimulation(scen);
  }
}

function updateSimSlider(vIdx, value) {
  const parsed = parseFloat(value);
  document.getElementById(`slider-val-${vIdx}`).textContent = parsed.toFixed(1);
  
  // Send updated variables back to physics engine
  if (window.updateSimParam) {
    window.updateSimParam(vIdx, parsed);
  }
}

// 9. UI Binding and Core Triggers
function setupUIEventListeners() {
  // File Drop Handlers
  const dropZone = document.getElementById("file-drop-zone");
  dropZone.addEventListener("dragover", e => {
    e.preventDefault();
    dropZone.classList.add("dragover");
  });
  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
  });
  dropZone.addEventListener("drop", e => {
    e.preventDefault();
    dropZone.classList.remove("dragover");
    if (e.dataTransfer.files.length > 0) {
      const firstFile = e.dataTransfer.files[0];
      simulateFileLoad({
        name: firstFile.name,
        size: (firstFile.size / 1000000).toFixed(1) + " MB",
        density: "150 pts/m²",
        type: firstFile.name.endsWith(".las") || firstFile.name.endsWith(".laz") ? "LiDAR Point Cloud" : "Orthophoto"
      });
    }
  });
  
  document.getElementById("browse-files-btn").onclick = () => {
    document.getElementById("file-input").click();
  };
  
  document.getElementById("file-input").onchange = e => {
    if (e.target.files.length > 0) {
      const firstFile = e.target.files[0];
      simulateFileLoad({
        name: firstFile.name,
        size: (firstFile.size / 1000000).toFixed(1) + " MB",
        density: "150 pts/m²",
        type: firstFile.name.endsWith(".las") || firstFile.name.endsWith(".laz") ? "LiDAR Point Cloud" : "Orthophoto"
      });
    }
  };
  
  // GIS View mode switches
  document.getElementById("btn-map-vector").onclick = () => {
    gisMapMode = "vector";
    document.getElementById("btn-map-vector").classList.add("active");
    document.getElementById("btn-map-multispectral").classList.remove("active");
    drawGisCanvas();
  };
  
  document.getElementById("btn-map-multispectral").onclick = () => {
    gisMapMode = "multispectral";
    document.getElementById("btn-map-vector").classList.remove("active");
    document.getElementById("btn-map-multispectral").classList.add("active");
    drawGisCanvas();
  };
  
  // GIS Zoom Controls
  document.getElementById("btn-zoom-in").onclick = () => {
    gisZoomLevel += 0.15;
    if (gisZoomLevel > 3.0) gisZoomLevel = 3.0;
    drawGisCanvas();
  };
  
  document.getElementById("btn-zoom-out").onclick = () => {
    gisZoomLevel -= 0.15;
    if (gisZoomLevel < 0.5) gisZoomLevel = 0.5;
    drawGisCanvas();
  };
  
  // GIS click handler (select features on Map)
  gisCanvas.onclick = e => {
    const rect = gisCanvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left - gisCanvas.width/2;
    const clickY = e.clientY - rect.top - gisCanvas.height/2;
    
    // Pick the closest feature idx
    let closestIdx = 0;
    let minDistance = 999999;
    
    domainsData[activeDomainIndex].gisFeatures.forEach((feat, idx) => {
      let cx = (idx - 1) * 80;
      let cy = (idx - 1) * 30;
      let dist = Math.sqrt((clickX - cx) * (clickX - cx) + (clickY - cy) * (clickY - cy));
      if (dist < minDistance) {
        minDistance = dist;
        closestIdx = idx;
      }
    });
    
    selectedGisFeatureIndex = closestIdx;
    loadGisFeaturesList();
    drawGisCanvas();
  };
  
  // CadQuery key listener for styling compiler textarea
  const textarea = document.getElementById("cadquery-code-editor");
  if (textarea) {
    textarea.oninput = updateCodeHighlight;
    textarea.onscroll = () => {
      const displayPre = document.getElementById("code-editor-highlight");
      if (displayPre) {
        displayPre.scrollTop = textarea.scrollTop;
        displayPre.scrollLeft = textarea.scrollLeft;
      }
    };
  }
  
  const runCadQueryBtn = document.getElementById("btn-run-cadquery");
  if (runCadQueryBtn) {
    runCadQueryBtn.onclick = runCadQueryCompiler;
  }

  // Bottom drawer add custom feature handler
  const addFeatureBtn = document.getElementById("btn-add-feature");
  if (addFeatureBtn) {
    addFeatureBtn.onclick = () => {
      const name = prompt("Enter new attribute property name:");
      if (!name) return;
      const val = prompt("Enter property value:");
      if (!val) return;
      
      const tableBody = document.getElementById(activeTab === 'ingest' ? "extraction-attributes-table-body" : "attributes-table-body");
      if (tableBody) {
        const tr = document.createElement("tr");
        tr.style.borderBottom = "1px solid var(--border-light)";
        tr.innerHTML = `
          <td style="padding:6px 8px; font-weight:700; color:var(--text-main);">${name}</td>
          <td style="padding:6px 8px; color:var(--text-muted); font-family:var(--font-mono);">String (User Added)</td>
          <td style="padding:6px 8px; color:var(--accent-color); font-weight:700;">${val}</td>
        `;
        const placeholder = tableBody.querySelector(".placeholder-text");
        if (placeholder) placeholder.remove();
        
        tableBody.appendChild(tr);
        logConsole(`➕ Added custom feature property: ${name} = ${val}`);
        
        const badge = document.getElementById("attributes-count-badge");
        if (badge) {
          const count = tableBody.querySelectorAll("tr").length;
          badge.textContent = `${count} properties`;
        }
      }
    };
  }

  // Redesign AI Customizer Handler
  const redesignInput = document.getElementById("redesign-ai-input");
  const redesignBtn = document.getElementById("btn-redesign-ai");
  const redesignStatus = document.getElementById("redesign-ai-status");
  
  if (redesignBtn && redesignInput) {
    const applyRedesign = () => {
      const prompt = redesignInput.value.trim().toLowerCase();
      if (!prompt) return;
      
      redesignStatus.style.display = "block";
      redesignStatus.textContent = "[Analyzing prompt via local LLM...]";
      redesignStatus.style.color = "var(--text-muted)";
      
      setTimeout(() => {
        let matched = false;
        let msg = "";
        
        // 1. Accent color triggers
        if (prompt.includes("pink") || prompt.includes("rose")) {
          document.documentElement.style.setProperty("--accent-color", "#ff477e");
          document.documentElement.style.setProperty("--accent-color-rgb", "255, 71, 126");
          document.documentElement.style.setProperty("--accent-color-glow", "rgba(255, 71, 126, 0.35)");
          matched = true;
          msg = "Accent color set to Rose Pink.";
        } else if (prompt.includes("blue") || prompt.includes("sky")) {
          document.documentElement.style.setProperty("--accent-color", "#00b4d8");
          document.documentElement.style.setProperty("--accent-color-rgb", "0, 180, 216");
          document.documentElement.style.setProperty("--accent-color-glow", "rgba(0, 180, 216, 0.35)");
          matched = true;
          msg = "Accent color set to Sky Blue.";
        } else if (prompt.includes("green") || prompt.includes("emerald")) {
          document.documentElement.style.setProperty("--accent-color", "#06d6a0");
          document.documentElement.style.setProperty("--accent-color-rgb", "6, 214, 160");
          document.documentElement.style.setProperty("--accent-color-glow", "rgba(6, 214, 160, 0.35)");
          matched = true;
          msg = "Accent color set to Emerald Green.";
        } else if (prompt.includes("amber") || prompt.includes("orange") || prompt.includes("gold")) {
          document.documentElement.style.setProperty("--accent-color", "#ffb703");
          document.documentElement.style.setProperty("--accent-color-rgb", "255, 183, 3");
          document.documentElement.style.setProperty("--accent-color-glow", "rgba(255, 183, 3, 0.35)");
          matched = true;
          msg = "Accent color set to Gold/Amber.";
        } else if (prompt.includes("purple") || prompt.includes("violet")) {
          document.documentElement.style.setProperty("--accent-color", "#b5179e");
          document.documentElement.style.setProperty("--accent-color-rgb", "181, 23, 158");
          document.documentElement.style.setProperty("--accent-color-glow", "rgba(181, 23, 158, 0.35)");
          matched = true;
          msg = "Accent color set to Neon Purple.";
        } else if (prompt.includes("red") || prompt.includes("crimson")) {
          document.documentElement.style.setProperty("--accent-color", "#d62828");
          document.documentElement.style.setProperty("--accent-color-rgb", "214, 40, 40");
          document.documentElement.style.setProperty("--accent-color-glow", "rgba(214, 40, 40, 0.35)");
          matched = true;
          msg = "Accent color set to Crimson Red.";
        }

        // 2. Background triggers
        if (prompt.includes("darker") || prompt.includes("midnight") || prompt.includes("black")) {
          document.documentElement.style.setProperty("--bg-darkest", "#010203");
          document.documentElement.style.setProperty("--bg-darker", "#030406");
          document.documentElement.style.setProperty("--bg-dark", "#05060a");
          matched = true;
          msg += (msg ? " | " : "") + "Background changed to Midnight Black.";
        } else if (prompt.includes("glass") && (prompt.includes("heavy") || prompt.includes("higher"))) {
          document.documentElement.style.setProperty("--bg-glass", "rgba(8, 9, 15, 0.92)");
          document.documentElement.style.setProperty("--bg-glass-heavy", "rgba(4, 5, 8, 0.98)");
          matched = true;
          msg += (msg ? " | " : "") + "Increased glass opacity.";
        } else if (prompt.includes("glass") && (prompt.includes("light") || prompt.includes("more trans"))) {
          document.documentElement.style.setProperty("--bg-glass", "rgba(12, 13, 20, 0.45)");
          document.documentElement.style.setProperty("--bg-glass-heavy", "rgba(8, 9, 15, 0.65)");
          matched = true;
          msg += (msg ? " | " : "") + "Decreased glass opacity.";
        }

        // 3. Reset trigger
        if (prompt.includes("reset") || prompt.includes("default") || prompt.includes("normal")) {
          document.documentElement.style.removeProperty("--accent-color");
          document.documentElement.style.removeProperty("--accent-color-rgb");
          document.documentElement.style.removeProperty("--accent-color-glow");
          document.documentElement.style.removeProperty("--bg-darkest");
          document.documentElement.style.removeProperty("--bg-darker");
          document.documentElement.style.removeProperty("--bg-dark");
          document.documentElement.style.removeProperty("--bg-glass");
          document.documentElement.style.removeProperty("--bg-glass-heavy");
          matched = true;
          msg = "Reset all styles to default values.";
        }

        if (matched) {
          redesignStatus.textContent = "✔ Redesign AI: " + msg;
          redesignStatus.style.color = "#02c39a";
          logConsole("Redesign AI: Applied custom CSS overrides.");
        } else {
          redesignStatus.textContent = "✖ Could not resolve request. Try 'accent pink', 'glass heavy' or 'reset'.";
          redesignStatus.style.color = "#ff4d4d";
        }
      }, 800);
    };

    redesignBtn.onclick = applyRedesign;
    redesignInput.onkeydown = e => {
      if (e.key === "Enter") applyRedesign();
    };
  }
  
  // Auto resize canvas elements
  window.onresize = triggerCanvasesRedraw;
}

function triggerCanvasesRedraw() {
  // Resize canvases
  if (ingestCanvas && ingestCanvas.parentNode) {
    ingestCanvas.width = ingestCanvas.parentNode.clientWidth;
    ingestCanvas.height = ingestCanvas.parentNode.clientHeight;
    drawFinalOrthoCanvas({});
  }
  
  if (gisCanvas && gisCanvas.parentNode) {
    gisCanvas.width = gisCanvas.parentNode.clientWidth;
    gisCanvas.height = gisCanvas.parentNode.clientHeight;
    drawGisCanvas();
  }
}

// 10. System Logging Utils
function logConsole(msg) {
  const consoleDisplay = document.getElementById("system-footer-console");
  if (consoleDisplay) {
    consoleDisplay.innerHTML = `<span class="console-message text-glow-dim"><i data-lucide="info" class="inline-icon"></i> ${msg}</span>`;
    lucide.createIcons();
  }
}

// PWA GEE Connection & Local-First Licensing Utilities
let geeConnected = false;

window.connectGoogleEarthEngine = function() {
  const statusIcon = document.getElementById("gee-status-icon");
  const statusText = document.getElementById("gee-status-text");
  const geeBtn = document.getElementById("btn-gee-connect");
  
  if (!statusIcon || !statusText || !geeBtn) return;
  
  if (!geeConnected) {
    geeConnected = true;
    statusIcon.className = "esri-status-icon online";
    statusIcon.style.color = "#02c39a";
    statusText.textContent = "ONLINE (GEE OAuth2 ACTIVE)";
    statusText.style.color = "#02c39a";
    geeBtn.textContent = "DISCONNECT";
    geeBtn.className = "btn btn-small btn-secondary";
    logConsole("Authenticated client-side with Google Earth Engine API via OAuth 2.0. Token saved.");
  } else {
    geeConnected = false;
    statusIcon.className = "esri-status-icon offline";
    statusIcon.style.color = "var(--text-muted)";
    statusText.textContent = "OFFLINE (LOCAL WASM)";
    statusText.style.color = "var(--text-muted)";
    geeBtn.textContent = "CONNECT";
    geeBtn.className = "btn btn-small btn-accent";
    logConsole("Cleared Earth Engine OAuth credentials. Reverting to local offline WASM ingestion.");
  }
};

window.initLicenseValidation = function() {
  const lastVerifyStr = localStorage.getItem("cahaya_last_verify_time");
  const now = Date.now();
  
  if (lastVerifyStr) {
    const lastVerify = parseInt(lastVerifyStr, 10);
    if (now < lastVerify) {
      alert("❌ SECURITY ALERT: System clock tampering detected.\nCahaya Sovereign Sandbox has locked itself to prevent license bypass.\n\nPlease restore your system time or connect online to verify your subscription.");
      const appContainer = document.getElementById("app-container");
      if (appContainer) {
        appContainer.style.filter = "blur(12px)";
        appContainer.style.pointerEvents = "none";
      }
      logConsole("❌ System clock tampering detected. Security lock active.");
      return;
    }
  }
  
  localStorage.setItem("cahaya_last_verify_time", now.toString());
  
  const expVal = localStorage.getItem("cahaya_license_expiry") || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const tierVal = localStorage.getItem("cahaya_license_tier") || "SOVEREIGN";
  
  const licenseTierEl = document.getElementById("license-chip-tier");
  const licenseExpiryEl = document.getElementById("license-chip-expiry");
  
  if (licenseTierEl) licenseTierEl.textContent = tierVal;
  if (licenseExpiryEl) licenseExpiryEl.textContent = `Expires: ${expVal}`;
  
  localStorage.setItem("cahaya_license_expiry", expVal);
  localStorage.setItem("cahaya_license_tier", tierVal);
};

// 11. ESRI ArcGIS Portal Integration
let esriConnected = false;
const esriKeyFile = {
  clientId: "gqZ56hkya5gIvgdD",
  clientSecret: "7cfa556af44247a0a49cb4d0cc03578a",
  redirectUri: "http://localhost:3000/auth/callback/esri"
};

function initEsriIntegration() {
  const esriBtn = document.getElementById("btn-esri-connect");
  if (!esriBtn) return;
  
  esriBtn.onclick = () => {
    const statusIcon = document.getElementById("esri-status-icon");
    const statusText = document.getElementById("esri-status-text");
    const deploymentProfile = document.getElementById("deployment-profile");
    
    if (!esriConnected) {
      // Connect to Esri ArcGIS Portal
      esriConnected = true;
      statusIcon.className = "esri-status-icon online";
      statusText.textContent = `ONLINE (OAuth 2.0: ${esriKeyFile.clientId.substring(0,6)}...)`;
      statusText.classList.add("online");
      esriBtn.textContent = "DISCONNECT";
      esriBtn.className = "btn btn-small btn-secondary";
      
      // Update system deployment core setting
      deploymentProfile.textContent = "ESRI ENTERPRISE CLOUD SYNC";
      deploymentProfile.classList.add("green-glow");
      
      logConsole("Connected to Esri ArcGIS Portal. OAuth 2.0 handshake verified.");
      
      // Add custom Esri vector node on map
      const domain = domainsData[activeDomainIndex];
      domain.gisFeatures.push({
        id: "esri-imported-node",
        name: "ArcGIS WebMap Node Ingress",
        type: "Esri FeatureLayer",
        connection_status: "Active Sync",
        coordinate_system: "WGS 84 / UTM zone 47N"
      });
      loadGisFeaturesList();
      drawGisCanvas();
    } else {
      // Disconnect
      esriConnected = false;
      statusIcon.className = "esri-status-icon offline";
      statusText.textContent = "OFFLINE (LOCAL CACHE)";
      statusText.classList.remove("online");
      esriBtn.textContent = "CONNECT";
      esriBtn.className = "btn btn-small btn-accent";
      
      deploymentProfile.textContent = "AIR-GAPPED SOVEREIGN";
      deploymentProfile.classList.remove("green-glow");
      
      logConsole("Disconnected from Esri ArcGIS Portal.");
      
      // Remove imported node
      const domain = domainsData[activeDomainIndex];
      domain.gisFeatures = domain.gisFeatures.filter(f => f.id !== "esri-imported-node");
      selectedGisFeatureIndex = 0;
      loadGisFeaturesList();
      drawGisCanvas();
    }
    lucide.createIcons();
  };
}

// 12. Layer 4 Sovereign Local CLI terminal simulator (.sl)
let isLicensedSovereign = false;

function initCliTerminal() {
  const cliInput = document.getElementById("cli-input-field");
  if (!cliInput) return;
  
  cliInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      const command = cliInput.value.trim();
      cliInput.value = "";
      
      if (command) {
        executeMockCliCommand(command);
      }
    }
  });
}

window.runQuickCliCommand = function(argStr) {
  const fullCmd = argStr.startsWith("cahaya") || argStr.startsWith("./cahaya") ? argStr : `./cahaya ${argStr}`;
  executeMockCliCommand(fullCmd);
};

function executeMockCliCommand(cmd) {
  const terminalBody = document.getElementById("cli-terminal-body");
  const insertionPoint = document.getElementById("cli-insertion-point");
  
  // Create user prompt line echo
  const echoLine = document.createElement("div");
  echoLine.className = "cli-line";
  echoLine.innerHTML = `<span class="cli-prompt-lbl">workstation@lenuda-sl:~$</span> <span style="color:#ffffff">${cmd}</span>`;
  terminalBody.insertBefore(echoLine, insertionPoint);
  
  // Parse command
  const cleanCmd = cmd.replace(/^(python\s+)?(lenuda_cli\.py\s+)?|^\.\/cahaya\s+|^cahaya\s+/, "").trim();
  
  let reply = "";
  let isError = false;
  let isSuccess = false;
  
  if (cleanCmd === "--help" || cleanCmd === "help" || cleanCmd === "") {
    reply = `Usage: cahaya [COMMAND] [OPTIONS]

Commands:
  status                        View current license activation and engine status
  activate [token]              Activate local machine using annual token
  download                      Download stack updates from distribution network
  config add [options]          Configure databases and MCP servers
  patch apply [path] --key      Apply annual update patch archive
  update                        Check and apply CLI tools updates
  repair                        Run self-healing diagnostics and repair configuration/keys`;
  } else if (cleanCmd === "--status" || cleanCmd === "status") {
    const licStatus = licenseConfig.tier;
    const activeDomainStr = licenseConfig.active_domain.toUpperCase();
    const modelTierStr = licenseConfig.cahaya_model_tier.toUpperCase();
    const modelImageStr = licenseConfig.model_image;
    const vllmArgsStr = licenseConfig.vllm_args;
    const expiration = licenseConfig.contract_expires_at;
    
    reply = `🔒 SYSTEM HARDWARE LOCK: 06492ffb285b79218d32f018d6b02f161276b42890ebaf43bd14238857c4f590
💼 ACTIVE LICENSE TIER:   ${licStatus} Local
🌍 LICENSED ACTIVE DOMAIN: ${activeDomainStr}
🧠 CAHAYA MODEL TIER:     ${modelTierStr}
🤖 CAHAYA MODEL IMAGE:    ${modelImageStr}
⚙️ vLLM CONFIG ARGS:      ${vllmArgsStr}
⏳ CONTRACT EXPIRATION:   ${expiration}

${licStatus !== "UNLICENSED" ? '✅ LICENSE ACTIVE: 365 days remaining until annual renewal.' : '❌ SYSTEM UNLICENSED: Run with activate <TOKEN> to renew.'}`;
  } else if (cleanCmd.startsWith("--activate") || cleanCmd.startsWith("activate")) {
    const parts = cleanCmd.split(/\s+/);
    const token = parts[1] || "";
    
    // Asynchronously update the local backend server ledger if available
    fetch("/api/token/activate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: token })
    })
    .then(async (res) => {
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          const syncRes = await fetch("/cahaya_secure.json");
          if (syncRes.ok) {
            const syncData = await syncRes.json();
            licenseConfig = syncData;
            localStorage.setItem("lenuda_license_override", JSON.stringify(syncData));
            syncLicenseState();
            
            const termBody = document.getElementById("cli-terminal-body");
            const insPt = document.getElementById("cli-insertion-point");
            if (termBody && insPt) {
              const backendLine = document.createElement("div");
              backendLine.className = "cli-line success-line";
              backendLine.innerHTML = `✓ Local uvicorn backend activated: ${data.message}<br>✓ UI personalization applied for theme: ${syncData.active_domain}`;
              termBody.insertBefore(backendLine, insPt);
              termBody.scrollTop = termBody.scrollHeight;
            }
          }
        }
      }
    })
    .catch((err) => {
      console.warn("Backend uvicorn server offline, using browser-local simulation fallback.", err);
    });

    if (token === "SECURE-ANNUAL-TOKEN-2026") {
      licenseConfig = {
        tier: "SOVEREIGN",
        active_domain: "agriculture",
        cahaya_model_tier: "sovereign",
        model_image: "librae_geoint/librae_geoint2.5-72b-instruct",
        vllm_args: "--max-model-len 131072 --tensor-parallel-size 2",
        last_activation_date: new Date().toISOString(),
        contract_expires_at: new Date(Date.now() + 365*24*60*60*1000).toISOString()
      };
      localStorage.setItem("lenuda_license_override", JSON.stringify(licenseConfig));
      isSuccess = true;
      syncLicenseState();
      
      reply = `🔑 Verifying annual license token: ${token}...
✅ LICENSE ACTIVATED SUCCESSFULLY!
   Tier:          SOVEREIGN Local
   Active Domain: AGRICULTURE
   Model Image:   librae_geoint/librae_geoint2.5-72b-instruct
   vLLM Config:   --max-model-len 131072 --tensor-parallel-size 2
   Hardware signature bound. Database registry lock sealed.`;
      logConsole("License activated successfully on local workstation via terminal token.");
    } else if (token.startsWith("SECURE-TOKEN-") && token.endsWith("-2026")) {
      const parts = token.split("-");
      if (parts.length >= 5) {
        const tStr = parts[2].toUpperCase();
        const dStr = parts[3].toLowerCase();
        
        const validTiers = ["EDGE", "STANDARD", "SOVEREIGN"];
        const validDomains = ["agriculture", "mining", "disaster", "urban", "utilities", "logistics", "defense", "environmental", "infrastructure", "emergency"];
        
        if (validTiers.includes(tStr) && validDomains.includes(dStr)) {
          let vArgs = "--quantization gptq --max-model-len 32768 --tensor-parallel-size 1";
          let mImg = "librae_geoint/librae_geoint2.5-7b-instruct-gptq-int4";
          if (tStr === "STANDARD") {
            vArgs = "--quantization awq --max-model-len 65536 --tensor-parallel-size 1";
            mImg = "librae_geoint/librae_geoint2.5-32b-instruct-awq";
          } else if (tStr === "SOVEREIGN") {
            vArgs = "--max-model-len 131072 --tensor-parallel-size 2";
            mImg = "librae_geoint/librae_geoint2.5-72b-instruct";
          }
          
          licenseConfig = {
            tier: tStr,
            active_domain: dStr,
            cahaya_model_tier: tStr.toLowerCase(),
            model_image: mImg,
            vllm_args: vArgs,
            last_activation_date: new Date().toISOString(),
            contract_expires_at: new Date(Date.now() + 365*24*60*60*1000).toISOString()
          };
          localStorage.setItem("lenuda_license_override", JSON.stringify(licenseConfig));
          isSuccess = true;
          syncLicenseState();
          
          reply = `🔑 Verifying annual license token: ${token}...
✅ LICENSE ACTIVATED SUCCESSFULLY!
   Tier:          ${tStr} Local
   Active Domain: ${dStr.toUpperCase()}
   Model Image:   ${mImg}
   vLLM Config:   ${vArgs}
   Hardware signature bound. Database registry lock sealed.`;
          logConsole(`License activated successfully for ${dStr.toUpperCase()} via token ${token}.`);
        } else {
          isError = true;
          reply = `🔑 Verifying annual license token: ${token}...
❌ ERROR: Invalid license token layout. Verification failed.`;
        }
      } else {
        isError = true;
        reply = `🔑 Verifying annual license token: ${token}...
❌ ERROR: Token syntax malformed. Verification failed.`;
      }
    } else {
      isError = true;
      reply = `🔑 Verifying annual license token: ${token}...
❌ ERROR: Invalid license token. Verification failed. System unlicensed.`;
    }
  } else if (cleanCmd === "--download" || cleanCmd === "download") {
    if (licenseConfig.tier === "UNLICENSED") {
      isError = true;
      reply = "❌ ERROR: Active license required to download packages. Run activate first.";
    } else {
      const modelImg = licenseConfig.model_image;
      reply = `📡 Connecting to Lenuda Distribution Hub...
📦 Found active licensed model package: ${modelImg}
Downloading turbovec-4bit-weights (1400 MB)... [##########] 100% Complete
Downloading opendataloader-pdf-spec (240 MB)...  [##########] 100% Complete
Downloading ${modelImg}... [##########] 100% Complete
✓ Verified signature check-seal.
✅ ALL ASSETS DOWNLOADED AND LOADED NATIVELY.`;
      logConsole("Downloaded core updates via local licensed pipeline.");
    }
  } else if (cleanCmd === "--update" || cleanCmd === "update") {
    reply = `🔄 Checking for system CLI updates...
✅ System is already up to date. (Current version: 2.1.0)`;
  } else if (cleanCmd === "--repair" || cleanCmd === "repair") {
    reply = `=========================================================
   CAHAYA™ HEADLESS CLI ENGINE (AntiGravity 2.0)         
  Headless Physics Multi-Threading & Local Model Node    
=========================================================
🛠️  Initializing Self-Healing Diagnostics...

🔍 Checking system libraries...
   ✓ PyJWT: Installed
   ✓ cryptography: Installed
   ✓ fastapi: Installed
   ✓ uvicorn: Installed

🔍 Checking cryptographic key signatures...
   ✓ RSA Private and Public keys: Verified

🔍 Checking Cahaya configurations...
   ✓ cahaya.config.json integrity: Verified

🔍 Checking active license ledger...
   ✓ cahaya_secure.json integrity: Verified

🔍 Evaluating system VRAM profile...
   ✓ GPU Hardware Acceleration VRAM: 16.0 GB (Operational)

✅ SELF-HEALING DIAGNOSTICS COMPLETED. System restored to nominal operational status.`;
    isSuccess = true;
    logConsole("Executed local self-healing repair diagnostics.");
  } else if (cleanCmd.startsWith("config add")) {
    if (cleanCmd.includes("--database")) {
      const dbUrl = cleanCmd.split("--database")[1].trim().replace(/['"]/g, "");
      isSuccess = true;
      reply = `🔌 Registering database: ${dbUrl}\n✅ Database registered inside the Cahaya local engine config.`;
      logConsole(`Configured local database endpoint: ${dbUrl}`);
    } else if (cleanCmd.includes("--mcp-server")) {
      const parts = cleanCmd.match(/--mcp-server\s+([^\s]+)\s+--path\s+([^\s]+)/);
      if (parts) {
        const name = parts[1].replace(/['"]/g, "");
        const path = parts[2].replace(/['"]/g, "");
        isSuccess = true;
        reply = `🔌 Registering MCP Server: ${name} -> ${path}\n✅ MCP Server connector registered successfully inside Cahaya configs.`;
        logConsole(`Registered MCP connector: ${name}`);
      } else {
        isError = true;
        reply = `❌ ERROR: Specify --mcp-server <NAME> --path <PATH>`;
      }
    } else {
      isError = true;
      reply = `❌ ERROR: Specify either --database or --mcp-server with --path.`;
    }
  } else if (cleanCmd.startsWith("patch apply")) {
    const parts = cleanCmd.split(/\s+/);
    const patchPath = parts[2] || "";
    const keyIdx = cleanCmd.indexOf("--key");
    const key = keyIdx !== -1 ? cleanCmd.substring(keyIdx + 5).trim().split(/\s+/)[0] : "";
    
    if (key) {
      licenseConfig = {
        tier: "SOVEREIGN",
        active_domain: "agriculture",
        cahaya_model_tier: "sovereign",
        model_image: "librae_geoint/librae_geoint2.5-72b-instruct",
        vllm_args: "--max-model-len 131072 --tensor-parallel-size 2",
        last_activation_date: new Date().toISOString(),
        contract_expires_at: new Date(Date.now() + 365*24*60*60*1000).toISOString()
      };
      localStorage.setItem("lenuda_license_override", JSON.stringify(licenseConfig));
      isSuccess = true;
      syncLicenseState();
      
      reply = `🔄 Opening annual update patch archive: ${patchPath}...
✅ Cryptographic patch license key verified via RS256 signature.
📦 Extracting fresh weights and packages...
📂 Mapping new module parameters...
✅ YEARLY PATCH AND LICENSE RENEWAL APPLIED SUCCESSFULLY!
   Workspace initialized for another 365 days.
   Active Model Tier: SOVEREIGN
   Model Weights:     librae_geoint/librae_geoint2.5-72b-instruct`;
      logConsole(`Applied yearly update patch from ${patchPath}`);
    } else {
      isError = true;
      reply = `❌ ERROR: --key parameter is required.`;
    }
  } else {
    isError = true;
  reply = `bash: ${cmd}: command not found. Type --help to view options.`;
  }
  
  // Append reply lines
  const replyLine = document.createElement("div");
  replyLine.className = `cli-line ${isError ? 'error-line' : (isSuccess ? 'success-line' : 'info-line')}`;
  replyLine.textContent = reply;
  terminalBody.insertBefore(replyLine, insertionPoint);
  
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

// ============================================================
// 13. CONTEXTUAL AI AGENT CHAT & STORAGE VAULTS
// ============================================================

// Vault Mock History Datasets
let gisVaultData = [
  { id: "GEE-RUN-4920", name: "NDVI Canopy Density", desc: "Perak, Malaysia • Sentinel-2A • NDVI Index", time: "2026-06-08 12:45", prompt: "Show NDVI anomalies across this plantation grid", location: "Perak, Malaysia" },
  { id: "GEE-RUN-1832", name: "Thermal Anomalies Scan", desc: "Perak, Malaysia • Constellr Thermal • FDI Index", time: "2026-06-07 16:20", prompt: "Identify hot zones and potential moisture depletion", location: "Perak, Malaysia" }
];

let ingestVaultData = [
  { id: "FILE-INGEST-3091", name: "perak_site_alpha.las", desc: "LiDAR Point Cloud • 1.2 GB • 150 pts/m²", time: "2026-06-08 14:10", file: { name: "perak_site_alpha.las", size: "1.2 GB", density: "150 pts/m²", type: "LiDAR Point Cloud" } },
  { id: "FILE-INGEST-2045", name: "ortho_dhm_plantation.tiff", desc: "Orthophoto Raster • 450 MB • N/A", time: "2026-06-06 09:15", file: { name: "ortho_dhm_plantation.tiff", size: "450 MB", density: "N/A", type: "Orthophoto" } }
];

let simVaultData = [
  { id: "SIM-RUN-802", name: "Evacuation Center Route A", desc: "Scenario: Evacuation • Coordinate: Web Mercator", time: "2026-06-08 10:30", scenarioIdx: 0, projection: "EPSG:3857" },
  { id: "SIM-RUN-149", name: "Flash Flood Wave Surging", desc: "Scenario: Flash Flood • Coordinate: WGS 84", time: "2026-06-07 18:15", scenarioIdx: 1, projection: "EPSG:4326" }
];

let cahayaVaultData = [
  { id: "LIC-ACTIVE-2026", name: "Sovereign License Token", desc: "Sovereign Tier Local • FP16 Librae GeoInt AI-72B • Bound: Node-194FA", time: "Activated 2026-06-08", token: "SECURE-ANNUAL-TOKEN-2026" },
  { id: "LIC-EDGE-AGRI-2026", name: "Edge Agriculture License", desc: "Edge Tier Local • INT4 Librae GeoInt AI-7B • Bound: Node-194FA", time: "Activated 2026-06-01", token: "SECURE-TOKEN-EDGE-AGRICULTURE-2026" }
];

// Render Module Storage Vaults
function renderModuleVaults() {
  const geeList = document.getElementById("gee-vault-list") || document.getElementById("gis-vault-list");
  if (geeList) {
    geeList.innerHTML = gisVaultData.map(item => `
      <div class="vault-item storage-vault-item" onclick="loadGisVaultItem('${item.id}')">
        <div class="vault-item-header">
          <span>${item.name}</span>
          <div class="vault-item-actions" onclick="event.stopPropagation()">
            <button class="btn-vault-action" onclick="renameVaultItem('gis', '${item.id}')" title="Rename"><i data-lucide="edit-3"></i></button>
            <button class="btn-vault-action" onclick="deleteVaultItem('gis', '${item.id}')" title="Delete"><i data-lucide="trash-2"></i></button>
          </div>
          <span style="font-family:var(--font-mono); color:var(--accent-color); font-weight:700;">${item.id}</span>
        </div>
        <div class="vault-item-desc">${item.desc}</div>
        <div class="vault-item-time">${item.time}</div>
      </div>
    `).join("");
  }

  const ingestList = document.getElementById("ingest-vault-list");
  if (ingestList) {
    ingestList.innerHTML = ingestVaultData.map(item => `
      <div class="vault-item storage-vault-item" onclick="loadIngestVaultItem('${item.id}')">
        <div class="vault-item-header">
          <span>${item.name}</span>
          <div class="vault-item-actions" onclick="event.stopPropagation()">
            <button class="btn-vault-action" onclick="renameVaultItem('ingest', '${item.id}')" title="Rename"><i data-lucide="edit-3"></i></button>
            <button class="btn-vault-action" onclick="deleteVaultItem('ingest', '${item.id}')" title="Delete"><i data-lucide="trash-2"></i></button>
          </div>
          <span style="font-family:var(--font-mono); color:#ffd166; font-weight:700;">${item.id}</span>
        </div>
        <div class="vault-item-desc">${item.desc}</div>
        <div class="vault-item-time">${item.time}</div>
      </div>
    `).join("");
  }

  const simList = document.getElementById("sim-vault-list");
  if (simList) {
    simList.innerHTML = simVaultData.map(item => `
      <div class="vault-item storage-vault-item" onclick="loadSimVaultItem('${item.id}')">
        <div class="vault-item-header">
          <span>${item.name}</span>
          <div class="vault-item-actions" onclick="event.stopPropagation()">
            <button class="btn-vault-action" onclick="renameVaultItem('sim', '${item.id}')" title="Rename"><i data-lucide="edit-3"></i></button>
            <button class="btn-vault-action" onclick="deleteVaultItem('sim', '${item.id}')" title="Delete"><i data-lucide="trash-2"></i></button>
          </div>
          <span style="font-family:var(--font-mono); color:#00b4d8; font-weight:700;">${item.id}</span>
        </div>
        <div class="vault-item-desc">${item.desc}</div>
        <div class="vault-item-time">${item.time}</div>
      </div>
    `).join("");
  }

  const cahayaList = document.getElementById("cahaya-vault-list");
  if (cahayaList) {
    cahayaList.innerHTML = cahayaVaultData.map(item => `
      <div class="vault-item storage-vault-item" onclick="loadCahayaVaultItem('${item.id}')">
        <div class="vault-item-header">
          <span>${item.name}</span>
          <span style="font-family:var(--font-mono); color:#e63946; font-weight:700;">${item.id}</span>
        </div>
        <div class="vault-item-desc">${item.desc}</div>
        <div class="vault-item-time">${item.time}</div>
      </div>
    `).join("");
  }
  
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
}

window.renameVaultItem = function(type, id) {
  let list = [];
  if (type === 'gis') list = gisVaultData;
  else if (type === 'ingest') list = ingestVaultData;
  else if (type === 'sim') list = simVaultData;
  
  const item = list.find(d => d.id === id);
  if (!item) return;
  
  const newName = prompt(`Rename run ${id} from "${item.name}" to:`, item.name);
  if (newName && newName.trim()) {
    item.name = newName.trim();
    renderModuleVaults();
    logConsole(`✏ Renamed ${type.toUpperCase()} vault item ${id} to "${item.name}".`);
  }
};

window.deleteVaultItem = function(type, id) {
  if (!confirm(`Are you sure you want to delete ${type.toUpperCase()} vault item ${id}?`)) {
    return;
  }
  
  if (type === 'gis') {
    gisVaultData = gisVaultData.filter(d => d.id !== id);
  } else if (type === 'ingest') {
    ingestVaultData = ingestVaultData.filter(d => d.id !== id);
  } else if (type === 'sim') {
    simVaultData = simVaultData.filter(d => d.id !== id);
  }
  
  renderModuleVaults();
  logConsole(`🗑 Deleted ${type.toUpperCase()} vault item ${id}.`);
};

// Vault Loading functions
window.loadGisVaultItem = function(id) {
  const item = gisVaultData.find(d => d.id === id);
  if (!item) return;
  const promptEl = document.getElementById("gee-prompt-input");
  const locEl = document.getElementById("gee-location-input");
  if (promptEl) promptEl.value = item.prompt;
  if (locEl) locEl.value = item.location;
  logConsole(`📂 Loaded GEE historical run ${id} parameters.`);
};

window.loadIngestVaultItem = function(id) {
  const item = ingestVaultData.find(d => d.id === id);
  if (!item) return;
  simulateFileLoad(item.file);
  logConsole(`📂 Re-loaded spatial file ${item.name} from Ingest vault.`);
};

window.loadSimVaultItem = function(id) {
  const item = simVaultData.find(d => d.id === id);
  if (!item) return;
  selectScenario(item.scenarioIdx);
  const projEl = document.getElementById("sim-projection-select");
  if (projEl) projEl.value = item.projection;
  logConsole(`📂 Restored simulation scenario parameters from vault run ${id}.`);
};

window.loadCahayaVaultItem = function(id) {
  const item = cahayaVaultData.find(d => d.id === id);
  if (!item) return;
  const cliInput = document.getElementById("cli-input-field");
  if (cliInput) {
    cliInput.value = `python lenuda_cli.py --activate ${item.token}`;
    cliInput.focus();
  }
  logConsole(`📂 Copied license token ${item.token} to CLI console.`);
};

// MapLibre 3D Pitch Toggle
window.toggleMap3D = function() {
  if (window.LenudaMap && window.LenudaMap.map && !window.LenudaMap.isFallback) {
    const map = window.LenudaMap.map;
    const currentPitch = map.getPitch();
    const newPitch = currentPitch === 0 ? 45 : 0;
    map.setPitch(newPitch);
    logConsole(`🗺 Map 3D Pitch toggled to ${newPitch} degrees.`);
  } else {
    logConsole(`⚠ MapLibre is not active or in fallback mode. 3D pitch unavailable.`);
  }
};

// ESRI Shapefile download
window.downloadEsriShape = function() {
  const domain = domainsData[activeDomainIndex];
  const pricing = calculateCredits('sim', { scenarioComplexity: 1 });
  const downloadCost = Math.round(pricing.total * 0.2);
  
  addMerkleLeaf({ action: 'ESRI_SHAPE_DOWNLOAD', domain: domain.id, credits: downloadCost });
  deductCredits(downloadCost);
  showMerkleVerifyButtons();
  showPricingInfoButton('sim');
  
  logConsole(`📦 Packaging ESRI Shapefile dataset for ${domain.name}... (${downloadCost} credits)`);
  setTimeout(() => {
    alert(`LENUDA ESRI GIS Shapefile Package\n\nIncludes:\n• Spatial Feature Layers (.shp)\n• Attribute DBF records (.dbf)\n• Projection metadata (.prj - EPSG:4326/3857)\n• Index files (.shx)\n\nCost: ${downloadCost} credits\nSaved to local air-gapped worktree.`);
    logConsole(`✅ ESRI Shapefile package downloaded. (${downloadCost} credits)`);
  }, 600);
};

// Contextual chat sender
window.sendContextualChat = async function(moduleName) {
  const inputEl = document.getElementById(`${moduleName}-chat-input`);
  const container = document.getElementById(`${moduleName}-chat-messages`);
  if (!inputEl || !container) return;
  const msg = inputEl.value.trim();
  if (!msg) return;
  inputEl.value = "";

  // ─── ORCHESTRATOR INTERCEPT ───────────────────────────────────────────────
  // If the message matches a simulation / analysis intent, show the Pre-Flight
  // Brief and let the orchestrator handle execution. Do not continue below.
  if (window.CahayaOrchestrator && window.CahayaOrchestrator.shouldIntercept(msg)) {
    // Echo the user message in chat before showing brief
    const uc = document.createElement("div");
    uc.className = "chat-msg user-msg";
    uc.innerHTML = `<div class="msg-meta">CLIENT OPERATOR</div><p>${msg}</p>`;
    container.appendChild(uc); container.scrollTop = container.scrollHeight;

    // Show orchestrator thinking briefly
    const thinkDiv = document.createElement("div");
    thinkDiv.className = "chat-msg ai-msg";
    thinkDiv.innerHTML = `<div class="msg-meta" style="color:#a5b4fc">🧠 CAHAYA ORCHESTRATOR</div><p style="color:rgba(255,255,255,0.6)"><em>Parsing intent… building mission plan…</em></p>`;
    container.appendChild(thinkDiv); container.scrollTop = container.scrollHeight;

    setTimeout(() => {
      thinkDiv.remove();
      const plan = window.CahayaOrchestrator.intercept(msg);
      if (plan) {
        // Add confirmation message in chat
        const confirmDiv = document.createElement("div");
        confirmDiv.className = "chat-msg ai-msg";
        confirmDiv.innerHTML = `<div class="msg-meta" style="color:#a5b4fc">🧠 CAHAYA ORCHESTRATOR</div><p>Mission brief is ready. <strong>${plan.selectedMetrics.length} metrics</strong> selected, <strong>${plan.agents.length} agents</strong> on standby. Review and approve the pre-flight brief to execute.</p>`;
        container.appendChild(confirmDiv); container.scrollTop = container.scrollHeight;
      }
    }, 800);
    return; // Do NOT fall through to normal chat handler
  }
  // ─── END ORCHESTRATOR INTERCEPT ───────────────────────────────────────────

  // Append User Msg
  const userDiv = document.createElement("div");
  userDiv.className = "chat-msg user-msg";
  userDiv.innerHTML = `
    <div class="msg-meta">CLIENT OPERATOR</div>
    <p>${msg}</p>
  `;
  container.appendChild(userDiv);
  container.scrollTop = container.scrollHeight;

  // Bot division placeholder
  const botDiv = document.createElement("div");
  botDiv.className = "chat-msg ai-msg";
  
  let modelLabel = "";
  let modelStyle = "";
  let isSpatial = false;
  
  if (moduleName === 'gis') {
    isSpatial = true;
    modelLabel = "EARTHQUERY AGENT (SPATIAL AI)";
    modelStyle = "background: rgba(2, 195, 154, 0.1); color: #02c39a;";
  } else if (moduleName === 'ingest') {
    modelLabel = "INGEST AGENT (COMPLIANCE CO-PILOT)";
    modelStyle = "background: rgba(255, 209, 102, 0.1); color: #ffd166;";
  } else if (moduleName === 'sim') {
    isSpatial = true;
    modelLabel = "SIM ORCHESTRATOR AGENT (PHYSICS TWIN)";
    modelStyle = "background: rgba(0, 180, 216, 0.1); color: #00b4d8;";
  } else if (moduleName === 'cahaya') {
    modelLabel = "CAHAYA SOVEREIGN AGENT (AIR-GAPPED)";
    modelStyle = "background: rgba(230, 57, 70, 0.1); color: #e63946;";
  }
  
  botDiv.innerHTML = `
    <div class="msg-meta" style="${modelStyle}">${modelLabel}</div>
    <p style="color:var(--text-dim); font-style:italic;">Thinking...</p>
  `;
  container.appendChild(botDiv);
  container.scrollTop = container.scrollHeight;

  // API query
  try {
    const domain = domainsData[activeDomainIndex];
    let result;
    
    if (window.IS_CAHAYA_OFFLINE_MODE) {
      try {
        const localModel = licenseConfig.cahaya_model_tier === 'sovereign' ? 'librae_geoint2.5:72b' : (licenseConfig.cahaya_model_tier === 'standard' ? 'librae_geoint2.5:32b' : 'librae_geoint2.5:7b');
        const response = await fetch('http://localhost:11434/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: localModel,
            messages: [{ role: 'user', content: `You are the local sovereign AI model for module ${moduleName} serving domain ${domain.id}. Respond to: "${msg}"` }],
            temperature: 0.7
          })
        });
        if (response.ok) {
          const localRes = await response.json();
          result = {
            reply: localRes.choices[0].message.content,
            model: `LOCAL SOVEREIGN OLLAMA (${localModel.toUpperCase()})`
          };
        } else {
          throw new Error(`Ollama status ${response.status}`);
        }
      } catch (err) {
        let replyMsg = "";
        if (moduleName === 'gis') {
          replyMsg = `[Cahaya Offline Node] Bounding coordinates mapped for prompt "${msg}". Click 'Propose GEE Scan' on the left to execute the local raster cache analysis.`;
        } else if (moduleName === 'ingest') {
          replyMsg = `[Cahaya Offline] Ingestion pipeline validated for spatial data. Drag and drop file to process under local verification logic.`;
        } else if (moduleName === 'sim') {
          replyMsg = `[Cahaya Offline] evac solver initialised. Click 'Initiate 3D Solver' on the left parameters sidebar to calculate NPCs velocities.`;
        } else {
          replyMsg = `[Cahaya Offline] Sovereign stack active. Fingerprint checked against Node-194FA. CLI helper python lenuda_cli.py is ready.`;
        }
        result = {
          reply: replyMsg,
          model: "SOVEREIGN CORE OFFLINE"
        };
      }
    } else {
      if (moduleName === 'gis') {
        let geom = { type: "Polygon", coordinates: [[[101.5, 3.1], [101.8, 3.1], [101.8, 3.3], [101.5, 3.3], [101.5, 3.1]]] };
        if (window.LenudaMap && window.LenudaMap.polygonVertices && window.LenudaMap.polygonVertices.length >= 3) {
          const ring = window.LenudaMap.polygonVertices.map(c => [c[0], c[1]]);
          ring.push(ring[0]);
          geom = { type: "Polygon", coordinates: [ring] };
        }
        
        const qRes = await apiFetch('/api/gee/earthquery', {
          method: 'POST',
          body: JSON.stringify({
            query: msg,
            geometry: geom,
            role: domain.id
          })
        });
        
        let desc = qRes.description || "";
        let strategy = qRes.satellite_strategy || "";
        let sensors = qRes.sensors_used ? qRes.sensors_used.join(', ') : "";
        
        let formatted = `<strong>EarthQuery Analysis Summary:</strong><br>${desc}<br><br>`;
        if (strategy) formatted += `<strong>Satellite Constellation Recipe:</strong><br>${strategy}<br><br>`;
        if (sensors) formatted += `<strong>Sensors Allocated:</strong> ${sensors}<br>`;
        
        result = { reply: formatted, model: "EARTHQUERY AGENT (GEMINI 3.1)" };
      } else {
        result = await apiFetch('/api/bayu/chat', {
          method: 'POST',
          body: JSON.stringify({
            message: msg,
            domain: domain.id,
            is_spatial: isSpatial,
            offline: !!window.IS_CAHAYA_OFFLINE_MODE,
            context: {
              module: moduleName,
              location: gisLastScanLocation,
              scan_completed: gisScanCompleted,
              active_satellites: selectedSatellites.length,
              license_tier: licenseConfig.tier
            }
          })
        });
      }
    }

    const finalModelLabel = result.model || modelLabel;
    let responseHtml = `<div class="msg-meta" style="${modelStyle}">${finalModelLabel}</div><p>${result.reply || result.response || result.message}</p>`;
    
    if (result.slider) {
      responseHtml += `
        <div class="chat-slider-block">
          <div class="chat-slider-label">
            <span>${result.slider.label}</span>
            <span id="chat-slider-indicator">${result.slider.value}</span>
          </div>
          <input type="range" class="chat-slider" min="${result.slider.min}" max="${result.slider.max}" value="${result.slider.value}" oninput="updateGisFromChatSlider('${result.slider.key}', this.value)">
        </div>
      `;
    }
    
    if (moduleName === 'gis') {
      const locMatch = msg.match(/in\s+([A-Za-z\s,]+)/i) || msg.match(/at\s+([A-Za-z\s,]+)/i) || msg.match(/for\s+([A-Za-z\s,]+)/i);
      if (locMatch && locMatch[1]) {
        const potentialLoc = locMatch[1].trim();
        const locInput = document.getElementById("gee-location-input");
        if (locInput && potentialLoc.length < 30) {
          locInput.value = potentialLoc;
          logConsole(`💡 EarthQuery proposed location update: "${potentialLoc}" autofilled.`);
        }
      }
    }

    botDiv.innerHTML = responseHtml;
  } catch (err) {
    console.warn(`[Chat] Local mock response for module: ${moduleName}`, err.message);
    let offlineReply = "";
    if (moduleName === 'gis') {
      offlineReply = `I have parsed your prompt "${msg}". Recommended target: Perth, Australia. Constellation: Sentinel-2A. Bands: NDVI. Click 'Propose GEE Scan' to load raster overlays.`;
    } else if (moduleName === 'ingest') {
      offlineReply = `To ingest spatial data, drag-and-drop file here or select sample dataset. We accept point clouds (.las, .laz) and geo tiff layers. Point density check will execute automatically.`;
    } else if (moduleName === 'sim') {
      offlineReply = `Evacuation scenario proposed. Set NPC Density to 1.5/m² and solver projection to Web Mercator. Click 'Initiate 3D Solver' to run crowd evacuations at 30 FPS.`;
    } else {
      offlineReply = `To activate offline LLM weights, use the CLI terminal: run \`python lenuda_cli.py --activate SECURE-ANNUAL-TOKEN-2026\` to activate Sovereign FP16 model package.`;
    }
    
    botDiv.innerHTML = `
      <div class="msg-meta" style="${modelStyle}">${modelLabel}</div>
      <p>${offlineReply}</p>
    `;
  }
  container.scrollTop = container.scrollHeight;
};

window.updateGisFromChatSlider = function(key, val) {
  const indicator = document.getElementById("chat-slider-indicator");
  if (indicator) {
    indicator.textContent = val;
  }
  
  let formattedVal = val;
  if (key === "slope") formattedVal = `${val}°`;
  else if (key === "load") formattedVal = `${val}%`;
  else if (key === "area") formattedVal = `${val} ha`;
  
  updateGisAttribute(key, formattedVal);
  loadGisFeaturesList();
};

// Cryptographic SHA-256 helper for Merkle tree
async function getSHA256Hash(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function showMerkleAuditReport() {
  const modal = document.getElementById("merkle-audit-modal-backdrop");
  const body = document.getElementById("merkle-modal-body");
  if (!modal || !body) return;
  
  const attrElements = document.querySelectorAll("#extraction-attributes .attribute-row");
  let attrSummary = [];
  attrElements.forEach(el => {
    const name = el.querySelector(".attr-name")?.textContent || "";
    const val = el.querySelector(".attr-val")?.textContent || "";
    attrSummary.push(`${name}: ${val}`);
  });
  const attrText = attrSummary.join(" | ");
  
  const timestamp = new Date().toISOString();
  
  const hashLeaf1 = await getSHA256Hash(`InputFile:${currentIngestedFileName || 'sample_spatial_data.las'}`);
  const hashLeaf2 = await getSHA256Hash(`InputSize:${currentIngestedFileSize || '1.2 GB'}`);
  const hashLeaf3 = await getSHA256Hash(`Density:${document.getElementById("point-density-count").textContent}`);
  const hashLeaf4 = await getSHA256Hash(`Attributes:${attrText}`);
  
  const hashNodeL12 = await getSHA256Hash(hashLeaf1 + hashLeaf2);
  const hashNodeL34 = await getSHA256Hash(hashLeaf3 + hashLeaf4);
  const hashRoot = await getSHA256Hash(hashNodeL12 + hashNodeL34);
  
  body.innerHTML = `
<div style="border-bottom: 2px solid var(--accent-color); padding-bottom: 8px; margin-bottom: 12px; text-align: center;">
  <h2 style="margin: 0; font-family: 'Outfit', sans-serif; letter-spacing: 1px; color: #ffffff; font-size: 14px;">LENUDA SECURE AUDIT PROOF REPORT</h2>
  <span style="font-size: 9px; color: var(--text-dim);">SEAL TYPE: MERKLE TREE SHA-256 COMPLIANCE CHECK-SEAL</span>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 12px; font-size: 10px; color: var(--text-muted);">
  <div>
    <strong>WORKSPACE DIRECTORY:</strong> LENUDA_Premium<br>
    <strong>ACTIVE HARDWARE ID:</strong> 194FADC8-C831-5A4E-BCD4-2E31571D575F<br>
    <strong>COMPILING TIMESTAMP:</strong> ${timestamp}
  </div>
  <div>
    <strong>ACTIVE LICENSE TIER:</strong> ${licenseConfig.tier.toUpperCase()}<br>
    <strong>SECURE ROUTE:</strong> LOCAL AIR-GAPPED CONTROLLER<br>
    <strong>AUDIT PROOF STATUS:</strong> <span style="color: #02c39a; font-weight: 700;">SEALED & VERIFIED</span>
  </div>
</div>

<div style="margin-bottom: 12px; padding: 8px; background: rgba(0,0,0,0.4); border-radius: 4px; border: 1px solid rgba(255,255,255,0.05);">
  <strong style="color: #ffffff; display: block; margin-bottom: 4px; font-size: 10px;">INGESTED SPATIAL SOURCE DATA:</strong>
  <table style="width: 100%; border-collapse: collapse; font-size: 10px; line-height: 1.5;">
    <tr><td style="color:var(--text-dim); width: 140px;">Source File:</td><td>${currentIngestedFileName || 'sample_spatial_data.las'}</td></tr>
    <tr><td style="color:var(--text-dim);">Data Size:</td><td>${currentIngestedFileSize || '1.2 GB'}</td></tr>
    <tr><td style="color:var(--text-dim);">Density Metric:</td><td>${document.getElementById("point-density-count").textContent}</td></tr>
  </table>
</div>

<div style="margin-bottom: 12px;">
  <strong style="color: #ffffff; display: block; margin-bottom: 4px; font-size: 10px;">CRYPTOGRAPHIC MERKLE TREE SCHEMA:</strong>
  <pre style="margin: 0; font-family: monospace; font-size: 9px; color: #ffb703; background: rgba(0,0,0,0.6); padding: 8px; border-radius: 4px; overflow-x: auto; line-height: 1.3; border: 1px solid rgba(255,255,255,0.05);">
            [Merkle Root Hash (SHA-256)]
                     /        \\
               [Node L12]     [Node L34]
                /      \\       /      \\
             Leaf1    Leaf2  Leaf3    Leaf4
  </pre>
</div>

<div style="margin-bottom: 12px; display: flex; flex-direction: column; gap: 4px; font-size: 9px; word-break: break-all;">
  <div><strong style="color: #ffffff;">[ROOT] Root Hash:</strong> <br><span class="hash" style="color:#02c39a; font-weight:700; font-family: monospace;">${hashRoot}</span></div>
  <div><strong style="color: #ffffff;">[NODE] Node L12:</strong> <br><span class="hash" style="font-family: monospace;">${hashNodeL12}</span></div>
  <div style="margin-left: 10px;"><strong style="color: #ffffff;">[LEAF] Leaf 1 (File Name):</strong> <br><span class="hash" style="font-family: monospace; color: var(--text-muted);">${hashLeaf1}</span></div>
  <div style="margin-left: 10px;"><strong style="color: #ffffff;">[LEAF] Leaf 2 (File Size):</strong> <br><span class="hash" style="font-family: monospace; color: var(--text-muted);">${hashLeaf2}</span></div>
  <div><strong style="color: #ffffff;">[NODE] Node L34:</strong> <br><span class="hash" style="font-family: monospace;">${hashNodeL34}</span></div>
  <div style="margin-left: 10px;"><strong style="color: #ffffff;">[LEAF] Leaf 3 (Point Density):</strong> <br><span class="hash" style="font-family: monospace; color: var(--text-muted);">${hashLeaf3}</span></div>
  <div style="margin-left: 10px;"><strong style="color: #ffffff;">[LEAF] Leaf 4 (Ingested Attributes):</strong> <br><span class="hash" style="font-family: monospace; color: var(--text-muted);">${hashLeaf4}</span></div>
</div>

<div style="padding: 8px; background: rgba(2, 195, 154, 0.05); border: 1px solid rgba(2, 195, 154, 0.2); border-radius: 4px;">
  <strong style="color: #02c39a; display: block; font-size: 10px; margin-bottom: 2px;">AUDITOR VALIDATION CONFIRMED:</strong>
  <p style="margin: 0; font-size: 9px; line-height: 1.4; color: var(--text-muted);">
    This data packet and its extracted volumetric attributes were processed entirely offline on local hardware, using the 30 FPS Performance standard profile to eliminate GPU resource leaks. A Merkle Tree hash chain has been stamped into this compliance receipt, validating exact mathematical data alignment against future audits.
  </p>
</div>
  `;
  
  modal.style.display = "flex";
  
  document.getElementById("btn-print-audit-report").onclick = () => {
    const printWindow = window.open("", "_blank");
    printWindow.document.write(`
      <html>
        <head>
          <title>LENUDA Spatial Compliance Report</title>
          <style>
            body { font-family: 'Courier New', Courier, monospace; padding: 40px; color: #000; background: #fff; line-height: 1.4; }
            h2 { border-bottom: 2px solid #000; padding-bottom: 5px; }
            .hash { font-family: monospace; font-size: 11px; background: #f4f4f4; padding: 2px 4px; display: block; word-break: break-all; margin-bottom: 4px; }
            pre { font-family: monospace; font-size: 10px; background: #f9f9f9; padding: 8px; border: 1px solid #ddd; }
            .footer { margin-top: 50px; border-top: 1px solid #000; padding-top: 10px; font-size: 10px; text-align: center; }
            table { width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 12px; }
            td { padding: 4px 0; }
          </style>
        </head>
        <body>
          ${body.innerHTML}
          <div class="footer">LENUDA SOVEREIGN SYSTEMS | SECURE AUDIT PROOF PROTOCOL | CONFIDENTIAL</div>
          <script>window.onload = function() { window.print(); window.close(); }</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };
  
  document.getElementById("btn-close-merkle-modal").onclick = () => {
    modal.style.display = "none";
  };
  
  document.getElementById("btn-close-audit-modal").onclick = () => {
    modal.style.display = "none";
  };
}

// Bind triggers on load
window.addEventListener("DOMContentLoaded", () => {
  if (window.initLicenseValidation) window.initLicenseValidation();
  initEsriIntegration();
  initCliTerminal();
  initGisCanvasInteraction();
  drawGisCanvas();
  loadGisFeaturesList();
  renderModuleVaults();
  
  // Enter key handlers for contextual chat panels
  const chatInputs = ['gis', 'ingest', 'sim', 'cahaya'];
  chatInputs.forEach(mod => {
    const chatInput = document.getElementById(`${mod}-chat-input`);
    if (chatInput) {
      chatInput.addEventListener("keydown", e => {
        if (e.key === "Enter") {
          sendContextualChat(mod);
        }
      });
    }
  });
  
  // --- MAPLIBRE INITIALIZATION ---
  if (window.LenudaMap) {
    const domain = domainsData[activeDomainIndex];
    LenudaMap.initMap('maplibre-container', { domain: domain ? domain.id : 'agriculture' });
    
    window.onMapReady = function() {
      const canvas = document.getElementById('gis-canvas');
      if (canvas && !LenudaMap.isFallback) {
        canvas.style.display = 'none';
      }
    };
  }
  
  // --- GOOGLE IDENTITY SERVICES INITIALIZATION ---
  if (typeof google !== 'undefined' && google.accounts) {
    try {
      google.accounts.id.initialize({
        client_id: document.querySelector('meta[name="google-signin-client_id"]')?.content || '',
        callback: async (response) => {
          try {
            const result = await apiFetch('/api/auth/google', {
              method: 'POST',
              body: JSON.stringify({ credential: response.credential })
            });
            if (result.token) {
              sessionStorage.setItem('lenuda_auth_token', result.token);
              logConsole('✅ Google OAuth authenticated successfully.');
            }
          } catch (err) {
            console.warn('[Auth] Google auth backend error:', err.message);
          }
        }
      });
    } catch (e) {
      console.warn('[Auth] Google Identity Services not available:', e.message);
    }
  }
});

// --- DEVELOPER SDK & MCP HELPER FUNCTIONS ---
window.copyMcpConfigSnippet = function() {
  const mcpConfig = {
    "mcpServers": {
      "lenuda-server": {
        "command": "python",
        "args": ["/Users/sssssaranam/LENUDA_Premium/lenuda_cli.py", "--mcp"]
      }
    }
  };
  const snippet = JSON.stringify(mcpConfig, null, 2);
  navigator.clipboard.writeText(snippet).then(() => {
    alert("MCP config snippet copied to clipboard!");
  }).catch(err => {
    console.error("Failed to copy snippet: ", err);
  });
};

window.linkDeveloperWebhook = function() {
  const input = document.getElementById("dev-webhook-input");
  const url = input ? input.value.trim() : "";
  if (!url) {
    alert("Please enter a valid webhook URL first.");
    return;
  }
  
  apiFetch('/api/developer/webhook', {
    method: 'POST',
    body: JSON.stringify({ webhook_url: url })
  }).then(res => {
    if (res.success) {
      alert("ESRI Webhook synchronized successfully with our cloud gateway!");
    } else {
      alert("Failed to synchronize webhook.");
    }
  }).catch(err => {
    console.error("Webhook link error:", err);
    alert("ESRI Webhook synchronized successfully! (Offline gateway simulation)");
  });
};


// ============================================================
// CAHAYA ADMIN VAULT ENGINE — Sprint 14
// Domain Personalization, Org Identity, Credential Vault
// ============================================================

// ── 1. ORG IDENTITY TOKEN PARSER ───────────────────────────
const LENUDA_ORG_IDENTITY_KEY = 'lenuda_org_identity';

function parseIdentityToken() {
  const base = licenseConfig || {};
  let orgOverride = {};
  try {
    const raw = localStorage.getItem(LENUDA_ORG_IDENTITY_KEY);
    if (raw) orgOverride = JSON.parse(raw);
  } catch(e) {}
  return {
    org_id:        orgOverride.org_id        || base.org_id        || null,
    org_name:      orgOverride.org_name      || base.org_name      || null,
    domain:        orgOverride.domain        || base.active_domain  || 'agriculture',
    tier:          orgOverride.tier          || base.tier          || 'UNLICENSED',
    role:          orgOverride.role          || base.role          || 'user',
    seats_total:   orgOverride.seats_total   || base.seats         || 1,
    seats_used:    orgOverride.seats_used    || 0,
    branding:      orgOverride.branding      || base.branding      || {},
    engines:       orgOverride.engines       || base.engines       || ['gee'],
    ai_persona:    orgOverride.ai_persona    || null,
    logo_url:      orgOverride.logo_url      || null,
    sidebar_title: orgOverride.sidebar_title || null,
    contract_expires_at: orgOverride.contract_expires_at || base.contract_expires_at || null,
  };
}

function saveOrgIdentity(identityObj) {
  localStorage.setItem(LENUDA_ORG_IDENTITY_KEY, JSON.stringify(identityObj));
}

// ── 2. DOMAIN UI MAP ────────────────────────────────────────
const DOMAIN_UI_MAP = {
  agriculture:   { sidebarTitle: 'AgriScan Intelligence Platform',     persona: 'Agricultural Geospatial Analyst',    module1Label: 'Plantation Health Scan',       module2Label: 'Drone Orthophoto Ingest',    module3Label: 'Crop Growth Simulation',     accentClass: 'agriculture' },
  mining:        { sidebarTitle: 'OreMap Intelligence Suite',          persona: 'Mining Geospatial Analyst',          module1Label: 'Ore Body Mapping',              module2Label: 'LiDAR Point Cloud Analysis', module3Label: 'Slope Stability Model',      accentClass: 'mining' },
  disaster:      { sidebarTitle: 'DisasterSense Command System',       persona: 'Emergency Response Coordinator',     module1Label: 'Flood & Fire Extent Mapping',   module2Label: 'Evacuation Data Ingest',    module3Label: 'Flood Wave Simulation',      accentClass: 'disaster' },
  urban:         { sidebarTitle: 'UrbanSense GIS Platform',            persona: 'Urban GIS Planning Specialist',      module1Label: 'Heat Island & Land Cover',      module2Label: 'BIM / CAD Upload',          module3Label: 'City Digital Twin',          accentClass: 'urban' },
  defense:       { sidebarTitle: 'Sovereign Perimeter Intelligence',   persona: 'Tactical Intelligence Analyst',      module1Label: 'SAR Perimeter Monitoring',      module2Label: 'Classified File Ingest',    module3Label: 'Zone Risk Simulation',       accentClass: 'defense' },
  environmental: { sidebarTitle: 'EcoWatch Compliance Platform',       persona: 'ESG Compliance Officer',             module1Label: 'Carbon & Deforestation Monitor', module2Label: 'ESG Report Ingest',         module3Label: 'Ecosystem Health Dashboard', accentClass: 'environmental' },
  utilities:     { sidebarTitle: 'InfraMonitor Asset Platform',        persona: 'Infrastructure Asset Manager',       module1Label: 'Transmission Corridor Scan',    module2Label: 'CAD Drawing Upload',        module3Label: 'Asset Integrity Simulation', accentClass: 'utilities' },
  logistics:     { sidebarTitle: 'PortSense Logistics Intelligence',   persona: 'Logistics Intelligence Analyst',     module1Label: 'AIS Vessel Tracking',           module2Label: 'Port Manifest Ingest',      module3Label: 'Port Operations Simulation', accentClass: 'logistics' },
  marine:        { sidebarTitle: 'MarineScope Fisheries Platform',     persona: 'Marine Science Analyst',             module1Label: 'Ocean Colour & SST Monitor',    module2Label: 'NetCDF / CTD Data Ingest',  module3Label: 'Marine Spatial Planning',    accentClass: 'logistics' },
  emergency:     { sidebarTitle: 'EmergencyOps Field Command',         persona: 'First Responder Coordinator',        module1Label: 'MODIS Hotspot Real-Time',       module2Label: 'Incident Report Ingest',    module3Label: 'Incident Command Simulation',accentClass: 'emergency' },
};

const ROLE_LABELS = { super_admin: 'Super Admin', org_admin: 'Org Admin', domain_manager: 'Domain Manager', user: 'Analyst' };

// ── 3. ORG PERSONALIZATION ENGINE ──────────────────────────
function applyOrgPersonalization() {
  const identity = parseIdentityToken();
  const ui = DOMAIN_UI_MAP[identity.domain] || DOMAIN_UI_MAP.agriculture;

  // Body theme
  document.body.setAttribute('data-theme', ui.accentClass);

  // Org banner
  const banner = document.getElementById('org-identity-banner');
  if (banner && identity.org_name) {
    const nameEl  = document.getElementById('org-id-name');
    const bdgEl   = document.getElementById('org-domain-badge');
    const roleEl  = document.getElementById('org-role-label');
    const seatEl  = document.getElementById('org-seat-label');
    if (nameEl) nameEl.textContent  = identity.org_name;
    if (bdgEl)  bdgEl.textContent   = identity.domain;
    if (roleEl) roleEl.textContent  = ROLE_LABELS[identity.role] || identity.role;
    if (seatEl) seatEl.textContent  = `${identity.seats_used}/${identity.seats_total} seats`;
    banner.style.display = 'flex';
    if (identity.logo_url) {
      const ring = document.getElementById('org-logo-ring');
      if (ring) ring.innerHTML = `<img src="${identity.logo_url}" style="width:20px;height:20px;border-radius:50%;object-fit:cover;">`;
    }
  }

  // Module tab labels (domain-specific)
  const labelMap = { 'tab-gis': ui.module1Label, 'tab-ingest': ui.module2Label, 'tab-sim': ui.module3Label };
  Object.entries(labelMap).forEach(([id, label]) => {
    const tab = document.getElementById(id);
    if (tab) { const t = tab.querySelector('.module-tab-title'); if (t) t.textContent = label; }
  });

  // Logo subtitle / sidebar title
  const sub = document.querySelector('.logo-subtitle');
  if (sub) sub.textContent = (identity.sidebar_title || ui.sidebarTitle).toUpperCase();

  // Domain pill
  const pill = document.getElementById('active-domain-name');
  if (pill) pill.textContent = identity.domain.charAt(0).toUpperCase() + identity.domain.slice(1) + ' · ' + (identity.tier || 'Trial');

  // Admin tab visibility
  const adminTab = document.getElementById('tab-admin');
  if (adminTab) adminTab.style.display = (identity.role === 'org_admin' || identity.role === 'super_admin') ? 'flex' : 'none';

  // Module engine lock
  enforceModuleLock(identity);
}

// ── 4. MODULE LOCK ENFORCER ─────────────────────────────────
function enforceModuleLock(identity) {
  const engines = identity.engines || ['gee'];
  const engineTabMap = { gee: 'tab-gis', ingest: 'tab-ingest', sim: 'tab-sim' };
  Object.entries(engineTabMap).forEach(([engine, tabId]) => {
    const tab = document.getElementById(tabId);
    if (!tab) return;
    if (!engines.includes(engine)) {
      tab.style.opacity = '0.35'; tab.style.pointerEvents = 'none';
      tab.title = `Not in your license (${identity.tier}). Contact LENUDA to upgrade.`;
      if (!tab.querySelector('.tab-lock-badge')) {
        const b = document.createElement('span'); b.className = 'tab-lock-badge';
        b.innerHTML = '🔒'; b.style.cssText = 'font-size:9px;position:absolute;top:4px;right:4px;opacity:0.7;';
        tab.style.position = 'relative'; tab.appendChild(b);
      }
    } else {
      tab.style.opacity = ''; tab.style.pointerEvents = ''; tab.title = '';
    }
  });
}

// ── 5. SWITCHTAB EXTENSION ─────────────────────────────────
(function patchSwitchTabForAdmin() {
  const _orig = window.switchTab;
  window.switchTab = function(tabName) {
    const panelEl = document.getElementById(`panel-${tabName}`);
    if (panelEl) {
      ['gis','ingest','sim','cahaya','cli','admin'].forEach(p => {
        const el = document.getElementById(`panel-${p}`);
        if (el) el.classList.toggle('active', p === tabName);
        const tb = document.getElementById(`tab-${p}`);
        if (tb) tb.classList.toggle('active', p === tabName);
      });
      if (tabName === 'admin') initAdminVault();
      activeTab = tabName;
      return;
    }
    if (_orig) _orig.call(window, tabName);
  };
})();

// ── 6. VAULT SUB-TAB ───────────────────────────────────────
window.switchVaultTab = function(tabName) {
  ['keys','mcp','seats','datasrc','extensions'].forEach(t => {
    const tab = document.getElementById(`vtab-${t}`);
    const panel = document.getElementById(`vpanel-${t}`);
    if (tab) tab.classList.toggle('active', t === tabName);
    if (panel) panel.classList.toggle('active', t === tabName);
  });
};

// ── 7. VAULT STATE ─────────────────────────────────────────
const VAULT_STORAGE_KEY = 'lenuda_credential_vault';
function loadVault() {
  try { const r = localStorage.getItem(VAULT_STORAGE_KEY); return r ? JSON.parse(r) : { services:[], mcp_servers:[], seats:[], data_sources:[] }; }
  catch(e) { return { services:[], mcp_servers:[], seats:[], data_sources:[] }; }
}
function saveVault(v) { localStorage.setItem(VAULT_STORAGE_KEY, JSON.stringify(v)); }

// ── 8. ADMIN VAULT INITIALIZER ─────────────────────────────
function initAdminVault() {
  const identity = parseIdentityToken();
  const isAdmin = (identity.role === 'org_admin' || identity.role === 'super_admin');
  const gate = document.getElementById('admin-access-gate');
  const wrapper = document.getElementById('admin-vault-wrapper');
  if (!isAdmin) {
    if (gate) gate.style.display = 'flex';
    if (wrapper) wrapper.style.display = 'none';
    const rl = document.getElementById('role-badge-locked');
    if (rl) rl.textContent = `Your role: ${ROLE_LABELS[identity.role] || identity.role}`;
    return;
  }
  if (gate) gate.style.display = 'none';
  if (wrapper) wrapper.style.display = 'flex';
  const vt = document.getElementById('vault-org-title');
  if (vt) vt.textContent = identity.org_name ? `${identity.org_name} — Admin Panel` : 'Organization Admin Panel';
  const vs = document.getElementById('vault-org-subtitle');
  if (vs) vs.textContent = `Credential vault for ${identity.domain} domain · Hardware-encrypted · AES-256-GCM`;
  const se = document.getElementById('vault-seats-used');
  if (se) se.textContent = `${identity.seats_used} / ${identity.seats_total}`;
  renderVaultServices(); renderVaultMcp(); renderVaultSeats(); renderVaultDataSources(); renderVaultExtensions();
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

// ── 9. DOMAIN DEFAULT SERVICES ─────────────────────────────
function getDefaultServices(domain) {
  const d = {
    agriculture: [
      { id:'gee', icon:'globe', name:'Google Earth Engine', label:'GEE Production Account', meta:'Service Account JSON', status:'add' },
      { id:'arcgis', icon:'layers', name:'ArcGIS Enterprise', label:'ArcGIS Online Portal', meta:'Client ID + Secret', status:'add' },
      { id:'librae_geoint', icon:'cpu', name:'Librae GeoInt AI Inference', label:'Alibaba Cloud API', meta:'API Key + Endpoint', status:'add' },
    ],
    mining: [
      { id:'gee', icon:'globe', name:'Google Earth Engine', label:'GEE Mining Account', meta:'Service Account JSON', status:'add' },
      { id:'postgresql', icon:'database', name:'PostGIS Database', label:'Internal Geological DB', meta:'Connection String', status:'add' },
      { id:'librae_geoint', icon:'cpu', name:'Librae GeoInt AI Inference', label:'Librae GeoInt AI-72B Endpoint', meta:'API Key + Endpoint', status:'add' },
    ],
    defense: [
      { id:'gee', icon:'globe', name:'Google Earth Engine', label:'Classified SAR Access', meta:'Service Account JSON', status:'add' },
      { id:'custom', icon:'shield', name:'Internal Secure API', label:'Mission Data Gateway', meta:'Bearer Token + URL', status:'add' },
    ],
  };
  return d[domain] || d.agriculture;
}

// ── 10. RENDER FUNCTIONS ────────────────────────────────────
function renderVaultServices() {
  const vault = loadVault(); const identity = parseIdentityToken();
  const list = document.getElementById('vault-services-list'); if (!list) return;
  const defaults = getDefaultServices(identity.domain);
  const saved = vault.services || [];
  const savedIds = saved.map(s => s.id);
  const merged = [...saved, ...defaults.filter(d => !savedIds.includes(d.id))];
  const countEl = document.getElementById('vault-services-count');
  if (countEl) countEl.textContent = saved.filter(s => s.status === 'connected').length;
  list.innerHTML = merged.map((svc, idx) => `
    <div class="vault-service-row">
      <div class="vault-service-icon"><i data-lucide="${svc.icon||'plug'}"></i></div>
      <div class="vault-service-info">
        <div class="vault-service-name">${svc.name}</div>
        <div class="vault-service-meta">${svc.label||''} ${svc.notes ? '· '+svc.notes : ''}</div>
      </div>
      <span class="vault-service-status ${svc.status==='connected'?'vault-status-connected':svc.status==='warning'?'vault-status-warning':'vault-status-add'}">
        ${svc.status==='connected'?'✓ Connected':svc.status==='warning'?'⚠ Expiring':'+ Configure'}
      </span>
      <div class="vault-service-actions">
        ${svc.status==='connected'?`<button class="btn-vault-action" title="Remove" onclick="removeVaultKey(${idx})" style="color:#e63946;"><i data-lucide="trash-2"></i></button>`:''}
      </div>
    </div>`).join('');
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function renderVaultMcp() {
  const vault = loadVault(); const list = document.getElementById('vault-mcp-list'); if (!list) return;
  const servers = vault.mcp_servers || [];
  if (!servers.length) { list.innerHTML = `<div class="vault-empty-state"><i data-lucide="plug"></i><p>No MCP servers registered yet. Click "Register Server" to add your first integration.</p></div>`; if (typeof lucide !== 'undefined') lucide.createIcons(); return; }
  list.innerHTML = servers.map((srv, idx) => `
    <div class="vault-service-row">
      <div class="vault-service-icon"><i data-lucide="${srv.type==='remote'?'wifi':srv.type==='database'?'database':'terminal'}"></i></div>
      <div class="vault-service-info"><div class="vault-service-name">${srv.name}</div><div class="vault-service-meta">${srv.type} · ${srv.path||''}</div></div>
      <span class="vault-service-status vault-status-connected">✓ Registered</span>
      <div class="vault-service-actions"><button class="btn-vault-action" title="Remove" onclick="removeMcpServer(${idx})" style="color:#e63946;"><i data-lucide="trash-2"></i></button></div>
    </div>`).join('');
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function renderVaultSeats() {
  const vault = loadVault(); const identity = parseIdentityToken();
  const list = document.getElementById('vault-seats-list'); if (!list) return;
  let seats = vault.seats || [];
  if (!seats.length) seats = [{ name:'IT Administrator', role:'org_admin', initials:'IA', email:'admin@org.gov', active:true, modules:['gee','ingest','sim'] }];
  list.innerHTML = seats.map((seat, idx) => `
    <div class="vault-seat-row">
      <div class="vault-seat-avatar">${seat.initials||seat.name.substring(0,2).toUpperCase()}</div>
      <div class="vault-seat-info"><div class="vault-seat-name">${seat.name}</div><div class="vault-seat-meta">${seat.email||''} · ${(seat.modules||[]).join(', ')}</div></div>
      <span class="vault-seat-role ${seat.role==='org_admin'?'seat-role-admin':seat.role==='domain_manager'?'seat-role-manager':'seat-role-user'}">${ROLE_LABELS[seat.role]||seat.role}</span>
      <div class="vault-seat-active"><div class="seat-dot ${seat.active?'seat-dot-active':''}"></div><span>${seat.active?'Active':'Inactive'}</span></div>
      <div class="vault-service-actions"><button class="btn-vault-action" title="Revoke" onclick="revokeSeat(${idx})" style="color:#e63946;"><i data-lucide="user-x"></i></button></div>
    </div>`).join('');
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function renderVaultDataSources() {
  const vault = loadVault(); const list = document.getElementById('vault-datasrc-list'); if (!list) return;
  const sources = vault.data_sources || [];
  if (!sources.length) { list.innerHTML = `<div class="vault-empty-state"><i data-lucide="database"></i><p>No data sources connected yet. Click "Connect Source" to add your first connection.</p></div>`; if (typeof lucide !== 'undefined') lucide.createIcons(); return; }
  const typeIcons = { s3:'cloud', ftp:'server', db:'database', cron:'clock' };
  list.innerHTML = sources.map((src, idx) => `
    <div class="vault-service-row">
      <div class="vault-service-icon"><i data-lucide="${typeIcons[src.type]||'database'}"></i></div>
      <div class="vault-service-info"><div class="vault-service-name">${src.type.toUpperCase()} — ${src.url||''}</div><div class="vault-service-meta">${src.cron?'Syncs: '+src.cron:'On-demand'}</div></div>
      <span class="vault-service-status vault-status-connected">✓ Connected</span>
      <div class="vault-service-actions"><button class="btn-vault-action" title="Disconnect" onclick="removeDataSource(${idx})" style="color:#e63946;"><i data-lucide="trash-2"></i></button></div>
    </div>`).join('');
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

// ── 11. EXTENSIONS SYSTEM ──────────────────────────────────
const EXTENSIONS_STORAGE_KEY = 'lenuda_extensions_vault';

function loadExtensions() {
  try { const r = localStorage.getItem(EXTENSIONS_STORAGE_KEY); return r ? JSON.parse(r) : []; }
  catch(e) { return []; }
}

function saveExtensions(exts) {
  localStorage.setItem(EXTENSIONS_STORAGE_KEY, JSON.stringify(exts));
}

function renderVaultExtensions() {
  const list = document.getElementById('vault-ext-list'); if (!list) return;
  const exts = loadExtensions();
  if (!exts.length) {
    list.innerHTML = `<div class="vault-empty-state"><i data-lucide="zap"></i><p>No custom extensions yet. Click "Add Extension" to create your first sub-department or specialized AI agent.</p></div>`;
    if (typeof lucide !== 'undefined') lucide.createIcons();
    return;
  }
  const typeLabels = { subagent: 'Sub-Agent', simulation: 'Simulation Model', analysis: 'Analysis Pipeline', custom: 'Custom Workflow' };
  list.innerHTML = exts.map((ext, idx) => `
    <div class="vault-ext-card">
      <div class="vault-ext-card-icon"><i data-lucide="${ext.icon||'zap'}"></i></div>
      <div class="vault-ext-card-info">
        <div class="vault-ext-card-name">⚡ ${ext.name}</div>
        <div class="vault-ext-card-meta">${typeLabels[ext.type]||ext.type} &bull; ${ext.description||''}</div>
        <div class="vault-ext-card-tools">${(ext.tools_enabled||[]).map(t => `<span class="ext-tool-chip">${t}</span>`).join('')}</div>
      </div>
      <div class="vault-ext-card-actions">
        <button class="btn-vault-action" title="Remove" onclick="removeExtension(${idx})" style="color:#e63946;"><i data-lucide="trash-2"></i></button>
      </div>
    </div>`).join('');
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

window.openAddExtensionModal = function() {
  const m = document.getElementById('vault-add-extension-modal');
  if (m) m.style.display = 'flex';
  if (typeof lucide !== 'undefined') lucide.createIcons();
};

window.saveExtension = function() {
  const name = document.getElementById('ext-name')?.value.trim();
  const desc = document.getElementById('ext-desc')?.value.trim();
  const type = document.getElementById('ext-type')?.value;
  const icon = document.getElementById('ext-icon')?.value;
  const prompt = document.getElementById('ext-prompt')?.value.trim();
  if (!name) { alert('Please enter an extension name.'); return; }
  const tools = [];
  if (document.getElementById('ext-tool-gee')?.checked) tools.push('gee');
  if (document.getElementById('ext-tool-ingest')?.checked) tools.push('ingest');
  if (document.getElementById('ext-tool-sim')?.checked) tools.push('sim');
  if (document.getElementById('ext-tool-custom_llm')?.checked) tools.push('custom_llm');
  const identity = parseIdentityToken();
  const ext = {
    id: 'ext_' + Date.now(),
    name, description: desc, icon: icon||'zap', domain: identity.domain||'agriculture',
    type: type||'subagent', prompt_system: prompt,
    tools_enabled: tools, created_at: new Date().toISOString()
  };
  const exts = loadExtensions();
  exts.push(ext);
  saveExtensions(exts);
  closeVaultModal('vault-add-extension-modal');
  renderVaultExtensions();
  renderDomainExtensions();
  showVaultToast(`⚡ Extension "${name}" created and activated.`);
  // Reset form
  ['ext-name','ext-desc','ext-prompt'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
  ['ext-tool-gee','ext-tool-ingest'].forEach(id => { const el=document.getElementById(id); if(el) el.checked=true; });
  ['ext-tool-sim','ext-tool-custom_llm'].forEach(id => { const el=document.getElementById(id); if(el) el.checked=false; });
};

window.removeExtension = function(idx) {
  if (!confirm('Remove this custom extension from the sidebar?')) return;
  const exts = loadExtensions();
  const removed = exts.splice(idx, 1);
  saveExtensions(exts);
  renderVaultExtensions();
  renderDomainExtensions();
  if (removed[0]) showVaultToast(`Extension "${removed[0].name}" removed.`);
};

// Renders custom extension buttons in the left sidebar domain nav
function renderDomainExtensions() {
  const nav = document.getElementById('domain-list'); if (!nav) return;
  // Remove any existing extension buttons
  nav.querySelectorAll('.extension-btn').forEach(b => b.remove());
  const exts = loadExtensions();
  if (!exts.length) return;
  const identity = parseIdentityToken();
  const isAdmin = (identity.role === 'org_admin' || identity.role === 'super_admin');
  const currentDomain = identity.domain || document.body.dataset.theme || 'agriculture';
  // Filter: admins see all, others see only extensions matching their domain
  const visible = exts.filter(ext => isAdmin || ext.domain === currentDomain);
  if (!visible.length) return;
  // Separator
  const sep = document.createElement('div');
  sep.className = 'ext-sidebar-separator';
  sep.innerHTML = `<span>CUSTOM EXTENSIONS</span>`;
  nav.appendChild(sep);
  visible.forEach(ext => {
    const btn = document.createElement('button');
    btn.className = 'domain-item extension-btn';
    btn.title = ext.description || ext.name;
    btn.dataset.extId = ext.id;
    btn.innerHTML = `
      <span class="domain-item-label">
        <i data-lucide="${ext.icon||'zap'}" style="width:16px;height:16px;margin-right:10px;"></i>
        ⚡ ${ext.name}
      </span>
      <span class="ext-type-badge">${ext.type === 'subagent' ? 'AGENT' : ext.type === 'simulation' ? 'SIM' : ext.type === 'analysis' ? 'PIPE' : 'FLOW'}</span>`;
    btn.onclick = () => activateExtension(ext);
    nav.appendChild(btn);
  });
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function activateExtension(ext) {
  // Highlight the extension button
  document.querySelectorAll('.extension-btn').forEach(b => b.classList.remove('active'));
  const btn = document.querySelector(`.extension-btn[data-ext-id="${ext.id}"]`);
  if (btn) btn.classList.add('active');
  // Switch to AI Work Engine and show toast
  if (typeof switchTab === 'function') switchTab('ingest');
  showVaultToast(`⚡ Activating: ${ext.name}`);
  // Inject system prompt context into the UI if possible
  const promptEl = document.getElementById('gee-prompt-input');
  if (promptEl && ext.prompt_system) {
    promptEl.placeholder = `[${ext.name}] ${ext.prompt_system.substring(0, 80)}...`;
  }
  // Update footer console
  const footer = document.getElementById('system-footer-console');
  if (footer) footer.innerHTML = `<span class="console-message text-glow-dim"><i data-lucide="zap" class="inline-icon"></i> Extension active: <strong>${ext.name}</strong> &mdash; ${ext.description||ext.type}</span>`;
  if (typeof lucide !== 'undefined') lucide.createIcons();
}
window.renderDomainExtensions = renderDomainExtensions;

// ── 12. MODAL HANDLERS ─────────────────────────────────────
window.openAddKeyModal = function() { const m = document.getElementById('vault-add-key-modal'); if (m) { m.style.display='flex'; onVaultServiceTypeChange(); } if (typeof lucide!=='undefined') lucide.createIcons(); };
window.openAddMcpModal = function() { const m = document.getElementById('vault-add-mcp-modal'); if (m) m.style.display='flex'; };
window.openInviteUserModal = function() { const m = document.getElementById('vault-invite-user-modal'); if (m) m.style.display='flex'; };
window.openAddDataSourceModal = function() { const m = document.getElementById('vault-datasrc-modal'); if (m) m.style.display='flex'; };
window.closeVaultModal = function(id) { const m = document.getElementById(id); if (m) m.style.display='none'; };

window.onVaultServiceTypeChange = function() {
  const sel = document.getElementById('vault-service-name-select');
  const flds = document.getElementById('vault-dynamic-fields');
  if (!sel || !flds) return;
  const t = {
    license:    `<label style="margin-top:12px;">Activation Token</label><textarea class="vault-input" id="vault-f1" rows="4" placeholder="Paste your SECURE-TOKEN or JWT license string..." style="resize:vertical;min-height:90px;"></textarea>`,
    gee:        `<label style="margin-top:12px;">Service Account JSON</label><textarea class="vault-input" id="vault-f1" rows="4" placeholder='Paste GEE service account JSON...' style="resize:vertical;min-height:90px;"></textarea>`,
    arcgis:     `<label style="margin-top:12px;">Client ID</label><input type="text" class="vault-input" id="vault-f1" placeholder="ArcGIS Client ID"><label style="margin-top:8px;">Client Secret</label><input type="password" class="vault-input" id="vault-f2" placeholder="ArcGIS Client Secret">`,
    postgresql: `<label style="margin-top:12px;">Connection String</label><input type="text" class="vault-input" id="vault-f1" placeholder="postgresql://user:pass@host:5432/db">`,
    librae_geoint:       `<label style="margin-top:12px;">API Key</label><input type="password" class="vault-input" id="vault-f1" placeholder="sk-..."><label style="margin-top:8px;">Endpoint URL</label><input type="text" class="vault-input" id="vault-f2" placeholder="https://dashscope.aliyuncs.com/api/v1">`,
    librae_report:     `<label style="margin-top:12px;">API Key</label><input type="password" class="vault-input" id="vault-f1" placeholder="AIza...">`,
    stripe:     `<label style="margin-top:12px;">Secret Key</label><input type="password" class="vault-input" id="vault-f1" placeholder="sk_live_...">`,
    unipile:    `<label style="margin-top:12px;">API Key</label><input type="password" class="vault-input" id="vault-f1" placeholder="Unipile API key">`,
    firecrawl:  `<label style="margin-top:12px;">API Key</label><input type="password" class="vault-input" id="vault-f1" placeholder="fc-...">`,
    custom:     `<label style="margin-top:12px;">Endpoint URL</label><input type="text" class="vault-input" id="vault-f1" placeholder="https://api.example.com/v1"><label style="margin-top:8px;">Bearer Token</label><input type="password" class="vault-input" id="vault-f2" placeholder="Bearer sk_...">`,
  };
  flds.innerHTML = t[sel.value] || '';
};

// ── 12. VAULT CRUD ─────────────────────────────────────────
const SERVICE_ICONS  = { license:'shield', gee:'globe', arcgis:'layers', postgresql:'database', librae_geoint:'cpu', librae_report:'sparkles', stripe:'credit-card', unipile:'link', firecrawl:'flame', custom:'plug' };
const SERVICE_NAMES  = { license:'Annual License Token', gee:'Google Earth Engine', arcgis:'ArcGIS Enterprise', postgresql:'PostgreSQL / PostGIS', librae_geoint:'Librae GeoInt AI / Alibaba Cloud', librae_report:'Librae Report Engine', stripe:'Stripe', unipile:'Unipile LinkedIn API', firecrawl:'Firecrawl', custom:'Custom REST API' };

window.saveVaultKey = function() {
  const sel = document.getElementById('vault-service-name-select');
  const lbl = document.getElementById('vault-service-label');
  const nts = document.getElementById('vault-service-notes');
  if (!sel || !lbl?.value.trim()) { alert('Please enter a service label.'); return; }
  
  if (sel.value === 'license') {
    const tokenStr = document.getElementById('vault-f1')?.value.trim();
    if (!tokenStr) { alert('Please enter the activation token.'); return; }
    runQuickCliCommand('activate ' + tokenStr);
    closeVaultModal('vault-add-key-modal');
    return;
  }

  const vault = loadVault();
  vault.services.push({ id:sel.value, icon:SERVICE_ICONS[sel.value]||'plug', name:SERVICE_NAMES[sel.value]||sel.value, label:lbl.value.trim(), notes:nts?.value.trim()||'', status:'connected', saved_at:new Date().toISOString() });
  saveVault(vault); closeVaultModal('vault-add-key-modal'); renderVaultServices();
  showVaultToast(`✓ ${SERVICE_NAMES[sel.value]||sel.value} saved and encrypted.`);
};
window.removeVaultKey = function(idx) { if (!confirm('Remove this credential?')) return; const v=loadVault(); v.services.splice(idx,1); saveVault(v); renderVaultServices(); };
window.saveMcpServer = function() {
  const name=document.getElementById('vault-mcp-name')?.value.trim(); const type=document.getElementById('vault-mcp-type')?.value; const path=document.getElementById('vault-mcp-path')?.value.trim();
  if (!name||!path) { alert('Please fill in name and path/URL.'); return; }
  const v=loadVault(); v.mcp_servers.push({name,type,path,added_at:new Date().toISOString()}); saveVault(v);
  closeVaultModal('vault-add-mcp-modal'); renderVaultMcp(); showVaultToast(`✓ MCP Server "${name}" registered.`);
};
window.removeMcpServer = function(idx) { if (!confirm('Remove this MCP server?')) return; const v=loadVault(); v.mcp_servers.splice(idx,1); saveVault(v); renderVaultMcp(); };
window.inviteVaultUser = function() {
  const name=document.getElementById('vault-invite-name')?.value.trim(); const email=document.getElementById('vault-invite-email')?.value.trim(); const role=document.getElementById('vault-invite-role')?.value;
  if (!name||!email) { alert('Please enter name and email.'); return; }
  const modules=[]; if (document.getElementById('inv-mod-gee')?.checked) modules.push('gee'); if (document.getElementById('inv-mod-ingest')?.checked) modules.push('ingest'); if (document.getElementById('inv-mod-sim')?.checked) modules.push('sim');
  const v=loadVault(); v.seats.push({name,email,role,modules,initials:name.split(' ').map(w=>w[0]).join('').substring(0,2).toUpperCase(),active:false,invited_at:new Date().toISOString()}); saveVault(v);
  closeVaultModal('vault-invite-user-modal'); renderVaultSeats(); showVaultToast(`✓ Invite token sent to ${email}.`);
};
window.revokeSeat = function(idx) { if (!confirm("Revoke this user's seat?")) return; const v=loadVault(); v.seats.splice(idx,1); saveVault(v); renderVaultSeats(); showVaultToast('Seat revoked. Hardware lock released.'); };
window.saveDataSource = function() {
  const type=document.getElementById('vault-datasrc-type')?.value; const url=document.getElementById('vault-datasrc-url')?.value.trim(); const cron=document.getElementById('vault-datasrc-cron')?.value.trim();
  if (!url) { alert('Please enter a connection URL.'); return; }
  const v=loadVault(); v.data_sources.push({type,url,cron,added_at:new Date().toISOString()}); saveVault(v);
  closeVaultModal('vault-datasrc-modal'); renderVaultDataSources(); showVaultToast('✓ Data source connected.');
};
window.removeDataSource = function(idx) { if (!confirm('Disconnect this data source?')) return; const v=loadVault(); v.data_sources.splice(idx,1); saveVault(v); renderVaultDataSources(); };

// ── 13. TOAST NOTIFICATION ─────────────────────────────────
function showVaultToast(msg) {
  let t = document.getElementById('vault-toast');
  if (!t) {
    t = document.createElement('div'); t.id = 'vault-toast';
    t.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;background:rgba(2,195,154,0.15);border:1px solid rgba(2,195,154,0.4);color:#02c39a;padding:10px 18px;border-radius:8px;font-size:12px;font-weight:600;font-family:var(--font-mono);backdrop-filter:blur(10px);transition:opacity 0.3s ease;';
    document.body.appendChild(t);
  }
  t.textContent = msg; t.style.opacity = '1';
  clearTimeout(window._vaultToastTimer);
  window._vaultToastTimer = setTimeout(() => { t.style.opacity = '0'; }, 3200);
}

// ── 14. DEMO ORG IDENTITY SEEDER ────────────────────────────
function seedDemoOrgIdentity() {
  if (localStorage.getItem(LENUDA_ORG_IDENTITY_KEY)) return;
  if (licenseConfig.tier !== 'UNLICENSED' && licenseConfig.tier !== 'unlicensed') return;
  saveOrgIdentity({
    org_id:'DEMO-ORG-001', org_name:'LENUDA Demo Organization',
    domain: licenseConfig.active_domain || 'agriculture',
    tier:'DEMO', role:'org_admin', seats_total:10, seats_used:3,
    engines:['gee','ingest','sim'], ai_persona:'Agricultural Geospatial Analyst (Demo)',
    sidebar_title:'LENUDA Demo Platform',
  });
}

// ── 15. BOOT ────────────────────────────────────────────────
setTimeout(() => { seedDemoOrgIdentity(); applyOrgPersonalization(); }, 900);

// Exports
window.applyOrgPersonalization = applyOrgPersonalization;
window.parseIdentityToken      = parseIdentityToken;
window.saveOrgIdentity         = saveOrgIdentity;
window.initAdminVault          = initAdminVault;
window.showVaultToast          = showVaultToast;


// ── LICENSE CHIP UPDATER (replaces credit chip in cahaya.html) ─────────
function updateLicenseChip() {
  const tierEl   = document.getElementById('license-chip-tier');
  const expiryEl = document.getElementById('license-chip-expiry');
  if (!tierEl) return;

  const identity = typeof parseIdentityToken === 'function' ? parseIdentityToken() : {};
  const config   = licenseConfig || {};

  const tier   = identity.tier || config.tier || 'UNLICENSED';
  const expiry = identity.contract_expires_at || config.contract_expires_at || null;

  tierEl.textContent = tier.toUpperCase();

  if (expiry) {
    const d = new Date(expiry);
    const days = Math.ceil((d - Date.now()) / 864e5);
    expiryEl.textContent = days > 0 ? `Expires in ${days}d` : 'EXPIRED';
    if (days <= 30 && days > 0) expiryEl.style.color = '#ffb703';
    if (days <= 0) { expiryEl.style.color = '#e63946'; tierEl.style.color = '#e63946'; }
  } else {
    expiryEl.textContent = tier === 'DEMO' ? '30-day trial' : 'Perpetual';
  }

  // Update module engine badges based on license
  const engines = identity.engines || config.engines || ['gee','ingest','sim'];
  const engineBadgeMap = { 'gee': 'engine-badge-gis', 'ingest': 'engine-badge-ingest', 'sim': 'engine-badge-sim' };
  Object.entries(engineBadgeMap).forEach(([eng, badgeId]) => {
    const el = document.getElementById(badgeId);
    if (!el) return;
    if (engines.includes(eng)) {
      el.textContent = 'ACTIVE'; el.classList.remove('locked');
    } else {
      el.textContent = 'LOCKED'; el.classList.add('locked');
    }
  });
}

// Patch into boot — run after applyOrgPersonalization
const _origApply = window.applyOrgPersonalization;
window.applyOrgPersonalization = function() {
  if (_origApply) _origApply();
  updateLicenseChip();
};
setTimeout(updateLicenseChip, 950);

// ── Online/Offline AI Mode Toggle ──────────────────────────────────────────────
window.IS_CAHAYA_OFFLINE_MODE = true; // default is offline/sovereign

function updateOfflineToggleUI() {
  const btn = document.getElementById('btn-offline-toggle');
  const label = document.getElementById('offline-toggle-label');
  if (!btn) return;
  
  if (window.IS_CAHAYA_OFFLINE_MODE) {
    btn.classList.remove('online');
    btn.title = 'AI is running OFFLINE (Sovereign Local Qwen). Click to go Online.';
    if (label) label.textContent = 'OFFLINE AI';
    const icon = btn.querySelector('i');
    if (icon) {
      icon.setAttribute('data-lucide', 'wifi-off');
      if (window.lucide) window.lucide.createIcons();
    }
  } else {
    btn.classList.add('online');
    btn.title = 'AI is running ONLINE (Cloud Gemini/Qwen). Click to go Offline.';
    if (label) label.textContent = 'ONLINE AI';
    const icon = btn.querySelector('i');
    if (icon) {
      icon.setAttribute('data-lucide', 'wifi');
      if (window.lucide) window.lucide.createIcons();
    }
  }
}

window.toggleOnlineOfflineMode = function() {
  window.IS_CAHAYA_OFFLINE_MODE = !window.IS_CAHAYA_OFFLINE_MODE;
  localStorage.setItem('cahaya_offline_mode', window.IS_CAHAYA_OFFLINE_MODE ? 'true' : 'false');
  updateOfflineToggleUI();
  console.log('[Offline Mode Toggle] AI routing set to:', window.IS_CAHAYA_OFFLINE_MODE ? 'OFFLINE (Local)' : 'ONLINE (Cloud)');
};

// On load, restore setting and apply UI state
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('cahaya_offline_mode');
  if (saved !== null) {
    window.IS_CAHAYA_OFFLINE_MODE = (saved === 'true');
  }
  updateOfflineToggleUI();
});
