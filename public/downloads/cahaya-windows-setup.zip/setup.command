#!/usr/bin/env bash
# =============================================================================
# CAHAYA Sovereign Workspace — macOS Auto-Run Setup Launcher
# =============================================================================
# Double-click to execute the installation sequence.
# =============================================================================

# Change directory to the folder containing this script
cd "$(dirname "$0")"

# Make scripts executable
chmod +x ./install.sh
chmod +x ./installer/install_wizard.sh

# Run the installer script
./install.sh
