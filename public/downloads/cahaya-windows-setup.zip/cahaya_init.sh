#!/bin/bash

# Ensure cahaya_secure.json exists
if [ ! -f "cahaya_secure.json" ]; then
    echo "❌ ERROR: cahaya_secure.json not found! Please run 'python3 lenuda_cli.py --activate <TOKEN>' first."
    exit 1
fi

# Extract CAHAYA_MODEL_TIER using Python to parse JSON
CAHAYA_MODEL_TIER=$(python3 -c "import json; print(json.load(open('cahaya_secure.json')).get('cahaya_model_tier', 'unlicensed').lower())")

if [ "$CAHAYA_MODEL_TIER" = "unlicensed" ] || [ "$CAHAYA_MODEL_TIER" = "none" ]; then
    echo "❌ ERROR: System is unlicensed. Please activate with a valid annual token first using the CLI."
    exit 1
fi

echo "🔍 Reading hardware bound licensing configuration..."
CAHAYA_MODEL_TIER_UPPER=$(echo "$CAHAYA_MODEL_TIER" | tr '[:lower:]' '[:upper:]')
echo "🤖 Cahaya Model Tier: $CAHAYA_MODEL_TIER_UPPER"

if [ "$CAHAYA_MODEL_TIER" = "edge" ]; then
    VLLM_ARGS="--quantization gptq --max-model-len 32768 --tensor-parallel-size 1"
    MODEL_IMAGE="qwen/qwen2.5-7b-instruct-gptq-int4"
elif [ "$CAHAYA_MODEL_TIER" = "standard" ]; then
    VLLM_ARGS="--quantization awq --max-model-len 65536 --tensor-parallel-size 1"
    MODEL_IMAGE="qwen/qwen2.5-32b-instruct-awq"
elif [ "$CAHAYA_MODEL_TIER" = "sovereign" ]; then
    VLLM_ARGS="--max-model-len 131072 --tensor-parallel-size 2"
    MODEL_IMAGE="qwen/qwen2.5-72b-instruct"
else
    echo "❌ ERROR: Unknown model tier: $CAHAYA_MODEL_TIER"
    exit 1
fi

export VLLM_ARGS
export MODEL_IMAGE

echo "⚡ Allocating container compute structures..."
echo "   Model Image: $MODEL_IMAGE"
echo "   vLLM Args:   $VLLM_ARGS"
echo ""
echo "🚀 Starting Cahaya local vLLM container execution..."
echo "Executing mock container startup:"
echo "docker run --gpus all -d -v ~/.cache/huggingface:/root/.cache/huggingface -p 8000:8000 \$MODEL_IMAGE python3 -m vllm.entrypoints.openai.api_server \$VLLM_ARGS"
echo ""
echo "✅ Cahaya container initialized. Terminal data streaming at 30fps simulation frequency."
