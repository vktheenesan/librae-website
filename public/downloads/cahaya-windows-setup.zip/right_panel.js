/**
 * CAHAYA SOVEREIGN — RIGHT PANEL (right_panel.js)
 * Librae AI Labs © 2025
 *
 * Collapsible right sidebar with 4 expandable sections:
 *   📁 Project Files   — files attached to active conversation
 *   📚 AI Library      — company documents always in AI context
 *   🔌 Connections     — GEE, ESRI, custom APIs, MCP, web toggle
 *   ⚙️ Settings        — domain, coord system, AI model, language, theme
 */

(function () {
  'use strict';

  /* ─── STATE ─────────────────────────────────────────────────────────────── */
  let _isOpen = false;
  let _activeSection = null;
  let _webAccessEnabled = JSON.parse(localStorage.getItem('cahaya_web_access') || 'false');
  let _currentConvId = null;
  let _panelEl = null;
  let _toggleEl = null;

  const SETTINGS_KEY = 'cahaya_workspace_settings';
  const defaultSettings = {
    domain: localStorage.getItem('cahaya_domain') || 'agriculture',
    coordSystem: 'WGS84',
    aiModel: 'librae_geoint',
    reportLanguage: 'en',
    exportFormat: 'pdf',
    theme: 'dark',
    unitSystem: 'metric',
  };

  function getSettings() {
    try { return { ...defaultSettings, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }; }
    catch { return { ...defaultSettings }; }
  }
  function saveSettings(s) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); }

  /* ─── CONNECTIONS DATA ───────────────────────────────────────────────────── */
  const BUILT_IN_CONNECTIONS = [
    { id: 'gee',          name: 'Google Earth Engine', icon: '🌍', desc: '30+ satellite constellations, real-time ingestion', category: 'satellite' },
    { id: 'esri',         name: 'ESRI ArcGIS REST',    icon: '🗺️', desc: 'Feature services, map services, geoprocessing',   category: 'gis' },
    { id: 'sentinel_hub', name: 'Sentinel Hub',         icon: '🛰️', desc: 'Copernicus data, custom scripts, EO Browser',    category: 'satellite' },
    { id: 'planet',       name: 'Planet Labs',          icon: '🌐', desc: 'Daily 3m PlanetScope, SkySat tasking',           category: 'satellite' },
    { id: 'openai',       name: 'Librae Strategic Engine',        icon: '🤖', desc: 'Fallback LLM for complex reasoning tasks',       category: 'ai' },
    { id: 'librae_report',       name: 'Librae Report Engine',        icon: '♊', desc: 'Multimodal analysis, long-context documents',    category: 'ai' },
  ];

  function getConnectionStatus(id) {
    const stored = JSON.parse(localStorage.getItem(`cahaya_conn_${id}`) || '{}');
    return stored.connected ? 'connected' : 'disconnected';
  }

  /* ─── PANEL BUILDER ──────────────────────────────────────────────────────── */
  function buildPanel() {
    const panel = document.createElement('div');
    panel.id = 'cahaya-right-panel';
    panel.innerHTML = `
      <div id="crp-inner">

        <!-- PANEL HEADER -->
        <div class="crp-header">
          <span class="crp-header-title">Workspace</span>
          <button class="crp-close" onclick="window.CahayaRightPanel.close()" title="Close panel">✕</button>
        </div>

        <!-- SECTION: PROJECT FILES -->
        <div class="crp-section" id="crps-files">
          <div class="crp-section-head" onclick="window.CahayaRightPanel.toggleSection('files')">
            <span class="crp-sec-icon">📁</span>
            <span class="crp-sec-title">Project Files</span>
            <span class="crp-sec-count" id="crp-files-count">0</span>
            <span class="crp-sec-chevron" id="crp-chev-files">›</span>
          </div>
          <div class="crp-sec-body" id="crp-body-files" style="display:none">
            <div class="crp-dropzone" id="crp-file-drop"
                 ondragover="event.preventDefault()"
                 ondrop="window.CahayaRightPanel.handleFileDrop(event)">
              <span>📂 Drop files here or</span>
              <button onclick="document.getElementById('crp-file-input').click()">Browse</button>
              <input type="file" id="crp-file-input" style="display:none" multiple
                     onchange="window.CahayaRightPanel.handleFileSelect(this.files)">
            </div>
            <div class="crp-file-formats">PDF · DOCX · CSV · GeoTIFF · LAS · SHP · DXF · KMZ</div>
            <div id="crp-file-list" class="crp-file-list">
              <div class="crp-empty-hint">No files attached to this project yet.</div>
            </div>
          </div>
        </div>

        <!-- SECTION: AI LIBRARY -->
        <div class="crp-section" id="crps-library">
          <div class="crp-section-head" onclick="window.CahayaRightPanel.toggleSection('library')">
            <span class="crp-sec-icon">📚</span>
            <span class="crp-sec-title">AI Library</span>
            <span class="crp-sec-badge crp-badge-green">Always-on</span>
            <span class="crp-sec-chevron" id="crp-chev-library">›</span>
          </div>
          <div class="crp-sec-body" id="crp-body-library" style="display:none">
            <div class="crp-lib-hint">
              Documents here are <strong>always injected into AI context</strong>.
              Add your company policies, methodologies, and SOPs.
            </div>
            <div class="crp-dropzone" id="crp-lib-drop"
                 ondragover="event.preventDefault()"
                 ondrop="window.CahayaRightPanel.handleLibraryDrop(event)">
              <span>📄 Drop company docs here or</span>
              <button onclick="document.getElementById('crp-lib-input').click()">Upload</button>
              <input type="file" id="crp-lib-input" style="display:none" multiple accept=".pdf,.docx,.txt"
                     onchange="window.CahayaRightPanel.handleLibraryUpload(this.files)">
            </div>
            <div id="crp-lib-list" class="crp-file-list">
              <div class="crp-empty-hint">No documents in AI Library yet.</div>
            </div>
            <div class="crp-lib-context-size" id="crp-lib-size">
              Context used: <strong>0</strong> / 8,000 tokens
            </div>
          </div>
        </div>

        <!-- SECTION: CONNECTIONS -->
        <div class="crp-section" id="crps-connections">
          <div class="crp-section-head" onclick="window.CahayaRightPanel.toggleSection('connections')">
            <span class="crp-sec-icon">🔌</span>
            <span class="crp-sec-title">Connections</span>
            <span class="crp-sec-count" id="crp-conn-count">0 active</span>
            <span class="crp-sec-chevron" id="crp-chev-connections">›</span>
          </div>
          <div class="crp-sec-body" id="crp-body-connections" style="display:none">
            <!-- Web Access toggle -->
            <div class="crp-web-toggle">
              <div class="crp-web-info">
                <span class="crp-web-icon">🌐</span>
                <div>
                  <div class="crp-web-title">Internet Access</div>
                  <div class="crp-web-sub">AI searches web for latest standards & data</div>
                </div>
              </div>
              <label class="crp-toggle-switch">
                <input type="checkbox" id="crp-web-toggle-cb" ${_webAccessEnabled ? 'checked' : ''}
                       onchange="window.CahayaRightPanel.toggleWebAccess(this.checked)">
                <span class="crp-toggle-slider"></span>
              </label>
            </div>

            <!-- Methodology badge/status -->
            <div class="crp-web-toggle" style="margin-top: 10px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 10px;">
              <div class="crp-web-info">
                <span class="crp-web-icon">📚</span>
                <div>
                  <div class="crp-web-title">Methodology Database</div>
                  <div class="crp-web-sub" id="crp-methodology-badge">847 standard metrics + 0 learned</div>
                </div>
              </div>
            </div>

            <div class="crp-conn-separator">DATA CONNECTIONS</div>
            <div id="crp-conn-list">
              ${BUILT_IN_CONNECTIONS.map(c => renderConnectionRow(c)).join('')}
            </div>

            <div class="crp-conn-separator">MCP SERVERS</div>
            <div id="crp-mcp-list">
              <div class="crp-empty-hint">No MCP servers configured.</div>
            </div>
            <button class="crp-add-btn" onclick="window.CahayaRightPanel.addMCPServer()">
              + Add MCP Server
            </button>

            <div class="crp-conn-separator">CUSTOM API</div>
            <button class="crp-add-btn" onclick="window.CahayaRightPanel.addCustomAPI()">
              + Add Custom REST API
            </button>
          </div>
        </div>

        <!-- SECTION: SETTINGS -->
        <div class="crp-section" id="crps-settings">
          <div class="crp-section-head" onclick="window.CahayaRightPanel.toggleSection('settings')">
            <span class="crp-sec-icon">⚙️</span>
            <span class="crp-sec-title">Settings</span>
            <span class="crp-sec-chevron" id="crp-chev-settings">›</span>
          </div>
          <div class="crp-sec-body" id="crp-body-settings" style="display:none">
            ${renderSettingsBody()}
          </div>
        </div>

        <!-- FOOTER -->
        <div class="crp-footer">
          <div class="crp-footer-domain" id="crp-footer-domain">
            <span class="crp-domain-dot"></span>
            <span id="crp-domain-name">${(localStorage.getItem('cahaya_domain') || 'agriculture').replace(/_/g,' ')}</span>
          </div>
          <button class="crp-reset-btn" onclick="window.CahayaGateway && window.CahayaGateway.reset()" title="Reset activation — return to gateway">
            ↩ Switch Domain
          </button>
        </div>
      </div>
    `;
    return panel;
  }

  function renderConnectionRow(conn) {
    const status = getConnectionStatus(conn.id);
    return `
      <div class="crp-conn-row" id="crp-conn-${conn.id}">
        <span class="crp-conn-icon">${conn.icon}</span>
        <div class="crp-conn-info">
          <div class="crp-conn-name">${conn.name}</div>
          <div class="crp-conn-desc">${conn.desc}</div>
        </div>
        <div class="crp-conn-status ${status === 'connected' ? 'crp-status-ok' : 'crp-status-off'}">
          ${status === 'connected' ? '✅' : '○'}
        </div>
        <button class="crp-conn-btn" onclick="window.CahayaRightPanel.connectService('${conn.id}', '${conn.name}')">
          ${status === 'connected' ? 'Edit' : 'Connect'}
        </button>
      </div>
    `;
  }

  function renderSettingsBody() {
    const s = getSettings();
    return `
      <div class="crp-settings-grid">
        <label class="crp-setting-row">
          <span class="crp-setting-label">Coordinate System</span>
          <select class="crp-setting-select" onchange="window.CahayaRightPanel.updateSetting('coordSystem', this.value)">
            ${['WGS84','UTM','Local Grid','MGRS'].map(v=>`<option ${s.coordSystem===v?'selected':''}>${v}</option>`).join('')}
          </select>
        </label>
        <label class="crp-setting-row">
          <span class="crp-setting-label">AI Model</span>
          <select class="crp-setting-select" onchange="window.CahayaRightPanel.updateSetting('aiModel', this.value)">
            ${[{v:'librae_geoint',l:'Librae GeoInt AI (Local)'},{v:'librae_report',l:'Librae Report Engine 2.0'},{v:'gpt4',l:'Librae Strategic Engine'}].map(m=>`<option value="${m.v}" ${s.aiModel===m.v?'selected':''}>${m.l}</option>`).join('')}
          </select>
        </label>
        <label class="crp-setting-row">
          <span class="crp-setting-label">Report Language</span>
          <select class="crp-setting-select" onchange="window.CahayaRightPanel.updateSetting('reportLanguage', this.value)">
            ${[{v:'en',l:'English'},{v:'bm',l:'Bahasa Malaysia'},{v:'id',l:'Bahasa Indonesia'},{v:'zh',l:'中文'},{v:'ar',l:'العربية'}].map(l=>`<option value="${l.v}" ${s.reportLanguage===l.v?'selected':''}>${l.l}</option>`).join('')}
          </select>
        </label>
        <label class="crp-setting-row">
          <span class="crp-setting-label">Default Export</span>
          <select class="crp-setting-select" onchange="window.CahayaRightPanel.updateSetting('exportFormat', this.value)">
            ${['pdf','docx','geojson','csv','excel'].map(v=>`<option ${s.exportFormat===v?'selected':''}>${v}</option>`).join('')}
          </select>
        </label>
        <label class="crp-setting-row">
          <span class="crp-setting-label">Unit System</span>
          <select class="crp-setting-select" onchange="window.CahayaRightPanel.updateSetting('unitSystem', this.value)">
            ${['metric','imperial'].map(v=>`<option ${s.unitSystem===v?'selected':''}>${v}</option>`).join('')}
          </select>
        </label>
      </div>
      <div class="crp-settings-divider">HARDWARE</div>
      <div class="crp-hw-info" id="crp-hw-info">
        <div class="crp-hw-row"><span>GPU</span><span id="crp-hw-gpu">Detecting…</span></div>
        <div class="crp-hw-row"><span>RAM</span><span id="crp-hw-ram">—</span></div>
        <div class="crp-hw-row"><span>WebGPU</span><span id="crp-hw-webgpu">—</span></div>
        <div class="crp-hw-row"><span>Tier</span><span id="crp-hw-tier">—</span></div>
      </div>
      <div class="crp-settings-divider">LICENCE</div>
      <div class="crp-lic-info">
        <div class="crp-hw-row"><span>Token</span><span id="crp-lic-token">${(localStorage.getItem('cahaya_token') || '—').substring(0,20)}…</span></div>
        <div class="crp-hw-row"><span>Activated</span><span id="crp-lic-date">${localStorage.getItem('cahaya_activated_at') ? new Date(localStorage.getItem('cahaya_activated_at')).toLocaleDateString() : '—'}</span></div>
        <div class="crp-hw-row"><span>Mode</span><span>${localStorage.getItem('cahaya_demo') === 'true' ? '🟡 Demo Mode' : '🟢 Licensed'}</span></div>
      </div>
    `;
  }

  /* ─── STYLES ─────────────────────────────────────────────────────────────── */
  const STYLES = `
    #cahaya-right-panel {
      position: fixed;
      top: 0; right: 0; bottom: 0;
      width: 320px;
      z-index: 8000;
      transform: translateX(100%);
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      pointer-events: none;
    }
    #cahaya-right-panel.crp-open {
      transform: translateX(0);
      pointer-events: all;
    }
    #crp-inner {
      height: 100%;
      background: linear-gradient(180deg, rgba(10,15,28,0.99) 0%, rgba(6,10,20,0.99) 100%);
      border-left: 1px solid rgba(255,255,255,0.07);
      display: flex; flex-direction: column;
      overflow-y: auto;
      font-family: 'Inter', system-ui, sans-serif;
      color: rgba(255,255,255,0.85);
      backdrop-filter: blur(20px);
    }
    #crp-inner::-webkit-scrollbar { width: 4px; }
    #crp-inner::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }

    .crp-header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 18px 16px 14px;
      border-bottom: 1px solid rgba(255,255,255,0.06);
      flex-shrink: 0;
    }
    .crp-header-title { font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: rgba(255,255,255,0.5); }
    .crp-close { background: none; border: none; color: rgba(255,255,255,0.3); cursor: pointer; font-size: 16px; padding: 4px 8px; border-radius: 6px; transition: 0.2s; }
    .crp-close:hover { color: white; background: rgba(255,255,255,0.1); }

    .crp-section { border-bottom: 1px solid rgba(255,255,255,0.05); }
    .crp-section-head {
      display: flex; align-items: center; gap: 10px;
      padding: 14px 16px; cursor: pointer;
      transition: background 0.15s;
      user-select: none;
    }
    .crp-section-head:hover { background: rgba(255,255,255,0.03); }
    .crp-sec-icon { font-size: 16px; }
    .crp-sec-title { font-size: 13px; font-weight: 600; flex: 1; color: rgba(255,255,255,0.8); }
    .crp-sec-count { font-size: 10px; color: rgba(255,255,255,0.3); background: rgba(255,255,255,0.06); padding: 2px 8px; border-radius: 10px; }
    .crp-sec-badge { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; padding: 2px 8px; border-radius: 10px; }
    .crp-badge-green { background: rgba(16,185,129,0.15); color: #6ee7b7; }
    .crp-sec-chevron { font-size: 16px; color: rgba(255,255,255,0.3); transition: transform 0.2s; }
    .crp-sec-chevron.open { transform: rotate(90deg); }

    .crp-sec-body { padding: 0 14px 14px; }

    /* Drop zones */
    .crp-dropzone {
      border: 1px dashed rgba(255,255,255,0.12); border-radius: 10px;
      padding: 14px; text-align: center; font-size: 12px;
      color: rgba(255,255,255,0.4); margin-bottom: 10px;
      display: flex; align-items: center; justify-content: center; gap: 8px;
      transition: 0.2s;
    }
    .crp-dropzone:hover { border-color: rgba(99,102,241,0.4); background: rgba(99,102,241,0.05); }
    .crp-dropzone button { background: rgba(99,102,241,0.15); border: 1px solid rgba(99,102,241,0.3); border-radius: 6px; color: #a5b4fc; padding: 4px 12px; cursor: pointer; font-size: 11px; font-family: inherit; }
    .crp-dropzone button:hover { background: rgba(99,102,241,0.25); }
    .crp-file-formats { font-size: 10px; color: rgba(255,255,255,0.2); text-align: center; margin-bottom: 10px; }

    /* File list */
    .crp-file-list { display: flex; flex-direction: column; gap: 6px; }
    .crp-file-item {
      display: flex; align-items: center; gap: 10px;
      background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06);
      border-radius: 8px; padding: 8px 10px;
    }
    .crp-file-icon { font-size: 18px; flex-shrink: 0; }
    .crp-file-info { flex: 1; min-width: 0; }
    .crp-file-name { font-size: 12px; font-weight: 500; color: rgba(255,255,255,0.8); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .crp-file-size { font-size: 10px; color: rgba(255,255,255,0.3); }
    .crp-file-del { background: none; border: none; color: rgba(255,255,255,0.2); cursor: pointer; font-size: 14px; flex-shrink: 0; transition: 0.2s; }
    .crp-file-del:hover { color: #ef4444; }
    .crp-empty-hint { font-size: 12px; color: rgba(255,255,255,0.25); text-align: center; padding: 12px 0; }

    /* AI Library */
    .crp-lib-hint { font-size: 11px; color: rgba(255,255,255,0.4); line-height: 1.5; margin-bottom: 10px; padding: 8px 10px; background: rgba(16,185,129,0.06); border-radius: 8px; border: 1px solid rgba(16,185,129,0.12); }
    .crp-lib-context-size { font-size: 10px; color: rgba(255,255,255,0.3); text-align: right; margin-top: 8px; }

    /* Connections */
    .crp-web-toggle { display: flex; align-items: center; gap: 12px; padding: 12px; background: rgba(255,255,255,0.03); border-radius: 10px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.06); }
    .crp-web-info { display: flex; align-items: center; gap: 10px; flex: 1; }
    .crp-web-icon { font-size: 20px; }
    .crp-web-title { font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.8); }
    .crp-web-sub { font-size: 10px; color: rgba(255,255,255,0.3); }

    .crp-toggle-switch { position: relative; width: 40px; height: 22px; flex-shrink: 0; }
    .crp-toggle-switch input { opacity: 0; width: 0; height: 0; }
    .crp-toggle-slider { position: absolute; inset: 0; background: rgba(255,255,255,0.1); border-radius: 11px; cursor: pointer; transition: 0.3s; }
    .crp-toggle-slider::before { content: ''; position: absolute; width: 16px; height: 16px; left: 3px; bottom: 3px; background: rgba(255,255,255,0.5); border-radius: 50%; transition: 0.3s; }
    .crp-toggle-switch input:checked + .crp-toggle-slider { background: rgba(99,102,241,0.6); }
    .crp-toggle-switch input:checked + .crp-toggle-slider::before { transform: translateX(18px); background: white; }

    .crp-conn-separator { font-size: 9px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: rgba(255,255,255,0.2); margin: 12px 0 8px; }
    .crp-conn-row { display: flex; align-items: center; gap: 10px; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.04); }
    .crp-conn-row:last-child { border-bottom: none; }
    .crp-conn-icon { font-size: 18px; flex-shrink: 0; }
    .crp-conn-info { flex: 1; min-width: 0; }
    .crp-conn-name { font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.8); }
    .crp-conn-desc { font-size: 10px; color: rgba(255,255,255,0.3); }
    .crp-conn-status { font-size: 14px; flex-shrink: 0; }
    .crp-conn-btn { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: rgba(255,255,255,0.5); padding: 4px 10px; cursor: pointer; font-size: 10px; font-family: inherit; white-space: nowrap; transition: 0.2s; }
    .crp-conn-btn:hover { background: rgba(99,102,241,0.15); border-color: rgba(99,102,241,0.3); color: #a5b4fc; }
    .crp-add-btn { width: 100%; background: rgba(255,255,255,0.04); border: 1px dashed rgba(255,255,255,0.12); border-radius: 8px; color: rgba(255,255,255,0.4); padding: 8px; cursor: pointer; font-size: 12px; font-family: inherit; margin-top: 6px; transition: 0.2s; }
    .crp-add-btn:hover { border-color: rgba(99,102,241,0.4); color: #a5b4fc; background: rgba(99,102,241,0.06); }

    /* Settings */
    .crp-settings-grid { display: flex; flex-direction: column; gap: 2px; }
    .crp-setting-row { display: flex; align-items: center; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.04); cursor: default; }
    .crp-setting-row:last-child { border-bottom: none; }
    .crp-setting-label { font-size: 12px; color: rgba(255,255,255,0.55); }
    .crp-setting-select { background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: rgba(255,255,255,0.8); font-size: 11px; padding: 4px 8px; cursor: pointer; font-family: inherit; }
    .crp-setting-select:focus { outline: none; border-color: #6366f1; }
    .crp-settings-divider { font-size: 9px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: rgba(255,255,255,0.2); margin: 14px 0 8px; }
    .crp-hw-info, .crp-lic-info { background: rgba(255,255,255,0.02); border-radius: 8px; padding: 8px; }
    .crp-hw-row { display: flex; justify-content: space-between; font-size: 11px; padding: 4px 0; color: rgba(255,255,255,0.5); }
    .crp-hw-row span:last-child { color: rgba(255,255,255,0.75); font-weight: 500; font-family: 'JetBrains Mono', monospace; font-size: 10px; }

    /* Footer */
    .crp-footer { margin-top: auto; padding: 14px 16px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; }
    .crp-footer-domain { display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 600; text-transform: capitalize; color: rgba(255,255,255,0.6); }
    .crp-domain-dot { width: 8px; height: 8px; border-radius: 50%; background: #6366f1; box-shadow: 0 0 6px rgba(99,102,241,0.8); animation: crp-pulse 2s infinite; }
    @keyframes crp-pulse { 0%,100%{box-shadow:0 0 6px rgba(99,102,241,0.8)} 50%{box-shadow:0 0 12px rgba(99,102,241,0.4)} }
    .crp-reset-btn { background: none; border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: rgba(255,255,255,0.3); font-size: 10px; padding: 5px 10px; cursor: pointer; font-family: inherit; transition: 0.2s; }
    .crp-reset-btn:hover { border-color: rgba(239,68,68,0.4); color: #fca5a5; }

    /* Backdrop */
    #crp-backdrop {
      display: none; position: fixed; inset: 0; z-index: 7999;
      background: rgba(0,0,0,0.4); backdrop-filter: blur(2px);
    }
    #crp-backdrop.crp-open { display: block; }

    /* Toggle button in workspace header */
    #crp-toggle-btn {
      background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
      border-radius: 8px; color: rgba(255,255,255,0.6); padding: 6px 12px;
      cursor: pointer; font-size: 12px; font-family: inherit;
      display: flex; align-items: center; gap: 6px; transition: 0.2s;
    }
    #crp-toggle-btn:hover, #crp-toggle-btn.active { background: rgba(99,102,241,0.15); border-color: rgba(99,102,241,0.3); color: #a5b4fc; }
  `;

  /* ─── CONNECTION MODAL ───────────────────────────────────────────────────── */
  function showConnectionModal(serviceId, serviceName) {
    const existing = document.getElementById('crp-conn-modal');
    if (existing) existing.remove();
    const stored = JSON.parse(localStorage.getItem(`cahaya_conn_${serviceId}`) || '{}');

    const modal = document.createElement('div');
    modal.id = 'crp-conn-modal';
    modal.style.cssText = 'position:fixed;inset:0;z-index:20000;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.7);backdrop-filter:blur(8px)';
    modal.innerHTML = `
      <div style="background:rgba(10,15,28,0.99);border:1px solid rgba(255,255,255,0.1);border-radius:18px;padding:28px;width:440px;font-family:'Inter',sans-serif;color:rgba(255,255,255,0.9)">
        <div style="font-size:18px;font-weight:700;margin-bottom:6px">${serviceName}</div>
        <div style="font-size:12px;color:rgba(255,255,255,0.4);margin-bottom:20px">Enter your credentials to connect</div>
        <label style="display:block;font-size:11px;color:rgba(255,255,255,0.4);margin-bottom:6px">API KEY / TOKEN</label>
        <input id="crp-modal-key" type="password" value="${stored.apiKey || ''}" placeholder="Paste your API key…"
               style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:10px 14px;color:white;font-family:'JetBrains Mono',monospace;font-size:13px;outline:none;margin-bottom:14px">
        <label style="display:block;font-size:11px;color:rgba(255,255,255,0.4);margin-bottom:6px">ENDPOINT URL (optional)</label>
        <input id="crp-modal-endpoint" type="url" value="${stored.endpoint || ''}" placeholder="https://your-service.com/api"
               style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:10px 14px;color:white;font-family:'Inter',sans-serif;font-size:13px;outline:none;margin-bottom:20px">
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button onclick="document.getElementById('crp-conn-modal').remove()" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:rgba(255,255,255,0.6);padding:10px 18px;cursor:pointer;font-family:inherit">Cancel</button>
          <button onclick="window.CahayaRightPanel._saveConnection('${serviceId}', '${serviceName}')" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;border-radius:10px;color:white;padding:10px 18px;cursor:pointer;font-family:inherit;font-weight:600">Connect</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    setTimeout(() => document.getElementById('crp-modal-key')?.focus(), 100);
  }

  /* ─── FILE HELPERS ───────────────────────────────────────────────────────── */
  function getFileIcon(name) {
    const ext = (name.split('.').pop() || '').toLowerCase();
    return ({pdf:'📄',docx:'📝',doc:'📝',txt:'📃',csv:'📊',xlsx:'📊',geotiff:'🗺️',tiff:'🗺️',las:'⛰️',laz:'⛰️',shp:'📍',kml:'📍',kmz:'📍',dxf:'📐',dwg:'📐',json:'{ }',zip:'🗜️'})[ext] || '📁';
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes/1024).toFixed(1)} KB`;
    return `${(bytes/1048576).toFixed(1)} MB`;
  }

  function refreshFileList() {
    if (!_currentConvId || !window.ConversationManager) return;
    window.ConversationManager.getConversation(_currentConvId).then(conv => {
      if (!conv) return;
      const list = document.getElementById('crp-file-list');
      if (!list) return;
      const files = conv.projectFiles || [];
      document.getElementById('crp-files-count').textContent = files.length;
      if (files.length === 0) {
        list.innerHTML = '<div class="crp-empty-hint">No files attached to this project yet.</div>';
        return;
      }
      list.innerHTML = files.map((f, i) => `
        <div class="crp-file-item">
          <span class="crp-file-icon">${getFileIcon(f.name)}</span>
          <div class="crp-file-info">
            <div class="crp-file-name" title="${f.name}">${f.name}</div>
            <div class="crp-file-size">${formatBytes(f.size)}</div>
          </div>
          <button class="crp-file-del" title="Remove" onclick="window.CahayaRightPanel.removeProjectFile(${i})">✕</button>
        </div>
      `).join('');
    });
  }

  function refreshLibraryList() {
    if (!window.ConversationManager) return;
    window.ConversationManager.getLibraryDocs().then(docs => {
      const list = document.getElementById('crp-lib-list');
      const sizeEl = document.getElementById('crp-lib-size');
      if (!list) return;
      if (!docs || docs.length === 0) {
        list.innerHTML = '<div class="crp-empty-hint">No documents in AI Library yet.</div>';
        if (sizeEl) sizeEl.innerHTML = 'Context used: <strong>0</strong> / 8,000 tokens';
        return;
      }
      const totalChars = docs.reduce((s, d) => s + (d.extractedText || '').length, 0);
      const tokenEst = Math.round(totalChars / 4);
      if (sizeEl) sizeEl.innerHTML = `Context used: <strong>${tokenEst.toLocaleString()}</strong> / 8,000 tokens`;
      list.innerHTML = docs.map(d => `
        <div class="crp-file-item">
          <span class="crp-file-icon">${getFileIcon(d.name)}</span>
          <div class="crp-file-info">
            <div class="crp-file-name" title="${d.name}">${d.name}</div>
            <div class="crp-file-size">${d.extractedText ? d.extractedText.substring(0,60) + '…' : 'Uploaded'}</div>
          </div>
          <button class="crp-file-del" title="Remove from AI Library" onclick="window.CahayaRightPanel.removeLibraryDoc('${d.id}')">✕</button>
        </div>
      `).join('');
    });
  }

  function refreshConnectionCount() {
    const connected = BUILT_IN_CONNECTIONS.filter(c => getConnectionStatus(c.id) === 'connected').length;
    const el = document.getElementById('crp-conn-count');
    if (el) el.textContent = connected > 0 ? `${connected} active` : '0 active';
  }

  function refreshMethodologyBadge() {
    if (!window.ConversationManager) return;
    window.ConversationManager.listLearnedMethodologies().then(items => {
      const el = document.getElementById('crp-methodology-badge');
      if (el) {
        let stdCount = 0;
        if (window.METHODOLOGY_LIBRARY) {
          Object.values(window.METHODOLOGY_LIBRARY).forEach(lib => {
            if (lib.keyIndices) {
              stdCount += lib.keyIndices.filter(k => !k.isLearned).length;
            }
          });
        }
        if (stdCount === 0) stdCount = 847; // Default standard count placeholder
        el.textContent = `${stdCount} standard metrics + ${items.length} learned`;
      }
    });
  }

  async function extractTextFromFile(file) {
    return new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = e => {
        if (file.type === 'text/plain') { resolve(reader.result); return; }
        // For PDF/DOCX: basic text extraction (production would use PDF.js)
        // Return a truncated version of the binary as placeholder text
        resolve(`[${file.name}] — Document uploaded. AI will reference this document in context. Size: ${formatBytes(file.size)}.`);
      };
      reader.readAsText(file);
    });
  }

  function detectHardwareForPanel() {
    const hw = JSON.parse(localStorage.getItem('cahaya_hw_profile') || '{}');
    const gpuEl = document.getElementById('crp-hw-gpu');
    const ramEl = document.getElementById('crp-hw-ram');
    const webgpuEl = document.getElementById('crp-hw-webgpu');
    const tierEl = document.getElementById('crp-hw-tier');
    if (gpuEl) gpuEl.textContent = hw.gpu || 'Unknown';
    if (ramEl) ramEl.textContent = hw.ram_gb ? `${hw.ram_gb} GB` : `${navigator.deviceMemory || '?'} GB`;
    if (webgpuEl) webgpuEl.textContent = hw.webgpu ? '✅ Supported' : '○ Not available';
    if (tierEl) tierEl.textContent = hw.recommended_tier ? hw.recommended_tier.toUpperCase() : '—';
  }

  /* ─── INIT ───────────────────────────────────────────────────────────────── */
  function init() {
    if (!document.getElementById('crp-styles')) {
      const s = document.createElement('style');
      s.id = 'crp-styles';
      s.textContent = STYLES;
      document.head.appendChild(s);
    }

    const backdrop = document.createElement('div');
    backdrop.id = 'crp-backdrop';
    backdrop.onclick = () => window.CahayaRightPanel.close();
    document.body.appendChild(backdrop);

    _panelEl = buildPanel();
    document.body.appendChild(_panelEl);

    // Detect hardware on open
    document.addEventListener('crp-opened', () => {
      setTimeout(detectHardwareForPanel, 200);
      refreshFileList();
      refreshLibraryList();
      refreshConnectionCount();
      refreshMethodologyBadge();
    });

    document.addEventListener('methodology-db-updated', refreshMethodologyBadge);
    document.addEventListener('methodology-learned', refreshMethodologyBadge);
  }

  /* ─── PUBLIC API ─────────────────────────────────────────────────────────── */
  window.CahayaRightPanel = {
    init,

    open() {
      if (!_panelEl) init();
      _panelEl.classList.add('crp-open');
      document.getElementById('crp-backdrop')?.classList.add('crp-open');
      _isOpen = true;
      document.dispatchEvent(new Event('crp-opened'));
      const btn = document.getElementById('crp-toggle-btn');
      if (btn) btn.classList.add('active');
    },

    close() {
      _panelEl?.classList.remove('crp-open');
      document.getElementById('crp-backdrop')?.classList.remove('crp-open');
      _isOpen = false;
      const btn = document.getElementById('crp-toggle-btn');
      if (btn) btn.classList.remove('active');
    },

    toggle() { _isOpen ? this.close() : this.open(); },

    toggleSection(name) {
      const body = document.getElementById(`crp-body-${name}`);
      const chev = document.getElementById(`crp-chev-${name}`);
      if (!body) return;
      const isOpen = body.style.display !== 'none';
      body.style.display = isOpen ? 'none' : 'block';
      if (chev) chev.classList.toggle('open', !isOpen);
    },

    setActiveConversation(convId) {
      _currentConvId = convId;
      refreshFileList();
    },

    toggleWebAccess(enabled) {
      _webAccessEnabled = enabled;
      localStorage.setItem('cahaya_web_access', JSON.stringify(enabled));
      document.dispatchEvent(new CustomEvent('web-access-changed', { detail: { enabled } }));
    },

    isWebAccessEnabled: () => _webAccessEnabled,

    updateSetting(key, value) {
      const s = getSettings();
      s[key] = value;
      saveSettings(s);
      document.dispatchEvent(new CustomEvent('cahaya-setting-changed', { detail: { key, value, settings: s } }));
    },

    getSettings,

    connectService(id, name) { showConnectionModal(id, name); },

    _saveConnection(serviceId, serviceName) {
      const key = document.getElementById('crp-modal-key')?.value?.trim();
      const endpoint = document.getElementById('crp-modal-endpoint')?.value?.trim();
      if (!key) return;
      localStorage.setItem(`cahaya_conn_${serviceId}`, JSON.stringify({ apiKey: key, endpoint, connected: true, connectedAt: new Date().toISOString() }));
      document.getElementById('crp-conn-modal')?.remove();
      // Update row
      const row = document.getElementById(`crp-conn-${serviceId}`);
      if (row) {
        row.querySelector('.crp-conn-status').textContent = '✅';
        row.querySelector('.crp-conn-status').className = 'crp-conn-status crp-status-ok';
        row.querySelector('.crp-conn-btn').textContent = 'Edit';
      }
      refreshConnectionCount();
      // Notify app
      document.dispatchEvent(new CustomEvent('service-connected', { detail: { serviceId, serviceName } }));
    },

    addMCPServer() {
      // Simplified prompt-based MCP add
      const url = prompt('Enter MCP Server URL (e.g. http://localhost:3001):');
      if (!url) return;
      const name = prompt('Name for this MCP server:') || url;
      const mcpList = document.getElementById('crp-mcp-list');
      if (mcpList) {
        const id = `mcp_${Date.now()}`;
        localStorage.setItem(`cahaya_conn_${id}`, JSON.stringify({ apiKey: '', endpoint: url, connected: true }));
        mcpList.innerHTML = `<div class="crp-conn-row"><span class="crp-conn-icon">🔧</span><div class="crp-conn-info"><div class="crp-conn-name">${name}</div><div class="crp-conn-desc">${url}</div></div><span class="crp-conn-status crp-status-ok">✅</span><button class="crp-conn-btn">Edit</button></div>`;
      }
    },

    addCustomAPI() {
      const name = prompt('API Name:');
      if (!name) return;
      showConnectionModal(`custom_${Date.now()}`, name);
    },

    async handleFileDrop(e) {
      e.preventDefault();
      const files = Array.from(e.dataTransfer.files);
      this.handleFileSelect(files);
    },

    async handleFileSelect(files) {
      if (!_currentConvId || !window.ConversationManager) return;
      for (const f of Array.from(files)) {
        const reader = new FileReader();
        reader.onload = async (ev) => {
          await window.ConversationManager.addProjectFile(_currentConvId, { name: f.name, type: f.type, size: f.size, dataUrl: ev.target.result, uploadedAt: new Date().toISOString() });
          refreshFileList();
        };
        reader.readAsDataURL(f);
      }
    },

    async removeProjectFile(index) {
      if (!_currentConvId || !window.ConversationManager) return;
      await window.ConversationManager.removeProjectFile(_currentConvId, index);
      refreshFileList();
    },

    async handleLibraryDrop(e) {
      e.preventDefault();
      this.handleLibraryUpload(Array.from(e.dataTransfer.files));
    },

    async handleLibraryUpload(files) {
      if (!window.ConversationManager) return;
      for (const f of Array.from(files)) {
        const text = await extractTextFromFile(f);
        await window.ConversationManager.addToLibrary({ name: f.name, type: f.type.split('/')[1] || 'unknown', extractedText: text.substring(0, 4000), dataUrl: null });
        refreshLibraryList();
      }
    },

    async removeLibraryDoc(id) {
      if (!window.ConversationManager) return;
      await window.ConversationManager.removeFromLibrary(id);
      refreshLibraryList();
    },

    isOpen: () => _isOpen,
  };

  // Auto-init when DOM is ready
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

  console.log('⚙️ CAHAYA Right Panel loaded.');
})();
