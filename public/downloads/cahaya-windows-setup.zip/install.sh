#!/usr/bin/env bash
# =============================================================================
# CAHAYA Sovereign Workspace — Root Install Entry Point
# Version 3.0.0 | Librae AI Labs Sdn Bhd
# =============================================================================
# This script:
#   1. Launches the install progress server (installer/install_server.py)
#   2. Opens http://127.0.0.1:8765 in the default browser (the installer UI)
#   3. Runs install_wizard.sh in the background, posting progress updates
# The user NEVER sees a terminal — the browser is their installer window.
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALLER_DIR="$SCRIPT_DIR/installer"
LOG_DIR="$HOME/.cahaya"
OS_TYPE="$(uname -s)"

mkdir -p "$LOG_DIR"

echo "[$(date)] CAHAYA install.sh entry point started" | tee -a "$LOG_DIR/install.log"

# ─── Check Python ─────────────────────────────────────────────────────────────
PYTHON_CMD=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null && "$cmd" -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" 2>/dev/null; then
        PYTHON_CMD="$cmd"
        break
    fi
done

if [[ -z "$PYTHON_CMD" ]]; then
    # No Python — fall back to the wizard which handles Python installation
    echo "[$(date)] Python not found — launching wizard directly" | tee -a "$LOG_DIR/install.log"
    chmod +x "$INSTALLER_DIR/install_wizard.sh"
    exec "$INSTALLER_DIR/install_wizard.sh"
fi

# ─── Install FastAPI if needed (silently) ─────────────────────────────────────
"$PYTHON_CMD" -c "import fastapi, uvicorn" 2>/dev/null || \
    "$PYTHON_CMD" -m pip install fastapi uvicorn aiofiles --quiet --disable-pip-version-check 2>/dev/null || true

# ─── Start Install Progress Server ───────────────────────────────────────────
INSTALL_SERVER="$INSTALLER_DIR/install_server.py"
SERVER_PID_FILE="$LOG_DIR/install_server.pid"

if [[ -f "$INSTALL_SERVER" ]]; then
    echo "[$(date)] Starting install progress server on port 8765..." | tee -a "$LOG_DIR/install.log"
    "$PYTHON_CMD" "$INSTALL_SERVER" --port 8765 >> "$LOG_DIR/install_server.log" 2>&1 &
    SERVER_PID=$!
    echo "$SERVER_PID" > "$SERVER_PID_FILE"

    # Wait up to 5s for server to be ready
    for i in {1..10}; do
        if curl -s "http://127.0.0.1:8765/health" &>/dev/null; then
            echo "[$(date)] Install server ready (PID=$SERVER_PID)" | tee -a "$LOG_DIR/install.log"
            break
        fi
        sleep 0.5
    done
fi

# ─── Open Installer UI in Browser ─────────────────────────────────────────────
echo "[$(date)] Opening installer UI in browser..." | tee -a "$LOG_DIR/install.log"

if [[ "$OS_TYPE" == "Darwin" ]]; then
    open "http://127.0.0.1:8765"
else
    xdg-open "http://127.0.0.1:8765" 2>/dev/null || \
    firefox "http://127.0.0.1:8765" 2>/dev/null || \
    chromium-browser "http://127.0.0.1:8765" 2>/dev/null || \
    google-chrome "http://127.0.0.1:8765" 2>/dev/null || true
fi

# ─── Run Installer Wizard in Background ───────────────────────────────────────
WIZARD="$INSTALLER_DIR/install_wizard.sh"

if [[ -f "$WIZARD" ]]; then
    chmod +x "$WIZARD"
    echo "[$(date)] Launching install wizard in background..." | tee -a "$LOG_DIR/install.log"
    # Small delay to allow browser to open first
    sleep 2
    "$WIZARD" >> "$LOG_DIR/install.log" 2>&1 &
    WIZARD_PID=$!
    echo "$WIZARD_PID" > "$LOG_DIR/wizard.pid"
    echo "[$(date)] Install wizard running (PID=$WIZARD_PID)" | tee -a "$LOG_DIR/install.log"
    wait "$WIZARD_PID" 2>/dev/null || true
else
    # Fallback: run legacy install logic directly
    echo "[$(date)] Running legacy install sequence..." | tee -a "$LOG_DIR/install.log"

    # Create venv if needed
    VENV_DIR="$LOG_DIR/venv"
    [[ ! -d "$VENV_DIR" ]] && "$PYTHON_CMD" -m venv "$VENV_DIR"
    source "$VENV_DIR/bin/activate"

    pip install --upgrade pip -q
    if [[ -f "$SCRIPT_DIR/backend/requirements.txt" ]]; then
        pip install -r "$SCRIPT_DIR/backend/requirements.txt" -q
    else
        pip install fastapi uvicorn cryptography PyJWT python-dotenv httpx -q
    fi

    # Keys
    mkdir -p "$SCRIPT_DIR/crypto"
    if [[ ! -f "$SCRIPT_DIR/crypto/private.pem" ]]; then
        "$PYTHON_CMD" "$SCRIPT_DIR/crypto/generate_keypair.py" 2>/dev/null || true
    fi

    # Post completion
    curl -s -X POST "http://127.0.0.1:8765/install-complete" \
        -H "Content-Type: application/json" \
        -d '{"tier":"EDGE","version":"3.0.0"}' 2>/dev/null || true

    # Start CAHAYA
    cd "$SCRIPT_DIR"
    uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload >> "$LOG_DIR/cahaya.log" 2>&1 &
    sleep 3

    if [[ "$OS_TYPE" == "Darwin" ]]; then
        open "http://127.0.0.1:8000"
    else
        xdg-open "http://127.0.0.1:8000" 2>/dev/null || true
    fi
fi

# ─── Cleanup install server after wizard completes ───────────────────────────
if [[ -f "$SERVER_PID_FILE" ]]; then
    SERVER_PID_OLD=$(cat "$SERVER_PID_FILE")
    sleep 35  # Give install server 30s grace period after completion
    kill "$SERVER_PID_OLD" 2>/dev/null || true
    rm -f "$SERVER_PID_FILE"
fi

echo "[$(date)] install.sh complete" | tee -a "$LOG_DIR/install.log"
