# generate_keypair.py
# Cryptographic keypair generator and JWT signer for CAHAYA local licensing

import os
import time
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
import jwt

CRYPTO_DIR = os.path.dirname(os.path.abspath(__file__))
PRIVATE_KEY_PATH = os.path.join(CRYPTO_DIR, "private.pem")
PUBLIC_KEY_PATH = os.path.join(CRYPTO_DIR, "public.pem")

def generate_keys():
    """Generates RSA-2048 keypair and writes them to PEM files."""
    print("Generating RSA-2048 keypair...")
    
    # Generate private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )
    
    # Serialize private key to PEM
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    
    # Serialize public key to PEM
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    # Save private key
    with open(PRIVATE_KEY_PATH, "wb") as f:
        f.write(private_pem)
    print(f"Saved private key to {PRIVATE_KEY_PATH}")
    
    # Save public key
    with open(PUBLIC_KEY_PATH, "wb") as f:
        f.write(public_pem)
    print(f"Saved public key to {PUBLIC_KEY_PATH}")

def sign_license_token(tier: str, vram_profile: str, max_nodes: int, valid_days: int, domain: str, hardware_lock: str = None) -> str:
    """Signs a JWT token with the private key containing license metadata."""
    if not os.path.exists(PRIVATE_KEY_PATH):
        raise FileNotFoundError(f"Private key not found at {PRIVATE_KEY_PATH}. Run generate_keys() first.")
        
    with open(PRIVATE_KEY_PATH, "rb") as f:
        private_key_pem = f.read()
        
    now = int(time.time())
    payload = {
        "iss": "LENUDA_PREMIUM_AUTH",
        "iat": now,
        "exp": now + (valid_days * 24 * 60 * 60),
        "tier": tier,            # FREE, PREMIUM, SOVEREIGN
        "vram_profile": vram_profile, # 8GB, 16GB, 24GB, 48GB, 80GB
        "max_nodes": max_nodes,
        "domain": domain
    }
    if hardware_lock:
        payload["hardware_lock"] = hardware_lock
        
    # Sign using RS256 algorithm
    token = jwt.encode(payload, private_key_pem, algorithm="RS256")
    return token

def verify_license_token(token: str) -> dict:
    """Verifies a license token using the public key."""
    if not os.path.exists(PUBLIC_KEY_PATH):
        raise FileNotFoundError(f"Public key not found at {PUBLIC_KEY_PATH}.")
        
    with open(PUBLIC_KEY_PATH, "rb") as f:
        public_key_pem = f.read()
        
    try:
        payload = jwt.decode(token, public_key_pem, algorithms=["RS256"])
        return {"valid": True, "payload": payload}
    except jwt.ExpiredSignatureError:
        return {"valid": False, "error": "Token expired"}
    except jwt.InvalidTokenError as e:
        return {"valid": False, "error": f"Invalid token: {str(e)}"}

if __name__ == "__main__":
    generate_keys()
    
    # Generate test token
    test_token = sign_license_token(
        tier="SOVEREIGN",
        vram_profile="24GB",
        max_nodes=10,
        valid_days=365,
        domain="agriculture.lenuda.premium"
    )
    print("\nGenerated Test License Token:")
    print(test_token)
    
    # Verify test token
    verification = verify_license_token(test_token)
    print("\nVerified Token Payload:")
    print(verification)
