/**
 * =============================================================================
 * CAHAYA SOVEREIGN DOMAIN GATEWAY — gateway.js
 * =============================================================================
 *
 * Production-quality, self-contained IIFE (Immediately Invoked Function
 * Expression) that renders a full-screen activation gateway for the CAHAYA
 * Sovereign platform. Zero external runtime dependencies; all styling is
 * injected dynamically via <style> tags; all fonts are loaded via an injected
 * Google Fonts <link> tag.
 *
 * Architecture overview
 * ─────────────────────
 *  1. On script execution the IIFE runs immediately.
 *  2. If the user has already activated (localStorage flag), the public
 *     window.CahayaGateway API is exposed and execution returns.
 *  3. Otherwise the full overlay UI is constructed and inserted into the DOM.
 *  4. The user selects a domain card, enters a token, and clicks "Activate".
 *  5. Activation stores keys in localStorage, dispatches a custom event, and
 *     fades out the overlay.
 *  6. window.CahayaGateway always remains available for programmatic control.
 *
 * Token validation flow
 * ──────────────────────
 *  • POST /api/validate_token  →  success  →  full activation
 *  • Network error OR non-ok   →  if token starts with "CAHAYA-" → demo mode
 *                              →  otherwise show inline error
 *
 * @file    gateway.js
 * @version 1.0.0
 * @author  Librae Labs — CAHAYA Platform Team
 * @license Proprietary — All rights reserved
 * =============================================================================
 */

/* ─────────────────────────────────────────────────────────────────────────────
   IIFE ENTRY POINT
   ───────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 1 — CONSTANTS & DOMAIN REGISTRY
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * localStorage key namespace.  All CAHAYA keys share this prefix so that
   * a single reset() call can wipe them cleanly.
   */
  var LS_PREFIX        = 'cahaya_';
  var LS_ACTIVATED     = 'cahaya_activated';
  var LS_DOMAIN        = 'cahaya_domain';
  var LS_TOKEN         = 'cahaya_token';
  var LS_ACTIVATED_AT  = 'cahaya_activated_at';
  var LS_DEMO          = 'cahaya_demo';

  /**
   * Validate token endpoint — expected to exist server-side.
   * If the fetch fails (offline / no server) the code falls back to demo mode
   * for tokens that begin with "CAHAYA-".
   */
  var TOKEN_API_ENDPOINT = '/api/validate_token';

  /**
   * Z-index for the full-screen overlay.  High enough to sit above virtually
   * any application chrome (React portals, modals, etc.).
   */
  var OVERLAY_Z_INDEX = 50000;

  /**
   * The ten sovereign industry domains exposed by the CAHAYA platform.
   * Each object describes the card UI, accent colour, and the tagline shown
   * in small type beneath the domain name.
   *
   * Fields
   * ──────
   *  id       {string}  Machine-readable identifier stored in localStorage.
   *  emoji    {string}  Decorative icon rendered large on the card.
   *  name     {string}  Human-readable domain label (also used in token panel).
   *  tagline  {string}  Comma-separated list of sub-topics shown in 11px type.
   *  accent   {string}  CSS colour string used for hover glow / selected state.
   *  delay    {number}  Animation delay in milliseconds (cardFloat keyframe).
   */
  var DOMAINS = [
    {
      id:      'agriculture-esg',
      emoji:   '🌾',
      name:    'Agriculture / ESG',
      tagline: 'RSPO · EUDR · Carbon Credits · Precision Farming',
      accent:  '#22c55e',
      delay:   0
    },
    {
      id:      'mining-resources',
      emoji:   '⛏️',
      name:    'Mining & Resources',
      tagline: 'JORC · Spectral Geology · Stockpile · Subsidence',
      accent:  '#f59e0b',
      delay:   100
    },
    {
      id:      'urban-planning',
      emoji:   '🏙️',
      name:    'Urban Planning',
      tagline: 'Zoning · Shadow Analysis · Traffic · FAR Compliance',
      accent:  '#60a5fa',
      delay:   200
    },
    {
      id:      'defense-security',
      emoji:   '🛡️',
      name:    'Defense & Security',
      tagline: 'Surveillance · Route Planning · Threat Analysis',
      accent:  '#ef4444',
      delay:   300
    },
    {
      id:      'maritime-coastal',
      emoji:   '🚢',
      name:    'Maritime & Coastal',
      tagline: 'Bathymetry · S-57 · Wave Energy · Port Planning',
      accent:  '#06b6d4',
      delay:   400
    },
    {
      id:      'environmental',
      emoji:   '🌊',
      name:    'Environmental',
      tagline: 'Conservation · Biodiversity · Water Quality · EIA',
      accent:  '#10b981',
      delay:   500
    },
    {
      id:      'energy-renewables',
      emoji:   '⚡',
      name:    'Energy & Renewables',
      tagline: 'Solar GHI · Wind Weibull · LCOE · Grid Siting',
      accent:  '#eab308',
      delay:   600
    },
    {
      id:      'infrastructure',
      emoji:   '🏗️',
      name:    'Infrastructure',
      tagline: 'Roads · Bridges · Pipelines · Corridor Survey',
      accent:  '#8b5cf6',
      delay:   700
    },
    {
      id:      'forestry-carbon',
      emoji:   '🌳',
      name:    'Forestry & Carbon',
      tagline: 'AGB · Verra VCS · LiDAR CHM · Deforestation',
      accent:  '#16a34a',
      delay:   800
    },
    {
      id:      'emergency-response',
      emoji:   '🚨',
      name:    'Emergency Response',
      tagline: 'Flood · Fire · Earthquake · Evacuation Routes',
      accent:  '#f97316',
      delay:   900
    }
  ];

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 2 — RUNTIME STATE
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Tracks which domain card the user has selected.  null means no selection.
   * @type {Object|null}
   */
  var selectedDomain = null;

  /**
   * Reference to the main overlay <div> element, kept for programmatic
   * show/remove operations via the public API.
   * @type {HTMLDivElement|null}
   */
  var overlayEl = null;

  /**
   * Reference to the token <input> element.
   * @type {HTMLInputElement|null}
   */
  var tokenInputEl = null;

  /**
   * Reference to the token panel container div (the panel that slides up
   * after a domain is selected).
   * @type {HTMLDivElement|null}
   */
  var tokenPanelEl = null;

  /**
   * Reference to the "Activate CAHAYA →" button element.
   * @type {HTMLButtonElement|null}
   */
  var activateBtnEl = null;

  /**
   * Reference to the inline error message <div>.
   * @type {HTMLDivElement|null}
   */
  var errorMsgEl = null;

  /**
   * Reference to the token panel label that shows the selected domain name.
   * @type {HTMLSpanElement|null}
   */
  var tokenLabelDomainEl = null;

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 3 — PUBLIC API (window.CahayaGateway)
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * The publicly exposed CahayaGateway object.  Assigned to window so that
   * external scripts (e.g., a React app shell) can trigger the gateway or
   * query activation status without coupling to this file's internals.
   *
   * Methods are defined here with stubs and fully wired up later once
   * the rest of the module has initialised.
   */
  window.CahayaGateway = {

    /**
     * show()
     * ──────
     * Programmatically injects and shows the gateway overlay.  Safe to call
     * even if the overlay is already visible (idempotent — will not create
     * duplicate overlays).
     */
    show: function () {
      if (!overlayEl || !document.body.contains(overlayEl)) {
        buildAndMountOverlay();
      } else {
        // If hidden, make it visible again
        overlayEl.style.opacity = '1';
        overlayEl.style.pointerEvents = 'all';
      }
    },

    /**
     * getActivation()
     * ───────────────
     * Returns the current activation record from localStorage, or null if the
     * user has not yet activated the platform.
     *
     * @returns {{ domain: string, token: string, activatedAt: string, demo: boolean }|null}
     */
    getActivation: function () {
      if (localStorage.getItem(LS_ACTIVATED) !== 'true') {
        return null;
      }
      return {
        domain:      localStorage.getItem(LS_DOMAIN)       || '',
        token:       localStorage.getItem(LS_TOKEN)        || '',
        activatedAt: localStorage.getItem(LS_ACTIVATED_AT) || '',
        demo:        localStorage.getItem(LS_DEMO)         === 'true'
      };
    },

    /**
     * reset()
     * ───────
     * Clears all CAHAYA-namespaced localStorage entries and reloads the page,
     * causing the gateway to re-appear.  Useful for licence rotation or
     * debugging.
     */
    reset: function () {
      // Gather all keys first to avoid mutation-during-iteration issues
      var keysToRemove = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf(LS_PREFIX) === 0) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach(function (k) {
        localStorage.removeItem(k);
      });
  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 3.5 — SERVER COMPLIANCE & LOCKOUT CONTROLLER
     ────────────────────────────────────────────────────────────────────────── */

  function performServerLicenseCheck() {
    fetch('/api/license/status')
      .then(function (res) {
        if (!res.ok) return;
        return res.json();
      })
      .then(function (data) {
        if (!data) return;
        if (data.status !== 'CLEARANCE_GRANTED') {
          enforceLockoutScreen(data.reason || 'Licensing compliance check failed.');
        } else {
          bootstrapWorkspaceSuites(data.licensed_suite, data.permitted_cross_grades);
        }
      })
      .catch(function (err) {
        console.warn('[CahayaGateway] Offline server check failed — running on offline cache:', err);
      });
  }

  function enforceLockoutScreen(reason) {
    var existing = document.getElementById('cahaya-lockout-overlay');
    if (existing) existing.remove();

    var lockout = document.createElement('div');
    lockout.id = 'cahaya-lockout-overlay';
    lockout.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(6,10,22,0.98);backdrop-filter:blur(25px);display:flex;flex-direction:column;align-items:center;justify-content:center;color:white;font-family:Inter,system-ui,sans-serif;padding:30px;text-align:center';
    
    lockout.innerHTML = `
      <div style="background:linear-gradient(135deg,rgba(255,255,255,0.03),rgba(255,255,255,0.01));border:1px solid rgba(239,68,68,0.25);padding:50px;border-radius:24px;max-width:550px;box-shadow:0 30px 80px rgba(0,0,0,0.6)">
        <span style="font-size:60px">🔒</span>
        <h2 style="font-family:Outfit,sans-serif;font-size:24px;margin:20px 0 10px;color:#fca5a5;letter-spacing:1px">CAHAYA SOVEREIGN LOCKOUT</h2>
        <p style="color:rgba(255,255,255,0.7);font-size:14px;line-height:1.6;margin-bottom:24px">${reason}</p>
        <div style="font-size:11px;color:rgba(255,255,255,0.3);margin-bottom:28px">System Footprint Lock & Monotonic Clock Trajectory Asserter Active.</div>
        <button onclick="window.location.reload();" style="background:linear-gradient(90deg,#ef4444,#dc2626);border:none;color:white;padding:12px 28px;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;box-shadow:0 4px 15px rgba(239,68,68,0.3);transition:0.2s" onmouseover="this.style.transform='scale(1.03)'" onmouseout="this.style.transform='scale(1)'">Retry Security Verification Scan</button>
      </div>
    `;
    
    document.body.appendChild(lockout);
  }

  function bootstrapWorkspaceSuites(activeSuite, crossGrades) {
    console.info('[CahayaGateway] Licensing verified. Active industrial vertical: ' + activeSuite);
    window.CAHAYA_LICENSED_SUITE = activeSuite;
    window.CAHAYA_CROSS_GRADES = crossGrades || [activeSuite];
    
    document.dispatchEvent(new CustomEvent('cahaya-license-loaded', {
      detail: { activeSuite: activeSuite, crossGrades: crossGrades }
    }));
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 4 — EARLY-EXIT IF ALREADY ACTIVATED
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * If the user already has a valid activation stored in localStorage we do
   * not show the gateway overlay at all.  The public API is already wired to
   * window.CahayaGateway above, so callers can still query activation status.
   */
  if (localStorage.getItem(LS_ACTIVATED) === 'true') {
    // Emit a console hint so developers know the gateway is in activated state
    console.info(
      '[CahayaGateway] Already activated — domain: ' +
      localStorage.getItem(LS_DOMAIN) +
      ', demo: ' +
      (localStorage.getItem(LS_DEMO) === 'true')
    );
    performServerLicenseCheck();
    return; // Exit the IIFE — nothing more to do
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 5 — GOOGLE FONTS INJECTION (OUTFIT)
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Injects the Google Fonts preconnect + stylesheet link tags for the
   * "Outfit" typeface if they have not already been added to the page.
   * We check for the presence of a link tag pointing to fonts.googleapis.com
   * with "Outfit" in the href to avoid duplication.
   */
  function injectGoogleFonts() {
    // Check whether Outfit is already loaded
    var existingLinks = document.querySelectorAll('link[rel="stylesheet"]');
    for (var i = 0; i < existingLinks.length; i++) {
      if (existingLinks[i].href && existingLinks[i].href.indexOf('Outfit') !== -1) {
        return; // Already present — skip injection
      }
    }

    // Preconnect hints for faster font loading
    var preconnect1 = document.createElement('link');
    preconnect1.rel  = 'preconnect';
    preconnect1.href = 'https://fonts.googleapis.com';

    var preconnect2 = document.createElement('link');
    preconnect2.rel         = 'preconnect';
    preconnect2.href        = 'https://fonts.gstatic.com';
    preconnect2.crossOrigin = 'anonymous';

    // The Outfit font stylesheet
    var fontLink = document.createElement('link');
    fontLink.rel  = 'stylesheet';
    fontLink.href = 'https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap';

    // Prepend to <head> so it loads as early as possible
    var head = document.head || document.documentElement;
    head.insertBefore(preconnect1, head.firstChild);
    head.insertBefore(preconnect2, preconnect1.nextSibling);
    head.insertBefore(fontLink,    preconnect2.nextSibling);
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 6 — CSS INJECTION
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Builds and injects all CSS required by the gateway into a single <style>
   * element.  We use a single injection so the browser needs only one style
   * recalculation pass, and the tag can be easily removed on teardown.
   *
   * Keyframe catalogue
   * ──────────────────
   *  @keyframes cahayaStarFloat    — individual star particle upward drift
   *  @keyframes cahayaStarTwinkle  — opacity pulse to simulate twinkling
   *  @keyframes cahayaCardFloat    — subtle vertical bob on domain cards
   *  @keyframes cahayaFadeIn       — opacity 0→1 used for overlay entrance
   *  @keyframes cahayaSlideUp      — translateY used for token panel reveal
   *  @keyframes cahayaSpinner      — rotate for the loading spinner on button
   *  @keyframes cahayaLogoGlow     — text-shadow pulse on the logo wordmark
   *
   * @returns {HTMLStyleElement}  The injected <style> element.
   */
  function injectStyles() {
    var styleId = 'cahaya-gateway-styles';
    var existing = document.getElementById(styleId);
    if (existing) {
      return existing; // Idempotent
    }

    var css = [
      /* ── Reset / base for gateway elements ──────────────────────────────── */
      '#cahaya-gateway-overlay *,',
      '#cahaya-gateway-overlay *::before,',
      '#cahaya-gateway-overlay *::after {',
      '  box-sizing: border-box;',
      '  margin: 0;',
      '  padding: 0;',
      '}',

      /* ── Overlay container ───────────────────────────────────────────────── */
      '#cahaya-gateway-overlay {',
      '  position: fixed;',
      '  inset: 0;',                    /* shorthand for top/right/bottom/left: 0 */
      '  z-index: ' + OVERLAY_Z_INDEX + ';',
      '  background: radial-gradient(',
      '    ellipse at center,',
      '    rgba(6, 10, 22, 0.99) 0%,',
      '    rgba(2, 4, 12, 1) 100%',
      '  );',
      '  display: flex;',
      '  flex-direction: column;',
      '  align-items: center;',
      '  justify-content: center;',
      '  overflow: hidden;',
      '  font-family: "Outfit", -apple-system, BlinkMacSystemFont, sans-serif;',
      '  animation: cahayaFadeIn 0.6s ease forwards;',
      '}',

      /* ── Star particle base class ────────────────────────────────────────── */
      '.cahaya-star {',
      '  position: absolute;',
      '  background: rgba(255, 255, 255, 0.85);',
      '  border-radius: 50%;',
      '  pointer-events: none;',
      '  animation: cahayaStarFloat var(--star-dur, 8s) linear infinite,',
      '             cahayaStarTwinkle var(--twinkle-dur, 4s) ease-in-out infinite;',
      '  animation-delay: var(--star-delay, 0s), var(--twinkle-delay, 0s);',
      '  will-change: transform, opacity;',
      '}',

      /* ── Inner scroll container ───────────────────────────────────────────── */
      '#cahaya-gateway-inner {',
      '  position: relative;',
      '  z-index: 2;',
      '  display: flex;',
      '  flex-direction: column;',
      '  align-items: center;',
      '  width: 100%;',
      '  max-height: 100vh;',
      '  overflow-y: auto;',
      '  padding: 48px 24px 64px;',
      '  scrollbar-width: thin;',
      '  scrollbar-color: rgba(255,255,255,0.1) transparent;',
      '}',
      '#cahaya-gateway-inner::-webkit-scrollbar { width: 4px; }',
      '#cahaya-gateway-inner::-webkit-scrollbar-thumb {',
      '  background: rgba(255,255,255,0.12);',
      '  border-radius: 4px;',
      '}',

      /* ── Logo ────────────────────────────────────────────────────────────── */
      '#cahaya-logo {',
      '  font-family: "Outfit", sans-serif;',
      '  font-size: 32px;',
      '  font-weight: 800;',
      '  letter-spacing: 4px;',
      '  text-transform: uppercase;',
      '  background: linear-gradient(135deg, #ffb703 0%, #f59e0b 100%);',
      '  -webkit-background-clip: text;',
      '  -webkit-text-fill-color: transparent;',
      '  background-clip: text;',
      '  margin-bottom: 12px;',
      '  user-select: none;',
      '  animation: cahayaLogoGlow 3s ease-in-out infinite;',
      '}',

      /* ── Subtitle ────────────────────────────────────────────────────────── */
      '#cahaya-subtitle {',
      '  font-size: 14px;',
      '  color: rgba(255, 255, 255, 0.4);',
      '  letter-spacing: 0.5px;',
      '  margin-bottom: 44px;',
      '  text-align: center;',
      '}',

      /* ── Domain grid ─────────────────────────────────────────────────────── */
      '#cahaya-domain-grid {',
      '  display: grid;',
      '  grid-template-columns: repeat(5, 1fr);',
      '  grid-template-rows: repeat(2, auto);',
      '  gap: 12px;',
      '  width: 100%;',
      '  max-width: 900px;',
      '  margin: 0 auto;',
      '}',

      /* ── Individual domain card ───────────────────────────────────────────── */
      '.cahaya-domain-card {',
      '  background: rgba(255, 255, 255, 0.03);',
      '  border: 1px solid rgba(255, 255, 255, 0.07);',
      '  border-radius: 18px;',
      '  padding: 24px 20px;',
      '  cursor: pointer;',
      '  transition:',
      '    border-color 0.25s ease,',
      '    box-shadow 0.25s ease,',
      '    transform 0.25s ease,',
      '    background 0.25s ease;',
      '  text-align: center;',
      '  animation: cahayaCardFloat 3s ease-in-out infinite;',
      '  animation-delay: var(--card-delay, 0ms);',
      '  will-change: transform;',
      '}',

      /* ── Card emoji ──────────────────────────────────────────────────────── */
      '.cahaya-card-emoji {',
      '  font-size: 48px;',
      '  display: block;',
      '  margin-bottom: 8px;',
      '  line-height: 1;',
      '}',

      /* ── Card domain name ────────────────────────────────────────────────── */
      '.cahaya-card-name {',
      '  font-family: "Outfit", sans-serif;',
      '  font-size: 13px;',
      '  font-weight: 600;',
      '  color: rgba(255, 255, 255, 0.85);',
      '  display: block;',
      '  margin-bottom: 4px;',
      '}',

      /* ── Card tagline ────────────────────────────────────────────────────── */
      '.cahaya-card-tagline {',
      '  font-size: 11px;',
      '  color: rgba(255, 255, 255, 0.35);',
      '  display: block;',
      '  margin-top: 6px;',
      '  line-height: 1.5;',
      '}',

      /* ── Token panel ─────────────────────────────────────────────────────── */
      '#cahaya-token-panel {',
      '  opacity: 0;',
      '  transform: translateY(40px);',
      '  transition: opacity 0.4s ease, transform 0.4s ease;',
      '  pointer-events: none;',
      '  margin-top: 40px;',
      '  width: 100%;',
      '  max-width: 520px;',
      '  display: flex;',
      '  flex-direction: column;',
      '  align-items: center;',
      '  gap: 14px;',
      '}',
      '#cahaya-token-panel.cahaya-panel-visible {',
      '  opacity: 1;',
      '  transform: translateY(0);',
      '  pointer-events: all;',
      '}',

      /* ── Token panel label ───────────────────────────────────────────────── */
      '#cahaya-token-label {',
      '  font-size: 13px;',
      '  font-weight: 500;',
      '  color: rgba(255, 255, 255, 0.55);',
      '  letter-spacing: 0.5px;',
      '  text-align: center;',
      '}',

      /* ── Token input ─────────────────────────────────────────────────────── */
      '#cahaya-token-input {',
      '  font-family: "Courier New", Courier, monospace;',
      '  width: 400px;',
      '  height: 48px;',
      '  padding: 12px 20px;',
      '  font-size: 16px;',
      '  background: rgba(255, 255, 255, 0.05);',
      '  border: 1px solid rgba(255, 255, 255, 0.15);',
      '  border-radius: 12px;',
      '  color: #ffffff;',
      '  outline: none;',
      '  transition: border-color 0.2s ease, box-shadow 0.2s ease;',
      '  letter-spacing: 1px;',
      '}',
      '#cahaya-token-input::placeholder {',
      '  color: rgba(255, 255, 255, 0.2);',
      '  letter-spacing: 0;',
      '}',
      '#cahaya-token-input:focus {',
      '  border-color: rgba(99, 102, 241, 0.6);',
      '  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.12);',
      '}',

      /* ── Activate button ─────────────────────────────────────────────────── */
      '#cahaya-activate-btn {',
      '  font-family: "Outfit", sans-serif;',
      '  font-size: 15px;',
      '  font-weight: 600;',
      '  color: #ffffff;',
      '  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);',
      '  border: none;',
      '  border-radius: 12px;',
      '  padding: 14px 40px;',
      '  cursor: pointer;',
      '  transition: opacity 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease;',
      '  letter-spacing: 0.3px;',
      '  position: relative;',
      '  overflow: hidden;',
      '}',
      '#cahaya-activate-btn:hover:not(:disabled) {',
      '  opacity: 0.9;',
      '  transform: translateY(-1px);',
      '  box-shadow: 0 8px 24px rgba(99, 102, 241, 0.4);',
      '}',
      '#cahaya-activate-btn:active:not(:disabled) {',
      '  transform: translateY(0);',
      '}',
      '#cahaya-activate-btn:disabled {',
      '  opacity: 0.6;',
      '  cursor: not-allowed;',
      '}',

      /* ── Loading spinner inside button ───────────────────────────────────── */
      '#cahaya-btn-spinner {',
      '  display: none;',
      '  width: 16px;',
      '  height: 16px;',
      '  border: 2px solid rgba(255, 255, 255, 0.3);',
      '  border-top-color: #ffffff;',
      '  border-radius: 50%;',
      '  animation: cahayaSpinner 0.8s linear infinite;',
      '  margin-right: 8px;',
      '  vertical-align: middle;',
      '}',
      '#cahaya-activate-btn.cahaya-loading #cahaya-btn-spinner {',
      '  display: inline-block;',
      '}',
      '#cahaya-activate-btn.cahaya-loading #cahaya-btn-label {',
      '  opacity: 0.7;',
      '}',

      /* ── Subtext & link ──────────────────────────────────────────────────── */
      '#cahaya-subtext {',
      '  font-size: 11px;',
      '  color: rgba(255, 255, 255, 0.3);',
      '  text-align: center;',
      '  line-height: 1.6;',
      '  max-width: 380px;',
      '}',
      '#cahaya-token-link {',
      '  font-size: 11px;',
      '  color: #6366f1;',
      '  text-decoration: none;',
      '  transition: color 0.2s ease;',
      '}',
      '#cahaya-token-link:hover { color: #818cf8; text-decoration: underline; }',

      /* ── Inline error message ─────────────────────────────────────────────── */
      '#cahaya-error-msg {',
      '  display: none;',
      '  font-size: 12px;',
      '  color: #f87171;',
      '  background: rgba(248, 113, 113, 0.08);',
      '  border: 1px solid rgba(248, 113, 113, 0.2);',
      '  border-radius: 8px;',
      '  padding: 10px 16px;',
      '  text-align: center;',
      '  max-width: 400px;',
      '  width: 100%;',
      '}',
      '#cahaya-error-msg.cahaya-error-visible {',
      '  display: block;',
      '}',

      /* ── Demo mode badge ─────────────────────────────────────────────────── */
      '#cahaya-demo-badge {',
      '  display: none;',
      '  font-size: 10px;',
      '  font-weight: 700;',
      '  letter-spacing: 1.5px;',
      '  text-transform: uppercase;',
      '  color: #fbbf24;',
      '  background: rgba(251, 191, 36, 0.1);',
      '  border: 1px solid rgba(251, 191, 36, 0.25);',
      '  border-radius: 6px;',
      '  padding: 4px 12px;',
      '}',

      /* ── Keyframe: overlay fade-in ───────────────────────────────────────── */
      '@keyframes cahayaFadeIn {',
      '  from { opacity: 0; }',
      '  to   { opacity: 1; }',
      '}',

      /* ── Keyframe: star floating upward ──────────────────────────────────── */
      '@keyframes cahayaStarFloat {',
      '  0%   { transform: translateY(100vh) translateX(0); opacity: 0; }',
      '  10%  { opacity: 1; }',
      '  90%  { opacity: 0.7; }',
      '  100% { transform: translateY(-20px) translateX(var(--star-drift, 0px)); opacity: 0; }',
      '}',

      /* ── Keyframe: star twinkling ─────────────────────────────────────────── */
      '@keyframes cahayaStarTwinkle {',
      '  0%,  100% { opacity: 0.9; }',
      '  50%        { opacity: 0.2; }',
      '}',

      /* ── Keyframe: card float bob ────────────────────────────────────────── */
      '@keyframes cahayaCardFloat {',
      '  0%   { transform: translateY(0px); }',
      '  50%  { transform: translateY(-8px); }',
      '  100% { transform: translateY(0px); }',
      '}',

      /* ── Keyframe: button loading spinner ────────────────────────────────── */
      '@keyframes cahayaSpinner {',
      '  to { transform: rotate(360deg); }',
      '}',

      /* ── Keyframe: logo glow pulse ───────────────────────────────────────── */
      '@keyframes cahayaLogoGlow {',
      '  0%,  100% { filter: brightness(1) drop-shadow(0 0 8px rgba(255, 183, 3, 0.4)); }',
      '  50%        { filter: brightness(1.15) drop-shadow(0 0 20px rgba(255, 183, 3, 0.8)); }',
      '}',

      /* ── Responsive: collapse to 2-col on narrow screens ────────────────── */
      '@media (max-width: 700px) {',
      '  #cahaya-domain-grid {',
      '    grid-template-columns: repeat(2, 1fr);',
      '    grid-template-rows: repeat(5, auto);',
      '  }',
      '  #cahaya-token-input { width: 90vw; max-width: 400px; }',
      '}',
      '@media (max-width: 960px) and (min-width: 701px) {',
      '  #cahaya-domain-grid { grid-template-columns: repeat(3, 1fr); }',
      '}',
    ].join('\n');

    var styleEl = document.createElement('style');
    styleEl.id        = styleId;
    styleEl.type      = 'text/css';
    styleEl.innerHTML = css;
    (document.head || document.documentElement).appendChild(styleEl);
    return styleEl;
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 7 — STAR PARTICLE SYSTEM
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Generates and appends 80 star particle <div> elements into the overlay.
   * Each star is assigned randomised properties via CSS custom properties
   * (--star-dur, --star-delay, --star-drift, --twinkle-dur, --twinkle-delay)
   * so that all animation variation is handled in CSS without any JS RAF loop.
   *
   * Size distribution
   * ─────────────────
   *  70% of stars are 1px (faint, distant)
   *  20% of stars are 2px (medium brightness)
   *  10% of stars are 3px (bright, foreground)
   *
   * @param {HTMLElement} container  The overlay element to append stars into.
   */
  function buildStarParticles(container) {
    var STAR_COUNT    = 80;
    var starFragment  = document.createDocumentFragment();

    for (var i = 0; i < STAR_COUNT; i++) {
      var star = document.createElement('div');
      star.className = 'cahaya-star';

      /* ── Randomised star size (1–3px) with weighted distribution ── */
      var rand = Math.random();
      var size;
      if (rand < 0.70)      { size = 1; }   // 70% — tiny, distant
      else if (rand < 0.90) { size = 2; }   // 20% — medium
      else                  { size = 3; }   //  10% — bright

      /* ── Horizontal starting position (left %) ── */
      var leftPct = (Math.random() * 100).toFixed(2);

      /* ── Vertical starting position — stars begin below the fold,
             so we scatter the initial Y to avoid a "wave" appearance ── */
      var startY = (Math.random() * 100 + 100); // 100vh – 200vh below top

      /* ── Float duration (6s – 14s) — varied for depth effect ── */
      var dur = (6 + Math.random() * 8).toFixed(2);

      /* ── Float animation delay (-dur → 0s) — negative delay makes stars
             appear to be mid-flight from the very first frame ── */
      var delay = -(Math.random() * parseFloat(dur)).toFixed(2);

      /* ── Horizontal drift during float (slight random wobble) ── */
      var drift = ((Math.random() - 0.5) * 60).toFixed(1);

      /* ── Twinkle period (2s – 6s) ── */
      var twinkleDur   = (2 + Math.random() * 4).toFixed(2);
      var twinkleDelay = -(Math.random() * parseFloat(twinkleDur)).toFixed(2);

      /* ── Brightness for size-based opacity variation ── */
      var opacity = size === 1 ? (0.4 + Math.random() * 0.4).toFixed(2)
                  : size === 2 ? (0.6 + Math.random() * 0.35).toFixed(2)
                  :              (0.8 + Math.random() * 0.2).toFixed(2);

      /* ── Apply inline styles ── */
      star.style.cssText = [
        'width:'  + size + 'px;',
        'height:' + size + 'px;',
        'left:'   + leftPct + '%;',
        'top:'    + startY  + 'vh;',
        'opacity:' + opacity + ';',
        '--star-dur:'      + dur          + 's;',
        '--star-delay:'    + delay        + 's;',
        '--star-drift:'    + drift        + 'px;',
        '--twinkle-dur:'   + twinkleDur   + 's;',
        '--twinkle-delay:' + twinkleDelay + 's;'
      ].join('');

      starFragment.appendChild(star);
    }

    container.appendChild(starFragment);
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 8 — DOMAIN CARD BUILDER
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Creates a single domain card <div> element with all child nodes,
   * event listeners, and CSS custom properties set.
   *
   * @param  {Object} domain  A domain object from the DOMAINS registry.
   * @returns {HTMLDivElement}
   */
  function buildDomainCard(domain) {
    var card = document.createElement('div');
    card.className               = 'cahaya-domain-card';
    card.setAttribute('role',      'button');
    card.setAttribute('tabindex',  '0');
    card.setAttribute('aria-label','Select domain: ' + domain.name);
    card.style.setProperty('--card-delay', domain.delay + 'ms');

    /* ── Emoji ── */
    var emojiEl = document.createElement('span');
    emojiEl.className   = 'cahaya-card-emoji';
    emojiEl.textContent = domain.emoji;
    emojiEl.setAttribute('aria-hidden', 'true');

    /* ── Domain name ── */
    var nameEl = document.createElement('span');
    nameEl.className   = 'cahaya-card-name';
    nameEl.textContent = domain.name;

    /* ── Tagline ── */
    var taglineEl = document.createElement('span');
    taglineEl.className   = 'cahaya-card-tagline';
    taglineEl.textContent = domain.tagline;

    card.appendChild(emojiEl);
    card.appendChild(nameEl);
    card.appendChild(taglineEl);

    /* ── Hover effects (JS-driven for per-domain accent colours) ── */
    card.addEventListener('mouseenter', function () {
      if (selectedDomain && selectedDomain.id === domain.id) return; // Selected state takes priority
      card.style.borderColor = domain.accent;
      card.style.boxShadow   = '0 0 24px ' + hexToRgba(domain.accent, 0.25) +
                               ', 0 4px 16px ' + hexToRgba(domain.accent, 0.15);
      card.style.transform   = 'scale(1.04)';
      card.style.background  = 'rgba(255, 255, 255, 0.055)';
    });

    card.addEventListener('mouseleave', function () {
      if (selectedDomain && selectedDomain.id === domain.id) return;
      resetCardStyle(card);
    });

    /* ── Click / keyboard selection ── */
    function selectCard() {
      // Deselect previously selected card
      if (selectedDomain) {
        var prevCard = document.querySelector(
          '[data-cahaya-id="' + selectedDomain.id + '"]'
        );
        if (prevCard) resetCardStyle(prevCard);
      }

      selectedDomain = domain;
      card.setAttribute('aria-selected', 'true');

      // Apply selected state styles
      card.style.borderColor = domain.accent;
      card.style.boxShadow   = '0 0 0 2px ' + domain.accent +
                               ', 0 8px 32px ' + hexToRgba(domain.accent, 0.25);
      card.style.transform   = 'scale(1.06)';
      card.style.background  = hexToRgba(domain.accent, 0.06);

      // Update token panel label
      if (tokenLabelDomainEl) {
        tokenLabelDomainEl.textContent = domain.name;
      }

      // Show the token panel
      showTokenPanel();

      // Hide any previous error
      hideError();
    }

    card.addEventListener('click', selectCard);

    // Keyboard accessibility — Enter / Space triggers selection
    card.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        selectCard();
      }
    });

    card.setAttribute('data-cahaya-id', domain.id);
    return card;
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 9 — TOKEN PANEL BUILDER
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Creates the token entry panel <div> with label, input, button, subtext,
   * link, and error message child elements.
   *
   * @returns {HTMLDivElement}
   */
  function buildTokenPanel() {
    var panel = document.createElement('div');
    panel.id = 'cahaya-token-panel';

    /* ── Label ── */
    var label = document.createElement('div');
    label.id          = 'cahaya-token-label';
    label.innerHTML   = 'Access Token for <span id="cahaya-token-label-domain">—</span>';

    /* ── Token input ── */
    var input = document.createElement('input');
    input.id          = 'cahaya-token-input';
    input.type        = 'password';
    input.placeholder = 'CAHAYA-XXXXXX-XXXXXX';
    input.autocomplete = 'off';
    input.spellcheck   = false;
    input.setAttribute('aria-label', 'Access token');

    // Allow pressing Enter in the input to trigger activation
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (activateBtnEl && !activateBtnEl.disabled) {
          activateBtnEl.click();
        }
      }
    });

    /* ── Demo badge ── */
    var demoBadge = document.createElement('div');
    demoBadge.id          = 'cahaya-demo-badge';
    demoBadge.textContent = 'Demo Mode';

    /* ── Activate button ── */
    var btn = document.createElement('button');
    btn.id   = 'cahaya-activate-btn';
    btn.type = 'button';
    btn.setAttribute('aria-live', 'polite');

    var spinner = document.createElement('span');
    spinner.id = 'cahaya-btn-spinner';
    spinner.setAttribute('aria-hidden', 'true');

    var btnLabel = document.createElement('span');
    btnLabel.id          = 'cahaya-btn-label';
    btnLabel.textContent = 'Activate CAHAYA →';

    btn.appendChild(spinner);
    btn.appendChild(btnLabel);

    btn.addEventListener('click', handleActivation);

    /* ── Error message div ── */
    var errorDiv = document.createElement('div');
    errorDiv.id = 'cahaya-error-msg';
    errorDiv.setAttribute('role', 'alert');
    errorDiv.setAttribute('aria-live', 'assertive');

    /* ── Subtext ── */
    var subtext = document.createElement('div');
    subtext.id          = 'cahaya-subtext';
    subtext.textContent = 'Token activates your 1-year local sovereign license. No internet required after activation.';

    /* ── Get-token link ── */
    var link = document.createElement('a');
    link.id        = 'cahaya-token-link';
    link.href      = 'https://librae-labs.com';
    link.target    = '_blank';
    link.rel       = 'noopener noreferrer';
    link.textContent = 'Get a token at librae-labs.com';

    /* ── Assemble ── */
    panel.appendChild(label);
    panel.appendChild(input);
    panel.appendChild(demoBadge);
    panel.appendChild(btn);
    panel.appendChild(errorDiv);
    panel.appendChild(subtext);
    panel.appendChild(link);

    /* ── Store element references ── */
    tokenInputEl         = input;
    activateBtnEl        = btn;
    errorMsgEl           = errorDiv;
    tokenLabelDomainEl   = panel.querySelector('#cahaya-token-label-domain');

    return panel;
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 10 — OVERLAY ASSEMBLY
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Constructs the complete overlay DOM tree and appends it to document.body.
   * This is the main "build" function that orchestrates all sub-builders.
   *
   * DOM structure produced
   * ──────────────────────
   *  #cahaya-gateway-overlay
   *    [star particles × 80]
   *    #cahaya-gateway-inner
   *      #cahaya-logo
   *      #cahaya-subtitle
   *      #cahaya-domain-grid
   *        .cahaya-domain-card × 10
   *      #cahaya-token-panel
   */
  function buildAndMountOverlay() {
    /* ── Ensure styles and fonts are injected first ── */
    injectGoogleFonts();
    injectStyles();

    /* ── Outer overlay ── */
    var overlay = document.createElement('div');
    overlay.id = 'cahaya-gateway-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'CAHAYA Sovereign Domain Gateway');

    /* ── Star particle layer ── */
    buildStarParticles(overlay);

    /* ── Inner scroll container ── */
    var inner = document.createElement('div');
    inner.id = 'cahaya-gateway-inner';

    /* ── Logo ── */
    var logo = document.createElement('div');
    logo.id          = 'cahaya-logo';
    logo.textContent = '✦ CAHAYA SOVEREIGN';
    logo.setAttribute('aria-label', 'CAHAYA SOVEREIGN');

    /* ── Subtitle ── */
    var subtitle = document.createElement('div');
    subtitle.id          = 'cahaya-subtitle';
    subtitle.textContent = 'Select your industry domain to begin';

    /* ── Domain grid ── */
    var grid = document.createElement('div');
    grid.id = 'cahaya-domain-grid';
    grid.setAttribute('role', 'listbox');
    grid.setAttribute('aria-label', 'Industry domain selection');

    DOMAINS.forEach(function (domain) {
      grid.appendChild(buildDomainCard(domain));
    });

    /* ── Token panel ── */
    tokenPanelEl = buildTokenPanel();

    /* ── Assemble inner ── */
    inner.appendChild(logo);
    inner.appendChild(subtitle);
    inner.appendChild(grid);
    inner.appendChild(tokenPanelEl);

    overlay.appendChild(inner);

    /* ── Mount to body ── */
    document.body.appendChild(overlay);
    overlayEl = overlay;

    /* ── Trap focus inside overlay for accessibility ── */
    trapFocus(overlay);

    console.info('[CahayaGateway] Overlay mounted — awaiting domain selection.');
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 11 — TOKEN PANEL SHOW / HIDE
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Reveals the token entry panel with a CSS transition.
   * Also focuses the token input for immediate keyboard entry.
   */
  function showTokenPanel() {
    if (!tokenPanelEl) return;
    tokenPanelEl.classList.add('cahaya-panel-visible');
    // Slight delay to let the transform transition start before focussing
    setTimeout(function () {
      if (tokenInputEl) {
        tokenInputEl.focus();
      }
    }, 150);
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 12 — TOKEN ACTIVATION HANDLER
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Handles the "Activate CAHAYA →" button click.
   *
   * Flow:
   *  1. Validate that a domain has been selected and a token has been entered.
   *  2. Set the button to loading state.
   *  3. POST to /api/validate_token.
   *  4a. On HTTP success (res.ok) — perform full activation.
   *  4b. On network error OR non-ok response:
   *       • If token starts with "CAHAYA-" → demo mode activation.
   *       • Else → show inline error.
   *  5. On activation — store localStorage keys, dispatch custom event,
   *     fade out overlay, remove from DOM.
   */
  function handleActivation() {
    /* ── Pre-flight checks ── */
    if (!selectedDomain) {
      showError('Please select an industry domain first.');
      return;
    }

    var token = tokenInputEl ? tokenInputEl.value.trim() : '';
    if (!token) {
      showError('Please enter your access token.');
      return;
    }

    hideError();
    setButtonLoading(true);

    var domain = selectedDomain;

    /* ── POST to validation endpoint ── */
    fetch(TOKEN_API_ENDPOINT, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ token: token, domain: domain.id })
    })
    .then(function (res) {
      if (res.ok) {
        /* ── Full server-validated activation ── */
        performActivation(domain, token, false);
      } else {
        /* ── Server responded but declined the token ── */
        handleFallback(domain, token);
      }
    })
    .catch(function () {
      /* ── Network error (server unreachable / offline) ── */
      handleFallback(domain, token);
    });
  }

  /**
   * Fallback path: called when the server is unreachable or returns an error.
   * Checks the token prefix to decide between demo mode and hard error.
   *
   * @param {Object} domain  The selected domain object.
   * @param {string} token   The token string entered by the user.
   */
  function handleFallback(domain, token) {
    if (token.indexOf('CAHAYA-') === 0) {
      /* ── Demo mode: server unavailable but token format looks valid ── */
      performActivation(domain, token, true);
    } else {
      setButtonLoading(false);
      showError('Invalid token. Try a CAHAYA-XXXXXX token for demo mode.');
    }
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 13 — ACTIVATION LOGIC
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Performs the full activation sequence:
   *   1. Writes activation data to localStorage.
   *   2. Dispatches the `gateway-activated` custom event on document.
   *   3. Fades out and removes the overlay from the DOM.
   *
   * @param {Object}  domain  The selected domain object.
   * @param {string}  token   The user-entered token string.
   * @param {boolean} isDemo  Whether this is a demo (offline-fallback) activation.
   */
  function performActivation(domain, token, isDemo) {
    var activatedAt = new Date().toISOString();

    /* ── Persist to localStorage ── */
    localStorage.setItem(LS_ACTIVATED,    'true');
    localStorage.setItem(LS_DOMAIN,       domain.id);
    localStorage.setItem(LS_TOKEN,        token);
    localStorage.setItem(LS_ACTIVATED_AT, activatedAt);
    localStorage.setItem(LS_DEMO,         isDemo ? 'true' : 'false');

    /* ── Show demo badge if in demo mode ── */
    if (isDemo) {
      var badge = document.getElementById('cahaya-demo-badge');
      if (badge) badge.style.display = 'inline-block';
    }

    /* ── Dispatch gateway-activated event for the host application ── */
    try {
      document.dispatchEvent(new CustomEvent('gateway-activated', {
        detail:  { domain: domain.id, token: token, demo: isDemo },
        bubbles: true
      }));
    } catch (e) {
      /* CustomEvent may not be available in very old browsers — silent fail */
      console.warn('[CahayaGateway] Could not dispatch CustomEvent:', e);
    }

    console.info(
      '[CahayaGateway] Activated — domain: ' + domain.id +
      ', demo: ' + isDemo +
      ', at: '   + activatedAt
    );

    /* ── Fade out the overlay, then remove from DOM ── */
    if (overlayEl) {
      overlayEl.style.transition = 'opacity 0.6s ease';
      overlayEl.style.opacity    = '0';
      overlayEl.style.pointerEvents = 'none';

      setTimeout(function () {
        if (overlayEl && overlayEl.parentNode) {
          overlayEl.parentNode.removeChild(overlayEl);
          overlayEl = null;
        }
        setButtonLoading(false);
      }, 620); // Slightly longer than the CSS transition to ensure completion
    }
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 14 — UI HELPER FUNCTIONS
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Resets a domain card's inline styles to the default (unselected) state.
   *
   * @param {HTMLElement} card  The card element to reset.
   */
  function resetCardStyle(card) {
    card.style.borderColor = '';
    card.style.boxShadow   = '';
    card.style.transform   = '';
    card.style.background  = '';
    card.removeAttribute('aria-selected');
  }

  /**
   * Sets or unsets the loading state on the activate button.
   * In loading state the spinner is shown and the button is disabled.
   *
   * @param {boolean} loading  True to enter loading state; false to exit.
   */
  function setButtonLoading(loading) {
    if (!activateBtnEl) return;
    if (loading) {
      activateBtnEl.classList.add('cahaya-loading');
      activateBtnEl.disabled = true;
      var lbl = activateBtnEl.querySelector('#cahaya-btn-label');
      if (lbl) lbl.textContent = 'Activating…';
    } else {
      activateBtnEl.classList.remove('cahaya-loading');
      activateBtnEl.disabled = false;
      var lbl2 = activateBtnEl.querySelector('#cahaya-btn-label');
      if (lbl2) lbl2.textContent = 'Activate CAHAYA →';
    }
  }

  /**
   * Displays an inline error message in the token panel.
   *
   * @param {string} message  Human-readable error text.
   */
  function showError(message) {
    if (!errorMsgEl) return;
    errorMsgEl.textContent = message;
    errorMsgEl.classList.add('cahaya-error-visible');
  }

  /**
   * Hides the inline error message.
   */
  function hideError() {
    if (!errorMsgEl) return;
    errorMsgEl.classList.remove('cahaya-error-visible');
    errorMsgEl.textContent = '';
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 15 — ACCESSIBILITY: FOCUS TRAP
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Implements a basic focus trap inside the overlay dialog.
   * When Tab is pressed and focus would leave the overlay, it wraps around
   * to the first focusable element (and vice-versa for Shift+Tab).
   *
   * This is critical for keyboard-only and assistive-technology users who
   * must not be able to interact with background content while the blocking
   * modal is open.
   *
   * @param {HTMLElement} container  The element to trap focus within.
   */
  function trapFocus(container) {
    var FOCUSABLE_SELECTORS = [
      'a[href]',
      'button:not([disabled])',
      'input:not([disabled])',
      'select:not([disabled])',
      'textarea:not([disabled])',
      '[tabindex]:not([tabindex="-1"])'
    ].join(', ');

    container.addEventListener('keydown', function (e) {
      if (e.key !== 'Tab') return;

      var focusable = Array.prototype.slice.call(
        container.querySelectorAll(FOCUSABLE_SELECTORS)
      ).filter(function (el) {
        return el.offsetParent !== null; // only visible elements
      });

      if (focusable.length === 0) return;

      var first = focusable[0];
      var last  = focusable[focusable.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    });
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 16 — UTILITY FUNCTIONS
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Converts a CSS hex colour string to an rgba() string with the specified
   * alpha value.  Handles both 3-digit (#rgb) and 6-digit (#rrggbb) formats.
   *
   * @param  {string} hex    CSS hex colour, e.g. '#22c55e' or '#abc'.
   * @param  {number} alpha  Alpha value between 0 and 1.
   * @returns {string}       rgba() string, e.g. 'rgba(34, 197, 94, 0.25)'.
   */
  function hexToRgba(hex, alpha) {
    // Strip leading '#'
    var clean = hex.replace(/^#/, '');

    // Expand 3-digit shorthand to 6 digits
    if (clean.length === 3) {
      clean = clean[0] + clean[0] +
              clean[1] + clean[1] +
              clean[2] + clean[2];
    }

    var r = parseInt(clean.substring(0, 2), 16);
    var g = parseInt(clean.substring(2, 4), 16);
    var b = parseInt(clean.substring(4, 6), 16);

    // Clamp alpha to valid range
    var a = Math.min(1, Math.max(0, alpha));

    return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + a + ')';
  }

  /* ──────────────────────────────────────────────────────────────────────────
     SECTION 17 — ENTRY POINT: MOUNT ON DOM READY
     ────────────────────────────────────────────────────────────────────────── */

  /**
   * Safely mounts the overlay as soon as the DOM is available.
   * If the document has already loaded we call immediately; otherwise we
   * wait for DOMContentLoaded.
   */
  function init() {
    if (
      document.readyState === 'complete'   ||
      document.readyState === 'interactive'
    ) {
      buildAndMountOverlay();
    } else {
      document.addEventListener('DOMContentLoaded', buildAndMountOverlay);
    }
  }

  init();

  /* ──────────────────────────────────────────────────────────────────────────
     END OF IIFE
     ────────────────────────────────────────────────────────────────────────── */

}());

/*
 * =============================================================================
 * END OF FILE — gateway.js
 * CAHAYA Sovereign Domain Gateway
 * © Librae Labs. All rights reserved.
 * =============================================================================
 */
