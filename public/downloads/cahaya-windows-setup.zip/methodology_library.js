/**
 * CAHAYA SOVEREIGN — INDUSTRY METHODOLOGY LIBRARY
 * Librae AI Labs © 2025
 *
 * This is the authoritative knowledge base for all 10 industry verticals.
 * Every AI-generated report, formula computation, and regulatory claim
 * is sourced from this library. Do not modify without domain expert review.
 *
 * Structure per industry:
 *   - meta: identity, regulatory framework, governing bodies
 *   - fileFormats: accepted input/output formats with notes
 *   - keyIndices: spectral/spatial indices the AI must compute
 *   - formulas: exact mathematical expressions with units and citations
 *   - reportSections: mandatory sections for regulatory acceptance
 *   - outputs: deliverable files per tier
 *   - workflowBenchmark: current industry pain vs CAHAYA improvement
 *   - aiPromptGuidance: how to frame AI queries for this industry
 */

window.METHODOLOGY_LIBRARY = {

  // ─────────────────────────────────────────────────────────────────────────
  // 1. AGRICULTURE / PLANTATION / ESG
  // ─────────────────────────────────────────────────────────────────────────
  agriculture: {
    meta: {
      name: "Agriculture / Plantation / ESG",
      icon: "🌾",
      regulatoryFramework: [
        "RSPO P&C 2018 (Roundtable on Sustainable Palm Oil)",
        "MSPO MS 2530:2022 (Malaysian Sustainable Palm Oil)",
        "ISO 14064-1:2018 (GHG Quantification & Reporting)",
        "ISO 19115:2014 (Geographic Metadata)",
        "VERRA VCS (Voluntary Carbon Standard)",
        "GHG Protocol Corporate Standard",
        "EU EUDR — EU Deforestation Regulation (2025+)",
        "USDA NRCS — FGDC Content Standard"
      ],
      governingBodies: ["RSPO Secretariat", "MSPO Certification Body", "Verra Registry", "ISO TC 211", "FAO Agri-GEOSS"],
      governmentAcceptance: ["RSPO Annual Communication of Progress (ACOP)", "DOA Dept of Agriculture", "ESG independent auditors (KPMG, PWC, Deloitte)", "Carbon credit verification bodies (SCS Global, SGS)"],
      mandatoryDataFormat: "Shapefile (GCS_WGS_1984) — RSPO plantation boundary submission standard"
    },

    fileFormats: {
      input: [
        { ext: "GeoTIFF", purpose: "Satellite imagery, NDVI rasters, DEMs, yield maps", notes: "Primary raster format. Sentinel-2 L2A at 10m/20m." },
        { ext: "Shapefile (.shp)", purpose: "Plantation boundaries, management zones", notes: "RSPO MANDATES this format for polygon submissions. GCS_WGS_1984 only. No overlapping polygons." },
        { ext: "LAS/LAZ", purpose: "Drone LiDAR for tree height, canopy structure", notes: "50–120 pts/m² typical for plantation." },
        { ext: "CSV/XLSX", purpose: "Soil sample results, GPS-tagged lab data", notes: "Must include POINT_X, POINT_Y columns in WGS84." },
        { ext: "Cloud-Optimized GeoTIFF (COG)", purpose: "Large-scale satellite archives", notes: "Preferred for Sentinel-2 and Landsat streaming." }
      ],
      output: [
        { ext: "GeoTIFF", purpose: "Index rasters (NDVI, NDRE, EVI, LAI)", tier: "all" },
        { ext: "GeoPackage (.gpkg)", purpose: "All vector layers in one file", tier: "professional+" },
        { ext: "Shapefile (.shp)", purpose: "RSPO-compliant boundary export", tier: "all" },
        { ext: "PDF/A-3", purpose: "Archival audit-ready report", tier: "all" },
        { ext: "CSV", purpose: "Per-hectare index summary table", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "NDVI",
        name: "Normalized Difference Vegetation Index",
        formula: "(NIR − Red) / (NIR + Red)",
        bands: { sentinel2: { NIR: "B8 (842nm)", Red: "B4 (665nm)" } },
        range: "−1 to +1",
        thresholds: { stressed: "< 0.3", moderate: "0.3–0.6", healthy: "0.6–0.85", saturated: "> 0.85" },
        purpose: "Overall vegetation vigour, chlorophyll proxy",
        standard: "ESA Sentinel-2 standard product"
      },
      {
        id: "NDRE",
        name: "Normalized Difference Red Edge",
        formula: "(NIR − RedEdge) / (NIR + RedEdge)",
        bands: { sentinel2: { NIR: "B8A (865nm)", RedEdge: "B5 (705nm)" } },
        range: "−1 to +1",
        thresholds: { nitrogenDeficient: "< 0.25", optimal: "0.35–0.55" },
        purpose: "Nitrogen/chlorophyll content mapping — more sensitive than NDVI in high biomass",
        standard: "Gitelson et al. 1994, Remote Sensing of Environment"
      },
      {
        id: "EVI",
        name: "Enhanced Vegetation Index",
        formula: "2.5 × (NIR − Red) / (NIR + 6×Red − 7.5×Blue + 1)",
        bands: { sentinel2: { NIR: "B8", Red: "B4", Blue: "B2" } },
        range: "−1 to +1",
        purpose: "Preferred over NDVI for dense tropical canopy — reduces atmospheric and soil noise",
        standard: "Huete et al. 2002, Remote Sensing of Environment"
      },
      {
        id: "SAVI",
        name: "Soil-Adjusted Vegetation Index",
        formula: "((NIR − Red) / (NIR + Red + L)) × (1 + L), L = 0.5",
        purpose: "Young/sparse plantations where open soil is visible",
        standard: "Huete 1988, Soil Science Society of America"
      },
      {
        id: "LAI",
        name: "Leaf Area Index",
        formula: "LAI = −ln(1 − fCover) / k, k≈0.5 for tropical broadleaf",
        units: "m²/m²",
        purpose: "Canopy density — direct input to yield forecasting models",
        standard: "MODIS MOD15A2H product algorithm"
      },
      {
        id: "CarbonStock",
        name: "Above-Ground Carbon Stock",
        formula: "C_stock = AGB × 0.47 (tC/ha), AGB from allometric: AGB = a × DBH^b",
        units: "tCO₂e/ha",
        conversion: "CO₂e = C_stock × (44/12)",
        standard: "IPCC 2006 Guidelines, Table 4.3 — tropical plantation default carbon fraction 0.47"
      },
      {
        id: "NDWI",
        name: "Normalized Difference Water Index",
        formula: "(Green − NIR) / (Green + NIR)",
        bands: { sentinel2: { Green: "B3 (560nm)", NIR: "B8 (842nm)" } },
        purpose: "Soil/plant water content, irrigation stress, drainage assessment",
        standard: "Gao 1996, Remote Sensing of Environment"
      }
    ],

    formulas: [
      {
        id: "carbon_co2e",
        name: "Carbon Credit Volume (VCUs)",
        equation: "VCU = (AGB × 0.47 × 44/12) − Baseline_emissions",
        units: "tCO₂e",
        standard: "VERRA VCS VM0045 §8.2"
      },
      {
        id: "rspo_buffer_check",
        name: "Riparian Buffer Zone Compliance",
        equation: "Buffer_width ≥ 50m (streams >3m wide) or 20m (streams <3m) from centre line",
        standard: "RSPO P&C 2018 Criterion 7.3"
      }
    ],

    reportSections: [
      { order: 1, title: "Executive Summary", required: true, mandatory_content: "Certification status, key indices, overall compliance pass/fail" },
      { order: 2, title: "Site Identification", required: true, mandatory_content: "GPS bounds (WGS84 decimal degrees), CRS declaration, area (ha), permit/title reference, acquisition date", regulatory_ref: "ISO 19115:2014 §6.5.1" },
      { order: 3, title: "Data Sources & Satellite Provenance", required: true, mandatory_content: "Sensor name, orbit/pass ID, acquisition date/time UTC, cloud cover %, processing level (L2A/L1C), GSD, radiometric correction method", regulatory_ref: "ISO 19115:2014 §6.5.2" },
      { order: 4, title: "Vegetation Health Analysis (NDVI/NDRE/EVI)", required: true, mandatory_content: "Classified raster map, area statistics per class (ha), time-series comparison vs. prior period, statistical confidence" },
      { order: 5, title: "Stress Zone Classification", required: true, mandatory_content: "Spatial distribution of stressed areas, root cause analysis, recommended intervention zones" },
      { order: 6, title: "Soil Carbon & Nutrient Status", required: false, mandatory_content: "Georeferenced soil sample results (0–20, 20–40, 40–60cm depths), SOC tCO₂e/ha, Carbon Management Index (CMI)" },
      { order: 7, title: "Water Body & Buffer Zone Compliance", required: true, mandatory_content: "Riparian buffer delineation (50m/20m per RSPO 7.3), encroachment incidents identified (count + area)", regulatory_ref: "RSPO P&C 2018 Criterion 7.3" },
      { order: 8, title: "Land Use Change Analysis", required: true, mandatory_content: "Multi-temporal comparison (T₁ vs T₀), HCV/HCS deforestation check, change detection map", regulatory_ref: "EUDR Art.3; RSPO P&C 7.1" },
      { order: 9, title: "Carbon Stock Estimate", required: false, mandatory_content: "Per-stratum AGB (tC/ha), total CO₂e, uncertainty (±%), carbon credit estimate (VCUs)", regulatory_ref: "ISO 14064-1:2018 §6.3; IPCC 2006 Table 4.3" },
      { order: 10, title: "ESG Compliance Matrix", required: true, mandatory_content: "Table mapping each RSPO/MSPO criterion to evidence status: Compliant / Non-Compliant / Not Applicable" },
      { order: 11, title: "Agronomic Recommendations", required: false, mandatory_content: "Priority zones for fertilisation, irrigation, replanting, pest control" },
      { order: 12, title: "Methodology Appendix", required: true, mandatory_content: "Formula derivations with citations, sensor specifications, accuracy assessment (RMSE, confusion matrix ≥85% OA), coordinate system declaration, software versions used" }
    ],

    workflowBenchmark: {
      currentTime: "2–5 days per report",
      currentSoftware: ["ESRI ArcGIS Pro ($3K+/yr)", "Agisoft Metashape", "Pix4DFields", "Excel"],
      currentSteps: 10,
      cahayaTime: "12–20 minutes",
      cahayaSteps: 3,
      valueSaved: "$800–$2,000 per report in consultant time"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a certified RSPO/MSPO GIS analyst. Analyse the uploaded satellite imagery for the plantation site. Compute NDVI, NDRE, and EVI using Sentinel-2 Band 4, 5, 8, 8A formulas. Classify into 4 stress levels. Check riparian buffer compliance at 50m. Cite RSPO P&C 2018 Criterion 7.3.",
      reportPromptPrefix: "Generate a RSPO-compliant plantation health report. Include a compliance matrix against RSPO P&C 2018 criteria. All carbon estimates must cite IPCC 2006 Table 4.3. State coordinate system in every section header."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 2. MINING / GEOSPATIAL EXPLORATION
  // ─────────────────────────────────────────────────────────────────────────
  mining: {
    meta: {
      name: "Mining / Geospatial Exploration",
      icon: "⛏️",
      regulatoryFramework: [
        "JORC Code 2012 (Australasian Joint Ore Reserves Committee)",
        "NI 43-101 (Canadian National Instrument)",
        "SAMREC Code (South Africa)",
        "ISO 19115:2014 (Geographic Metadata)",
        "MSHA 30 CFR Part 75 (US Mine Safety)",
        "Malaysia JMG — Jabatan Mineral dan Geosains",
        "ASPRS LiDAR Specification (Quality Levels QL0–QL5)",
        "IHO S-44 (where applicable for offshore mining)"
      ],
      governingBodies: ["JORC Committee", "NI 43-101 Qualified Person (QP)", "ASX / TSX / JSE Stock Exchanges", "State Dept of Mines"],
      governmentAcceptance: ["JORC-compliant Technical Report signed by Competent Person", "NI 43-101 Technical Report signed by Qualified Person", "State mining authority annual compliance report"],
      mandatoryDataFormat: "LAS/LAZ point clouds (ASPRS spec), GeoTIFF DEM, Shapefile for boundaries"
    },

    fileFormats: {
      input: [
        { ext: "LAS / LAZ", purpose: "Primary LiDAR point cloud — pit walls, stockpiles, underground tunnels", notes: "ASPRS LAS 1.4 spec. LAZ ~5:1 compression. QL2 minimum (2 pts/m²), corridor surveys 20–180 pts/m²." },
        { ext: "GeoTIFF", purpose: "DEM, DTM, subsidence difference rasters, SAR imagery", notes: "Primary raster output. InSAR: Sentinel-1 5.6cm C-band wavelength." },
        { ext: "Shapefile / .gdb", purpose: "Mine boundaries, monitoring points, haul roads", notes: "File Geodatabase preferred for ESRI enterprise environments." },
        { ext: "DXF / DWG", purpose: "Engineering cross-sections, pit design, blast patterns", notes: "AutoCAD Civil 3D primary engineering platform." },
        { ext: "OMF", purpose: "3D geological block models", notes: "Open Mining Format — emerging standard. Replaces proprietary Surpac/Datamine formats." },
        { ext: "CSV", purpose: "Drill hole collar/assay/interval data, blast hole coordinates", notes: "Must include Easting, Northing, RL (elevation), date." }
      ],
      output: [
        { ext: "LAS", purpose: "Processed classified point cloud deliverable", tier: "professional+" },
        { ext: "GeoTIFF DEM", purpose: "DTM/DSM at 0.1–0.5m resolution", tier: "all" },
        { ext: "DXF", purpose: "Stockpile cross-sections, pit wall profiles", tier: "all" },
        { ext: "CSV", purpose: "Volume reconciliation table", tier: "all" },
        { ext: "PDF/A", purpose: "JORC-compliant report with QP sign-off block", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "StockpileVolume",
        name: "Stockpile Volume (TIN Differencing)",
        formula: "V = ∬(h(x,y) − base_plane) dx dy",
        method: "TIN surface differencing between current scan DTM and reference base plane",
        accuracy: "±0.5% at 95% confidence (industry standard)",
        standard: "AS 3774:2017; JORC Table 1 item 19"
      },
      {
        id: "Tonnage",
        name: "Stockpile Tonnage",
        formula: "T = V × ρ_bulk, where ρ_bulk is bulk density (t/m³) from sampling",
        units: "metric tonnes",
        notes: "Bulk density must be measured in-situ (nuclear density gauge or sampling) — cannot be assumed",
        standard: "JORC Code 2012 §49"
      },
      {
        id: "SlopeStability",
        name: "Factor of Safety — Mohr-Coulomb",
        formula: "FS = (c + (σ_n − u) × tan(φ)) / τ",
        variables: "c = cohesion (kPa), φ = friction angle (°), σ_n = normal stress, u = pore pressure, τ = shear stress",
        thresholds: { unsafe: "< 1.3", marginal: "1.3–1.5", safe: "> 1.5" },
        method: "2D limit equilibrium (Bishop simplified) — minimum; 3D analysis recommended for complex geometries",
        standard: "ISRM (International Society for Rock Mechanics)"
      },
      {
        id: "InSAR_Subsidence",
        name: "InSAR Line-of-Sight Displacement",
        formula: "Δh_LOS = (λ / 4π) × Δφ",
        variables: "λ = radar wavelength (5.6cm for Sentinel-1 C-band), Δφ = interferometric phase difference",
        accuracy: "1–5mm per Sentinel-1 acquisition (PS-InSAR method)",
        units: "mm",
        standard: "ESA Sentinel-1 mission; PS-InSAR methodology (Ferretti et al. 2000)"
      },
      {
        id: "SubsidenceDoD",
        name: "Surface Subsidence (DoD — DEM of Difference)",
        formula: "DoD = DTM_current − DTM_baseline",
        units: "m (positive = uplift, negative = subsidence)",
        notes: "Geomorphic change detection; propagated uncertainty = sqrt(σ₁² + σ₂²)",
        standard: "Wheaton et al. 2010, GCD methodology"
      },
      {
        id: "OreGrade",
        name: "Ore Grade",
        formula: "Grade(%) = (mass_element / mass_sample) × 100",
        standard: "JORC Code 2012 §10; sampling intervals, assay lab certification required"
      }
    ],

    formulas: [
      {
        id: "blast_ppv",
        name: "Blast Peak Particle Velocity (PPV)",
        equation: "PPV = K × (Q^0.5 / R)^n",
        variables: "K = site constant (~160), n = attenuation (~1.6), Q = charge weight (kg), R = distance (m)",
        units: "mm/s",
        thresholds: { residential: "< 5 mm/s", industrial: "< 25 mm/s" },
        standard: "ISEE (International Society of Explosives Engineers); AS 2187.2"
      },
      {
        id: "haul_fuel",
        name: "Haul Truck Fuel Consumption (Tay Model)",
        equation: "FC = (GVW × grade_resistance + rolling_resistance) / (3600 × η_drivetrain)",
        units: "L/km",
        standard: "Caterpillar Performance Handbook §14"
      }
    ],

    reportSections: [
      { order: 1, title: "Executive Summary", required: true, mandatory_content: "Key findings, any JORC exceedances, resource/reserve status" },
      { order: 2, title: "Site Description & Mine Permit", required: true, mandatory_content: "GPS bounds, mine permit number, mining method, geology summary, CRS, geodetic datum", regulatory_ref: "JORC Table 1 Section 1" },
      { order: 3, title: "LiDAR Acquisition Parameters", required: true, mandatory_content: "Sensor model (manufacturer/model), flight altitude AGL, speed, overlap %, scan angle, GSD, point density (pts/m²), acquisition date/time", regulatory_ref: "ASPRS LiDAR Specification 2019" },
      { order: 4, title: "Ground Control Point (GCP) Accuracy Report", required: true, mandatory_content: "Number of GCPs, RMSE (Horizontal ≤3cm, Vertical ≤3cm), checkpoint validation, datum used", regulatory_ref: "ASPRS QL2 requirements" },
      { order: 5, title: "Point Cloud Processing Methodology", required: true, mandatory_content: "Classification algorithm (ground/veg/building), software used, noise filtering parameters, DTM interpolation method (TIN/IDW/Kriging)" },
      { order: 6, title: "Stockpile Volume Table", required: true, mandatory_content: "Volume per pile (m³) with uncertainty (±%), base plane method, bulk density source, tonnage estimate, ore grade (if sampled)", regulatory_ref: "JORC Table 1 §19; AS 3774" },
      { order: 7, title: "Pit Wall Stability Analysis", required: true, mandatory_content: "Slope angle per sector (°), Factor of Safety per method (Bishop/Janbu), TARP trigger thresholds, current status vs. triggers", regulatory_ref: "ISRM; MSHA 30 CFR §75" },
      { order: 8, title: "InSAR / Subsidence Displacement Map", required: false, mandatory_content: "Line-of-sight displacement raster (mm), time-series at monitoring points, comparison with threshold, trend analysis (mm/year)" },
      { order: 9, title: "Infrastructure Risk Assessment", required: true, mandatory_content: "Roads, pipelines, buildings within subsidence influence zone; tilt and horizontal strain values; risk classification" },
      { order: 10, title: "JORC / NI 43-101 Compliance Checklist", required: true, mandatory_content: "Table mapping every JORC Table 1 criteria to evidence status", regulatory_ref: "JORC Code 2012 Table 1" },
      { order: 11, title: "Competent/Qualified Person Statement", required: true, mandatory_content: "Name, qualifications, professional body membership (AusIMM/AIPG/MMSA), signature block, date", regulatory_ref: "JORC Code §19; NI 43-101 §4" },
      { order: 12, title: "Methodology Appendix", required: true, mandatory_content: "LiDAR flight log, calibration certificates, GCP coordinates table, software versions, ISO 19115 metadata XML" }
    ],

    workflowBenchmark: {
      currentTime: "2–4 weeks per report cycle",
      currentSoftware: ["Leica Cyclone", "TerraSolid", "FLAC3D", "ArcGIS Pro", "AutoCAD Civil 3D"],
      currentCost: "$5,000–$15,000 per survey report",
      cahayaTime: "25–40 minutes",
      cahayaSteps: 3,
      valueSaved: "$4,000–$14,000 per report"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a JORC-qualified mine surveyor. Analyse the uploaded LiDAR scan. Calculate stockpile volumes using TIN differencing against the base plane at elevation Z. Apply Mohr-Coulomb slope stability analysis to pit wall sectors. State all results with ±uncertainty at 95% confidence. Cite JORC Code 2012 Table 1.",
      reportPromptPrefix: "Generate a JORC Code 2012 compliant stockpile survey report. Include GCP accuracy table, volume reconciliation table, and JORC Table 1 compliance checklist. The Competent Person sign-off block must appear on the final page."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 3. URBAN PLANNING / SMART CITY
  // ─────────────────────────────────────────────────────────────────────────
  urban: {
    meta: {
      name: "Urban Planning / Smart City",
      icon: "🏙️",
      regulatoryFramework: [
        "ISO 37120:2018 (Sustainable cities — Indicators)",
        "ISO 19650:2018 (BIM information management)",
        "OGC CityGML 3.0 (3D city model standard)",
        "UN-Habitat New Urban Agenda (NUA)",
        "LEED for Communities v4 (USGBC)",
        "BREEAM Communities 2012",
        "Malaysia: Town & Country Planning Act 172",
        "FEMA FIRM (Flood Insurance Rate Maps)",
        "US: Local Zoning Ordinances + APA planning standards",
        "UK NPPF (National Planning Policy Framework)"
      ],
      governingBodies: ["Local Planning Authority", "UN-Habitat", "ISO TC 268 (Sustainable Cities)", "OGC"],
      governmentAcceptance: ["Local council planning approval", "EIA clearance", "Building plan approval"],
      mandatoryDataFormat: "GeoPackage (OGC standard); DWG for engineering; CityGML for 3D models"
    },

    fileFormats: {
      input: [
        { ext: "DWG / DXF", purpose: "Architectural/engineering site plans", notes: "Must be georeferenced before GIS analysis. AutoCAD DWG often delivered without CRS — conversion step required." },
        { ext: "GeoPackage (.gpkg)", purpose: "Zoning, parcels, road networks, planning constraints", notes: "OGC standard — preferred over Shapefile for new projects." },
        { ext: "CityGML (.gml)", purpose: "3D urban models for shadow/UHI analysis", notes: "LOD1 (block model) or LOD2 (roof detail) depending on analysis." },
        { ext: "GeoTIFF", purpose: "LiDAR-derived DSM, aerial imagery, heat maps", notes: "0.1–0.5m for building footprint extraction." },
        { ext: "IFC", purpose: "Building-level BIM models", notes: "ISO 16739-1. Integrates with CityGML via CityGML-IFC bridge." }
      ],
      output: [
        { ext: "GeoPackage", purpose: "All planning GIS layers", tier: "all" },
        { ext: "CityGML", purpose: "3D urban model export", tier: "sovereign" },
        { ext: "PDF/A-3", purpose: "Planning report with embedded GIS", tier: "all" },
        { ext: "KMZ", purpose: "Stakeholder visualization", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "FAR",
        name: "Floor Area Ratio",
        formula: "FAR = Total_GFA / Site_Area",
        example: "GFA=10,000m², Site=4,000m² → FAR=2.5",
        purpose: "Primary zoning compliance check — must not exceed zone limit",
        standard: "Local planning ordinance; JICA urban planning guidelines"
      },
      {
        id: "GreenCoverage",
        name: "Green Coverage Ratio",
        formula: "GCR = (Permeable_Green_Area / Total_Site_Area) × 100%",
        threshold: "WHO recommends ≥9m² green space per person; LEED: ≥40% green coverage",
        standard: "WHO 2016; LEED for Communities v4"
      },
      {
        id: "SolarShadow",
        name: "Solar Position & Shadow Analysis",
        formula: "θ_elevation = arcsin(sin(φ)sin(δ) + cos(φ)cos(δ)cos(h)), θ_azimuth = arccos((sin(δ) − sin(φ)sin(θ_elev)) / (cos(φ)cos(θ_elev)))",
        variables: "φ = site latitude, δ = solar declination, h = hour angle",
        purpose: "Right-to-light compliance; winter shadow impact on neighbouring parcels",
        standard: "ISO 9060; BRE Site Layout Planning for Daylight and Sunlight (2022)"
      },
      {
        id: "TrafficBPR",
        name: "Traffic Volume-Delay (BPR Function)",
        formula: "t(v) = t₀ × (1 + 0.15 × (v/c)⁴)",
        variables: "t₀ = free-flow travel time, v = volume (veh/h), c = capacity (veh/h)",
        standard: "US Bureau of Public Roads (BPR); Highway Capacity Manual (HCM 7th ed.)"
      },
      {
        id: "UHI",
        name: "Urban Heat Island Intensity",
        formula: "UHI = T_urban − T_rural",
        derivation: "Land Surface Temperature (LST) from Landsat Band 10/11: T = K₂ / ln(K₁/L_λ + 1) − 273.15",
        units: "°C",
        standard: "USEPA Urban Heat Island Effect; ISO 37120 Indicator 18.3"
      },
      {
        id: "PopDensity",
        name: "Population Density",
        formula: "ρ = Population / Area_km²",
        benchmarks: { low: "< 1,000/km²", medium: "1,000–10,000/km²", high: "> 10,000/km²" },
        standard: "UN-Habitat City Prosperity Index"
      }
    ],

    reportSections: [
      { order: 1, title: "Project Overview & Location", required: true, mandatory_content: "Legal description, GPS coordinates (WGS84), site area, current land use, developer/proponent details" },
      { order: 2, title: "Existing Zoning & Land Use Analysis", required: true, mandatory_content: "Current classification, permitted uses table, overlay controls, heritage listing if any", regulatory_ref: "Town & Country Planning Act 172 (Malaysia) / local ordinance" },
      { order: 3, title: "Development Compliance Matrix", required: true, mandatory_content: "FAR, plot coverage, height limit, setbacks — actual vs. permitted. Pass/Fail per parameter", regulatory_ref: "Local Development Plan; Act 172 §22" },
      { order: 4, title: "3D Urban Design Study", required: true, mandatory_content: "Shadow impact analysis (equinox, solstice, summer morning/afternoon), view corridor study, skyline profile" },
      { order: 5, title: "Traffic Impact Assessment (TIA)", required: true, mandatory_content: "AM/PM peak hour trip generation, distribution, assignment; Level of Service (LOS) A–F per intersection", regulatory_ref: "Highway Capacity Manual HCM 7th Ed." },
      { order: 6, title: "Infrastructure Capacity Analysis", required: true, mandatory_content: "Water supply (L/person/day), sewerage (PE), power (kVA), stormwater (Q = CIA rational method)" },
      { order: 7, title: "Environmental Assessment", required: true, mandatory_content: "Flood zone (FEMA FIRM or JPS flood map), protected areas buffer, heritage zones, noise contours" },
      { order: 8, title: "Green Space & UHI Analysis", required: false, mandatory_content: "Green coverage ratio, Land Surface Temperature, green corridor connectivity" },
      { order: 9, title: "Conclusion & Recommendation", required: true, mandatory_content: "Overall planning merits, conditions for approval" },
      { order: 10, title: "GIS Data Appendix", required: true, mandatory_content: "Coordinate system declaration (projection, datum, EPSG code), data dictionary, ISO 19115 metadata" }
    ],

    workflowBenchmark: {
      currentTime: "3–6 months per EIA/planning report",
      currentSoftware: ["AutoCAD Civil 3D", "Bentley MicroStation", "ArcGIS Urban", "VISSIM", "SoundPlan"],
      currentCost: "$30,000–$100,000 per planning study",
      cahayaTime: "2–4 hours initial analysis",
      cahayaSteps: 3,
      valueSaved: "$25,000–$80,000 per study"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a certified urban planner. Analyse this site's land cover and urban form. Compute FAR, green coverage ratio, and Land Surface Temperature from the uploaded imagery. Check for flood zone overlap from JPS/FEMA data. Reference ISO 37120 and local zoning ordinance.",
      reportPromptPrefix: "Generate a planning report compliant with the Town & Country Planning Act 172. Include a compliance matrix for all development parameters. Traffic analysis must reference HCM 7th edition Level of Service definitions."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 4. DEFENSE / SECURITY
  // ─────────────────────────────────────────────────────────────────────────
  defense: {
    meta: {
      name: "Defense / Security",
      icon: "🛡️",
      regulatoryFramework: [
        "NGA NSG Standards Registry (GEOINT standards)",
        "DGIWG Standards (NATO Defence Geospatial)",
        "MIL-STD-2411 (RPF — Raster Product Format)",
        "MIL-PRF-89020B (DTED standard)",
        "MIL-STD-2525D (Joint Military Symbology)",
        "NATO STANAG 7074 (Digital Geographic Information)",
        "DoD Instruction 8560.01 (Geospatial Policy)",
        "DISA Security Technical Implementation Guides (STIGs)"
      ],
      governingBodies: ["NGA (National Geospatial-Intelligence Agency)", "DISA", "DGIWG", "NATO ACT"],
      governmentAcceptance: ["NGA GEOINT product approval", "DISA network compliance", "NATO certification"],
      mandatoryDataFormat: "NITF for imagery; DTED for elevation; MGRS for all coordinates; MIL-STD-2525 for symbology",
      airGapRequired: true
    },

    fileFormats: {
      input: [
        { ext: "NITF (.ntf)", purpose: "Primary imagery format — multi-band, SAR, SICD", notes: "STANAG 4545. All classified imagery exchanged in NITF." },
        { ext: "DTED (.dt2)", purpose: "Elevation data — terrain analysis, LOS, weapon trajectory", notes: "Level 2 (~30m resolution) for operational planning. Level 3/4 classified." },
        { ext: "RPF (.rpm/.rp0)", purpose: "Digital map rasters for field systems", notes: "MIL-STD-2411 compliance required." },
        { ext: "CoT XML", purpose: "Real-time Cursor on Target position sharing", notes: "TAK (Team Awareness Kit) platform exchange format." },
        { ext: "KMZ", purpose: "Unclassified tactical overlays", notes: "Google Earth Pro widely used at operational level." }
      ],
      output: [
        { ext: "NITF", purpose: "Annotated imagery product", tier: "sovereign" },
        { ext: "GeoPackage", purpose: "Unclassified GIS data exchange (coalition)", tier: "all" },
        { ext: "KMZ", purpose: "Tactical overlay for field systems", tier: "all" },
        { ext: "PDF (UNCLASSIFIED)", purpose: "Situational awareness briefing", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "ChangeDetection",
        name: "SAR Change Detection",
        formula: "CD = |σ⁰_T2 − σ⁰_T1| / σ⁰_T1",
        variables: "σ⁰ = normalised radar backscatter, T1 = baseline, T2 = current",
        threshold: "> 3dB change = significant activity",
        standard: "NGA Change Detection Product Specification; ESA Copernicus EMS"
      },
      {
        id: "Viewshed",
        name: "Line of Sight / Viewshed",
        formula: "LOS(A→B) = DTED_profile − Earth_curvature_correction − Refraction_k×d²/(2R)",
        variables: "k = atmospheric refraction coefficient (~0.13), R = Earth radius (6,371,000m), d = distance (m)",
        purpose: "Radar siting, sniper overwatch, UAV detection coverage",
        standard: "MIL-HDBK-1110B; NGA GEOINT Standard"
      },
      {
        id: "NIIRS",
        name: "National Imagery Interpretability Rating Scale",
        formula: "NIIRS ≈ 0 + GSD-based lookup table (0.05m→9, 1m→5, 5m→3)",
        range: "0–9",
        practical: "NIIRS 5 = identify vehicle type; NIIRS 7 = count personnel; NIIRS 9 = read text",
        standard: "NGA NIIRS Reference Guide"
      },
      {
        id: "ThermalAnomaly",
        name: "Thermal Anomaly (Planck Inversion)",
        formula: "T = hc/(kλ × ln(2hc²/λ⁵L_λ + 1))",
        variables: "L_λ = spectral radiance, λ = wavelength, h = Planck constant, k = Boltzmann constant",
        units: "Kelvin → Celsius",
        purpose: "Hot spot detection — engines, generators, personnel under foliage",
        standard: "FLIR Systems LWIR specification; NGA thermal product standards"
      }
    ],

    reportSections: [
      { order: 1, title: "Classification Markings", required: true, mandatory_content: "Header/footer classification on every page. Distribution statement (A–F). Special handling (NOFORN, ORCON, REL TO list)", regulatory_ref: "DoD Manual 5200.01; ODNI CAPCO" },
      { order: 2, title: "BLUF (Bottom Line Up Front)", required: true, mandatory_content: "2–3 sentence key assessment — who, what, where, when, so-what" },
      { order: 3, title: "Collection Source & Metadata", required: true, mandatory_content: "Sensor, date/time (Zulu), cloud cover, NIIRS rating, GSD, pass direction, source classification caveats" },
      { order: 4, title: "Key Terrain Analysis", required: true, mandatory_content: "Dominant terrain features, mobility corridors, choke points, observation/fields of fire", regulatory_ref: "NATO OCOKA terrain analysis methodology" },
      { order: 5, title: "Change Detection Assessment", required: false, mandatory_content: "Bi-temporal comparison, new/removed features (coordinates in MGRS), date of change, confidence level" },
      { order: 6, title: "Activity Assessment", required: false, mandatory_content: "Observed patterns, equipment identification (platform type if NIIRS allows), activity class" },
      { order: 7, title: "Coordinate Appendix", required: true, mandatory_content: "MGRS and WGS84 (DMS and DD) for all identified features. Positional accuracy statement." },
      { order: 8, title: "Dissemination Controls", required: true, mandatory_content: "Authority, declassification date/event, further distribution instructions" }
    ],

    workflowBenchmark: {
      currentTime: "Hours to days depending on classification level",
      currentSoftware: ["SOCET GXP", "ENVI", "Palantir Foundry", "ArcGIS Pro", "TAK"],
      cahayaTime: "30–90 minutes for unclassified GEOINT products",
      cahayaSteps: 2,
      airGapNote: "100% local inference mandatory — no cloud API calls permitted"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a GEOINT analyst. All operations are air-gapped. Analyse the uploaded satellite imagery. Report all coordinates in MGRS. Identify changes vs baseline using SAR backscatter differencing. Rate imagery interpretability on NIIRS scale 0–9.",
      reportPromptPrefix: "Generate a GEOINT intelligence report. Every page must begin with UNCLASSIFIED header. All coordinates in MGRS. BLUF in first paragraph. Cite NGA product standards."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 5. MARITIME / COASTAL
  // ─────────────────────────────────────────────────────────────────────────
  maritime: {
    meta: {
      name: "Maritime / Coastal",
      icon: "🌊",
      regulatoryFramework: [
        "IHO S-44 Ed.6 (Standards for Hydrographic Surveys)",
        "IHO S-57 Ed.3.1 (ENC Production Standard)",
        "IHO S-101 (Next-Gen ENC — S-100 framework)",
        "IHO S-58 (ENC Validation Checks)",
        "IMO SOLAS Ch.V (ECDIS mandatory use on SOLAS vessels)",
        "NOAA HSSD (Hydrographic Surveys Specifications & Deliverables)",
        "IMO MARPOL (Marine Environmental Protection)",
        "ISO 19104 (Maritime terminology standard)"
      ],
      governingBodies: ["IHO (International Hydrographic Organization)", "NOAA Office of Coast Survey", "UKHO (UK Hydrographic Office)", "National hydrographic offices"],
      governmentAcceptance: ["National Hydrographic Office chart approval", "NOAA chart update acceptance", "Port Authority navigation clearance"],
      mandatoryDataFormat: "S-57 (.000) for ENC production; S-102 HDF5 for high-density bathymetry"
    },

    fileFormats: {
      input: [
        { ext: "S-57 (.000)", purpose: "Current ENC production/update", notes: "IHO S-57 Ed.3.1. 14 core object classes. Must pass S-58 validation (0 errors allowed for publication)." },
        { ext: "S-102 (HDF5)", purpose: "High-density bathymetric surface", notes: "New S-100 framework product. Contains QA uncertainty layers." },
        { ext: "GSF", purpose: "Raw multibeam sonar data", notes: "Generic Sensor Format — NOAA standard for raw ping data archiving." },
        { ext: "NetCDF (.nc)", purpose: "Tidal models, current forecasts, oceanographic data", notes: "CF conventions required." }
      ],
      output: [
        { ext: "S-57 (.000)", purpose: "ENC update cell", tier: "sovereign" },
        { ext: "GeoTIFF", purpose: "Bathymetric DEM at 0.5–1m resolution", tier: "professional+" },
        { ext: "GeoPackage", purpose: "Coastal zone analysis vectors", tier: "all" },
        { ext: "PDF", purpose: "Survey report per NOAA HSSD", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "BathymetricUncertainty",
        name: "Total Propagated Uncertainty (TPU)",
        formula: "TPU = sqrt(σ_depth² + σ_positioning² + σ_attitude² + σ_sound_velocity²)",
        threshold: "IHO S-44 Order 1a: TPU ≤ √(0.5² + (0.013×d)²) at 95% CI, where d = depth (m)",
        purpose: "Navigation safety — critical uncertainty must not exceed IHO limits",
        standard: "IHO S-44 Edition 6.1.0 Table 1"
      },
      {
        id: "CoastalErosion",
        name: "Shoreline Change Rate",
        formula: "SCR = (Shoreline_T2 − Shoreline_T1) / Δt",
        units: "m/year (negative = erosion, positive = accretion)",
        method: "DSAS (Digital Shoreline Analysis System) — USGS free tool",
        standard: "EUROSION; Coastal Zone Management Act"
      },
      {
        id: "WaveEnergyFlux",
        name: "Wave Energy Flux (Power)",
        formula: "P = ρg²H_s²T_e / (64π)",
        variables: "ρ = water density (1025 kg/m³), g = 9.81 m/s², H_s = significant wave height (m), T_e = energy period (s)",
        units: "W/m (per unit crest width)",
        standard: "ISO 21650:2007 (Actions from waves)"
      },
      {
        id: "MNDWI",
        name: "Modified Normalized Difference Water Index",
        formula: "MNDWI = (Green − SWIR) / (Green + SWIR)",
        purpose: "Water extent mapping, tidal flat delineation, mangrove edge detection",
        standard: "Xu 2006, International Journal of Remote Sensing"
      },
      {
        id: "UnderKeelClearance",
        name: "Under-Keel Clearance (UKC)",
        formula: "UKC = Charted_depth + Tidal_height − Ship_draft − Squat − Settlement − Heave_allowance",
        threshold: "Minimum UKC = 10–15% of maximum draft (IMO/port authority specific)",
        standard: "PIANC (Permanent International Association of Navigation Congresses) Guidelines"
      }
    ],

    reportSections: [
      { order: 1, title: "Survey Authorization & Reference Numbers", required: true, mandatory_content: "Contract/task number, authorizing agency, survey dates, vessel name/callsign" },
      { order: 2, title: "Survey Area Description", required: true, mandatory_content: "Geographic bounds (decimal degrees), chart scale, port/coastal context, adjacent surveys" },
      { order: 3, title: "Instrumentation & Calibration", required: true, mandatory_content: "MBES manufacturer/model, frequency (kHz), swath angle, GNSS class (DP2 minimum), patch test results, SVP profiler type/frequency", regulatory_ref: "NOAA HSSD §4.2" },
      { order: 4, title: "Sound Velocity Profile (SVP)", required: true, mandatory_content: "SVP cast frequency, depth range, plot of c(z), surface sound speed mean, any anomalies" },
      { order: 5, title: "Tidal Reduction", required: true, mandatory_content: "Tide gauge station reference, offset distance, datum used (LAT/MLW/MLLW), gauge accuracy" },
      { order: 6, title: "Data Coverage Diagram", required: true, mandatory_content: "Flight-line/trackline coverage, overlap percentage, any gaps (with justification)" },
      { order: 7, title: "Quality Control — CUBE Surface Statistics", required: true, mandatory_content: "Normalised Total Weighted Mean Square (NTWMS), percentage soundings within ±2σ, IHO Order compliance confirmation", regulatory_ref: "IHO S-44 Ed.6 Table 1" },
      { order: 8, title: "Feature Report", required: true, mandatory_content: "New wrecks/obstructions (position MGRS/WGS84, depth, dimensions), shoals shallower than charted, any previously charted features not found" },
      { order: 9, title: "Coastal Change Analysis", required: false, mandatory_content: "Shoreline change rates (DSAS), erosion hotspots, accretion zones, multi-epoch comparison" },
      { order: 10, title: "S-57 Validation Summary", required: true, mandatory_content: "S-58 check suite run, all errors resolved (mandatory zero error count), ENC cell metadata", regulatory_ref: "IHO S-58 validation standard" }
    ],

    workflowBenchmark: {
      currentTime: "2–6 months survey-to-chart cycle",
      currentSoftware: ["CARIS HIPS&SIPS", "QPS QINSy", "HYPACK", "NOAA NBS chartmaker"],
      currentCost: "$50,000–$300,000 per survey + charting",
      cahayaTime: "1–3 hours for coastal zone analysis",
      cahayaSteps: 3,
      valueSaved: "Months of manual chart generalization work"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are an IHO-qualified hydrographer. Analyse the uploaded bathymetric data. Compute Total Propagated Uncertainty against IHO S-44 Order 1a thresholds. Identify features shallower than surrounding seafloor. Apply tidal correction to Chart Datum (LAT). State all depths in metres below LAT.",
      reportPromptPrefix: "Generate a hydrographic survey report compliant with NOAA HSSD and IHO S-44 Ed.6. Include TPU statistics table showing IHO Order compliance. All feature positions in WGS84 decimal degrees AND MGRS. S-57 validation summary must confirm zero S-58 errors."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 6. ENVIRONMENTAL / CONSERVATION
  // ─────────────────────────────────────────────────────────────────────────
  environmental: {
    meta: {
      name: "Environmental / Conservation",
      icon: "🌿",
      regulatoryFramework: [
        "ISO 14001:2015 (Environmental Management Systems)",
        "ISO 19115:2014 (Geographic Metadata)",
        "IAIA Best Practice Principles for EIA",
        "US EPA NEPA (National Environmental Policy Act)",
        "US EPA Clean Water Act §404 (Wetland Delineation)",
        "IUCN Red List Spatial Standards (range mapping)",
        "CBD Kunming-Montreal GBF (30×30 target monitoring)",
        "Ramsar Convention (Wetland reporting standards)",
        "Malaysia EIA Order 1987 (Environmental Quality Act 1974)",
        "EU Habitats Directive 92/43/EEC (species/habitat protection)"
      ],
      governingBodies: ["EPA / DoE", "IUCN", "US Fish & Wildlife Service", "Ramsar Secretariat", "Malaysia DOE/PERHILITAN"],
      governmentAcceptance: ["EIA approval (DoE Malaysia)", "EPA §404 permit", "IUCN Red List submission", "EU Article 6 habitat assessment"],
      mandatoryDataFormat: "Shapefile for habitat polygons (EPA requirement); FGDC-XML metadata mandatory for EPA submissions"
    },

    fileFormats: {
      input: [
        { ext: "GeoTIFF", purpose: "Land cover classification, NDVI, habitat suitability", notes: "Sentinel-2 L2A or Planet NICFI for tropical habitats." },
        { ext: "Shapefile / GeoPackage", purpose: "Habitat polygons, protected areas, species occurrence", notes: "GBIF species occurrence download in CSV/Darwin Core; IUCN PA boundaries in Shapefile." },
        { ext: "NetCDF", purpose: "Climate model outputs for species distribution modelling", notes: "WorldClim v2.1 at 1km; CHELSA at 1km." },
        { ext: "CSV (Darwin Core)", purpose: "Species occurrence records (GBIF, iNaturalist, eBird)", notes: "Spatial bias correction required — citizen science data highly skewed toward accessible areas." }
      ],
      output: [
        { ext: "GeoTIFF", purpose: "Habitat suitability index raster (0–1)", tier: "all" },
        { ext: "GeoPackage", purpose: "All habitat polygons + species occurrence", tier: "professional+" },
        { ext: "XML (FGDC-ISO 19115)", purpose: "Mandatory metadata for EPA submissions", tier: "all" },
        { ext: "PDF/A", purpose: "EIA chapter or full report", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "ShannonWiener",
        name: "Shannon-Wiener Biodiversity Index",
        formula: "H' = −Σ(pᵢ × ln(pᵢ))",
        variables: "pᵢ = proportion of species i in the sample; Σ across all S species",
        interpretation: { low: "H' < 1.5", medium: "1.5–3.0", high: "> 3.0" },
        standard: "IAIA EIA good practice; Shannon & Weaver 1949"
      },
      {
        id: "HabitatSuitabilityIndex",
        name: "Habitat Suitability Index (HSI)",
        formula: "HSI = ∏(Vᵢ)^(1/n), where Vᵢ = individual suitability variable score (0–1)",
        method: "MaxEnt (Maximum Entropy) or Random Forest species distribution model",
        standard: "USFWS HSI model series; IUCN SSC guidelines"
      },
      {
        id: "NDII",
        name: "Normalized Difference Infrared Index",
        formula: "NDII = (NIR − SWIR) / (NIR + SWIR)",
        bands: { sentinel2: { NIR: "B8 (842nm)", SWIR: "B11 (1610nm)" } },
        purpose: "Forest moisture stress — indicator of drought/fire risk in conservation areas",
        standard: "Hardisky et al. 1983; Ceccato et al. 2001"
      },
      {
        id: "MNDWI",
        name: "Modified NDWI (Water extent)",
        formula: "MNDWI = (Green − SWIR) / (Green + SWIR)",
        purpose: "Wetland delineation, surface water extent mapping",
        standard: "US EPA NWI (National Wetlands Inventory); Cowardin classification"
      },
      {
        id: "LeopoldMatrix",
        name: "Leopold Impact Matrix Score",
        formula: "Impact_score = Magnitude × Importance, both on scale 1–10",
        interpretation: "Scores > 60 = Significant; 20–60 = Moderate; < 20 = Minor",
        purpose: "Systematic EIA impact assessment across all receptor categories",
        standard: "Leopold et al. 1971; IAIA best practice"
      }
    ],

    reportSections: [
      { order: 1, title: "Introduction & Objectives", required: true, mandatory_content: "Regulatory trigger (EIA Act, EPA §404), project description, terms of reference" },
      { order: 2, title: "Methodology", required: true, mandatory_content: "Classification system (EUNIS/NWI/CMECS), software versions, satellite sensor specifications, field survey design, sampling strategy with statistical rationale", regulatory_ref: "ISO 19115 §6.5.2; FGDC CSDGM §5" },
      { order: 3, title: "Baseline Conditions", required: true, mandatory_content: "Existing habitat types (with areas in ha), species list (with IUCN/national status), land cover map, water quality baseline" },
      { order: 4, title: "Habitat Classification & Mapping", required: true, mandatory_content: "Classified habitat map, confusion matrix (overall accuracy ≥85% required), area statistics per habitat type with uncertainty" },
      { order: 5, title: "Species Occurrence & Distribution", required: true, mandatory_content: "GPS-verified occurrence records, habitat suitability map (0–1 scale), key sensitive species locations" },
      { order: 6, title: "Impact Assessment — Leopold Matrix", required: true, mandatory_content: "Full Leopold Matrix table across all project phases × receptor categories; cumulative impact assessment", regulatory_ref: "IAIA EIA Best Practice; Malaysia EIA Guidelines" },
      { order: 7, title: "Mitigation Hierarchy", required: true, mandatory_content: "Avoid → Minimize → Restore → Offset (in that preference order). Quantified residual impact after mitigation.", regulatory_ref: "BBOP (Business & Biodiversity Offsets Programme) Standard" },
      { order: 8, title: "QA/QC", required: true, mandatory_content: "Classification accuracy assessment (confusion matrix, κappa coefficient), positional accuracy (RMSE), sample representativeness" },
      { order: 9, title: "Monitoring Plan", required: true, mandatory_content: "Key indicators, monitoring frequency, responsible party, trigger thresholds, adaptive management protocol" },
      { order: 10, title: "Metadata Appendix", required: true, mandatory_content: "FGDC-XML metadata file reference, data dictionary, CRS declaration, all dataset lineage statements", regulatory_ref: "EPA FGDC CSDGM metadata standard" }
    ],

    workflowBenchmark: {
      currentTime: "3–12 months for full EIA",
      currentSoftware: ["ENVI", "ArcGIS Pro", "QGIS", "MaxEnt", "R (dismo/biomod2)", "FRAGSTATS"],
      currentCost: "$30,000–$150,000 per EIA chapter",
      cahayaTime: "2–4 hours for initial screening assessment",
      cahayaSteps: 3,
      valueSaved: "$25,000–$120,000 per assessment"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a certified environmental impact assessment specialist. Analyse the uploaded satellite imagery and species occurrence data. Classify habitat types using EUNIS level 2 system. Compute NDVI, MNDWI, and NDII. Identify sensitive habitats within project footprint. Calculate Shannon-Wiener index for observed species.",
      reportPromptPrefix: "Generate an EIA-standard environmental baseline report. Include a Leopold Matrix impact assessment table. Classification accuracy must be reported (confusion matrix, OA ≥85%). All metadata must comply with FGDC CSDGM standard. Mitigation measures must follow the avoid-minimize-restore-offset hierarchy."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 7. ENERGY / RENEWABLE
  // ─────────────────────────────────────────────────────────────────────────
  energy: {
    meta: {
      name: "Energy / Renewable",
      icon: "⚡",
      regulatoryFramework: [
        "IEC 61724-1:2017 (Solar PV monitoring & yield assessment)",
        "IEC 61400-12 (Wind turbine power performance)",
        "IEC 61400-1 (Wind turbine design loads)",
        "NEPA (US: EIS/EA requirement for federal permits)",
        "BOEM GIS Submission Requirements (US offshore wind)",
        "BLM Solar/Wind Energy Development PEIS",
        "ISO 50001:2018 (Energy management system)",
        "IRENA metrics (renewable energy statistics)",
        "Malaysia Suruhanjaya Tenaga — CRESS/FiT guidelines",
        "Gold Standard / Verra VCS — renewable energy carbon methodology"
      ],
      governingBodies: ["IEC TC 88 (Wind)", "IEA", "IRENA", "BOEM", "BLM", "Suruhanjaya Tenaga (Malaysia)"],
      governmentAcceptance: ["NEPA EIS approval", "BOEM/BLM Plan of Development", "Grid connection application (TNB/utility)", "FAA aviation obstruction clearance"],
      mandatoryDataFormat: "Shapefile/GDB for BOEM submission; IEC 61724 compliant yield data format"
    },

    fileFormats: {
      input: [
        { ext: "NetCDF (.nc)", purpose: "ERA5 wind reanalysis, MERRA-2 solar data, 10–50yr time series", notes: "ERA5: 31km horizontal, 1-hour temporal resolution. Download via Copernicus CDS API." },
        { ext: "GeoTIFF", purpose: "Solar irradiance rasters (GHI, DNI, DHI), terrain slope/aspect", notes: "NASA POWER at 0.5° or PVGIS at 1km resolution." },
        { ext: "GeoPackage / Shapefile", purpose: "Project lease area, exclusion zones, turbine/panel layout", notes: "BOEM GeoJSON or Shapefile for offshore; BLM GDB for onshore federal." },
        { ext: "KMZ", purpose: "FAA airspace consultation; community visual impact visualization", notes: "FAA OE/AAA form requires KMZ coordinate submission." }
      ],
      output: [
        { ext: "GeoTIFF", purpose: "Solar resource raster, wind power density, suitability map, ZTV viewshed", tier: "all" },
        { ext: "CSV / XLSX", purpose: "Energy yield summary, LCOE calculation, Weibull parameters", tier: "all" },
        { ext: "PDF/A", purpose: "Pre-Application Report / Environmental Statement", tier: "all" },
        { ext: "KMZ", purpose: "Turbine/panel layout for stakeholder consultation", tier: "professional+" }
      ]
    },

    keyIndices: [
      {
        id: "LCOE",
        name: "Levelized Cost of Energy",
        formula: "LCOE = Σ(C_t / (1+r)^t) / Σ(E_t / (1+r)^t)",
        variables: "C_t = total costs in year t ($), E_t = energy output in year t (MWh), r = discount rate (8–10% typical), t = project lifetime (20–30 years)",
        units: "$/MWh or RM/kWh",
        benchmarks: { solarUtility: "$25–50/MWh (2024)", wind_onshore: "$30–60/MWh", wind_offshore: "$80–130/MWh" },
        standard: "IEA World Energy Outlook methodology; NREL SAM"
      },
      {
        id: "SolarYield",
        name: "Annual Solar Energy Yield",
        formula: "E = A × r × H × PR",
        variables: "A = array area (m²), r = module efficiency (%), H = annual GHI (kWh/m²/yr), PR = performance ratio (0.70–0.82)",
        units: "kWh/year",
        standard: "IEC 61724-1:2017 §9; EU JRC PVGIS methodology"
      },
      {
        id: "WindPower",
        name: "Wind Power Density",
        formula: "P = ½ × ρ × v³ × Cp",
        variables: "ρ = air density (1.225 kg/m³ at sea level, 15°C), v = wind speed (m/s), Cp = power coefficient (max Betz limit = 0.593)",
        units: "W/m²",
        standard: "IEC 61400-12; AWS Truepower methodology"
      },
      {
        id: "WeibullDistribution",
        name: "Weibull Wind Speed Distribution",
        formula: "f(v) = (k/λ)(v/λ)^(k−1) × exp(−(v/λ)^k)",
        variables: "k = shape parameter (~2 for typical sites), λ = scale parameter ≈ v_mean × 1.128",
        purpose: "Statistical characterization of wind speed at hub height",
        standard: "IEC 61400-12; WAsP methodology"
      },
      {
        id: "CapacityFactor",
        name: "Capacity Factor",
        formula: "CF = Actual_annual_generation_MWh / (Nameplate_capacity_MW × 8760h)",
        benchmarks: { solarMalaysia: "14–18%", windOnshore_AU: "30–45%", windOffshore: "40–55%" },
        standard: "IRENA Renewable Power Generation Costs report"
      },
      {
        id: "ZTV",
        name: "Zone of Theoretical Visibility (Viewshed)",
        formula: "Visible if: z_target + h_turbine > z_observer + (d²/12.8km correction)",
        method: "ArcGIS Viewshed2 tool; ray casting from blade-tip height against LiDAR DSM + turbine height",
        standard: "UK SNH Visual Representation of Wind Farms v2.2; LVIA methodology"
      }
    ],

    reportSections: [
      { order: 1, title: "Project Description", required: true, mandatory_content: "Location (WGS84 + national grid), technology type, installed capacity (MWp/MW), number of units, hub/tilt height, land tenure" },
      { order: 2, title: "Site Selection & Alternatives", required: true, mandatory_content: "MCDA suitability analysis, alternatives considered, selection rationale", regulatory_ref: "NEPA DEIS alternatives analysis requirement" },
      { order: 3, title: "Wind/Solar Resource Assessment", required: true, mandatory_content: "Data source (ERA5/MERRA-2/measured), period of record (≥10 years), uncertainty analysis (P50/P90/P99 yields), Weibull parameters (wind)", regulatory_ref: "IEC 61724-1; IEC 61400-12" },
      { order: 4, title: "Energy Yield Estimate", required: true, mandatory_content: "Gross yield, loss assumptions (soiling, shading, wake, availability, degradation), net P50 yield, performance ratio", regulatory_ref: "IEC 61724-1 §9" },
      { order: 5, title: "LCOE & Financial Analysis", required: false, mandatory_content: "CAPEX breakdown, OPEX ($/MWh/year), discount rate, project lifetime, LCOE, NPV, IRR, payback period" },
      { order: 6, title: "Visual Impact Assessment (ZTV)", required: true, mandatory_content: "Viewshed extent map, key viewpoint photographs with photomontages, affected settlements within ZTV", regulatory_ref: "UK SNH Guidelines; LVIA best practice" },
      { order: 7, title: "Environmental Constraints", required: true, mandatory_content: "Protected areas buffer (IUCN categories I–VI), bird/bat strike risk, noise contours (dB(A) at nearest receptor), setback distances" },
      { order: 8, title: "Grid Connection Study", required: true, mandatory_content: "Grid injection point, transmission line routing (least-cost path), network capacity assessment" },
      { order: 9, title: "Cumulative Impact", required: true, mandatory_content: "Existing + consented + planned projects within study radius; cumulative ZTV, cumulative wake loss" },
      { order: 10, title: "Appendices", required: true, mandatory_content: "GIS data dictionary, coordinate system, turbine/panel coordinates table, ERA5 data citation, acoustic modelling parameters" }
    ],

    workflowBenchmark: {
      currentTime: "12–24 months site assessment to EIA submission",
      currentSoftware: ["PVsyst ($2K/yr)", "WAsP/windPRO ($5K/yr)", "SAM (NREL free)", "ArcGIS Pro", "AutoCAD Civil 3D"],
      currentCost: "$50,000–$200,000 per feasibility study",
      cahayaTime: "3–5 hours initial assessment",
      cahayaSteps: 3,
      valueSaved: "$40,000–$180,000 per study"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are an IEC-qualified renewable energy resource assessment engineer. Analyse the uploaded GHI/wind speed data. Compute LCOE using IEA methodology. Fit a Weibull distribution to wind speed data. Calculate P50/P90/P99 solar yields using IEC 61724-1. Include a MCDA suitability exclusion analysis.",
      reportPromptPrefix: "Generate a pre-application renewable energy assessment report. All yield estimates must state uncertainty as P50/P90/P99. LCOE must show sensitivity to ±20% CAPEX variation. ZTV viewshed analysis must reference UK SNH guidelines. All data sources cited with retrieval dates."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 8. INFRASTRUCTURE / CIVIL ENGINEERING
  // ─────────────────────────────────────────────────────────────────────────
  infrastructure: {
    meta: {
      name: "Infrastructure / Civil Engineering",
      icon: "🏗️",
      regulatoryFramework: [
        "ISO 19650:2018 (BIM information management — UK, Singapore, EU mandated)",
        "ASPRS LiDAR Specification 2019 (Quality Levels QL0–QL5)",
        "USGS 3DEP QL1/QL2 Specifications",
        "ISO 16739-1:2018 (IFC — Open BIM standard)",
        "Eurocode 7 (BS EN 1997 — Geotechnical design)",
        "AASHTO LRFD Bridge Design Specifications (US)",
        "Highway Capacity Manual HCM 7th Edition",
        "JKR Specification (Jabatan Kerja Raya Malaysia)",
        "OGC LandInfra / InfraGML (infrastructure data standard)"
      ],
      governingBodies: ["JKR Malaysia", "UK Highways England", "US FHWA", "buildingSMART International (IFC)", "AASHTO"],
      governmentAcceptance: ["JKR/PWD plan approval", "ISO 19650 BIM compliance", "AASHTO/Eurocode engineering certification"],
      mandatoryDataFormat: "IFC for BIM; LAS/LAZ for LiDAR; LandXML for civil alignment design"
    },

    fileFormats: {
      input: [
        { ext: "LAS / LAZ", purpose: "Airborne/mobile LiDAR — road corridors, bridges, utilities", notes: "ASPRS QL2 minimum (2pts/m²). Bridge inspection: QL0 (20+pts/m²) for deformation mapping." },
        { ext: "E57", purpose: "Terrestrial laser scanner (TLS) — tunnels, bridge decks", notes: "ISO 17742. Leica/Trimble TLS standard output." },
        { ext: "DWG / LandXML", purpose: "Road/rail alignment design", notes: "Civil 3D surfaces export to LandXML for GIS import." },
        { ext: "IFC (.ifc)", purpose: "BIM models — bridges, buildings, utilities", notes: "ISO 16739-1. Navisworks clash detection requires IFC." }
      ],
      output: [
        { ext: "LAS", purpose: "Classified point cloud deliverable", tier: "professional+" },
        { ext: "GeoTIFF", purpose: "DTM at 0.1–0.5m resolution", tier: "all" },
        { ext: "DXF", purpose: "Cross-sections, volume profiles", tier: "all" },
        { ext: "IFC", purpose: "BIM model with GIS-georeferenced coordinates", tier: "sovereign" },
        { ext: "PDF/A", purpose: "Survey report with ISO 19650 BIM data pack reference", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "RMSEz",
        name: "Vertical Accuracy (RMSEz)",
        formula: "RMSEz = sqrt(Σ(z_measured − z_reference)² / n)",
        thresholds: { QL2: "≤ 10cm RMSEz", QL1: "≤ 5cm RMSEz", QL0: "≤ 2.5cm RMSEz" },
        standard: "ASPRS LiDAR Specification 2019 §3; USGS 3DEP"
      },
      {
        id: "CutFillVolume",
        name: "Cut & Fill Earthwork Volumes",
        formula: "V_cut = Σ(A_cut × L), V_fill = Σ(A_fill × L) [Prismoidal method]",
        method: "TIN surface differencing between design grade and existing terrain",
        standard: "FIDIC contracts; AutoCAD Civil 3D surface volumes"
      },
      {
        id: "PavementCondition",
        name: "Pavement Condition Index (PCI)",
        formula: "PCI = 100 − CDV_max",
        variables: "CDV = Corrected Deduct Value, from distress density and severity per ASTM D6433",
        range: "0 (failed) to 100 (excellent)",
        thresholds: { excellent: "85–100", good: "70–84", fair: "55–69", poor: "40–54", failed: "0–39" },
        standard: "ASTM D6433-18; AASHTO Pavement Design Guide"
      },
      {
        id: "Settlement",
        name: "Primary Consolidation Settlement",
        formula: "δ_primary = (Cc / (1 + e₀)) × H × log₁₀((σ'v0 + Δσ) / σ'v0)",
        variables: "Cc = compression index, e₀ = initial void ratio, H = layer thickness (m), σ'v0 = effective vertical stress, Δσ = stress increase",
        units: "mm or m",
        standard: "Eurocode 7 (BS EN 1997); Terzaghi consolidation theory"
      },
      {
        id: "FloodInundation",
        name: "Rational Method Peak Flood Flow",
        formula: "Q = C × I × A",
        variables: "Q = peak flow (m³/s), C = runoff coefficient (0.2–0.95), I = rainfall intensity (mm/h), A = catchment area (km²)",
        standard: "JKR Urban Stormwater Management Manual (MSMA 2nd Ed.); HEC-RAS for routing"
      }
    ],

    reportSections: [
      { order: 1, title: "Project Information & BIM Execution Plan Reference", required: true, mandatory_content: "Project code, ISO 19650 information requirements, Level of Development (LOD 200/300/400), LOI (Level of Information)", regulatory_ref: "ISO 19650-2:2018 §5" },
      { order: 2, title: "LiDAR Survey Methodology", required: true, mandatory_content: "ASPRS quality level, sensor specs, flight altitude, speed, overlap %, GCP count, datum", regulatory_ref: "ASPRS LiDAR Spec 2019" },
      { order: 3, title: "Accuracy Assessment", required: true, mandatory_content: "Checkpoint RMSE table (horizontal and vertical), number of checkpoints, Class (ground/paved/vegetation)" },
      { order: 4, title: "Point Cloud Classification Report", required: true, mandatory_content: "Classes used (ASPRS classes 2/4/5/6/9), percentage per class, visual cross-section plots" },
      { order: 5, title: "DTM/DSM Products Description", required: true, mandatory_content: "Resolution, projection (UTM zone, datum), hydro-enforcement applied, voids (count + area + cause)" },
      { order: 6, title: "Earthwork Volume Calculations", required: false, mandatory_content: "Cut/fill table by chainage, mass-haul diagram, import/export balance" },
      { order: 7, title: "Infrastructure Asset Inventory", required: false, mandatory_content: "Bridges (span, width, clearance, condition rating), road furniture, utilities — linked to GIS feature IDs" },
      { order: 8, title: "Pavement Condition Assessment", required: false, mandatory_content: "PCI per road section, distress type and severity, recommended treatment (preventive/rehabilitation/reconstruction)" },
      { order: 9, title: "BIM-GIS Integration Summary", required: false, mandatory_content: "Coordinate reference system bridging method, IFC export parameters, Cesium ion/ArcGIS Scene reference" },
      { order: 10, title: "Metadata & Data Dictionary", required: true, mandatory_content: "LiDAR flight logs, point cloud tiling scheme, GeoTIFF projection metadata, all ASPRS class codes used" }
    ],

    workflowBenchmark: {
      currentTime: "4–12 weeks survey-to-design",
      currentSoftware: ["TerraSolid", "AutoCAD Civil 3D", "Revit", "Navisworks", "ArcGIS Pro", "FME"],
      currentCost: "$20,000–$100,000 per corridor survey + report",
      cahayaTime: "1–3 hours analysis",
      cahayaSteps: 3,
      valueSaved: "$15,000–$80,000 per survey report"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are an ASPRS-certified LiDAR processing specialist. Analyse the uploaded point cloud. Classify ground/vegetation/building/wire classes per ASPRS LAS classification. Generate DTM at 0.1m. Compute RMSEz from checkpoints. State quality level achieved per ASPRS 2019 specification.",
      reportPromptPrefix: "Generate a LiDAR survey report compliant with ASPRS LiDAR Specification 2019. Include checkpoint accuracy table with QL-level achieved. BIM reference per ISO 19650. JKR drawing block in report header. All volumes stated in cubic metres ±accuracy."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 9. FORESTRY / CARBON CREDITS
  // ─────────────────────────────────────────────────────────────────────────
  forestry: {
    meta: {
      name: "Forestry / Carbon Credits",
      icon: "🌲",
      regulatoryFramework: [
        "Verra VCS Standard v4.6 (VM0045 IFM, VM0007 REDD+, VM0010, VM0015)",
        "Gold Standard for the Global Goals (Land Use Activity)",
        "Climate Action Reserve Forest Project Protocol v4.0",
        "IPCC 2006 Guidelines for National GHG Inventories",
        "UNFCCC REDD+ Warsaw Framework (Decision 9/CP.19)",
        "ISO 14064-1:2018 (GHG Quantification — Forest Carbon)",
        "FAO NFMA (National Forest Monitoring Assessment) field protocols",
        "SBTi FLAG (Forest, Land and Agriculture) guidance"
      ],
      governingBodies: ["Verra Registry", "Gold Standard Foundation", "UNFCCC Secretariat", "Validation/Verification Bodies (VVB)"],
      governmentAcceptance: ["Verra VCS carbon credit issuance (VCU)", "REDD+ national registry", "SBTi FLAG accepted offset"],
      mandatoryDataFormat: "Shapefile for project boundary (Verra requirement); LAS for LiDAR-based carbon inventory"
    },

    fileFormats: {
      input: [
        { ext: "LAS / LAZ", purpose: "Aerial LiDAR — Canopy Height Model, AGB estimation", notes: "5–15 pts/m² sufficient for AGB regression. GEDI satellite LiDAR (HDF5) for national scale." },
        { ext: "GeoTIFF", purpose: "CHM, NDVI, Land cover change detection", notes: "Sentinel-2 10m or Planet NICFI 4.77m for monitoring." },
        { ext: "Shapefile / GeoPackage", purpose: "Project boundary, forest strata, field plot locations", notes: "Verra PDD REQUIRES Shapefile project boundary submission." },
        { ext: "CSV", purpose: "Field plot measurements (DBH, height, species)", notes: "Darwin Core or FAO NFMA format. Must include plot GPS coordinates (WGS84 to ±1m accuracy)." }
      ],
      output: [
        { ext: "GeoTIFF", purpose: "AGB raster (t/ha), CHM, land cover", tier: "all" },
        { ext: "GeoPackage", purpose: "Forest strata, plot locations, project boundary", tier: "professional+" },
        { ext: "CSV", purpose: "Carbon stock table per stratum with uncertainty", tier: "all" },
        { ext: "PDF/A", purpose: "Verra-formatted PDD sections + MRV report", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "AGB",
        name: "Above-Ground Biomass (Allometric)",
        formula: "AGB = a × DBH^b [species-specific allometric]; tropical default: AGB = 0.0509 × ρ × D² × H",
        variables: "DBH = diameter at breast height (cm), H = tree height (m), ρ = wood density (g/cm³)",
        units: "kg/tree → t/ha (sum / plot area × 10,000)",
        standard: "Chave et al. 2014 (pantropical); IPCC 2006 Table 4.5 for regional defaults"
      },
      {
        id: "CarbonStock",
        name: "Forest Carbon Stock",
        formula: "C_stock = AGB × CF, CF = 0.47 (IPCC default, tropical broadleaf)",
        units: "tC/ha",
        components: "AGB (above-ground) + BGB (below-ground = AGB × 0.235) + deadwood + litter + soil",
        standard: "IPCC 2006 Ch. 4; Verra VCS VM0045 §8"
      },
      {
        id: "VCU",
        name: "Verified Carbon Units",
        formula: "VCU = [(C_with − C_baseline) − Leakage] × (44/12)",
        variables: "C_with = project scenario carbon stock, C_baseline = business-as-usual stock, Leakage = market + activity shifting emissions",
        units: "tCO₂e/year",
        standard: "Verra VCS Standard v4.6 §8.1–8.6; VM0045 Equation 9"
      },
      {
        id: "CHM",
        name: "Canopy Height Model",
        formula: "CHM = DSM_first_return − DTM_ground",
        derivation: "From airborne LiDAR: DTM from last/ground returns (CSF algorithm), DSM from first returns",
        units: "m above ground level",
        standard: "ASPRS LiDAR classification; lidR R package (Roussel et al. 2020)"
      },
      {
        id: "DeforestationRate",
        name: "Historical Deforestation Rate",
        formula: "r = (ln(A_t0/A_t1)) / Δt",
        variables: "A_t0 = forest area at baseline, A_t1 = forest area at end of reference period, Δt = years",
        units: "% per year",
        purpose: "REDD+ baseline emission factor — required for PDD §5",
        standard: "UNFCCC REDD+ Warsaw Framework Decision 12/CP.17"
      }
    ],

    reportSections: [
      { order: 1, title: "Project Summary", required: true, mandatory_content: "Project title, proponent contacts, VCS methodology used, project start date, crediting period (30–100 years), project area (ha)", regulatory_ref: "Verra VCS Standard v4.6 §3.2" },
      { order: 2, title: "Project Activity Description", required: true, mandatory_content: "Location (country, GPS bounds, Shapefile), forest type, intervention activities (conservation, IFM, agroforestry)", regulatory_ref: "Verra PDD Template §2" },
      { order: 3, title: "Application of Methodology", required: true, mandatory_content: "Eligibility criteria checklist (all criteria met with evidence), applicability conditions compliance table", regulatory_ref: "VM0045 §3 or applicable methodology" },
      { order: 4, title: "Project Boundary & Maps", required: true, mandatory_content: "Legal description, Shapefile boundary (WGS84/GCS), stratum map, leakage belt boundary (min 20% of project area)", regulatory_ref: "Verra VCS Standard v4.6 §4.6" },
      { order: 5, title: "Baseline Scenario", required: true, mandatory_content: "Historical deforestation rate (10-year reference), reference region definition, BAU scenario carbon stock trajectory", regulatory_ref: "VM0045 §5; UNFCCC REDD+ Warsaw" },
      { order: 6, title: "Additionality Demonstration", required: true, mandatory_content: "Investment barrier analysis OR performance method (below benchmark deforestation rate)", regulatory_ref: "Verra VCS Tool for Demonstrating Additionality v4.0" },
      { order: 7, title: "GHG Quantification", required: true, mandatory_content: "Forest inventory results per stratum (AGB, BGB, deadwood, litter, soil), carbon stock map, uncertainty analysis (±10% target), VCU estimate with buffer pool allocation", regulatory_ref: "VM0045 §8; IPCC 2006 Tier 2" },
      { order: 8, title: "Monitoring Plan", required: true, mandatory_content: "Plot remeasurement schedule (5-year interval minimum), remote sensing update (annual Sentinel-2), trigger thresholds, QA/QC protocol", regulatory_ref: "Verra VCS Standard v4.6 §4.11" },
      { order: 9, title: "Environmental & Social Safeguards", required: true, mandatory_content: "FPIC (Free, Prior, Informed Consent) documentation, CCBS (Climate, Community & Biodiversity Standards) alignment if applicable, grievance mechanism" },
      { order: 10, title: "Permanence & Buffer Pool", required: true, mandatory_content: "Risk tool score (Verra Risk Tool), buffer pool allocation (% of VCUs withheld), permanence risk factors assessment", regulatory_ref: "Verra VCS Non-Permanence Risk Tool v4.0" },
      { order: 11, title: "LiDAR & Field Data Appendix", required: true, mandatory_content: "Sensor specs, flight parameters, point density, GCP accuracy, allometric equations (source, validation study, n, R²), field data forms" }
    ],

    workflowBenchmark: {
      currentTime: "18–36 months for first carbon project registration",
      currentSoftware: ["LAStools / lidR (R)", "ArcGIS Pro / QGIS", "R (biomass allometrics)", "Google Earth Engine", "Excel (inventory)"],
      currentCost: "$100,000–$500,000 per project registration",
      cahayaTime: "4–8 hours for carbon baseline report",
      cahayaSteps: 4,
      valueSaved: "$80,000–$400,000 per project"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a Verra-accredited forest carbon specialist. Analyse the uploaded LiDAR data. Compute CHM from first return minus ground return. Apply pantropical allometric equation (Chave et al. 2014) with wood density lookup for dominant species. Calculate AGB × 0.47 for carbon fraction. Apply IPCC 2006 below-ground biomass ratio 0.235. Estimate total carbon stock with ±15% uncertainty.",
      reportPromptPrefix: "Generate a Verra VCS Project Design Document (PDD) section for the GHG Quantification chapter. Use VM0045 equation structure. All carbon values in tCO₂e. Uncertainty must be reported at 90% confidence interval. Cite IPCC 2006 Guidelines for all default factors used."
    }
  },

  // ─────────────────────────────────────────────────────────────────────────
  // 10. EMERGENCY RESPONSE / DISASTER MANAGEMENT
  // ─────────────────────────────────────────────────────────────────────────
  disaster: {
    meta: {
      name: "Emergency Response / Disaster Management",
      icon: "🚨",
      regulatoryFramework: [
        "Sphere Handbook 2018 (minimum standards in humanitarian response)",
        "UN OCHA IASC Cluster System standards",
        "Sendai Framework for Disaster Risk Reduction 2015–2030",
        "FEMA Incident Command System (ICS) GIS standards",
        "Copernicus Emergency Management Service (EMS) protocols",
        "UNOSAT Emergency Mapping standards",
        "ISCGM (International Steering Committee for Global Mapping)",
        "ISO 22300:2021 (Security & resilience — Vocabulary)"
      ],
      governingBodies: ["UN OCHA", "FEMA", "Copernicus EMS", "UNOSAT", "National disaster management agencies"],
      governmentAcceptance: ["Copernicus EMS activation products", "FEMA hazard mitigation plan", "UN Situation Report maps", "National DM agency operational approval"],
      mandatoryDataFormat: "KMZ/KML for field teams; GeoPackage for GIS analysts; MBTiles for offline field maps; PDF sitrep"
    },

    fileFormats: {
      input: [
        { ext: "GeoTIFF", purpose: "SAR imagery (Sentinel-1), multispectral (Planet, Maxar) for damage assessment", notes: "Pre/post disaster imagery pairs. Sentinel-1 available within 6h of tasking." },
        { ext: "GeoPackage / Shapefile", purpose: "Administrative boundaries, population data, shelter locations", notes: "OCHA GADM admin boundaries; Worldpop population grid at 100m." },
        { ext: "MBTiles", purpose: "Offline basemaps for field teams with no internet", notes: "Mapbox offline tiles; OSM humanitarian basemap." },
        { ext: "KMZ", purpose: "Field team navigation, shelter coordinates, evac routes", notes: "Load into Garmin GPS, aPhone, or TAK/ATAK field platforms." }
      ],
      output: [
        { ext: "GeoPackage", purpose: "Full damage assessment GIS dataset", tier: "all" },
        { ext: "KMZ", purpose: "Field navigation overlays", tier: "all" },
        { ext: "MBTiles", purpose: "Offline field map package", tier: "sovereign" },
        { ext: "PDF Sitrep", purpose: "Situation report for authorities", tier: "all" }
      ]
    },

    keyIndices: [
      {
        id: "BuildingDamage_SAR",
        name: "SAR Building Damage Proxy Map",
        formula: "Damage = |σ⁰_post − σ⁰_pre| / σ⁰_pre",
        classification: { none: "< 10% change", partial: "10–30% change", severe: "> 30% change" },
        validation: "Copernicus EMS grading class: Destroyed / Heavily Damaged / Moderately Damaged",
        standard: "Copernicus EMS Technical Note EMSR; UNOSAT Damage Assessment Methodology v2.0"
      },
      {
        id: "FloodExtent",
        name: "Flood Extent Mapping (MNDWI)",
        formula: "MNDWI = (Green − SWIR) / (Green + SWIR) > 0.0 = flooded",
        note: "SAR: flooded pixels = low backscatter over urban (double bounce lost), high over open water",
        accuracy: "Typical OA: 90–96% vs field validation",
        standard: "Copernicus Global Flood Awareness System (GloFAS); UNOSAT Flood Mapping Guide"
      },
      {
        id: "BurnedArea",
        name: "Burned Area Index (NBR)",
        formula: "NBR = (NIR − SWIR2) / (NIR + SWIR2); dNBR = NBR_pre − NBR_post",
        classification: { regrowth: "dNBR < −0.1", unburned: "−0.1 to 0.1", low: "0.1–0.27", moderate: "0.27–0.44", high_moderate: "0.44–0.66", high: "> 0.66" },
        standard: "USFS (US Forest Service) burn severity classification; UN-SPIDER"
      },
      {
        id: "ShelterCapacity",
        name: "Emergency Shelter Capacity",
        formula: "Capacity = Floor_area_m² / 3.5",
        note: "3.5 m² per person is the Sphere Handbook emergency minimum",
        extended: "15 m²/person for longer-term displaced settings (Sphere 2018 §NFI)",
        standard: "Sphere Handbook 2018 Standard 2 (Shelter)"
      },
      {
        id: "EvacuationRoute",
        name: "Evacuation Route Accessibility",
        formula: "Time_to_safety = Σ(segment_length / speed_factor), speed_factor varies by road_condition × vehicle_type",
        method: "Network analysis (Dijkstra / A* algorithm) on OpenStreetMap road network + damage overlay",
        standard: "FEMA ICS §G-191 GIS; UN OCHA Spatial Data Infrastructure"
      }
    ],

    reportSections: [
      { order: 1, title: "Situation Overview", required: true, mandatory_content: "Event type, date/time, epicentre/origin (WGS84), affected area (km²), estimated population at risk", regulatory_ref: "UN OCHA Situation Report template" },
      { order: 2, title: "Data Sources & Timeliness", required: true, mandatory_content: "Satellite constellation, acquisition date/time (UTC), revisit gap from event, cloud cover, processing level" },
      { order: 3, title: "Damage Assessment Map", required: true, mandatory_content: "Building damage classes (Destroyed/Heavily/Moderately damaged/Intact), count per class, spatial distribution", regulatory_ref: "Copernicus EMS Grading; UNOSAT v2.0" },
      { order: 4, title: "Flood / Fire Extent", required: false, mandatory_content: "Inundation/burn area (km²), depth estimate where available, affected settlements, population exposed (Worldpop overlay)" },
      { order: 5, title: "Infrastructure Status", required: true, mandatory_content: "Roads: open/blocked/destroyed per segment; bridges: passable/damaged; hospitals/schools: intact/damaged/destroyed" },
      { order: 6, title: "Shelter & IDP Assessment", required: false, mandatory_content: "Shelter capacity (Sphere standard 3.5m²/person), IDP (Internally Displaced Persons) count estimate, open camp areas identified" },
      { order: 7, title: "Evacuation Route Analysis", required: true, mandatory_content: "Accessible routes to safe zones, estimated travel time, choke points, alternative routes if primary blocked" },
      { order: 8, title: "Humanitarian Access Constraints", required: true, mandatory_content: "Areas inaccessible due to flooding/damage/security, estimated population cut off" },
      { order: 9, title: "Response Priorities & Recommendations", required: true, mandatory_content: "Top 3–5 priority locations for immediate response, resource pre-positioning recommendations" },
      { order: 10, title: "Data Quality Statement", required: true, mandatory_content: "Known errors, change detection accuracy (if validated), areas requiring ground truth verification" }
    ],

    workflowBenchmark: {
      currentTime: "1–3 days for post-disaster assessment map",
      currentSoftware: ["ArcGIS Pro (ESRI Disaster Response)", "QGIS + SAGA", "Google Crisis Map", "Copernicus EMS"],
      currentCost: "N/A — government/NGO cost; timeliness = lives saved",
      cahayaTime: "20–45 minutes from satellite imagery to sitrep",
      cahayaSteps: 2,
      criticalNote: "Speed is the single most important metric. Every hour of delay = additional casualties"
    },

    aiPromptGuidance: {
      geePromptPrefix: "You are a Copernicus EMS emergency mapping specialist. You have 30 minutes to produce a usable damage assessment. Analyse the pre/post SAR imagery pair. Classify building damage into 4 classes (Destroyed/Heavily/Moderate/Intact) using backscatter differencing. Map flood extent using MNDWI. Identify passable evacuation routes. All coordinates in WGS84 decimal degrees.",
      reportPromptPrefix: "Generate an emergency situation report. Format: UN OCHA SitRep template. BLUF in first paragraph. All population figures cited from Worldpop 2020. Damage counts in table format. Response priority list at the end. Time-stamp every analysis result."
    }
  }

};

// ─────────────────────────────────────────────────────────────────────────
// HELPER FUNCTIONS — Used by report generators and AI prompt builders
// ─────────────────────────────────────────────────────────────────────────

/**
 * Get methodology for a domain ID
 * @param {string} domainId - e.g. "agriculture", "mining"
 * @returns {Object} methodology object
 */
window.getMethodology = function(domainId) {
  return window.METHODOLOGY_LIBRARY[domainId] || null;
};

/**
 * Get GEE prompt prefix for a domain
 */
window.getGeePromptPrefix = function(domainId) {
  const m = window.getMethodology(domainId);
  return m ? m.aiPromptGuidance.geePromptPrefix : "";
};

/**
 * Get report prompt prefix for a domain
 */
window.getReportPromptPrefix = function(domainId) {
  const m = window.getMethodology(domainId);
  return m ? m.aiPromptGuidance.reportPromptPrefix : "";
};

/**
 * Get mandatory report sections for a domain (required only)
 */
window.getRequiredReportSections = function(domainId) {
  const m = window.getMethodology(domainId);
  if (!m) return [];
  return m.reportSections.filter(s => s.required).sort((a,b) => a.order - b.order);
};

/**
 * Get formula by ID for a domain
 */
window.getFormula = function(domainId, formulaId) {
  const m = window.getMethodology(domainId);
  if (!m) return null;
  const all = [...(m.keyIndices || []), ...(m.formulas || [])];
  return all.find(f => f.id === formulaId) || null;
};

/**
 * Get workflow benchmark comparison string
 */
window.getWorkflowImpact = function(domainId) {
  const m = window.getMethodology(domainId);
  if (!m || !m.workflowBenchmark) return "";
  const b = m.workflowBenchmark;
  return `Industry standard: ${b.currentTime} | CAHAYA: ${b.cahayaTime} | Saved: ${b.valueSaved || "significant time & cost"}`;
};

/**
 * Generate regulatory compliance header string for report PDFs
 */
window.getComplianceHeader = function(domainId) {
  const m = window.getMethodology(domainId);
  if (!m) return "";
  return `Prepared in compliance with: ${m.meta.regulatoryFramework.slice(0,3).join("; ")}`;
};

/**
 * Validate that an output PDF contains all mandatory sections
 * Returns array of missing sections
 */
window.validateReportSections = function(domainId, presentSectionTitles) {
  const required = window.getRequiredReportSections(domainId);
  const missing = required.filter(req =>
    !presentSectionTitles.some(title =>
      title.toLowerCase().includes(req.title.toLowerCase().substring(0,15))
    )
  );
  return missing;
};

console.log("📚 CAHAYA Methodology Library loaded —", Object.keys(window.METHODOLOGY_LIBRARY).length, "industry verticals ready.");
