"""
LENUDA™ Premium 2.0 — Authentication Service
================================================
Handles:
  - Supabase Auth token validation
  - Google OAuth token exchange
  - Session management via JWT
  - Admin role checking
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any

import httpx
import jwt as pyjwt  # PyJWT

from config import (
    SUPABASE_URL,
    SUPABASE_KEY,
    SUPABASE_SERVICE_KEY,
    SESSION_SECRET,
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    is_admin_email,
)

logger = logging.getLogger("auth_service")

JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24


# ============================================================================
# JWT SESSION TOKEN
# ============================================================================

def create_session_token(
    user_id: str,
    email: str,
    role: str = "user",
    extra_claims: Optional[Dict[str, Any]] = None,
) -> str:
    """Create a signed JWT session token for the LENUDA frontend."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "iat": now,
        "exp": now + timedelta(hours=JWT_EXPIRY_HOURS),
        **(extra_claims or {}),
    }
    return pyjwt.encode(payload, SESSION_SECRET, algorithm=JWT_ALGORITHM)


def verify_session_token(token: str) -> Optional[Dict[str, Any]]:
    """Verify and decode a LENUDA session JWT. Returns claims dict or None."""
    try:
        payload = pyjwt.decode(token, SESSION_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except pyjwt.ExpiredSignatureError:
        logger.warning("Session token expired")
        return None
    except pyjwt.InvalidTokenError as e:
        logger.warning(f"Invalid session token: {e}")
        return None


# ============================================================================
# SUPABASE AUTH — Validate Supabase Access Token
# ============================================================================

async def validate_supabase_token(access_token: str) -> Optional[Dict[str, Any]]:
    """
    Validate a Supabase access token by calling the /auth/v1/user endpoint.
    Returns user data dict if valid, None otherwise.
    """
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.error("Supabase not configured for auth validation")
        return None

    url = f"{SUPABASE_URL}/auth/v1/user"
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {access_token}",
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                user_data = resp.json()
                return {
                    "id": user_data.get("id"),
                    "email": user_data.get("email"),
                    "role": user_data.get("role", "authenticated"),
                    "app_metadata": user_data.get("app_metadata", {}),
                    "user_metadata": user_data.get("user_metadata", {}),
                    "created_at": user_data.get("created_at"),
                }
            else:
                logger.warning(f"Supabase token validation failed: {resp.status_code}")
                return None
    except Exception as e:
        logger.error(f"Supabase auth error: {e}")
        return None


# ============================================================================
# GOOGLE OAUTH — Token Exchange
# ============================================================================

async def exchange_google_oauth_code(
    code: str,
    redirect_uri: str = "http://localhost:3000/auth/callback/google",
) -> Optional[Dict[str, Any]]:
    """
    Exchange a Google OAuth authorization code for tokens.
    Returns user info + tokens.
    """
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        return {"error": "Google OAuth not configured"}

    token_url = "https://oauth2.googleapis.com/token"

    try:
        async with httpx.AsyncClient() as client:
            # Exchange code for tokens
            resp = await client.post(token_url, data={
                "code": code,
                "client_id": GOOGLE_CLIENT_ID,
                "client_secret": GOOGLE_CLIENT_SECRET,
                "redirect_uri": redirect_uri,
                "grant_type": "authorization_code",
            }, timeout=15)

            if resp.status_code != 200:
                logger.error(f"Google OAuth token exchange failed: {resp.status_code}")
                return {"error": f"Token exchange failed: {resp.status_code}"}

            tokens = resp.json()
            access_token = tokens.get("access_token")
            id_token = tokens.get("id_token")

            # Get user info
            user_resp = await client.get(
                "https://www.googleapis.com/oauth2/v2/userinfo",
                headers={"Authorization": f"Bearer {access_token}"},
                timeout=10,
            )

            if user_resp.status_code == 200:
                user_info = user_resp.json()
                return {
                    "google_id": user_info.get("id"),
                    "email": user_info.get("email"),
                    "name": user_info.get("name"),
                    "picture": user_info.get("picture"),
                    "access_token": access_token,
                    "id_token": id_token,
                    "refresh_token": tokens.get("refresh_token"),
                }
            else:
                return {"error": f"Failed to get user info: {user_resp.status_code}"}

    except Exception as e:
        logger.error(f"Google OAuth error: {e}")
        return {"error": str(e)}


# ============================================================================
# COMBINED AUTH — Extract User from Request
# ============================================================================

async def authenticate_request(
    authorization: Optional[str] = None,
    cookie_token: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Authenticate a request using either:
    1. Bearer token (Supabase access token) from Authorization header
    2. Session JWT from cookie

    Returns user dict with id, email, role, is_admin fields.
    """
    # Try Bearer token first
    if authorization and authorization.startswith("Bearer "):
        token = authorization[7:]

        # Try as Supabase token
        user = await validate_supabase_token(token)
        if user:
            user["is_admin"] = is_admin_email(user.get("email", ""))
            user["auth_method"] = "supabase"
            return user

        # Try as session JWT
        claims = verify_session_token(token)
        if claims:
            return {
                "id": claims["sub"],
                "email": claims.get("email", ""),
                "role": claims.get("role", "user"),
                "is_admin": is_admin_email(claims.get("email", "")),
                "auth_method": "session_jwt",
            }

    # Try cookie token
    if cookie_token:
        claims = verify_session_token(cookie_token)
        if claims:
            return {
                "id": claims["sub"],
                "email": claims.get("email", ""),
                "role": claims.get("role", "user"),
                "is_admin": is_admin_email(claims.get("email", "")),
                "auth_method": "cookie_jwt",
            }

    return None
