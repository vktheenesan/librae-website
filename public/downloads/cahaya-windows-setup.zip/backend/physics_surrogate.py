"""
LENUDA™ — Physics Surrogate Engine (Powered by The Well)
============================================================
Provides pre-trained Fourier Neural Operators (FNO) to act as physics surrogates
for real-time thermal convection (Rayleigh-Bénard) simulations in 3D twins.
Includes graceful fallback if PyTorch/the_well are not installed.
"""

import logging
import math
import random

logger = logging.getLogger("physics_surrogate")

try:
    import torch
    from the_well.benchmark.models import FNO
    _HAS_TORCH_AND_WELL = True
except ImportError:
    _HAS_TORCH_AND_WELL = False
    logger.warning("PyTorch or Polymathic 'the_well' not installed. Falling back to math-surrogate simulation.")

class PhysicsSurrogateEngine:
    def __init__(self):
        self.enabled = False
        self.device = "cpu"
        if _HAS_TORCH_AND_WELL:
            try:
                # Detect and enable CUDA acceleration (e.g. GCP GPU nodes)
                self.device = "cuda" if torch.cuda.is_available() else "cpu"
                logger.info(f"Loading pre-trained FNO model 'polymathic-ai/FNO-rayleigh_benard' on device: {self.device}...")
                self.thermal_model = FNO.from_pretrained("polymathic-ai/FNO-rayleigh_benard")
                self.thermal_model.to(self.device)
                self.thermal_model.eval()
                self.enabled = True
            except Exception as e:
                logger.error(f"Failed to load FNO model weights: {e}. Fallback active.")
                self.enabled = False
        else:
            self.enabled = False

    def simulate_thermal_stress(self, initial_state_grid):
        """
        Runs real-time Navier-Stokes PDE thermal convection surrogate simulation.
        If PyTorch FNO is active, runs tensor inference on the designated device (GCP GPU/CPU).
        If inactive, calculates a mathematical Rayleigh-Bénard harmonic convection flow.
        """
        if self.enabled:
            try:
                # Convert list to PyTorch tensor and move to GPU/CPU device
                with torch.no_grad():
                    input_tensor = torch.tensor(initial_state_grid, dtype=torch.float32).to(self.device)
                    # Run FNO forward pass
                    predicted_state = self.thermal_model(input_tensor)
                    # Move result back to CPU for list serialization
                    return predicted_state.cpu().tolist()
            except Exception as e:
                logger.error(f"Error running neural FNO simulation on {self.device}: {e}. Falling back to math approximation.")

        # Fallback Math Simulation: Rayleigh-Bénard Convection Cell approximation
        # Generates alternating convective updrafts/downdrafts (plumes)
        # Input grid size: assume 32x32 if not specified
        rows = len(initial_state_grid) if initial_state_grid else 32
        cols = len(initial_state_grid[0]) if (initial_state_grid and initial_state_grid[0]) else 32
        
        simulated_grid = []
        for r in range(rows):
            row_data = []
            for c in range(cols):
                # Normalized coordinates
                x = c / float(cols) * 2.0 * math.pi
                y = r / float(rows) * 2.0 * math.pi
                
                # Convection cells formula: combines vertical temperature gradient and spatial harmonics
                cell1 = math.sin(2.0 * x) * math.cos(2.0 * y)
                cell2 = 0.5 * math.sin(4.0 * x) * math.sin(4.0 * y)
                
                # Base temperature + convection perturbation + small physical turbulence
                temp = 25.0 - (r / float(rows) * 15.0)  # temperature decreases with height
                convection_flow = 3.5 * (cell1 + cell2)
                noise = random.uniform(-0.2, 0.2)
                
                final_value = round(temp + convection_flow + noise, 3)
                row_data.append(final_value)
            simulated_grid.append(row_data)
            
        return simulated_grid

    def generate_velocity_field(self, spatial_grid):
        """
        Generates 2D velocity vector fields (u, v) matching the convection cells
        for Unreal Engine 5 mesh animation.
        """
        rows = len(spatial_grid)
        cols = len(spatial_grid[0])
        
        u_vectors = []  # horizontal velocities
        v_vectors = []  # vertical velocities
        
        for r in range(rows):
            u_row = []
            v_row = []
            for c in range(cols):
                x = c / float(cols) * 2.0 * math.pi
                y = r / float(rows) * 2.0 * math.pi
                
                # Velocity derived from stream function: u = d(psi)/dy, v = -d(psi)/dx
                # psi = sin(x)*sin(y)
                u = math.sin(x) * math.cos(y) * 2.0  # Convection roll flow
                v = -math.cos(x) * math.sin(y) * 2.0
                
                u_row.append(round(u, 4))
                v_row.append(round(v, 4))
            u_vectors.append(u_row)
            v_vectors.append(v_row)
            
        return {
            "u_field": u_vectors,
            "v_field": v_vectors
        }
