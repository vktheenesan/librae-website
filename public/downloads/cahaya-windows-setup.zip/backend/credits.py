"""
LENUDA™ — Credit Management
==============================
All credit-related operations: query, update, deduct (atomic), and request.
Extracted from app.py to enable single-responsibility and testability.
"""

import requests
from typing import Optional
from config import SUPABASE_URL, get_supabase_api_key


# ============================================================================
# QUERY CREDITS
# ============================================================================

def get_profile_credits(user_id: str) -> Optional[int]:
    """Fetch latest user credits from profiles table."""
    if not SUPABASE_URL or not user_id:
        return None

    api_key = get_supabase_api_key()
    if not api_key:
        return None

    try:
        url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/profiles?id=eq.{user_id}&select=credits&limit=1"
        headers = {
            'apikey': api_key,
            'Authorization': f'Bearer {api_key}',
        }
        response = requests.get(url, headers=headers, timeout=20)
        if response.status_code in (200, 206):
            rows = response.json() or []
            if rows:
                return int(rows[0].get('credits') or 0)
        return None
    except Exception:
        return None


# ============================================================================
# UPDATE CREDITS
# ============================================================================

def update_profile_credits(user_id: str, new_credits: int) -> bool:
    """Update user credits in profiles table."""
    if not SUPABASE_URL or not user_id:
        return False

    api_key = get_supabase_api_key()
    if not api_key:
        return False

    try:
        url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/profiles?id=eq.{user_id}"
        headers = {
            'apikey': api_key,
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
            'Prefer': 'return=minimal'
        }
        response = requests.patch(url, headers=headers, json={'credits': int(new_credits)}, timeout=20)
        return response.status_code in (200, 204)
    except Exception:
        return False


# ============================================================================
# REQUEST CREDITS
# ============================================================================

def submit_credit_request(user_id: str, user_email: str, requested_credits: int, reason: str) -> dict:
    """Insert a credit request for admin review queue."""
    if not SUPABASE_URL or not user_id:
        raise RuntimeError('Missing Supabase URL or user id')

    api_key = get_supabase_api_key()
    if not api_key:
        raise RuntimeError('Supabase credentials not configured')

    url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/credit_requests"
    headers = {
        'apikey': api_key,
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
    }
    payload = {
        'user_id': user_id,
        'user_email': user_email,
        'requested_credits': int(requested_credits),
        'reason': reason,
        'status': 'pending'
    }
    response = requests.post(url, headers=headers, json=payload, timeout=20)
    if response.status_code not in (200, 201):
        raise RuntimeError(f"Credit request failed: {response.status_code} - {response.text}")
    return response.json()


# ============================================================================
# ATOMIC CREDIT DEDUCTION (RPC)
# ============================================================================

def deduct_user_credits_atomic(user_id: str, amount: int, description: str = None, metadata: dict = None) -> dict:
    """
    Deduct credits atomically using Supabase RPC function.
    Prevents race conditions during concurrent credit deductions.

    Returns:
        dict with keys: success, previous_credits, new_credits, deducted,
        transaction_id, error, code
    """
    if not SUPABASE_URL or not user_id:
        return {'success': False, 'error': 'Missing Supabase URL or user ID', 'code': 'MISSING_CONFIG'}

    api_key = get_supabase_api_key()
    if not api_key:
        return {'success': False, 'error': 'Supabase credentials not configured', 'code': 'MISSING_CREDENTIALS'}

    try:
        # Use the logged version if description or metadata provided
        if description or metadata:
            url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/rpc/deduct_user_credits_with_log"
            payload = {
                'p_user_id': user_id,
                'p_amount': int(amount),
                'p_description': description,
                'p_metadata': metadata or {}
            }
        else:
            url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/rpc/deduct_user_credits"
            payload = {
                'p_user_id': user_id,
                'p_amount': int(amount)
            }

        headers = {
            'apikey': api_key,
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }

        response = requests.post(url, headers=headers, json=payload, timeout=20)

        if response.status_code == 200:
            return response.json()
        else:
            return {
                'success': False,
                'error': f'RPC call failed: {response.status_code}',
                'code': 'RPC_ERROR'
            }
    except Exception as e:
        return {
            'success': False,
            'error': f'Exception during credit deduction: {str(e)}',
            'code': 'EXCEPTION'
        }

def get_profile_storage(user_id: str) -> dict:
    """Fetch storage details from profiles table."""
    fallback = {'used_bytes': 0, 'limit_bytes': 107374182400}  # 100GB default fallback
    if not SUPABASE_URL or not user_id:
        return fallback
    api_key = get_supabase_api_key()
    if not api_key:
        return fallback
    try:
        url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/profiles?id=eq.{user_id}&select=storage_used_bytes,storage_limit_bytes&limit=1"
        headers = {
            'apikey': api_key,
            'Authorization': f'Bearer {api_key}',
        }
        response = requests.get(url, headers=headers, timeout=20)
        if response.status_code in (200, 206):
            rows = response.json() or []
            if rows:
                return {
                    'used_bytes': int(rows[0].get('storage_used_bytes') or 0),
                    'limit_bytes': int(rows[0].get('storage_limit_bytes') or 107374182400)
                }
        return fallback
    except Exception:
        return fallback

def update_profile_storage(user_id: str, new_used_bytes: int) -> bool:
    """Updates storage_used_bytes on Supabase profiles table."""
    if not SUPABASE_URL or not user_id:
        return False
    api_key = get_supabase_api_key()
    if not api_key:
        return False
    try:
        url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/profiles?id=eq.{user_id}"
        headers = {
            'apikey': api_key,
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        payload = {
            'storage_used_bytes': int(new_used_bytes)
        }
        response = requests.patch(url, headers=headers, json=payload, timeout=20)
        return response.status_code in (200, 204, 201)
    except Exception:
        return False
