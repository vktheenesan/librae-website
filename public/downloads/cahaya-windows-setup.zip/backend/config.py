"""
LENUDA™ Premium 2.0 — Centralized Configuration (FastAPI)
============================================================
Single source of truth for environment config, admin aliases, and Supabase credentials.
Adapted from legacy Streamlit config — uses pure os.getenv() and python-dotenv.
All other modules import from here to avoid duplication.
"""

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# ============================================================================
# LOAD .env FROM PARENT DIRECTORY
# ============================================================================

_ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(_ENV_PATH, override=False)

# ============================================================================
# GOOGLE CLOUD CREDENTIALS AUTO-LOAD
# ============================================================================

def _initialize_gcp_credentials():
    """If GOOGLE_APPLICATION_CREDENTIALS is not set, look for local keys."""
    if not os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
        base_dir = Path(__file__).resolve().parent
        possible_keys = [
            base_dir.parent / "secrets" / "esg-lenuda-key.json",
            base_dir / "esg-lenuda-key.json",
            base_dir / ".gcp_credentials.json",
            base_dir / "antigravity-gcp-key.json",
        ]
        for key_path in possible_keys:
            if key_path.exists():
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(key_path)
                os.environ.setdefault("GOOGLE_CLOUD_PROJECT", "esg-lenuda")
                break

_initialize_gcp_credentials()
GCP_PROJECT_ID: str = os.getenv("GOOGLE_CLOUD_PROJECT", "esg-lenuda")


# ============================================================================
# CONFIG LOADER
# ============================================================================

def cfg(key: str, default=None):
    """Load config from environment variables → default."""
    return os.getenv(key, default)


# ============================================================================
# ADMIN EMAIL ALIASES — single canonical list
# ============================================================================

ADMIN_EMAIL_ALIASES = {
    "oneedusmartresources@gmail.com",
}

_env_admin = cfg("ADMIN_EMAIL", "")
if _env_admin:
    ADMIN_EMAIL_ALIASES.add(str(_env_admin).strip().lower())


def is_admin_email(email: str) -> bool:
    """Check if an email belongs to an admin user."""
    if not email:
        return False
    return str(email).strip().lower() in ADMIN_EMAIL_ALIASES


# ============================================================================
# SUPABASE CONFIG
# ============================================================================

SUPABASE_URL: Optional[str] = cfg("SUPABASE_URL")
SUPABASE_KEY: Optional[str] = cfg("SUPABASE_KEY") or cfg("SUPABASE_ANON_KEY")
SUPABASE_SERVICE_KEY: Optional[str] = cfg("SUPABASE_SERVICE_KEY") or cfg("SUPABASE_SERVICE_ROLE_KEY")


def get_supabase_api_key() -> Optional[str]:
    """Return the best available Supabase API key (service key preferred)."""
    return SUPABASE_SERVICE_KEY or SUPABASE_KEY


# ============================================================================
# AI / LLM KEYS
# ============================================================================

GEMINI_API_KEY: str = cfg("GEMINI_API_KEY", "")
GEMINI_PROJECT: str = cfg("GEMINI_PROJECT", "")
ALIBABA_MODEL_STUDIO_API_KEY: str = cfg("ALIBABA_MODEL_STUDIO_API_KEY", "")
LLM_API_BASE: str = cfg("LLM_API_BASE", "")
LLM_MODEL_NAME: str = cfg("LLM_MODEL_NAME", "qwen3.7-max")
ANTHROPIC_API_KEY: str = cfg("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY: str = cfg("OPENAI_API_KEY", "")

# ============================================================================
# STRIPE
# ============================================================================

STRIPE_SECRET_KEY: str = cfg("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET: str = cfg("STRIPE_WEBHOOK_SECRET", "")

# ============================================================================
# SESSION SECRET
# ============================================================================

SESSION_SECRET: str = cfg("SESSION_SECRET", "librae_portal_secret_2026")

# ============================================================================
# ESRI ARCGIS CREDENTIALS
# ============================================================================

ESRI_CLIENT_ID: str = cfg("ESRI_CLIENT_ID", "")
ESRI_CLIENT_SECRET: str = cfg("ESRI_CLIENT_SECRET", "")
NEXT_PUBLIC_ESRI_REDIRECT_URI: str = cfg("NEXT_PUBLIC_ESRI_REDIRECT_URI", "http://localhost:3000/auth/callback/esri")
ESRI_TEMPORARY_TOKEN: str = cfg("ESRI_TEMPORARY_TOKEN", "")

# ============================================================================
# RESEND EMAIL
# ============================================================================

RESEND_API_KEY: str = cfg("RESEND_API_KEY", "")

# ============================================================================
# GOOGLE OAUTH
# ============================================================================

GOOGLE_CLIENT_ID: str = cfg("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET: str = cfg("GOOGLE_CLIENT_SECRET", "")

# ============================================================================
# BAYU CRM SUPABASE (secondary)
# ============================================================================

BAYU_SUPABASE_URL: Optional[str] = cfg("BAYU_SUPABASE_URL") or SUPABASE_URL
BAYU_SUPABASE_KEY: Optional[str] = cfg("BAYU_SUPABASE_SERVICE_ROLE_KEY") or cfg("BAYU_SUPABASE_ANON_KEY") or cfg("BAYU_SUPABASE_KEY") or SUPABASE_KEY

# ============================================================================
# BUILD INFO
# ============================================================================

APP_BUILD: str = cfg("APP_BUILD", cfg("RAILWAY_GIT_COMMIT_SHA", "lenuda-premium-2.0"))
