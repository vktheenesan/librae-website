"""
CAHAYA Sovereign — Work Order Engine
=====================================
Principle: Plan → Confirm → Execute. No computation waste.

When a user sends any task request, CAHAYA NEVER immediately runs it.
Instead it generates a structured Work Order showing:
  - Location (with polygon preview)
  - Time frame (dates, comparison period)
  - Data sources (which satellites, why)
  - Analysis steps (numbered, method cited)
  - Simulation actors / NPCs (if scenario needed)
  - Outputs planned (what files they will receive)
  - Estimated cost (credits + time)

User reviews, edits any section, confirms.
Only after explicit approval does CAHAYA execute.

This ensures:
  1. Perfect alignment — user gets exactly what they asked for
  2. Zero wasted compute — no API calls until approved
  3. Scientific traceability — every step is pre-declared
  4. User education — they learn what CAHAYA is doing and why
"""

import uuid
import json
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from pydantic import BaseModel

logger = logging.getLogger("work_order")

# ── Models ─────────────────────────────────────────────────────────────────────

class WorkOrderLocation(BaseModel):
    name: str
    country: str = "Malaysia"
    polygon_geojson: Optional[Dict] = None   # GeoJSON polygon for map preview
    bbox: Optional[List[float]] = None       # [west, south, east, north]
    area_km2: Optional[float] = None
    confidence: str = "high"                 # high / medium / low — how sure we are

class WorkOrderTimeframe(BaseModel):
    baseline_date: Optional[str] = None      # e.g. "2020-01-01" (EUDR cutoff)
    start_date: str                          # Analysis start
    end_date: str                            # Analysis end (today by default)
    description: str                         # Human-readable summary

class WorkOrderDataSource(BaseModel):
    name: str                                # e.g. "Sentinel-2 MSI"
    purpose: str                             # Why we're using it
    resolution_m: Optional[int] = None
    frequency: Optional[str] = None         # e.g. "5-day revisit"

class WorkOrderStep(BaseModel):
    step: int
    action: str                              # What happens
    method: str                              # Algorithm/standard used
    cite: Optional[str] = None              # DOI or standard reference

class WorkOrderActor(BaseModel):
    type: str                                # e.g. "logging_operator", "plantation_zone"
    label: str                               # Human-readable name
    count: int = 1
    behavior: str                            # What this actor does in simulation
    parameters: Optional[Dict] = None

class WorkOrderOutput(BaseModel):
    type: str                                # "geojson", "pdf_report", "mp4", "csv", "ots"
    label: str                               # Human-readable name
    included: bool = True
    note: Optional[str] = None

class WorkOrder(BaseModel):
    work_order_id: str
    title: str
    domain: str
    status: str = "pending_approval"         # pending_approval | approved | executing | done | cancelled
    created_at: str
    user_intent: str                         # The original user message verbatim

    location: WorkOrderLocation
    timeframe: WorkOrderTimeframe
    data_sources: List[WorkOrderDataSource]
    analysis_steps: List[WorkOrderStep]
    simulation_actors: List[WorkOrderActor] = []
    outputs: List[WorkOrderOutput]

    estimated_credits: int
    estimated_minutes: int
    methodology_standards: List[str] = []   # e.g. ["EUDR Article 3(1)", "JORC 2012"]
    special_notes: List[str] = []           # Any caveats or assumptions made

    # Set after execution
    result: Optional[Dict] = None
    executed_at: Optional[str] = None


# ── Work Order Generator ───────────────────────────────────────────────────────

WORK_ORDER_SYSTEM_PROMPT = """You are CAHAYA's Work Order Generator.
Your job is to interpret a user's spatial intelligence request and output a
COMPLETE, DETAILED work order in JSON format.

Rules:
1. ALWAYS infer a specific polygon/location — never leave it vague.
   For "Klang", use the Klang Valley bounding box. For "Perak", use Perak state.
2. ALWAYS specify exact date ranges. If "2026" is mentioned, use 2026-01-01 to today.
   If comparing deforestation, set baseline_date to "2020-12-31" (EUDR cutoff).
3. Auto-select the right satellites for the domain:
   Forestry/Agriculture → Sentinel-2 + Sentinel-1 SAR
   Coastal/Maritime → Sentinel-2 + Landsat-9
   Mining → Sentinel-2 + Planet Labs (if available)
   Urban → Sentinel-2 + Copernicus DEM
4. Add simulation actors (NPCs) ONLY if the task involves a simulation/scenario.
   For deforestation, actors = logging operators, plantation zones, encroachment fronts.
   For flood, actors = water sources, drainage capacity, population zones.
   For wildfire, actors = ignition points, wind direction zones, fuel load.
5. Estimate credits based on area × time span × outputs:
   Small area (<100km²): 200-400 credits
   Medium (100-1000km²): 400-900 credits
   Large (>1000km²): 900-2000 credits
6. Estimate time based on complexity: simple=1-3min, medium=3-8min, complex=8-20min.
7. List ONLY the outputs the user actually needs. Default: GeoJSON + PDF report.
   Add MP4 only if user mentions "simulate", "animation", "video", "scenario".
   Add OpenTimestamps proof by default (it's free and important for compliance).

Output ONLY valid JSON matching the work order schema. No markdown, no explanation."""


async def generate_work_order(
    user_message: str,
    domain: str = "agriculture",
    context: Optional[Dict] = None,
) -> WorkOrder:
    """
    Generate a complete Work Order from a user's natural language request.
    Calls the AI to interpret intent, infer location/time, plan steps.
    Returns a WorkOrder that must be approved before execution.
    """
    from ollama_router import route_to_ollama
    from ai_router import route_to_gemini

    work_order_id = f"WO-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
    now = datetime.now(timezone.utc)

    schema_example = _build_schema_example(work_order_id, user_message, domain, now)

    prompt = f"""User request: "{user_message}"
Domain: {domain}
Today's date: {now.strftime('%Y-%m-%d')}
Context: {json.dumps(context or {}, indent=2)}

Generate a complete work order JSON for this request.
The JSON must follow this exact schema:
{json.dumps(schema_example, indent=2)}

Fill in all fields with specific, accurate information for the user's request.
Infer location polygons, dates, data sources, steps, and actors from the request.
Be specific and detailed — vague entries are not acceptable."""

    # Try local AI first (Qwen preferred for this structured task)
    result = await route_to_ollama(
        prompt=prompt,
        system_message=WORK_ORDER_SYSTEM_PROMPT,
        temperature=0.3,  # Low temp for structured output
        force_model="qwen2.5:32b" if _check_tier_sovereign_or_standard() else None,
    )

    raw = result.get("text", "")

    # Fallback to Gemini if local AI failed or gave poor output
    if result.get("fallback_required") or len(raw) < 200:
        logger.info("Work order generation falling back to Gemini")
        gem = await route_to_gemini(
            prompt=prompt,
            system_instruction=WORK_ORDER_SYSTEM_PROMPT,
        )
        raw = gem.get("text", "")

    # Parse the JSON response
    work_order_dict = _parse_work_order_json(raw, work_order_id, user_message, domain, now)
    return WorkOrder(**work_order_dict)


def _parse_work_order_json(raw: str, work_order_id: str, user_message: str, domain: str, now) -> Dict:
    """Parse AI response into valid work order dict, with fallback defaults."""
    import re

    # Strip markdown code blocks if present
    raw = re.sub(r"```(?:json)?\s*", "", raw).strip().rstrip("```").strip()

    try:
        parsed = json.loads(raw)
        # Ensure required fields exist
        parsed.setdefault("work_order_id", work_order_id)
        parsed.setdefault("status", "pending_approval")
        parsed.setdefault("created_at", now.isoformat())
        parsed.setdefault("user_intent", user_message)
        parsed.setdefault("domain", domain)
        return parsed
    except json.JSONDecodeError:
        logger.warning(f"Work order JSON parse failed, using fallback. Raw: {raw[:200]}")
        return _fallback_work_order(work_order_id, user_message, domain, now)


def _fallback_work_order(work_order_id: str, user_message: str, domain: str, now) -> Dict:
    """Minimal fallback work order when AI parse fails."""
    today = now.strftime("%Y-%m-%d")
    return {
        "work_order_id": work_order_id,
        "title": f"Analysis — {user_message[:60]}",
        "domain": domain,
        "status": "pending_approval",
        "created_at": now.isoformat(),
        "user_intent": user_message,
        "location": {
            "name": "Location to be confirmed",
            "country": "Malaysia",
            "confidence": "low",
        },
        "timeframe": {
            "start_date": "2020-01-01",
            "end_date": today,
            "description": "2020 to present",
        },
        "data_sources": [
            {"name": "Sentinel-2 MSI", "purpose": "Optical imagery", "resolution_m": 10},
            {"name": "Sentinel-1 GRD", "purpose": "SAR radar backup", "resolution_m": 10},
        ],
        "analysis_steps": [
            {"step": 1, "action": "Location geocoding and polygon extraction", "method": "GEE geocoder"},
            {"step": 2, "action": "Satellite data acquisition", "method": "Google Earth Engine"},
            {"step": 3, "action": "Change detection analysis", "method": "ChangeFormer v2.1"},
            {"step": 4, "action": "Report generation", "method": "AI synthesis + PDF"},
        ],
        "simulation_actors": [],
        "outputs": [
            {"type": "geojson", "label": "Analysis boundaries", "included": True},
            {"type": "pdf_report", "label": "Intelligence report", "included": True},
            {"type": "ots", "label": "OpenTimestamps proof", "included": True},
        ],
        "estimated_credits": 500,
        "estimated_minutes": 5,
        "methodology_standards": [],
        "special_notes": ["⚠️ Location could not be auto-detected — please edit the location field"],
    }


def _build_schema_example(work_order_id: str, user_message: str, domain: str, now) -> Dict:
    """Build the schema template to show the AI what format to output."""
    today = now.strftime("%Y-%m-%d")
    return {
        "work_order_id": work_order_id,
        "title": "Descriptive title based on the request",
        "domain": domain,
        "status": "pending_approval",
        "created_at": now.isoformat(),
        "user_intent": user_message,
        "location": {
            "name": "Full place name",
            "country": "Country",
            "bbox": ["west_lng", "south_lat", "east_lng", "north_lat"],
            "area_km2": 0,
            "confidence": "high",
        },
        "timeframe": {
            "baseline_date": "2020-12-31",
            "start_date": "YYYY-MM-DD",
            "end_date": today,
            "description": "Human-readable range",
        },
        "data_sources": [
            {"name": "Satellite name", "purpose": "Why used", "resolution_m": 10, "frequency": "5-day revisit"}
        ],
        "analysis_steps": [
            {"step": 1, "action": "What happens", "method": "Algorithm/standard", "cite": "DOI or reference"}
        ],
        "simulation_actors": [
            {"type": "actor_type", "label": "Human label", "count": 1, "behavior": "What this actor does"}
        ],
        "outputs": [
            {"type": "geojson", "label": "Output name", "included": True},
            {"type": "pdf_report", "label": "Report name", "included": True},
            {"type": "ots", "label": "OpenTimestamps Bitcoin proof", "included": True},
        ],
        "estimated_credits": 500,
        "estimated_minutes": 5,
        "methodology_standards": ["Applicable standard 1", "Applicable standard 2"],
        "special_notes": ["Any assumptions or caveats"],
    }


def _check_tier_sovereign_or_standard() -> bool:
    """Check if we're on STANDARD or SOVEREIGN tier (can force Qwen for work orders)."""
    import os
    config_path = os.path.join(os.path.dirname(__file__), "..", "cahaya.config.json")
    try:
        with open(config_path) as f:
            return json.load(f).get("tier", "EDGE").upper() in ("STANDARD", "SOVEREIGN")
    except Exception:
        return False


# ── In-Memory Work Order Store ─────────────────────────────────────────────────
# In production, persist to Supabase. For now, session memory.
_work_order_store: Dict[str, WorkOrder] = {}


def save_work_order(wo: WorkOrder) -> WorkOrder:
    _work_order_store[wo.work_order_id] = wo
    return wo


def get_work_order(work_order_id: str) -> Optional[WorkOrder]:
    return _work_order_store.get(work_order_id)


def list_work_orders(limit: int = 20) -> List[WorkOrder]:
    orders = list(_work_order_store.values())
    orders.sort(key=lambda x: x.created_at, reverse=True)
    return orders[:limit]


# ── Work Order Executor ────────────────────────────────────────────────────────

async def execute_work_order(work_order_id: str) -> Dict[str, Any]:
    """
    Execute an approved Work Order. This is the ONLY function that
    actually runs GEE scans, simulations, and report generation.
    Called ONLY after user approval.
    """
    wo = get_work_order(work_order_id)
    if not wo:
        return {"success": False, "error": "Work order not found"}
    if wo.status == "executing":
        return {"success": False, "error": "Already executing"}
    if wo.status not in ("pending_approval", "approved"):
        return {"success": False, "error": f"Cannot execute — status: {wo.status}"}

    wo.status = "executing"
    save_work_order(wo)

    try:
        results = {}

        # Step 1: GEE Scan
        from earthquery_engine import run_earthquery
        location_str = wo.location.name
        prompt_summary = f"{wo.title} | {wo.timeframe.description}"

        gee_result = await run_earthquery(
            query=prompt_summary,
            location=location_str,
            domain=wo.domain,
            date_start=wo.timeframe.start_date,
            date_end=wo.timeframe.end_date,
        )
        results["gee"] = gee_result

        # Step 2: Generate report if PDF output requested
        pdf_outputs = [o for o in wo.outputs if o.type == "pdf_report" and o.included]
        if pdf_outputs:
            from ai_router import route_to_gemini
            report_text = await route_to_gemini(
                prompt=f"Generate a professional {wo.domain} intelligence report for: {wo.title}. "
                       f"Location: {wo.location.name}. Period: {wo.timeframe.description}. "
                       f"Standards: {', '.join(wo.methodology_standards)}. "
                       f"GEE data: {str(gee_result)[:2000]}",
                system_instruction="You are a professional GIS report writer. Output a structured report.",
            )
            results["report_text"] = report_text.get("text", "")

        # Step 3: OpenTimestamps proof
        ots_outputs = [o for o in wo.outputs if o.type == "ots" and o.included]
        if ots_outputs:
            try:
                from opentimestamps_engine import stamp_work_order
                ots_result = await stamp_work_order(wo.dict())
                results["ots"] = ots_result
            except Exception as e:
                logger.warning(f"OTS stamping failed: {e}")
                results["ots"] = {"error": str(e)}

        wo.status = "done"
        wo.executed_at = datetime.now(timezone.utc).isoformat()
        wo.result = results
        save_work_order(wo)

        return {"success": True, "work_order_id": work_order_id, "results": results}

    except Exception as e:
        wo.status = "pending_approval"  # Reset so user can retry
        save_work_order(wo)
        logger.error(f"Work order execution error: {e}")
        return {"success": False, "error": str(e), "work_order_id": work_order_id}
