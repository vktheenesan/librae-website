"""
LENUDA Email Delivery via Resend
==================================
Simple, production-ready email integration for report delivery and monitoring alerts.
"""

import os
from typing import Optional, List, Dict


try:
    import resend
except ImportError:
    resend = None


# ============================================================================
# RESEND CONFIGURATION
# ============================================================================

def init_resend(api_key: Optional[str] = None) -> bool:
    """Initialize Resend API client."""
    if resend is None:
        return False
    
    key = api_key or os.getenv("RESEND_API_KEY", "")
    if key:
        resend.api_key = key
        return True
    return False


def get_resend_api_key() -> str:
    """Retrieve Resend API key from environment."""
    return os.getenv("RESEND_API_KEY", "")


# ============================================================================
# EMAIL TEMPLATES
# ============================================================================

def email_template_report_ready(
    recipient_email: str,
    report_id: str,
    estate_name: str,
    risk_score: int,
    download_link: str,
) -> Dict[str, str]:
    """
    Email when report is ready for download.
    """
    return {
        "from": "reports@lenuda.io",
        "to": recipient_email,
        "subject": f"✅ Your EcoScan Report is Ready: {estate_name}",
        "html": f"""
        <h2>Environmental Compliance Report Ready</h2>
        <p>Your report for <strong>{estate_name}</strong> has been generated and is ready for review.</p>
        
        <h3>Quick Summary</h3>
        <ul>
            <li><strong>Risk Score:</strong> {risk_score}/100</li>
            <li><strong>Report ID:</strong> {report_id}</li>
            <li><strong>Generated:</strong> Today</li>
        </ul>
        
        <p><a href="{download_link}" style="background: #2D5016; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block;">
            📥 Download Report
        </a></p>
        
        <p><small>This is an automated message from LENUDA Environmental Compliance Intelligence.</small></p>
        """,
    }


def email_template_alert(
    recipient_email: str,
    alert_type: str,
    estate_name: str,
    alert_message: str,
    severity: str = "medium",
) -> Dict[str, str]:
    """
    Email for monitoring alert (anomaly, boundary change, etc).
    """
    severity_color = {
        "low": "#4CAF50",
        "medium": "#FFC107",
        "high": "#F44336",
    }.get(severity, "#FFC107")
    
    return {
        "from": "alerts@lenuda.io",
        "to": recipient_email,
        "subject": f"⚠️ LENUDA Alert [{severity.upper()}]: {alert_type} - {estate_name}",
        "html": f"""
        <div style="border-left: 4px solid {severity_color}; padding: 15px;">
            <h3 style="color: {severity_color};">Alert: {alert_type}</h3>
            <p><strong>Estate:</strong> {estate_name}</p>
            <p><strong>Severity:</strong> {severity.upper()}</p>
            <p>{alert_message}</p>
            <p><a href="https://app.lenuda.io/dashboard" style="color: {severity_color}; text-decoration: none;">
                View in Dashboard →
            </a></p>
        </div>
        <p><small>Monitor your estates continuously with LENUDA.</small></p>
        """,
    }


def email_template_monthly_summary(
    recipient_email: str,
    estates_summary: List[Dict],
    month: str,
) -> Dict[str, str]:
    """
    Monthly watchlist summary email.
    """
    estate_rows = ""
    for est in estates_summary:
        estate_rows += f"""
        <tr>
            <td style="padding: 8px; border-bottom: 1px solid #eee;">{est.get('name', 'Unknown')}</td>
            <td style="padding: 8px; border-bottom: 1px solid #eee;">{est.get('risk_score', 'N/A')}/100</td>
            <td style="padding: 8px; border-bottom: 1px solid #eee;">{est.get('status', 'Monitoring')}</td>
        </tr>
        """
    
    return {
        "from": "monitoring@lenuda.io",
        "to": recipient_email,
        "subject": f"📊 Monthly Environmental Summary — {month}",
        "html": f"""
        <h2>Your Monthly LENUDA Summary</h2>
        <p>Here's a snapshot of your monitored properties for <strong>{month}</strong>.</p>
        
        <h3>Portfolio Overview</h3>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #E6F2EA;">
                    <th style="padding: 10px; text-align: left;">Estate</th>
                    <th style="padding: 10px; text-align: left;">Risk Score</th>
                    <th style="padding: 10px; text-align: left;">Status</th>
                </tr>
            </thead>
            <tbody>
                {estate_rows}
            </tbody>
        </table>
        
        <p style="margin-top: 20px;">
            <a href="https://app.lenuda.io/dashboard" style="background: #2D5016; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block;">
                📈 View Full Dashboard
            </a>
        </p>
        """,
    }


# ============================================================================
# SEND FUNCTIONS
# ============================================================================

def send_report_ready_email(
    recipient_email: str,
    report_id: str,
    estate_name: str,
    risk_score: int,
    download_link: str,
) -> bool:
    """Send report-ready notification email."""
    if not resend or not get_resend_api_key():
        return False
    
    try:
        params = email_template_report_ready(
            recipient_email, report_id, estate_name, risk_score, download_link
        )
        response = resend.Emails.send(params)
        return response and response.get("id") is not None
    except Exception as e:
        print(f"Resend error (report email): {e}")
        return False


def send_alert_email(
    recipient_email: str,
    alert_type: str,
    estate_name: str,
    alert_message: str,
    severity: str = "medium",
) -> bool:
    """Send monitoring alert email."""
    if not resend or not get_resend_api_key():
        return False
    
    try:
        params = email_template_alert(
            recipient_email, alert_type, estate_name, alert_message, severity
        )
        response = resend.Emails.send(params)
        return response and response.get("id") is not None
    except Exception as e:
        print(f"Resend error (alert email): {e}")
        return False


def send_monthly_summary_email(
    recipient_email: str,
    estates_summary: List[Dict],
    month: str,
) -> bool:
    """Send monthly monitoring summary email."""
    if not resend or not get_resend_api_key():
        return False
    
    try:
        params = email_template_monthly_summary(recipient_email, estates_summary, month)
        response = resend.Emails.send(params)
        return response and response.get("id") is not None
    except Exception as e:
        print(f"Resend error (summary email): {e}")
        return False
