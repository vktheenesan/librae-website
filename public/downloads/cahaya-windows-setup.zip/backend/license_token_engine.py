"""
BAYU Commercial OS — License Token Engine
============================================
Generates, validates, renews, and revokes cryptographic license tokens
for Cahaya deployments. Tokens are HMAC-SHA256 signed and only the hash
is stored — the plaintext is shown exactly once at creation time.
"""

import hashlib
import hmac
import secrets
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List
from uuid import uuid4

from supabase_client import get_bayu_client
from config import cfg

logger = logging.getLogger("license_token_engine")

# Secret key for HMAC signing — loaded from env or generated deterministically
LICENSE_SECRET_KEY = cfg("LICENSE_SECRET_KEY") or secrets.token_hex(32)

# Tier → duration mapping
TIER_DURATIONS = {
    "1yr": timedelta(days=365),
    "5yr": timedelta(days=365 * 5),
    "10yr": timedelta(days=365 * 10),
    "25yr": timedelta(days=365 * 25),
}


# ============================================================================
# CRYPTOGRAPHIC HELPERS
# ============================================================================

def _generate_raw_token() -> str:
    """Generate a cryptographically secure raw token string."""
    unique_id = uuid4().hex
    random_bytes = secrets.token_hex(16)
    return f"cahaya_{unique_id}_{random_bytes}"


def _hash_token(plaintext_token: str) -> str:
    """Create HMAC-SHA256 hash of a plaintext token."""
    return hmac.new(
        LICENSE_SECRET_KEY.encode("utf-8"),
        plaintext_token.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


# ============================================================================
# TOKEN GENERATION
# ============================================================================

async def generate_license_token(
    org_name: str,
    contact_email: Optional[str] = None,
    tier: str = "1yr",
    annual_fee: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Generate a new license token. Returns the plaintext token ONCE.
    Only the HMAC-SHA256 hash is persisted in the database.
    """
    bayu = get_bayu_client()

    plaintext = _generate_raw_token()
    token_hash = _hash_token(plaintext)
    token_preview = plaintext[:8]

    duration = TIER_DURATIONS.get(tier, TIER_DURATIONS["1yr"])
    now = datetime.now(timezone.utc)
    expires_at = now + duration

    record = await bayu.insert("license_tokens", {
        "organization_name": org_name,
        "contact_email": contact_email,
        "token_hash": token_hash,
        "token_preview": token_preview,
        "license_tier": tier,
        "issued_at": now.isoformat(),
        "expires_at": expires_at.isoformat(),
        "grace_period_days": 90,
        "is_active": True,
        "renewal_count": 0,
        "annual_service_fee": annual_fee,
        "escalation_percent": 5.00,
    })

    logger.info(f"License generated for {org_name} (tier={tier}, expires={expires_at.date()})")

    return {
        "token_id": record.get("id") if record else None,
        "plaintext_token": plaintext,  # shown ONCE — not stored
        "token_preview": token_preview,
        "organization_name": org_name,
        "license_tier": tier,
        "issued_at": now.isoformat(),
        "expires_at": expires_at.isoformat(),
        "annual_service_fee": annual_fee,
    }


# ============================================================================
# TOKEN VALIDATION
# ============================================================================

async def validate_token(plaintext_token: str) -> Dict[str, Any]:
    """Validate a plaintext token against the database. Checks hash, expiry, and grace period."""
    bayu = get_bayu_client()
    token_hash = _hash_token(plaintext_token)

    rows = await bayu.select(
        "license_tokens",
        f"token_hash=eq.{token_hash}",
        limit=1,
    )

    if not rows:
        return {"valid": False, "reason": "Token not found"}

    token = rows[0]

    if not token.get("is_active"):
        return {"valid": False, "reason": "Token has been revoked", "token_id": token["id"]}

    expires_at = datetime.fromisoformat(token["expires_at"].replace("Z", "+00:00"))
    grace_days = token.get("grace_period_days", 90)
    grace_deadline = expires_at + timedelta(days=grace_days)
    now = datetime.now(timezone.utc)

    if now > grace_deadline:
        return {
            "valid": False,
            "reason": "Token expired beyond grace period",
            "token_id": token["id"],
            "expired_at": token["expires_at"],
            "grace_deadline": grace_deadline.isoformat(),
        }

    in_grace = now > expires_at
    return {
        "valid": True,
        "in_grace_period": in_grace,
        "token_id": token["id"],
        "organization_name": token.get("organization_name"),
        "license_tier": token.get("license_tier"),
        "expires_at": token["expires_at"],
        "grace_deadline": grace_deadline.isoformat() if in_grace else None,
        "renewal_count": token.get("renewal_count", 0),
    }


# ============================================================================
# TOKEN RENEWAL
# ============================================================================

async def renew_token(
    token_id: str,
    new_expiry: Optional[str] = None,
) -> Dict[str, Any]:
    """Extend a token's expiry by its tier duration. Increments renewal_count."""
    bayu = get_bayu_client()

    rows = await bayu.select("license_tokens", f"id=eq.{token_id}", limit=1)
    if not rows:
        return {"error": "Token not found"}

    token = rows[0]
    tier = token.get("license_tier", "1yr")
    duration = TIER_DURATIONS.get(tier, TIER_DURATIONS["1yr"])

    if new_expiry:
        expires_at = new_expiry
    else:
        current_expiry = datetime.fromisoformat(token["expires_at"].replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        base = max(current_expiry, now)
        expires_at = (base + duration).isoformat()

    renewal_count = (token.get("renewal_count") or 0) + 1
    now_iso = datetime.now(timezone.utc).isoformat()

    await bayu.update("license_tokens", f"id=eq.{token_id}", {
        "expires_at": expires_at,
        "renewal_count": renewal_count,
        "last_renewed_at": now_iso,
        "is_active": True,
    })

    logger.info(f"Token {token_id} renewed (count={renewal_count}, new_expiry={expires_at})")

    return {
        "token_id": token_id,
        "renewed": True,
        "renewal_count": renewal_count,
        "new_expires_at": expires_at,
        "renewal_price": await calculate_renewal_price(token_id),
    }


# ============================================================================
# TOKEN REVOCATION
# ============================================================================

async def revoke_token(token_id: str) -> bool:
    """Revoke a license token by setting is_active=False."""
    bayu = get_bayu_client()
    success = await bayu.update("license_tokens", f"id=eq.{token_id}", {
        "is_active": False,
    })
    if success:
        logger.info(f"Token {token_id} revoked")
    return success


# ============================================================================
# TOKEN LISTING
# ============================================================================

async def list_tokens(active_only: bool = True) -> List[Dict[str, Any]]:
    """Return all license tokens, optionally filtered to active only."""
    bayu = get_bayu_client()
    query = "order=created_at.desc"
    if active_only:
        query = f"is_active=eq.true&{query}"
    return await bayu.select("license_tokens", query, limit=200)


# ============================================================================
# RENEWAL PRICING
# ============================================================================

async def calculate_renewal_price(token_id: str) -> Optional[Dict[str, Any]]:
    """Calculate the renewal price applying escalation_percent per renewal_count."""
    bayu = get_bayu_client()

    rows = await bayu.select("license_tokens", f"id=eq.{token_id}", limit=1)
    if not rows:
        return None

    token = rows[0]
    base_fee = float(token.get("annual_service_fee") or 0)
    escalation = float(token.get("escalation_percent") or 5.0)
    renewals = int(token.get("renewal_count") or 0)

    # Compound escalation: fee * (1 + escalation/100) ^ renewals
    current_fee = base_fee * ((1 + escalation / 100) ** renewals)

    return {
        "token_id": token_id,
        "base_annual_fee": base_fee,
        "escalation_percent": escalation,
        "renewal_count": renewals,
        "current_annual_fee": round(current_fee, 2),
    }


# ============================================================================
# EXPIRING SOON
# ============================================================================

async def get_expiring_soon(days: int = 90) -> List[Dict[str, Any]]:
    """Return active tokens expiring within N days."""
    bayu = get_bayu_client()
    cutoff = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()

    # Fetch active tokens and filter by expiry in Python
    # (PostgREST filter: expires_at less than cutoff AND is_active)
    rows = await bayu.select(
        "license_tokens",
        f"is_active=eq.true&expires_at=lt.{cutoff}&order=expires_at.asc",
        limit=200,
    )
    return rows
