"""
LENUDA™ Premium 2.0 — Supabase Client Module
===============================================
Dual Supabase client:
  - get_lenuda_client() → for main DB
  - get_bayu_client()   → for CRM DB
  - Pipeline status CRUD
  - Telemetry logging
"""

import os
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any

import httpx

from config import (
    SUPABASE_URL, SUPABASE_KEY, SUPABASE_SERVICE_KEY,
    BAYU_SUPABASE_URL, BAYU_SUPABASE_KEY, get_supabase_api_key,
)

logger = logging.getLogger("supabase_client")

# ============================================================================
# SUPABASE CLIENT WRAPPERS
# ============================================================================

class SupabaseClient:
    """Lightweight Supabase REST client using httpx."""

    def __init__(self, url: str, api_key: str, service_key: Optional[str] = None):
        self.url = url.rstrip("/") if url else ""
        self.api_key = api_key or ""
        self.service_key = service_key
        self._best_key = service_key or api_key or ""

    @property
    def is_configured(self) -> bool:
        return bool(self.url and self._best_key)

    def _headers(self, use_service_key: bool = True) -> dict:
        key = self.service_key if (use_service_key and self.service_key) else self.api_key
        return {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }

    async def select(self, table: str, query_params: str = "", limit: int = 100) -> list:
        if not self.is_configured:
            return []
        url = f"{self.url}/rest/v1/{table}?{query_params}&limit={limit}"
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=self._headers(), timeout=20)
            if resp.status_code in (200, 206):
                return resp.json()
            logger.warning(f"Supabase select {table} failed: {resp.status_code}")
            return []

    async def insert(self, table: str, data: dict) -> Optional[dict]:
        if not self.is_configured:
            return None
        url = f"{self.url}/rest/v1/{table}"
        headers = {**self._headers(), "Prefer": "return=representation"}
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, headers=headers, json=data, timeout=20)
            if resp.status_code in (200, 201):
                rows = resp.json()
                return rows[0] if rows else data
            logger.warning(f"Supabase insert {table} failed: {resp.status_code} - {resp.text}")
            return None

    async def update(self, table: str, match_query: str, data: dict) -> bool:
        if not self.is_configured:
            return False
        url = f"{self.url}/rest/v1/{table}?{match_query}"
        headers = {**self._headers(), "Prefer": "return=minimal"}
        async with httpx.AsyncClient() as client:
            resp = await client.patch(url, headers=headers, json=data, timeout=20)
            return resp.status_code in (200, 204)

    async def rpc(self, function_name: str, params: dict) -> Any:
        if not self.is_configured:
            return None
        url = f"{self.url}/rest/v1/rpc/{function_name}"
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, headers=self._headers(), json=params, timeout=20)
            if resp.status_code == 200:
                return resp.json()
            logger.warning(f"Supabase RPC {function_name} failed: {resp.status_code}")
            return None

    async def health_check(self) -> bool:
        if not self.is_configured:
            return False
        try:
            url = f"{self.url}/rest/v1/"
            async with httpx.AsyncClient() as client:
                resp = await client.get(url, headers=self._headers(), timeout=5)
                return resp.status_code in (200, 204)
        except Exception:
            return False


# ============================================================================
# CLIENT SINGLETONS
# ============================================================================

_lenuda_client: Optional[SupabaseClient] = None
_bayu_client: Optional[SupabaseClient] = None


def get_lenuda_client() -> SupabaseClient:
    """Get the main LENUDA Supabase client."""
    global _lenuda_client
    if _lenuda_client is None:
        _lenuda_client = SupabaseClient(
            url=SUPABASE_URL or "",
            api_key=SUPABASE_KEY or "",
            service_key=SUPABASE_SERVICE_KEY,
        )
    return _lenuda_client


def get_bayu_client() -> SupabaseClient:
    """Get the BAYU CRM Supabase client."""
    global _bayu_client
    if _bayu_client is None:
        _bayu_client = SupabaseClient(
            url=BAYU_SUPABASE_URL or "",
            api_key=BAYU_SUPABASE_KEY or "",
        )
    return _bayu_client


# ============================================================================
# PIPELINE STATUS CRUD
# ============================================================================

async def create_pipeline_status(
    user_id: str,
    report_id: str,
    estate_name: str,
    domain: str,
    status: str = "queued",
) -> Optional[dict]:
    """Create a new pipeline status entry."""
    client = get_lenuda_client()
    return await client.insert("pipeline_status", {
        "user_id": user_id,
        "report_id": report_id,
        "estate_name": estate_name,
        "domain": domain,
        "status": status,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })


async def update_pipeline_status(
    report_id: str,
    status: str,
    progress_pct: int = 0,
    message: str = "",
) -> bool:
    """Update pipeline status for a report."""
    client = get_lenuda_client()
    data = {
        "status": status,
        "progress_pct": progress_pct,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    if message:
        data["status_message"] = message
    return await client.update("pipeline_status", f"report_id=eq.{report_id}", data)


async def get_pipeline_status(report_id: str) -> Optional[dict]:
    """Get pipeline status for a report."""
    client = get_lenuda_client()
    rows = await client.select("pipeline_status", f"report_id=eq.{report_id}", limit=1)
    return rows[0] if rows else None


# ============================================================================
# TELEMETRY LOGGING
# ============================================================================

async def log_telemetry_event(
    user_id: str,
    event_type: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> Optional[dict]:
    """Log a telemetry event to the telemetry table."""
    client = get_lenuda_client()
    return await client.insert("telemetry", {
        "user_id": user_id,
        "event_type": event_type,
        "metadata": metadata or {},
        "created_at": datetime.now(timezone.utc).isoformat(),
    })


# ============================================================================
# PROFILE OPERATIONS
# ============================================================================

async def get_user_profile(user_id: str) -> Optional[dict]:
    """Get a user profile by ID."""
    client = get_lenuda_client()
    rows = await client.select("profiles", f"id=eq.{user_id}", limit=1)
    return rows[0] if rows else None


async def upsert_user_profile(user_id: str, data: dict) -> bool:
    """Upsert a user profile."""
    client = get_lenuda_client()
    existing = await get_user_profile(user_id)
    if existing:
        return await client.update("profiles", f"id=eq.{user_id}", data)
    else:
        data["id"] = user_id
        result = await client.insert("profiles", data)
        return result is not None
