"""
CAHAYA Sovereign — AI Render Self-Verification Engine
=====================================================
Principle 3: The AI sees what it renders.

After every map render or simulation frame in CAHAYA, the frontend
captures a canvas screenshot and sends it here. We pass it to a
vision model which evaluates whether the render:
  - Matches the user's stated intent
  - Contains any visible errors (blank tiles, wrong colors, JS exceptions)
  - Is scientifically correct (color ramp, legend, scale bar present)

This closes the "silent failure" loop — the AI no longer assumes
its code worked; it actually sees and verifies the output.

Render states:
  VERIFIED    — Output matches intent, no errors detected
  CORRECTED   — AI detected issue and reissued corrected code
  FAILED      — Could not auto-correct after 3 retries (human needed)
  SKIPPED     — Vision model unavailable (offline mode)
"""

import os
import base64
import hashlib
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from enum import Enum

import httpx

from config import GEMINI_API_KEY

logger = logging.getLogger("render_verifier")

# ── Config ─────────────────────────────────────────────────────────────────────
MAX_RETRIES = 3
VISION_MODEL = "gemini-2.0-flash"   # Fast vision model for render checks
VERIFY_TIMEOUT = 30                  # seconds


class RenderState(str, Enum):
    VERIFIED = "verified"
    CORRECTED = "corrected"
    FAILED = "failed"
    SKIPPED = "skipped"
    PENDING = "pending"


# ── Core Verification ──────────────────────────────────────────────────────────

async def verify_render(
    screenshot_b64: str,
    intent: str,
    domain: str,
    previous_code: Optional[str] = None,
    retry_count: int = 0,
) -> Dict[str, Any]:
    """
    Core verification function. Sends screenshot to Gemini Vision and
    evaluates whether the render matches the stated intent.

    Args:
        screenshot_b64: Base64-encoded PNG screenshot from browser canvas
        intent: The user's original task description (e.g. "flood map of Klang Valley")
        domain: Industry domain context (agriculture, mining, etc.)
        previous_code: The GEE/JS code that produced this render (for correction prompts)
        retry_count: Internal retry counter (max MAX_RETRIES)

    Returns:
        {
            state: RenderState,
            verified: bool,
            confidence: float (0.0-1.0),
            observations: [str],   # What the AI saw
            errors_detected: [str], # Specific errors found
            corrected_code: str,    # If state==CORRECTED, new code to execute
            screenshot_hash: str,  # SHA-256 of the screenshot for audit log
            model: str,
            timestamp: str
        }
    """
    # Compute screenshot hash for audit trail
    img_bytes = base64.b64decode(screenshot_b64)
    screenshot_hash = hashlib.sha256(img_bytes).hexdigest()

    # If Gemini not available, skip gracefully
    if not GEMINI_API_KEY:
        return _skipped_result(screenshot_hash, "Vision model not configured")

    # Build the verification prompt
    verification_prompt = _build_verification_prompt(intent, domain, previous_code, retry_count)

    try:
        result = await _call_vision_model(verification_prompt, screenshot_b64)
        parsed = _parse_vision_response(result, screenshot_hash, previous_code)
        logger.info(
            f"Render verification: {parsed['state']} | "
            f"Confidence: {parsed['confidence']:.2f} | "
            f"Errors: {parsed['errors_detected']}"
        )
        return parsed

    except Exception as e:
        logger.error(f"Render verification error: {e}")
        return _skipped_result(screenshot_hash, str(e))


async def verify_and_correct(
    screenshot_b64: str,
    intent: str,
    domain: str,
    current_code: str,
    execute_callback,  # async callable: takes code str, returns new screenshot_b64
    max_retries: int = MAX_RETRIES,
) -> Dict[str, Any]:
    """
    Full correction loop: verify render → if error, generate corrected code →
    re-execute → re-verify → repeat up to max_retries times.

    execute_callback is provided by the caller (usually the GEE code runner
    in main.py) and handles actually running the code and capturing the result.
    """
    screenshot = screenshot_b64
    code = current_code
    history = []

    for attempt in range(max_retries + 1):
        result = await verify_render(screenshot, intent, domain, code, attempt)
        history.append({
            "attempt": attempt,
            "state": result["state"],
            "errors": result["errors_detected"],
            "screenshot_hash": result["screenshot_hash"],
        })

        if result["state"] == RenderState.VERIFIED:
            return {
                **result,
                "attempts": attempt + 1,
                "history": history,
                "final_code": code,
            }

        if result["state"] == RenderState.SKIPPED:
            return {**result, "attempts": attempt + 1, "history": history, "final_code": code}

        # If errors detected and we have corrected code, retry
        corrected = result.get("corrected_code")
        if corrected and attempt < max_retries:
            logger.info(f"Auto-correcting render (attempt {attempt + 1}/{max_retries})")
            code = corrected
            try:
                screenshot = await execute_callback(code)
            except Exception as e:
                logger.error(f"Code execution failed during correction: {e}")
                break

    # Exhausted retries
    return {
        **result,
        "state": RenderState.FAILED,
        "attempts": max_retries + 1,
        "history": history,
        "final_code": code,
        "message": "Auto-correction exhausted. Human review recommended.",
    }


# ── Vision Model Call ──────────────────────────────────────────────────────────

async def _call_vision_model(prompt: str, screenshot_b64: str) -> str:
    """Calls Gemini Vision API with the render screenshot."""
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{VISION_MODEL}:generateContent?key={GEMINI_API_KEY}"
    )
    body = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {
                    "inline_data": {
                        "mime_type": "image/png",
                        "data": screenshot_b64,
                    }
                },
            ]
        }],
        "generationConfig": {
            "temperature": 0.1,   # Low temp for factual visual assessment
            "maxOutputTokens": 1024,
            "responseMimeType": "application/json",
        },
    }

    async with httpx.AsyncClient(timeout=VERIFY_TIMEOUT) as client:
        resp = await client.post(url, json=body)
        resp.raise_for_status()
        data = resp.json()
        candidates = data.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            return "".join(p.get("text", "") for p in parts)
        return "{}"


# ── Prompt Builder ─────────────────────────────────────────────────────────────

def _build_verification_prompt(
    intent: str, domain: str, code: Optional[str], retry: int
) -> str:
    base = f"""You are a spatial intelligence quality assurance system.

A CAHAYA user requested: "{intent}"
Domain context: {domain}

Look at this rendered screenshot from CAHAYA's mapping engine.
Respond with ONLY valid JSON matching this exact schema:

{{
  "matches_intent": true/false,
  "confidence": 0.0-1.0,
  "observations": ["what you see in the image"],
  "errors_detected": ["list any visible errors, blank tiles, wrong overlays, etc"],
  "scientific_issues": ["color ramp problems, missing scale bar, wrong projection, etc"],
  "corrected_code_needed": true/false,
  "correction_hint": "brief description of what needs to change in the code"
}}

Check specifically for:
1. Blank or grey tiles (data loading failure)
2. Wrong geographic area (code rendered wrong location)
3. Error messages or console output visible in the render
4. Missing or incorrect legend/color scale
5. Completely black or white render (rendering failure)
6. Obvious scientific errors (e.g., NDVI values outside -1 to +1 range shown in legend)
7. Does the map actually show what was requested?"""

    if retry > 0:
        base += f"\n\nThis is correction attempt #{retry}. Previous attempts failed to render correctly."

    if code and retry > 0:
        base += f"\n\nThe code that produced this render:\n```javascript\n{code[:2000]}\n```"

    return base


# ── Response Parser ────────────────────────────────────────────────────────────

def _parse_vision_response(
    raw_json: str, screenshot_hash: str, previous_code: Optional[str]
) -> Dict[str, Any]:
    """Parse and normalize the vision model's JSON response."""
    import json

    try:
        data = json.loads(raw_json)
    except json.JSONDecodeError:
        # Try to extract JSON from markdown code blocks
        import re
        match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw_json, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
            except Exception:
                data = {}
        else:
            data = {}

    matches = data.get("matches_intent", True)
    errors = data.get("errors_detected", [])
    sci_issues = data.get("scientific_issues", [])
    confidence = float(data.get("confidence", 0.9 if matches else 0.3))
    needs_correction = data.get("corrected_code_needed", not matches)

    all_errors = errors + sci_issues

    if matches and not all_errors:
        state = RenderState.VERIFIED
    elif needs_correction:
        state = RenderState.CORRECTED
    else:
        state = RenderState.FAILED

    return {
        "state": state,
        "verified": state == RenderState.VERIFIED,
        "confidence": confidence,
        "observations": data.get("observations", []),
        "errors_detected": all_errors,
        "correction_hint": data.get("correction_hint", ""),
        "corrected_code": None,  # Populated by caller if re-execution needed
        "screenshot_hash": screenshot_hash,
        "model": VISION_MODEL,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "raw_assessment": data,
    }


def _skipped_result(screenshot_hash: str, reason: str) -> Dict[str, Any]:
    return {
        "state": RenderState.SKIPPED,
        "verified": False,
        "confidence": 0.0,
        "observations": [],
        "errors_detected": [],
        "correction_hint": "",
        "corrected_code": None,
        "screenshot_hash": screenshot_hash,
        "model": None,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "skip_reason": reason,
    }


# ── Scientific Metadata Stamper ────────────────────────────────────────────────

def stamp_scientific_metadata(
    output_type: str,
    algorithm: str,
    algorithm_version: str,
    data_sources: List[Dict],
    methodology_standard: Optional[str],
    domain: str,
    parameters: Dict,
    uncertainty_estimate: Optional[Dict] = None,
) -> Dict[str, Any]:
    """
    Stamps every CAHAYA output with full scientific provenance.
    This is attached to every export, report, and saved analysis.

    Args:
        output_type: 'map' | 'report' | 'simulation' | 'measurement'
        algorithm: Algorithm name (e.g. 'ChangeFormer', 'Prithvi-EO-2.0')
        algorithm_version: Pinned version string
        data_sources: List of {satellite, scene_id, date, cloud_pct, resolution_m}
        methodology_standard: e.g. 'EUDR Article 3(1)', 'JORC 2012 §42', 'Verra VCS VM0042'
        domain: Industry domain
        parameters: All parameters used (for reproducibility)
        uncertainty_estimate: Optional {value, unit, method, confidence_interval}

    Returns:
        Scientific metadata dict — attach to every output as 'provenance' field
    """
    import uuid
    from hashlib import sha256

    # Create a reproducibility seed from all inputs
    seed_input = f"{algorithm}{algorithm_version}{str(sorted(parameters.items()))}"
    reproducibility_hash = sha256(seed_input.encode()).hexdigest()[:16]

    metadata = {
        "provenance_id": str(uuid.uuid4()),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "output_type": output_type,
        "domain": domain,
        "algorithm": {
            "name": algorithm,
            "version": algorithm_version,
            "reproducibility_seed": reproducibility_hash,
        },
        "data_sources": data_sources,
        "parameters_used": parameters,
        "methodology": {
            "standard": methodology_standard,
            "reference": _get_doi_for_standard(methodology_standard),
        },
        "uncertainty": uncertainty_estimate or {
            "note": "Uncertainty quantification not computed for this output type"
        },
        "system": {
            "cahaya_version": "3.0.0",
            "produced_by": "Librae AI Labs — CAHAYA Sovereign",
            "verification_chain": "SHA-256 + Merkle Tree + Bitcoin OpenTimestamps",
        },
    }

    return metadata


def _get_doi_for_standard(standard: Optional[str]) -> Optional[str]:
    """Map regulatory standard to published reference."""
    if not standard:
        return None
    DOI_MAP = {
        "EUDR": "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32023R1115",
        "RSPO": "https://www.rspo.org/principles-criteria",
        "MSPO": "https://www.doa.gov.my/mspo",
        "JORC 2012": "https://www.jorc.org/docs/jorc_code2012.pdf",
        "Verra VCS": "https://verra.org/programs/verified-carbon-standard/",
        "VM0042": "https://verra.org/methodologies/vm0042/",
        "ISO 14064": "https://www.iso.org/standard/66453.html",
        "GHG Protocol": "https://ghgprotocol.org/",
        "IPCC": "https://www.ipcc.ch/",
        "ChangeFormer": "https://doi.org/10.1109/IGARSS46834.2022.9883209",
        "Prithvi-EO-2.0": "https://huggingface.co/ibm-nasa-geospatial/Prithvi-EO-2.0-300M",
        "SAM 2": "https://arxiv.org/abs/2408.00714",
        "RemoteCLIP": "https://arxiv.org/abs/2306.11029",
    }
    for key, doi in DOI_MAP.items():
        if key.lower() in (standard or "").lower():
            return doi
    return None
