#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAHAYA™ — License Enforcer Middleware
Location: backend/license_enforcer_middleware.py

FastAPI middleware that intercepts requests to protected routes and enforces
license state (GRACE / LOCKED) with appropriate 402 responses.

Protected route prefixes:
  /api/gee/*
  /api/earthquery/*
  /api/simulate/*
  /api/report/*

Always-allowed routes (even when LOCKED):
  /api/health
  /api/license/*
  /api/auth/*         (login must remain accessible)
  Static assets / root
"""

import logging
from typing import Callable

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger("license_enforcer")

# ─────────────────────────────────────────────────────────────────────────────
# Route Policy Configuration
# ─────────────────────────────────────────────────────────────────────────────

# Routes that require an active license to accept write/compute operations
PROTECTED_PREFIXES = (
    "/api/gee/",
    "/api/earthquery/",
    "/api/simulate/",
    "/api/report/",
)

# Routes that are ALWAYS allowed regardless of license state
ALWAYS_ALLOWED_PREFIXES = (
    "/api/health",
    "/api/license/",
    "/api/auth/",
)

# HTTP methods that constitute a "write" / analysis operation
ANALYSIS_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

# ─────────────────────────────────────────────────────────────────────────────
# Middleware
# ─────────────────────────────────────────────────────────────────────────────


class LicenseEnforcerMiddleware(BaseHTTPMiddleware):
    """
    Starlette/FastAPI middleware that enforces license state on every request.

    Enforcement matrix:
    ┌────────────────┬──────────────────────────────────────────────────────┐
    │ License State  │ Effect on protected routes                           │
    ├────────────────┼──────────────────────────────────────────────────────┤
    │ ACTIVE         │ Pass through — no restriction                        │
    │ WARNING_90     │ Pass through — banner shown in UI                    │
    │ WARNING_30     │ Pass through — urgent banner shown in UI             │
    │ GRACE          │ GET allowed (view data); POST/PUT/PATCH/DELETE → 402 │
    │ LOCKED         │ All protected routes → 402 (only health+license OK)  │
    │ INVALID        │ Treated same as LOCKED                               │
    └────────────────┴──────────────────────────────────────────────────────┘
    """

    def __init__(self, app: ASGIApp, license_jwt: str = None):
        """
        Args:
            app:         The ASGI application.
            license_jwt: Optional JWT token string.  If not supplied, the
                         middleware resolves the license from local files /
                         env on each request (cached after first load).
        """
        super().__init__(app)
        self._license_jwt = license_jwt
        self._cached_status = None   # populated lazily on first request

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        method = request.method.upper()

        # ── Always-allowed routes ─────────────────────────────────────────────
        if _is_always_allowed(path):
            return await call_next(request)

        # ── Only enforce on protected route prefixes ───────────────────────────
        if not _is_protected(path):
            return await call_next(request)

        # ── Resolve license status ─────────────────────────────────────────────
        status = self._get_license_status(request)

        # ── Enforce by state ──────────────────────────────────────────────────
        from licensing import LicenseState  # local import to avoid circular at module load

        if status.state in (LicenseState.ACTIVE, LicenseState.WARNING_90, LicenseState.WARNING_30):
            # Active — pass through; warn headers are appended by the /api/license/status
            # endpoint which the UI polls separately.
            return await call_next(request)

        elif status.state == LicenseState.GRACE:
            # GRACE: allow read (GET/HEAD/OPTIONS), block writes
            if method in ANALYSIS_METHODS:
                logger.info(
                    f"[LicenseEnforcer] GRACE — blocked {method} {path}"
                )
                return JSONResponse(
                    status_code=402,
                    content={
                        "error": "license_degraded",
                        "degraded": True,
                        "state": "GRACE",
                        "message": status.warning_message,
                        "grace_days_remaining": status.grace_days_remaining,
                        "renew_url": "https://librae.work/renew",
                    },
                )
            # GET allowed — attach a Deprecation-style header to inform caller
            response = await call_next(request)
            response.headers["X-License-State"] = "GRACE"
            response.headers["X-License-Warning"] = status.warning_message
            return response

        else:
            # LOCKED or INVALID — block everything on protected routes
            logger.warning(
                f"[LicenseEnforcer] {status.state} — blocked {method} {path}"
            )
            return JSONResponse(
                status_code=402,
                content={
                    "error": "license_locked",
                    "degraded": False,
                    "state": status.state.value if hasattr(status.state, "value") else str(status.state),
                    "message": status.warning_message,
                    "grace_days_remaining": 0,
                    "renew_url": "https://librae.work/renew",
                    "contact": "sales@librae.earth",
                },
            )

    def _get_license_status(self, request: Request):
        """
        Resolve LicenseStatus.  Priority:
          1. Authorization header (Bearer <jwt>)
          2. X-License-Token header
          3. Constructor-injected JWT
          4. Local file / env fallback (cached after first successful load)
        """
        from licensing import check_license_status

        # Per-request JWT from header
        auth_header = request.headers.get("Authorization", "")
        x_token = request.headers.get("X-License-Token", "")

        if auth_header.startswith("Bearer "):
            token = auth_header.split(" ", 1)[1]
        elif x_token:
            token = x_token
        elif self._license_jwt:
            token = self._license_jwt
        else:
            token = None

        try:
            status = check_license_status(token)
            # Cache for non-JWT path (local file doesn't change between requests)
            if not token:
                self._cached_status = status
            return status
        except Exception as exc:
            logger.warning(f"[LicenseEnforcer] check_license_status error: {exc}")
            # Return cached status if available, otherwise INVALID
            if self._cached_status:
                return self._cached_status
            from licensing import LicenseStatus, LicenseState
            return LicenseStatus(
                state=LicenseState.INVALID,
                days_remaining=0,
                grace_days_remaining=0,
                warning_message=str(exc),
                can_run_analysis=False,
                can_export=False,
            )


# ─────────────────────────────────────────────────────────────────────────────
# Route classification helpers
# ─────────────────────────────────────────────────────────────────────────────


def _is_always_allowed(path: str) -> bool:
    return any(path.startswith(prefix) for prefix in ALWAYS_ALLOWED_PREFIXES)


def _is_protected(path: str) -> bool:
    return any(path.startswith(prefix) for prefix in PROTECTED_PREFIXES)
