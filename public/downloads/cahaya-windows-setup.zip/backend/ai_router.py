"""
LENUDA™ Premium 2.0 — Multi-Model AI Router
==============================================
Routes prompts to the appropriate AI model:
  - Gemini  → GEE code generation, report narrative
  - Qwen   → MCP/tool use, BAYU conversational agent
  - Claude  → Report compilation (placeholder)
  - GPT     → Telemetry/pricing analysis (placeholder)

Each function uses httpx for async API calls.
"""

import json
import logging
from typing import Optional, Dict, Any, List

import httpx

from config import (
    GEMINI_API_KEY,
    ALIBABA_MODEL_STUDIO_API_KEY,
    LLM_API_BASE,
    LLM_MODEL_NAME,
    ANTHROPIC_API_KEY,
    OPENAI_API_KEY,
    cfg,
)

logger = logging.getLogger("ai_router")


# ============================================================================
# GEMINI — GEE Code Generation + Report Narrative
# ============================================================================

async def route_to_gemini(
    prompt: str,
    system_instruction: str = "",
    temperature: float = 0.7,
    max_tokens: int = 8192,
) -> Dict[str, Any]:
    """
    Route prompt to Google Gemini API for GEE code generation and report narrative.
    Uses the Gemini REST API v1beta/generateContent endpoint.
    """
    if not GEMINI_API_KEY:
        return {"error": "GEMINI_API_KEY not configured", "text": ""}

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

    contents = [{"parts": [{"text": prompt}]}]

    body: Dict[str, Any] = {
        "contents": contents,
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
        },
    }

    if system_instruction:
        body["systemInstruction"] = {
            "parts": [{"text": system_instruction}]
        }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=body, timeout=120)
            resp.raise_for_status()
            data = resp.json()

            candidates = data.get("candidates", [])
            if candidates:
                parts = candidates[0].get("content", {}).get("parts", [])
                text = "".join(p.get("text", "") for p in parts)
                return {
                    "text": text,
                    "model": "gemini-2.0-flash",
                    "finish_reason": candidates[0].get("finishReason", ""),
                    "usage": data.get("usageMetadata", {}),
                }

            return {"text": "", "error": "No candidates returned"}
    except httpx.HTTPStatusError as e:
        logger.error(f"Gemini API HTTP error: {e.response.status_code} - {e.response.text}")
        return {"text": "", "error": f"Gemini API error: {e.response.status_code}"}
    except Exception as e:
        logger.error(f"Gemini API error: {e}")
        return {"text": "", "error": str(e)}


# ============================================================================
# QWEN (Alibaba Model Studio) — MCP/Tool Use, BAYU Agent
# ============================================================================

async def route_to_qwen(
    prompt: str,
    system_message: str = "You are BAYU, the LENUDA AI assistant for environmental intelligence.",
    temperature: float = 0.7,
    max_tokens: int = 4096,
    enable_thinking: bool = True,
    conversation_history: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    """
    Route prompt to Alibaba Model Studio (Qwen) for conversational AI and tool use.
    Uses OpenAI-compatible API endpoint.
    """
    if not ALIBABA_MODEL_STUDIO_API_KEY or not LLM_API_BASE:
        return {"error": "Alibaba Model Studio credentials not configured", "text": ""}

    url = f"{LLM_API_BASE.rstrip('/')}/chat/completions"

    messages = [{"role": "system", "content": system_message}]

    if conversation_history:
        messages.extend(conversation_history)

    messages.append({"role": "user", "content": prompt})

    body = {
        "model": LLM_MODEL_NAME,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    if enable_thinking:
        body["extra_body"] = {"enable_thinking": True}

    headers = {
        "Authorization": f"Bearer {ALIBABA_MODEL_STUDIO_API_KEY}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=body, headers=headers, timeout=120)
            resp.raise_for_status()
            data = resp.json()

            choices = data.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                text = message.get("content", "")
                reasoning = message.get("reasoning_content", "")
                return {
                    "text": text,
                    "reasoning": reasoning,
                    "model": LLM_MODEL_NAME,
                    "finish_reason": choices[0].get("finish_reason", ""),
                    "usage": data.get("usage", {}),
                }

            return {"text": "", "error": "No choices returned"}
    except httpx.HTTPStatusError as e:
        logger.error(f"Qwen API HTTP error: {e.response.status_code} - {e.response.text}")
        return {"text": "", "error": f"Qwen API error: {e.response.status_code}"}
    except Exception as e:
        logger.error(f"Qwen API error: {e}")
        return {"text": "", "error": str(e)}


# ============================================================================
# CLAUDE — Report Compilation
# ============================================================================

async def route_to_claude(
    prompt: str,
    system_message: str = "You are a professional environmental compliance report writer.",
    temperature: float = 0.5,
    max_tokens: int = 8192,
) -> Dict[str, Any]:
    """
    Route prompt to Anthropic Claude API for report compilation.
    Uses the Anthropic Messages API.
    """
    api_key = ANTHROPIC_API_KEY
    if not api_key:
        # Fallback to Gemini if Claude not configured
        logger.info("Claude not configured, falling back to Gemini for report compilation")
        return await route_to_gemini(
            prompt=prompt,
            system_instruction=system_message,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }
    body = {
        "model": "claude-sonnet-4-20250514",
        "max_tokens": max_tokens,
        "system": system_message,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=body, headers=headers, timeout=120)
            resp.raise_for_status()
            data = resp.json()

            content = data.get("content", [])
            text = "".join(c.get("text", "") for c in content if c.get("type") == "text")
            return {
                "text": text,
                "model": data.get("model", "claude-sonnet-4-20250514"),
                "usage": data.get("usage", {}),
                "stop_reason": data.get("stop_reason", ""),
            }
    except httpx.HTTPStatusError as e:
        logger.error(f"Claude API HTTP error: {e.response.status_code}")
        return await route_to_gemini(prompt=prompt, system_instruction=system_message)
    except Exception as e:
        logger.error(f"Claude API error: {e}")
        return await route_to_gemini(prompt=prompt, system_instruction=system_message)


# ============================================================================
# GPT — Telemetry/Pricing Analysis
# ============================================================================

async def route_to_gpt(
    prompt: str,
    system_message: str = "You are an analytics assistant for environmental intelligence pricing.",
    temperature: float = 0.3,
    max_tokens: int = 4096,
) -> Dict[str, Any]:
    """
    Route prompt to OpenAI GPT API for telemetry and pricing analysis.
    Falls back to Qwen if not configured.
    """
    api_key = OPENAI_API_KEY
    if not api_key:
        logger.info("OpenAI not configured, falling back to Qwen for analysis")
        return await route_to_qwen(
            prompt=prompt,
            system_message=system_message,
            temperature=temperature,
            max_tokens=max_tokens,
            enable_thinking=False,
        )

    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    body = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=body, headers=headers, timeout=60)
            resp.raise_for_status()
            data = resp.json()

            choices = data.get("choices", [])
            if choices:
                text = choices[0].get("message", {}).get("content", "")
                return {
                    "text": text,
                    "model": "gpt-4o-mini",
                    "usage": data.get("usage", {}),
                    "finish_reason": choices[0].get("finish_reason", ""),
                }
            return {"text": "", "error": "No choices returned"}
    except httpx.HTTPStatusError as e:
        logger.error(f"GPT API HTTP error: {e.response.status_code}")
        return await route_to_qwen(prompt=prompt, system_message=system_message, enable_thinking=False)
    except Exception as e:
        logger.error(f"GPT API error: {e}")
        return await route_to_qwen(prompt=prompt, system_message=system_message, enable_thinking=False)
