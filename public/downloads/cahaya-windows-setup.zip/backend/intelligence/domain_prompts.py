"""
LENUDA 3.0 — Domain Intelligence Registry
==========================================
The canonical registry of all supported analysis domains.
Each domain defines its own:
  - Sensing stack (which GEE bands/products to prioritize)
  - Regulatory context (injected into the AI system prompt)
  - Agent types (what populations to simulate)
  - Risk thresholds
  - Report section templates

Adding a new domain = adding one entry here. Nothing else changes.
"""

from typing import Dict, Any

DOMAIN_REGISTRY: Dict[str, Dict[str, Any]] = {

    "agriculture": {
        "display_name": "Agriculture & Plantation",
        "icon": "🌿",
        "description": "Palm oil, rubber, cocoa, rice — EUDR/MSPO compliance and soil health.",
        "sensing_stack": ["ndvi", "evi", "gedi_canopy", "palsar_peat", "sar_flood", "chirps_rainfall", "soc"],
        "regulatory_context": (
            "EUDR Regulation 2023/1115 — Article 4 due diligence obligations for deforestation-free supply chains. "
            "MSPO MS2530:2013 Malaysian Sustainable Palm Oil Standard. "
            "RSPO Principles & Criteria (2018 revision). "
            "ISO 14001:2015 Environmental Management Systems."
        ),
        "risk_parameters": {
            "ndvi_low_threshold": 0.35,
            "forest_loss_warning_pct": 5.0,
            "peat_overlap_critical_pct": 10.0,
        },
        "agent_types": ["plantation_workers", "wildlife_mammals", "ground_vehicles"],
        "report_sections": ["Executive Summary", "EUDR Compliance Assessment", "Forest Cover Change", "Peatland Risk", "Carbon Estimate", "Recommendations"],
        "credit_cost": 15,
    },

    "construction": {
        "display_name": "Construction & Infrastructure",
        "icon": "🏗️",
        "description": "Site clearance, slope stability, urban heat, EIA compliance.",
        "sensing_stack": ["sar_displacement", "dem_slope", "lst_urban_heat", "ndvi_greenery_loss", "rainfall_erosion"],
        "regulatory_context": (
            "ISO 14001:2015 Environmental Impact Assessment guidelines. "
            "Local EIA regulations and site clearance right-of-way erosion codes. "
            "IFC Performance Standard 3 — Resource Efficiency and Pollution Prevention. "
            "Regional landslide vulnerability classifications and slope stability mandates."
        ),
        "risk_parameters": {
            "slope_critical_degrees": 35.0,
            "subsidence_warning_mm": 5.0,
            "urban_heat_warning_celsius": 40.0,
        },
        "agent_types": ["construction_workers", "site_vehicles", "pedestrians_perimeter"],
        "report_sections": ["Executive Summary", "Slope & Geotechnical Risk", "Ground Subsidence (InSAR)", "Urban Heat Island Effect", "Biodiversity Corridor Impact", "Recommendations"],
        "credit_cost": 18,
    },

    "shipping": {
        "display_name": "Maritime & Shipping Logistics",
        "icon": "🚢",
        "description": "Vessel route risk, oil spill detection, port environmental compliance.",
        "sensing_stack": ["sar_vessel_detection", "optical_oil_spill_ndwi", "coastal_wave_height", "wind_field"],
        "regulatory_context": (
            "IMO MARPOL Annex I — Prevention of pollution by oil from ships. "
            "IMO MARPOL Annex II — Control of pollution by noxious liquid substances. "
            "IMO DCS (Data Collection System) for fuel consumption reporting. "
            "HELCOM/OSPAR regional sea conventions for coastal environmental protection. "
            "Port State Control MOU inspection requirements."
        ),
        "risk_parameters": {
            "oil_spill_detection_ndwi_threshold": -0.3,
            "wave_height_critical_m": 4.0,
            "vessel_density_congestion_threshold": 50,
        },
        "agent_types": ["vessel_crew", "marine_mammals", "coastal_fishermen"],
        "report_sections": ["Executive Summary", "Vessel Route Risk Assessment", "Oil/Chemical Spill Detection", "Marine Biodiversity Impact", "Port Compliance Status", "Recommendations"],
        "credit_cost": 20,
        "user_data_fields": ["ais_track_geojson", "vessel_imo_number", "cargo_manifest_type"],
    },

    "water": {
        "display_name": "Water Resources & Hydrology",
        "icon": "💧",
        "description": "Flood mapping, water quality, reservoir monitoring, SDG 6 compliance.",
        "sensing_stack": ["chirps_rainfall_intensity", "sar_flood_extent", "ndwi_water_quality", "dem_watershed"],
        "regulatory_context": (
            "UN Sustainable Development Goal 6 — Clean Water and Sanitation targets. "
            "WHO/UNICEF Joint Monitoring Programme water quality baselines. "
            "EU Water Framework Directive ecological status classification. "
            "National Hydraulics Research Institute standards for flood risk mapping. "
            "IPCC AR6 hydrological extremes risk bands."
        ),
        "risk_parameters": {
            "flood_depth_warning_m": 0.5,
            "ndwi_pollution_threshold": 0.4,
            "drought_spi_critical": -1.5,
        },
        "agent_types": ["civilians_low_lying", "livestock", "rescue_boats"],
        "report_sections": ["Executive Summary", "Flood Extent Mapping", "Water Quality Index", "Watershed Health", "Drought/Surplus Risk", "Recommendations"],
        "credit_cost": 15,
    },

    "forestry": {
        "display_name": "Forestry & Carbon Credits",
        "icon": "🌲",
        "description": "Forest cover change, biomass estimation, REDD+/VCS carbon verification.",
        "sensing_stack": ["gedi_lidar_biomass", "hansen_forest_loss", "modis_fire", "palsar_aboveground_biomass", "ndvi_canopy"],
        "regulatory_context": (
            "Verra Voluntary Carbon Standard (VCS) VM0007 — REDD+ Methodology. "
            "REDD+ Warsaw Framework and UNFCCC Article 5 guidelines. "
            "Paris Agreement Article 6 — Carbon market integrity requirements. "
            "Gold Standard for Global Goals — Nature-Based Solutions certification. "
            "IUCN Green List of Protected Areas standards."
        ),
        "risk_parameters": {
            "biomass_loss_warning_pct": 10.0,
            "fire_recurrence_critical_years": 3,
            "deforestation_alert_hectares": 5.0,
        },
        "agent_types": ["forest_rangers", "indigenous_communities", "wildlife_canopy"],
        "report_sections": ["Executive Summary", "Forest Cover Change (Hansen)", "Above-Ground Biomass (GEDI)", "Carbon Stock Estimate", "Fire Risk Timeline", "REDD+ Eligibility", "Recommendations"],
        "credit_cost": 18,
    },

    "aviation": {
        "display_name": "Aviation & Airspace Safety",
        "icon": "✈️",
        "description": "Terrain clearance, obstacle mapping, weather envelope, runway environment.",
        "sensing_stack": ["dem_terrain_clearance", "weather_ceiling_raster", "obstacle_height_lidar", "wind_shear_sar"],
        "regulatory_context": (
            "ICAO Annex 14 — Aerodromes: Physical characteristics and obstacle limitation surfaces. "
            "FAA Advisory Circular AC 150/5300-13A — Airport Design standards. "
            "EASA CS-ADR-DSN Certification Specifications for Aerodrome Design. "
            "NOTAM (Notice to Air Missions) geospatial clearance validation. "
            "IATA Ground Hazard Risk Assessment Framework."
        ),
        "risk_parameters": {
            "terrain_clearance_warning_m": 300.0,
            "crosswind_critical_knots": 15.0,
            "obstacle_height_critical_m": 150.0,
        },
        "agent_types": ["aircraft", "ground_crew", "airport_perimeter_public"],
        "report_sections": ["Executive Summary", "Obstacle Limitation Surface Analysis", "Terrain Clearance Profile", "Weather Ceiling Assessment", "Wildlife Strike Risk", "Recommendations"],
        "credit_cost": 22,
        "user_data_fields": ["flight_path_geojson", "aircraft_type", "approach_procedure"],
    },

    "mining": {
        "display_name": "Mining & Extractives",
        "icon": "⛏️",
        "description": "Subsidence monitoring, tailings dam integrity, acid drainage, EIA compliance.",
        "sensing_stack": ["insar_subsidence", "ndwi_tailings_dam", "acid_drainage_ndvi", "sar_slope_movement"],
        "regulatory_context": (
            "IFC Performance Standard 6 — Biodiversity Conservation and Sustainable Management. "
            "MAC (Mining Association of Canada) Towards Sustainable Mining Protocol. "
            "ICOLD Bulletin 121 — Tailings Dam safety guidelines. "
            "National Environmental Quality Act (NEQA) mining concession standards. "
            "Global Industry Standard on Tailings Management (GISTM) 2020."
        ),
        "risk_parameters": {
            "subsidence_critical_mm": 15.0,
            "tailings_dam_freeboard_warning_m": 0.5,
            "acid_rock_drainage_ph_threshold": 4.5,
        },
        "agent_types": ["mine_workers", "perimeter_communities", "ground_vehicles"],
        "report_sections": ["Executive Summary", "Ground Subsidence (InSAR)", "Tailings Dam Status", "Acid Rock Drainage Risk", "Community Proximity Impact", "Regulatory Compliance Status", "Recommendations"],
        "credit_cost": 22,
    },
}


def get_domain(domain_key: str) -> Dict[str, Any]:
    """Return the domain config or raise ValueError for unknown domains."""
    key = domain_key.lower().strip()
    if key not in DOMAIN_REGISTRY:
        raise ValueError(
            f"Unknown domain '{domain_key}'. "
            f"Supported: {', '.join(DOMAIN_REGISTRY.keys())}"
        )
    return DOMAIN_REGISTRY[key]


def list_domains() -> list:
    """Return a lightweight list of all domains for the frontend selector."""
    return [
        {
            "key": key,
            "display_name": v["display_name"],
            "icon": v["icon"],
            "description": v["description"],
            "credit_cost": v["credit_cost"],
            "user_data_fields": v.get("user_data_fields", []),
        }
        for key, v in DOMAIN_REGISTRY.items()
    ]
