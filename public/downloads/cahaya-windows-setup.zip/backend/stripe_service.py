"""
LENUDA™ Premium 2.0 — Stripe Integration Service
===================================================
Handles:
  - create_checkout_session() → returns Stripe Checkout session URL
  - handle_webhook()         → processes checkout.session.completed events
  - Customer lookup/creation
"""

import logging
from typing import Optional, Dict, Any

import stripe

from config import STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET

logger = logging.getLogger("stripe_service")

# Initialize Stripe
if STRIPE_SECRET_KEY:
    stripe.api_key = STRIPE_SECRET_KEY


# ============================================================================
# CHECKOUT SESSION
# ============================================================================

async def create_checkout_session(
    report_id: str,
    user_email: str,
    amount_cents: int,
    currency: str = "usd",
    success_url: str = "http://localhost:3000/payment/success?session_id={CHECKOUT_SESSION_ID}",
    cancel_url: str = "http://localhost:3000/payment/cancel",
    metadata: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Create a Stripe Checkout session for a report purchase.
    Returns dict with session_id and checkout_url.
    """
    if not STRIPE_SECRET_KEY:
        return {"error": "Stripe not configured", "session_id": None, "checkout_url": None}

    try:
        session_metadata = {
            "report_id": report_id,
            "user_email": user_email,
            **(metadata or {}),
        }

        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": currency,
                    "product_data": {
                        "name": f"LENUDA Environmental Intelligence Report",
                        "description": f"Report ID: {report_id}",
                    },
                    "unit_amount": amount_cents,
                },
                "quantity": 1,
            }],
            mode="payment",
            success_url=success_url,
            cancel_url=cancel_url,
            customer_email=user_email,
            metadata=session_metadata,
        )

        logger.info(f"Stripe checkout session created: {session.id} for report {report_id}")

        return {
            "session_id": session.id,
            "checkout_url": session.url,
            "amount_cents": amount_cents,
            "currency": currency,
        }
    except stripe.error.StripeError as e:
        logger.error(f"Stripe error creating checkout: {e}")
        return {"error": str(e), "session_id": None, "checkout_url": None}
    except Exception as e:
        logger.error(f"Error creating checkout session: {e}")
        return {"error": str(e), "session_id": None, "checkout_url": None}


# ============================================================================
# WEBHOOK HANDLER
# ============================================================================

async def handle_webhook(payload: bytes, sig_header: str) -> Dict[str, Any]:
    """
    Process incoming Stripe webhook events.
    Verifies signature and handles checkout.session.completed.
    Returns processing result.
    """
    if not STRIPE_WEBHOOK_SECRET:
        logger.warning("Stripe webhook secret not configured — skipping verification")
        # Still try to parse the event without verification for development
        import json
        try:
            event = stripe.Event.construct_from(json.loads(payload), stripe.api_key)
        except Exception as e:
            return {"error": f"Failed to parse webhook payload: {e}", "processed": False}
    else:
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, STRIPE_WEBHOOK_SECRET
            )
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"Stripe webhook signature verification failed: {e}")
            return {"error": "Invalid signature", "processed": False}
        except Exception as e:
            logger.error(f"Stripe webhook error: {e}")
            return {"error": str(e), "processed": False}

    event_type = event.get("type", "")
    logger.info(f"Stripe webhook received: {event_type}")

    # Handle checkout.session.completed
    if event_type == "checkout.session.completed":
        session = event["data"]["object"]
        return await _handle_checkout_completed(session)

    # Handle payment_intent.succeeded
    elif event_type == "payment_intent.succeeded":
        intent = event["data"]["object"]
        logger.info(f"Payment intent succeeded: {intent.get('id')}")
        return {"processed": True, "event_type": event_type}

    # Handle customer.subscription.created
    elif event_type == "customer.subscription.created":
        subscription = event["data"]["object"]
        logger.info(f"Subscription created: {subscription.get('id')}")
        return {"processed": True, "event_type": event_type}

    # Unhandled event type
    else:
        logger.info(f"Unhandled Stripe event type: {event_type}")
        return {"processed": False, "event_type": event_type, "note": "Event type not handled"}


async def _handle_checkout_completed(session: dict) -> Dict[str, Any]:
    """Process a completed checkout session — unlock report, credit account, etc."""
    metadata = session.get("metadata", {})
    report_id = metadata.get("report_id", "")
    user_email = metadata.get("user_email", session.get("customer_email", ""))
    amount_total = session.get("amount_total", 0)
    currency = session.get("currency", "usd")
    payment_status = session.get("payment_status", "")

    logger.info(
        f"Checkout completed: report={report_id}, email={user_email}, "
        f"amount={amount_total}, currency={currency}, status={payment_status}"
    )

    if payment_status != "paid":
        return {
            "processed": False,
            "event_type": "checkout.session.completed",
            "error": f"Payment status is '{payment_status}', not 'paid'",
        }

    # Update pipeline status and credit the user (done via Supabase in main.py routes)
    # Here we just return the parsed data for the route handler to act on
    return {
        "processed": True,
        "event_type": "checkout.session.completed",
        "report_id": report_id,
        "user_email": user_email,
        "amount_total": amount_total,
        "currency": currency,
        "session_id": session.get("id"),
        "customer_id": session.get("customer"),
    }


# ============================================================================
# CUSTOMER MANAGEMENT
# ============================================================================

async def get_or_create_customer(email: str, name: str = "") -> Optional[str]:
    """Get existing Stripe customer or create new one. Returns customer ID."""
    if not STRIPE_SECRET_KEY:
        return None

    try:
        # Search for existing customer
        customers = stripe.Customer.list(email=email, limit=1)
        if customers.data:
            return customers.data[0].id

        # Create new customer
        customer = stripe.Customer.create(
            email=email,
            name=name or email,
            metadata={"source": "lenuda_premium"},
        )
        return customer.id
    except Exception as e:
        logger.error(f"Stripe customer error: {e}")
        return None
