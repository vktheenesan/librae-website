"""
CAHAYA Sovereign — Ollama Local LLM Router
==========================================
Manages local AI inference via Ollama running on 127.0.0.1:11434.
Handles hardware tier detection, model selection, and chat routing.

Final Model Strategy (June 2026):
──────────────────────────────────────────────────────────────────
EDGE      → gemma4:12b  (primary)  — 7.5 GB, 8 GB VRAM
                                     Gemma 4 better general reasoning
           → qwen2.5:7b (fallback) — 4.5 GB, 6 GB VRAM
                                     Auto-switch for GEE code / Malay / math

STANDARD  → qwen2.5:32b            — 18 GB, 24 GB VRAM
                                     Best for GEE code, long context, SEA language

SOVEREIGN → qwen2.5:72b            — 41 GB, 80 GB VRAM
                                     Maximum reasoning, defense-grade analysis

VISION    → qwen2.5vl:7b (all)     — 5 GB — render verification + image analysis
EMBEDDINGS→ nomic-embed-text (all) — 274 MB — ChromaDB document search

Why these choices:
  • Qwen wins on: GEE JavaScript code, Malay/Indonesian, long context, spatial math
  • Gemma4 wins on: efficiency, general queries on low-end hardware
  • No Claude locally (not open source — kept as silent cloud fallback only)
  • Users never see model names — the router decides transparently

Server deployment (enterprise): One Sovereign server, multiple browser clients.
Analysts need only a browser — no GPU on their desk.
"""

import os
import json
import logging
import httpx
from typing import Optional, Dict, Any, List, AsyncGenerator

logger = logging.getLogger("ollama_router")

# ── Configuration ──────────────────────────────────────────────────────────────
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")

# Primary model per tier
TIER_MODEL_MAP = {
    "EDGE":      os.getenv("OLLAMA_MODEL_EDGE",      "gemma4:12b"),
    "STANDARD":  os.getenv("OLLAMA_MODEL_STANDARD",  "qwen2.5:32b"),
    "SOVEREIGN": os.getenv("OLLAMA_MODEL_SOVEREIGN", "qwen2.5:72b"),
}

# EDGE code/language fallback — auto-selected when prompt needs GEE code or Malay
EDGE_CODE_MODEL = os.getenv("OLLAMA_MODEL_EDGE_CODE", "qwen2.5:7b")

# Vision model for render verification (all tiers share this)
VISION_MODEL_LOCAL = os.getenv("OLLAMA_MODEL_VISION", "qwen2.5vl:7b")

# Keywords that trigger auto-switch to Qwen on EDGE tier
_CODE_TRIGGERS = [
    "var ", "const ", "function ", "ee.", "Map.", "var image", ".filterDate",
    "javascript", "code", "script", "gee", "earth engine",
    "kod", "skrip",  # Malay
    "kode", "skrip", # Indonesian
]
_MALAY_TRIGGERS = [
    "dalam bahasa", "tolong", "bantu saya", "saya nak", "mohon", "terima kasih",
    "boleh", "nak", "macam mana", "bagaimana", "apakah", "kenapa", "di mana",
]

def _needs_qwen_on_edge(prompt: str) -> bool:
    """Auto-detect if an EDGE prompt needs Qwen instead of Gemma4."""
    p = prompt.lower()
    return any(t in p for t in _CODE_TRIGGERS + _MALAY_TRIGGERS)


# Default model: read from cahaya.config.json or fall back to EDGE
def _get_active_model() -> str:
    config_paths = [
        os.path.join(os.path.dirname(__file__), "..", "cahaya.config.json"),
        os.path.join(os.path.dirname(__file__), "cahaya.config.json"),
    ]
    for path in config_paths:
        if os.path.exists(path):
            try:
                with open(path) as f:
                    cfg = json.load(f)
                tier = cfg.get("tier", "EDGE").upper()
                return TIER_MODEL_MAP.get(tier, TIER_MODEL_MAP["EDGE"])
            except Exception:
                pass
    return TIER_MODEL_MAP["EDGE"]


# ── Health Check ───────────────────────────────────────────────────────────────
async def check_ollama_health() -> Dict[str, Any]:
    """Check if Ollama is running and return available models."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{OLLAMA_BASE_URL}/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = [m["name"] for m in data.get("models", [])]
            return {
                "running": True,
                "models": models,
                "active_model": _get_active_model(),
                "tier": _get_tier_label(),
            }
    except Exception as e:
        return {
            "running": False,
            "error": str(e),
            "models": [],
            "active_model": None,
        }


def _get_tier_label() -> str:
    config_paths = [
        os.path.join(os.path.dirname(__file__), "..", "cahaya.config.json"),
        os.path.join(os.path.dirname(__file__), "cahaya.config.json"),
    ]
    for path in config_paths:
        if os.path.exists(path):
            try:
                with open(path) as f:
                    return json.load(f).get("tier", "EDGE").upper()
            except Exception:
                pass
    return "EDGE"


# ── Pull Model ─────────────────────────────────────────────────────────────────
async def pull_model_if_missing(tier: str = "EDGE") -> Dict[str, Any]:
    """
    Pull the correct model for the given tier if not already downloaded.
    Returns progress as streaming JSON lines from Ollama.
    Called by the installer at first run.
    """
    model_tag = TIER_MODEL_MAP.get(tier.upper(), TIER_MODEL_MAP["EDGE"])
    logger.info(f"Pulling Ollama model: {model_tag} for tier {tier}")
    try:
        async with httpx.AsyncClient(timeout=3600) as client:
            async with client.stream(
                "POST",
                f"{OLLAMA_BASE_URL}/api/pull",
                json={"name": model_tag, "stream": True},
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if line.strip():
                        try:
                            yield json.loads(line)
                        except json.JSONDecodeError:
                            yield {"status": line}
    except Exception as e:
        logger.error(f"Model pull error: {e}")
        yield {"error": str(e)}


# ── Chat Completion ────────────────────────────────────────────────────────────
async def route_to_ollama(
    prompt: str,
    system_message: str = (
        "You are Librae GeoInt AI, a sovereign spatial intelligence assistant. "
        "You help with environmental analysis, satellite data interpretation, GIS workflows, "
        "and compliance reporting. Be precise, verifiable, and concise."
    ),
    conversation_history: Optional[List[Dict[str, str]]] = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    stream: bool = False,
    force_model: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Route a prompt to the locally running Ollama model.

    Smart EDGE routing:
      - EDGE tier uses Gemma4:12b by default (better general reasoning)
      - Auto-switches to Qwen2.5:7b if prompt contains GEE code patterns or Malay/Indonesian
      - STANDARD/SOVEREIGN always use Qwen (best for spatial + code + SEA languages)

    Falls back gracefully if Ollama is not running.
    Users never see model names — transparent routing.
    """
    tier = _get_tier_label()
    model = force_model or _get_active_model()

    # Smart EDGE routing: switch to Qwen if task needs it
    if tier == "EDGE" and not force_model and _needs_qwen_on_edge(prompt):
        model = EDGE_CODE_MODEL
        logger.info(f"EDGE smart-switch: Gemma4 → Qwen2.5-7b (code/language detected)")

    messages = [{"role": "system", "content": system_message}]
    if conversation_history:
        messages.extend(conversation_history)
    messages.append({"role": "user", "content": prompt})

    body = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
        },
    }

    try:
        async with httpx.AsyncClient(timeout=300) as client:
            resp = await client.post(
                f"{OLLAMA_BASE_URL}/api/chat",
                json=body,
            )
            resp.raise_for_status()
            data = resp.json()

            message = data.get("message", {})
            text = message.get("content", "")
            return {
                "text": text,
                "model": model,
                "tier": tier,
                "done": data.get("done", True),
                "total_duration_ms": data.get("total_duration", 0) // 1_000_000,
                "source": "ollama_local",
            }

    except httpx.ConnectError:
        logger.warning("Ollama not running — falling back to cloud AI")
        return {
            "text": "",
            "error": "local_ai_offline",
            "fallback_required": True,
            "source": "ollama_local",
        }
    except Exception as e:
        logger.error(f"Ollama error: {e}")
        return {"text": "", "error": str(e), "source": "ollama_local"}


# ── Streaming Chat ─────────────────────────────────────────────────────────────
async def stream_ollama(
    prompt: str,
    system_message: str = (
        "You are Librae GeoInt AI. Be precise, concise, and technically accurate."
    ),
    conversation_history: Optional[List[Dict[str, str]]] = None,
    temperature: float = 0.7,
) -> AsyncGenerator[str, None]:
    """
    Stream tokens from Ollama for real-time chat display.
    Yields raw token strings as they arrive.
    """
    model = _get_active_model()
    messages = [{"role": "system", "content": system_message}]
    if conversation_history:
        messages.extend(conversation_history)
    messages.append({"role": "user", "content": prompt})

    body = {
        "model": model,
        "messages": messages,
        "stream": True,
        "options": {"temperature": temperature},
    }

    try:
        async with httpx.AsyncClient(timeout=600) as client:
            async with client.stream(
                "POST", f"{OLLAMA_BASE_URL}/api/chat", json=body
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if line.strip():
                        try:
                            chunk = json.loads(line)
                            token = chunk.get("message", {}).get("content", "")
                            if token:
                                yield token
                            if chunk.get("done"):
                                break
                        except json.JSONDecodeError:
                            continue
    except Exception as e:
        logger.error(f"Ollama stream error: {e}")
        yield f"[AI offline: {e}]"


# ── Embedding Generation ───────────────────────────────────────────────────────
async def get_ollama_embedding(text: str, model: str = "nomic-embed-text") -> List[float]:
    """
    Generate text embeddings using Ollama's embedding models.
    Used by LlamaIndex/ChromaDB for document intelligence.
    Default: nomic-embed-text (768-dim, very fast, free).
    """
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{OLLAMA_BASE_URL}/api/embeddings",
                json={"model": model, "prompt": text},
            )
            resp.raise_for_status()
            return resp.json().get("embedding", [])
    except Exception as e:
        logger.error(f"Ollama embedding error: {e}")
        return []
