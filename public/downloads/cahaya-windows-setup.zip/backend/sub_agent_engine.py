"""
BAYU Commercial OS — Sub-Agent Engine
=======================================
Manages autonomous sub-agents spawned by executive agents (CFO, CTO, CMO, COO, CSR).
Includes budget tracking, reusable programs, and outcome learning.
"""

import json
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

from supabase_client import get_bayu_client
from ai_router import route_to_gemini, route_to_gpt, route_to_qwen, route_to_claude
from config import cfg

logger = logging.getLogger("sub_agent_engine")

# Daily budget ceiling per agent (USD)
DEFAULT_BUDGET_CEILING = float(cfg("AGENT_BUDGET_CEILING_USD", "10.00"))

# Approximate cost per 1K tokens (input+output blended)
MODEL_COST_PER_1K = {
    "gpt-4o": 0.005,
    "gpt-4o-mini": 0.00015,
    "gemini-2.0-flash": 0.0001,
    "claude-sonnet-4-20250514": 0.006,
    "qwen-plus": 0.0004,
}


# ============================================================================
# BUDGET HELPERS
# ============================================================================

async def get_agent_budget(agent_key: str) -> Dict[str, Any]:
    """Return today's spend vs ceiling for an agent."""
    bayu = get_bayu_client()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    rows = await bayu.select(
        "agent_budget_log",
        f"agent_key=eq.{agent_key}&log_date=eq.{today}",
        limit=1,
    )

    if rows:
        row = rows[0]
        return {
            "agent_key": agent_key,
            "log_date": today,
            "tokens_used": row.get("tokens_used", 0),
            "cost_usd": float(row.get("cost_usd", 0)),
            "ceiling_usd": float(row.get("ceiling_usd", DEFAULT_BUDGET_CEILING)),
            "sub_agents_spawned": row.get("sub_agents_spawned", 0),
            "remaining_usd": float(row.get("ceiling_usd", DEFAULT_BUDGET_CEILING)) - float(row.get("cost_usd", 0)),
        }

    return {
        "agent_key": agent_key,
        "log_date": today,
        "tokens_used": 0,
        "cost_usd": 0.0,
        "ceiling_usd": DEFAULT_BUDGET_CEILING,
        "sub_agents_spawned": 0,
        "remaining_usd": DEFAULT_BUDGET_CEILING,
    }


async def _update_budget(agent_key: str, tokens: int, cost: float, spawned: int = 0):
    """Upsert today's budget log for an agent."""
    bayu = get_bayu_client()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    rows = await bayu.select(
        "agent_budget_log",
        f"agent_key=eq.{agent_key}&log_date=eq.{today}",
        limit=1,
    )

    if rows:
        row = rows[0]
        await bayu.update(
            "agent_budget_log",
            f"id=eq.{row['id']}",
            {
                "tokens_used": row.get("tokens_used", 0) + tokens,
                "cost_usd": float(row.get("cost_usd", 0)) + cost,
                "sub_agents_spawned": row.get("sub_agents_spawned", 0) + spawned,
            },
        )
    else:
        await bayu.insert("agent_budget_log", {
            "agent_key": agent_key,
            "log_date": today,
            "tokens_used": tokens,
            "cost_usd": round(cost, 4),
            "ceiling_usd": DEFAULT_BUDGET_CEILING,
            "sub_agents_spawned": spawned,
        })


# ============================================================================
# SUB-AGENT CRUD
# ============================================================================

async def create_sub_agent(
    parent_agent: str,
    name: str,
    task_description: str,
    model: str = "gpt-4o",
) -> Optional[Dict[str, Any]]:
    """Create a sub-agent record after checking budget."""
    budget = await get_agent_budget(parent_agent)
    if budget["remaining_usd"] <= 0:
        logger.warning(f"Budget exhausted for {parent_agent}: ${budget['cost_usd']:.4f} / ${budget['ceiling_usd']:.2f}")
        return {"error": "Budget ceiling reached for today", "budget": budget}

    bayu = get_bayu_client()
    record = await bayu.insert("sub_agents", {
        "parent_agent": parent_agent,
        "name": name,
        "task_description": task_description,
        "model": model,
        "status": "active",
    })

    if record:
        await _update_budget(parent_agent, tokens=0, cost=0.0, spawned=1)
        logger.info(f"Sub-agent created: {name} for {parent_agent} (model={model})")

    return record


async def execute_sub_agent(sub_agent_id: str) -> Dict[str, Any]:
    """Run the LLM call for a sub-agent, store result, and update budget."""
    bayu = get_bayu_client()

    rows = await bayu.select("sub_agents", f"id=eq.{sub_agent_id}", limit=1)
    if not rows:
        return {"error": "Sub-agent not found"}

    agent = rows[0]
    if agent.get("status") not in ("active",):
        return {"error": f"Sub-agent is in '{agent.get('status')}' state, not executable"}

    model = agent.get("model", "gpt-4o")
    task = agent.get("task_description", "")
    parent = agent.get("parent_agent", "unknown")

    system_msg = (
        f"You are a specialized sub-agent of the {parent.upper()} executive agent at Librae AI Labs. "
        f"Complete the following task thoroughly and concisely. Return structured JSON when possible."
    )

    # Route to appropriate model
    if "gemini" in model.lower():
        result = await route_to_gemini(prompt=task, system_instruction=system_msg)
    elif "claude" in model.lower():
        result = await route_to_claude(prompt=task, system_message=system_msg)
    elif "qwen" in model.lower():
        result = await route_to_qwen(prompt=task, system_message=system_msg, enable_thinking=False)
    else:
        result = await route_to_gpt(prompt=task, system_message=system_msg)

    # Extract token usage
    usage = result.get("usage", {})
    total_tokens = usage.get("totalTokenCount") or usage.get("total_tokens") or 0
    cost_per_1k = MODEL_COST_PER_1K.get(model, 0.005)
    cost = (total_tokens / 1000) * cost_per_1k

    # Update sub-agent record
    now = datetime.now(timezone.utc).isoformat()
    await bayu.update(
        "sub_agents",
        f"id=eq.{sub_agent_id}",
        {
            "status": "completed" if not result.get("error") else "failed",
            "result": json.dumps({"text": result.get("text", ""), "model": result.get("model", model)}),
            "tokens_used": total_tokens,
            "cost_usd": round(cost, 4),
            "completed_at": now,
        },
    )

    # Update budget
    await _update_budget(parent, tokens=total_tokens, cost=cost)

    logger.info(f"Sub-agent {sub_agent_id} executed: {total_tokens} tokens, ${cost:.4f}")

    return {
        "sub_agent_id": sub_agent_id,
        "status": "completed" if not result.get("error") else "failed",
        "text": result.get("text", ""),
        "tokens_used": total_tokens,
        "cost_usd": round(cost, 4),
        "error": result.get("error"),
    }


async def list_sub_agents(
    parent_agent: Optional[str] = None,
    status: str = "active",
) -> List[Dict[str, Any]]:
    """Return list of sub-agents, optionally filtered by parent and status."""
    bayu = get_bayu_client()
    query = f"status=eq.{status}&order=created_at.desc"
    if parent_agent:
        query = f"parent_agent=eq.{parent_agent}&{query}"
    return await bayu.select("sub_agents", query, limit=100)


async def archive_sub_agent(sub_agent_id: str) -> bool:
    """Soft-archive a sub-agent."""
    bayu = get_bayu_client()
    now = datetime.now(timezone.utc).isoformat()
    success = await bayu.update(
        "sub_agents",
        f"id=eq.{sub_agent_id}",
        {"status": "archived", "archived_at": now},
    )
    if success:
        logger.info(f"Sub-agent {sub_agent_id} archived")
    return success


# ============================================================================
# AGENT PROGRAMS
# ============================================================================

async def store_program(
    created_by: str,
    name: str,
    description: str,
    program_code: str,
    program_type: str = "prompt_template",
) -> Optional[Dict[str, Any]]:
    """Save a reusable agent program."""
    bayu = get_bayu_client()
    record = await bayu.insert("agent_programs", {
        "created_by": created_by,
        "name": name,
        "description": description,
        "program_code": program_code,
        "program_type": program_type,
    })
    if record:
        logger.info(f"Program stored: {name} by {created_by}")
    return record


async def list_programs(created_by: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return agent programs, optionally filtered by creator."""
    bayu = get_bayu_client()
    query = "order=created_at.desc"
    if created_by:
        query = f"created_by=eq.{created_by}&{query}"
    return await bayu.select("agent_programs", query, limit=100)


# ============================================================================
# AGENT LEARNING LOG
# ============================================================================

async def log_learning(
    agent_key: str,
    action_type: str,
    input_summary: str,
    output_summary: str,
    outcome: str,
    details: Optional[Dict[str, Any]] = None,
    learning_extracted: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Store a learning outcome for prompt refinement."""
    bayu = get_bayu_client()
    record = await bayu.insert("agent_learning_log", {
        "agent_key": agent_key,
        "action_type": action_type,
        "input_summary": input_summary,
        "output_summary": output_summary,
        "outcome": outcome,
        "outcome_details": json.dumps(details) if details else None,
        "learning_extracted": learning_extracted,
    })
    if record:
        logger.info(f"Learning logged: {agent_key}/{action_type} → {outcome}")
    return record
