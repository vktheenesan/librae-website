"""
BAYU Commercial OS — CEO-001 & War Room API Routes
====================================================
Sprint 19–20: Backend API expansion for the 10-Layer Commercial OS.

Endpoints:
  - /api/ceo/queue          — Pending approval queue
  - /api/ceo/dashboard      — Executive KPIs
  - /api/ceo/queue/{id}/decide — Approve/reject/revise
  - /api/warroom/chat       — War Room multi-agent chat
  - /api/warroom/sessions   — List War Room sessions
  - /api/trials/activate    — Activate a trial
  - /api/trials             — List trials
  - /api/trials/{id}/usage  — Trial usage data
  - /api/proposals/generate — Generate a proposal
  - /api/proposals/{id}/send — Send a proposal
  - /api/customer/health    — Customer health scores
  - /api/learning/insights  — Learning database insights
  - /api/agents/…           — Sub-agent CRUD, programs, budget
  - /api/licenses/…         — License token management
  - /api/csr/…              — CSR call scripts & installation guides
"""

import os
import uuid
import asyncio
import logging
import json
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel

from supabase_client import get_bayu_client
from ai_router import route_to_gemini, route_to_qwen

from sub_agent_engine import (
    create_sub_agent,
    execute_sub_agent,
    list_sub_agents,
    archive_sub_agent,
    store_program,
    list_programs,
    get_agent_budget,
    log_learning,
)
from license_token_engine import (
    generate_license_token,
    validate_token,
    renew_token,
    revoke_token,
    list_tokens,
    calculate_renewal_price,
    get_expiring_soon,
)

logger = logging.getLogger("ceo_api")

router = APIRouter(prefix="/api", tags=["BAYU Commercial OS"])

# AI Model config
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ALIBABA_MODEL_STUDIO_API_KEY = os.getenv("ALIBABA_MODEL_STUDIO_API_KEY", "")
LLM_API_BASE = os.getenv("LLM_API_BASE", "")


# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class CEODecisionRequest(BaseModel):
    decision: str  # 'approve', 'reject', 'revise'
    notes: Optional[str] = ""
    decided_by: str = "founder"


class WarRoomChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    target_agents: Optional[List[str]] = None


class TrialActivateRequest(BaseModel):
    lead_id: str
    product: str = "cahaya"
    deployment_type: str = "local"
    modules: Optional[List[str]] = None


class ProposalGenerateRequest(BaseModel):
    lead_id: str
    trial_id: Optional[str] = None
    modules: Optional[List[str]] = None
    deployment_type: str = "local"
    seats: int = 1


class SubAgentCreateRequest(BaseModel):
    name: str
    task_description: str
    model: str = "gpt-4o"


class ProgramCreateRequest(BaseModel):
    created_by: str
    name: str
    description: str = ""
    program_code: str
    program_type: str = "prompt_template"


class LicenseGenerateRequest(BaseModel):
    org_name: str
    contact_email: Optional[str] = None
    tier: str = "1yr"
    annual_fee: Optional[float] = None


class LicenseValidateRequest(BaseModel):
    token: str


class CSRCallScriptRequest(BaseModel):
    org_name: str
    contact_name: str
    product: str = "cahaya"
    deployment_type: str = "local"
    modules: Optional[List[str]] = None
    notes: Optional[str] = ""


class CSRInstallationGuideRequest(BaseModel):
    org_name: str
    deployment_type: str = "local"
    modules: Optional[List[str]] = None
    os_environment: str = "ubuntu_22"


# ============================================================================
# CEO-001: APPROVAL QUEUE
# ============================================================================

@router.get("/ceo/queue")
async def get_approval_queue():
    """Get all pending items in the CEO-001 approval queue."""
    bayu = get_bayu_client()
    pending = await bayu.select(
        "approval_queue",
        "status=eq.pending&order=created_at.desc"
    )
    return {"queue": pending, "count": len(pending)}


@router.get("/ceo/dashboard")
async def get_ceo_dashboard():
    """Executive KPI dashboard for CEO-001."""
    bayu = get_bayu_client()

    # Pending approvals
    pending = await bayu.select("approval_queue", "status=eq.pending")

    # Active trials
    trials = await bayu.select("trials", "status=eq.active")

    # Active customers (orgs with status=active)
    orgs = await bayu.select("organizations", "select=id,status,mrr_usd,arr_usd")
    active_orgs = [o for o in orgs if o.get("status") == "active"]

    # Recent decisions
    decisions = await bayu.select(
        "executive_decisions",
        "order=created_at.desc",
        limit=10
    )

    # Pipeline value
    leads = await bayu.select("leads", "select=id,metadata")
    pipeline_value = 0
    for lead in leads:
        meta = lead.get("metadata") or {}
        # Try to extract estimated deal value
        if meta.get("lead_value_index"):
            lvi = float(meta.get("lead_value_index", 0))
            # Rough estimate: LVI 80 → $150K, LVI 50 → $50K
            pipeline_value += (lvi / 100) * 200000

    total_mrr = sum(float(o.get("mrr_usd", 0)) for o in active_orgs)
    total_arr = sum(float(o.get("arr_usd", 0)) for o in active_orgs)

    return {
        "pending_approvals": len(pending),
        "active_trials": len(trials),
        "active_customers": len(active_orgs),
        "pipeline_value_usd": round(pipeline_value, 2),
        "mrr_usd": total_mrr,
        "arr_usd": total_arr,
        "total_leads": len(leads),
        "recent_decisions": decisions[:5],
    }


@router.post("/ceo/queue/{item_id}/decide")
async def ceo_decide(item_id: str, req: CEODecisionRequest):
    """Approve, reject, or revise a CEO-001 queue item."""
    bayu = get_bayu_client()

    # Update approval_queue
    status_map = {
        "approve": "approved",
        "reject": "rejected",
        "revise": "revised"
    }
    new_status = status_map.get(req.decision, "revised")

    updated = await bayu.update(
        "approval_queue",
        f"id=eq.{item_id}",
        {
            "status": new_status,
            "decision_by": req.decided_by,
            "decision_notes": req.notes,
            "decided_at": datetime.now(timezone.utc).isoformat()
        }
    )

    # Record in executive_decisions audit trail
    await bayu.insert("executive_decisions", {
        "queue_item_id": item_id,
        "decision": req.decision,
        "rationale": req.notes or f"{req.decision} by {req.decided_by}",
    })

    logger.info(f"CEO-001: {req.decision.upper()} for item {item_id} by {req.decided_by}")

    return {
        "success": True,
        "item_id": item_id,
        "decision": req.decision,
        "status": new_status,
        "decided_by": req.decided_by
    }


# ============================================================================
# WAR ROOM: MULTI-AGENT VIRTUAL BOARDROOM
# ============================================================================

async def call_ai_for_warroom(agent_role: str, agent_name: str, user_message: str, context: str = "") -> str:
    """Call an AI model for a War Room agent response."""
    import httpx

    system_prompt = f"""You are the {agent_name} of Librae AI Labs, participating in an executive War Room session.
Your role: {agent_role}

RULES:
1. Be concise but insightful. Max 3 paragraphs.
2. Always tie your analysis back to business impact.
3. Use data and specifics when possible.
4. If you disagree with a decision, say so constructively.
5. Address Theenesan directly as "Theenesan" or "Founder".
6. Sign off with your title abbreviation (e.g., "— CFO").

{f'Context: {context}' if context else ''}"""

    try:
        # CFO → GPT-4o
        if "CFO" in agent_name and OPENAI_API_KEY:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
                    json={"model": "gpt-4o", "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message}
                    ], "max_tokens": 500},
                    timeout=30
                )
                if resp.status_code == 200:
                    return resp.json()["choices"][0]["message"]["content"]

        # CTO → Claude
        if "CTO" in agent_name and ANTHROPIC_API_KEY:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "Content-Type": "application/json"
                    },
                    json={"model": "claude-sonnet-4-20250514", "max_tokens": 500,
                          "system": system_prompt,
                          "messages": [{"role": "user", "content": user_message}]},
                    timeout=30
                )
                if resp.status_code == 200:
                    return resp.json()["content"][0]["text"]

        # CMO → Gemini
        if "CMO" in agent_name and GEMINI_API_KEY:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GEMINI_API_KEY}",
                    json={"contents": [{"parts": [{"text": f"{system_prompt}\n\nUser: {user_message}"}]}],
                          "generationConfig": {"maxOutputTokens": 500}},
                    timeout=30
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return data["candidates"][0]["content"]["parts"][0]["text"]

        # COO → Qwen
        if "COO" in agent_name and ALIBABA_MODEL_STUDIO_API_KEY and LLM_API_BASE:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"{LLM_API_BASE}/chat/completions",
                    headers={"Authorization": f"Bearer {ALIBABA_MODEL_STUDIO_API_KEY}", "Content-Type": "application/json"},
                    json={"model": os.getenv("LLM_MODEL_NAME", "qwen-plus"),
                          "messages": [
                              {"role": "system", "content": system_prompt},
                              {"role": "user", "content": user_message}
                          ], "max_tokens": 500},
                    timeout=30
                )
                if resp.status_code == 200:
                    return resp.json()["choices"][0]["message"]["content"]

        # Fallback: use Gemini for any agent
        if GEMINI_API_KEY:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GEMINI_API_KEY}",
                    json={"contents": [{"parts": [{"text": f"{system_prompt}\n\nUser: {user_message}"}]}],
                          "generationConfig": {"maxOutputTokens": 500}},
                    timeout=30
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return data["candidates"][0]["content"]["parts"][0]["text"]

    except Exception as e:
        logger.error(f"War Room AI call failed for {agent_name}: {e}")

    return f"[{agent_name} is temporarily offline. Please try again.]"


@router.post("/warroom/chat")
async def warroom_chat(req: WarRoomChatRequest):
    """Send a message to the War Room and get responses from all 4 executive agents."""
    bayu = get_bayu_client()
    import asyncio

    # Get or create session
    session_id = req.session_id
    if not session_id:
        session = await bayu.insert("warroom_sessions", {
            "title": f"Session — {datetime.now().strftime('%d %b %Y %H:%M')}",
            "participants": ["founder", "cfo", "cto", "cmo", "coo"],
            "status": "active"
        })
        session_id = session.get("id") if session else str(uuid.uuid4())

    # Store founder message
    await bayu.insert("warroom_messages", {
        "session_id": session_id,
        "sender": "founder",
        "content": req.message,
        "message_type": "text"
    })

    # Fetch recent context (last 5 messages for context)
    recent = await bayu.select(
        "warroom_messages",
        f"session_id=eq.{session_id}&order=created_at.desc",
        limit=5
    )
    context = "\n".join([f"{m['sender']}: {m['content']}" for m in reversed(recent)]) if recent else ""

    # Call selected agents in parallel
    agents = {
        "cfo": ("Chief Financial Officer — Revenue, pricing, cash flow analysis", "CFO Agent"),
        "cto": ("Chief Technology Officer — Architecture, security, deployment", "CTO Agent"),
        "cmo": ("Chief Marketing Officer — Brand, outreach, positioning", "CMO Agent"),
        "coo": ("Chief Operating Officer — Ops, delivery, process efficiency", "COO Agent"),
    }

    target_keys = req.target_agents if req.target_agents else list(agents.keys())
    target_keys = [k for k in target_keys if k in agents]
    if not target_keys:
        target_keys = list(agents.keys())

    tasks = []
    for agent_key in target_keys:
        role, name = agents[agent_key]
        tasks.append(call_ai_for_warroom(role, name, req.message, context))

    results = await asyncio.gather(*tasks, return_exceptions=True)

    responses = {}
    for i, result in enumerate(results):
        key = target_keys[i]
        if isinstance(result, Exception):
            responses[key] = f"[{agents[key][1]} encountered an error: {str(result)}]"
        else:
            responses[key] = result

        # Store each agent's response
        await bayu.insert("warroom_messages", {
            "session_id": session_id,
            "sender": key,
            "content": responses[key],
            "message_type": "analysis",
            "metadata": json.dumps({"model_used": agents[key][1]})
        })

    logger.info(f"War Room: {len(target_keys)} agents responded in session {session_id}")

    return {
        "session_id": session_id,
        "responses": responses,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }


@router.get("/warroom/sessions")
async def list_warroom_sessions():
    """List all War Room sessions."""
    bayu = get_bayu_client()
    sessions = await bayu.select(
        "warroom_sessions",
        "order=created_at.desc",
        limit=20
    )
    return {"sessions": sessions}


@router.get("/warroom/sessions/{session_id}/messages")
async def get_warroom_messages(session_id: str):
    """Get all messages from a War Room session."""
    bayu = get_bayu_client()
    messages = await bayu.select(
        "warroom_messages",
        f"session_id=eq.{session_id}&order=created_at.asc",
        limit=200
    )
    return {"messages": messages}


# ============================================================================
# TRIALS
# ============================================================================

@router.post("/trials/activate")
async def activate_trial(req: TrialActivateRequest):
    """Activate a 30-day trial for a lead."""
    bayu = get_bayu_client()

    # Get lead
    leads = await bayu.select("leads", f"id=eq.{req.lead_id}", limit=1)
    if not leads:
        raise HTTPException(status_code=404, detail="Lead not found")
    lead = leads[0]

    # Generate trial token (simplified — in production, call /api/token/generate)
    trial_token = f"trial_{uuid.uuid4().hex[:16]}"
    now = datetime.now(timezone.utc)
    expiry = now + timedelta(days=30)

    modules = req.modules or ["gee_analytics", "ingest", "compliance"]

    # Create trial record
    trial = await bayu.insert("trials", {
        "org_id": lead.get("org_id"),
        "lead_id": req.lead_id,
        "product": req.product,
        "trial_token": trial_token,
        "deployment_type": req.deployment_type,
        "modules_enabled": modules,
        "start_date": now.isoformat(),
        "expiry_date": expiry.isoformat(),
        "status": "active"
    })

    # Update lead pipeline_status
    await bayu.update(
        "leads",
        f"id=eq.{req.lead_id}",
        {"pipeline_status": "trial_active"}
    )

    logger.info(f"Trial activated for lead {req.lead_id}: token={trial_token}, expires={expiry.isoformat()}")

    return {
        "success": True,
        "trial": trial,
        "trial_token": trial_token,
        "expires": expiry.isoformat()
    }


@router.get("/trials")
async def list_trials():
    """List all trials."""
    bayu = get_bayu_client()
    trials = await bayu.select("trials", "order=created_at.desc", limit=50)
    return {"trials": trials}


@router.get("/trials/{trial_id}/usage")
async def get_trial_usage(trial_id: str):
    """Get usage data for a specific trial."""
    bayu = get_bayu_client()
    usage = await bayu.select(
        "trial_usage",
        f"trial_id=eq.{trial_id}&order=date.desc",
        limit=30
    )
    return {"trial_id": trial_id, "usage": usage}


# ============================================================================
# PROPOSALS
# ============================================================================

@router.post("/proposals/generate")
async def generate_proposal(req: ProposalGenerateRequest):
    """Generate a dynamic pricing proposal for a lead."""
    bayu = get_bayu_client()

    leads = await bayu.select("leads", f"id=eq.{req.lead_id}", limit=1)
    if not leads:
        raise HTTPException(status_code=404, detail="Lead not found")
    lead = leads[0]
    meta = lead.get("metadata") or {}

    # Dynamic pricing calculation
    base_price_usd = 2400  # Base annual for EDGE tier
    module_prices = {
        "gee_analytics": 1200, "ingest": 800, "compliance": 1500,
        "sim": 2000, "drone_integration": 3000, "api_gateway": 1800,
        "white_label": 5000, "multi_tenant": 8000
    }

    modules = req.modules or ["gee_analytics", "ingest", "compliance"]
    module_cost = sum(module_prices.get(m, 1000) for m in modules)
    seat_cost = (req.seats - 1) * 600  # $600 per additional seat
    annual_value = base_price_usd + module_cost + seat_cost

    # Geography multiplier
    country = (meta.get("headquarters_country") or "").lower()
    if any(c in country for c in ["united states", "australia", "switzerland", "norway", "japan"]):
        annual_value *= 1.3
    elif any(c in country for c in ["malaysia", "indonesia", "thailand", "india"]):
        annual_value *= 0.7

    pricing_json = {
        "base_price_usd": base_price_usd,
        "modules": {m: module_prices.get(m, 1000) for m in modules},
        "seat_cost": seat_cost,
        "geography_multiplier": round(annual_value / (base_price_usd + module_cost + seat_cost), 2),
        "total_annual_usd": round(annual_value, 2),
        "monthly_usd": round(annual_value / 12, 2),
    }

    proposal = await bayu.insert("proposals", {
        "org_id": lead.get("org_id"),
        "lead_id": req.lead_id,
        "trial_id": req.trial_id,
        "version": 1,
        "pricing_json": json.dumps(pricing_json),
        "modules": modules,
        "deployment_type": req.deployment_type,
        "seats": req.seats,
        "annual_value_usd": round(annual_value, 2),
        "status": "draft",
        "expires_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
    })

    logger.info(f"Proposal generated for {lead.get('company_name')}: ${annual_value:.2f}/yr")

    return {
        "success": True,
        "proposal": proposal,
        "pricing": pricing_json
    }


@router.get("/proposals")
async def list_proposals():
    """List all proposals."""
    bayu = get_bayu_client()
    proposals = await bayu.select("proposals", "order=created_at.desc", limit=50)
    return {"proposals": proposals}


# ============================================================================
# CUSTOMER HEALTH
# ============================================================================

@router.get("/customer/health")
async def get_customer_health():
    """Get customer health scores."""
    bayu = get_bayu_client()
    health = await bayu.select(
        "customer_health",
        "order=created_at.desc",
        limit=50
    )
    return {"health_data": health}


# ============================================================================
# LEARNING INSIGHTS
# ============================================================================

@router.get("/learning/insights")
async def get_learning_insights():
    """Get aggregated learning insights from the learning database."""
    bayu = get_bayu_client()

    # Winning messages (top by success_rate)
    winning = await bayu.select(
        "learning_db",
        "category=eq.winning_message&order=success_rate.desc",
        limit=10
    )

    # Objections
    objections = await bayu.select(
        "learning_db",
        "category=eq.objection&order=created_at.desc",
        limit=10
    )

    # Pricing insights
    pricing = await bayu.select(
        "learning_db",
        "category=eq.pricing_insight&order=created_at.desc",
        limit=5
    )

    return {
        "winning_messages": winning,
        "objections": objections,
        "pricing_insights": pricing,
        "total_learnings": len(winning) + len(objections) + len(pricing)
    }


# ============================================================================
# RENEWALS
# ============================================================================

@router.get("/renewals")
async def list_renewals():
    """List all renewal records."""
    bayu = get_bayu_client()
    renewals = await bayu.select("renewals", "order=created_at.desc", limit=50)
    return {"renewals": renewals}


# ============================================================================
# PAYMENTS
# ============================================================================

@router.get("/payments")
async def list_payments():
    """List all payment records."""
    bayu = get_bayu_client()
    payments = await bayu.select("payments", "order=created_at.desc", limit=50)
    return {"payments": payments}


# ============================================================================
# SUB-AGENTS
# ============================================================================

@router.post("/agents/{agent_key}/sub-agents")
async def api_create_sub_agent(agent_key: str, req: SubAgentCreateRequest):
    """Create a new sub-agent for a parent executive agent."""
    result = await create_sub_agent(
        parent_agent=agent_key,
        name=req.name,
        task_description=req.task_description,
        model=req.model,
    )
    if result and result.get("error"):
        raise HTTPException(status_code=429, detail=result["error"])
    if not result:
        raise HTTPException(status_code=500, detail="Failed to create sub-agent")
    return {"success": True, "sub_agent": result}


@router.get("/agents/{agent_key}/sub-agents")
async def api_list_sub_agents(agent_key: str, status: str = "active"):
    """List sub-agents for a specific parent agent."""
    agents = await list_sub_agents(parent_agent=agent_key, status=status)
    return {"sub_agents": agents, "count": len(agents)}


@router.post("/agents/sub-agents/{sub_id}/execute")
async def api_execute_sub_agent(sub_id: str):
    """Execute a sub-agent's LLM task."""
    result = await execute_sub_agent(sub_id)
    if result.get("error"):
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.delete("/agents/sub-agents/{sub_id}")
async def api_archive_sub_agent(sub_id: str):
    """Archive (soft-delete) a sub-agent."""
    success = await archive_sub_agent(sub_id)
    if not success:
        raise HTTPException(status_code=404, detail="Sub-agent not found or already archived")
    return {"success": True, "archived": sub_id}


# ============================================================================
# AGENT PROGRAMS
# ============================================================================

@router.get("/agents/programs")
async def api_list_programs(created_by: Optional[str] = None):
    """List all agent programs, optionally filtered by creator."""
    programs = await list_programs(created_by=created_by)
    return {"programs": programs, "count": len(programs)}


@router.post("/agents/programs")
async def api_create_program(req: ProgramCreateRequest):
    """Create a new reusable agent program."""
    result = await store_program(
        created_by=req.created_by,
        name=req.name,
        description=req.description,
        program_code=req.program_code,
        program_type=req.program_type,
    )
    if not result:
        raise HTTPException(status_code=500, detail="Failed to store program")
    return {"success": True, "program": result}


# ============================================================================
# AGENT BUDGET
# ============================================================================

@router.get("/agents/{agent_key}/budget")
async def api_get_agent_budget(agent_key: str):
    """Get today's budget status for an agent."""
    budget = await get_agent_budget(agent_key)
    return budget


# ============================================================================
# LICENSE TOKENS
# ============================================================================

@router.post("/licenses/generate")
async def api_generate_license(req: LicenseGenerateRequest):
    """Generate a new Cahaya license token. The plaintext token is returned ONCE."""
    result = await generate_license_token(
        org_name=req.org_name,
        contact_email=req.contact_email,
        tier=req.tier,
        annual_fee=req.annual_fee,
    )
    return {"success": True, "license": result}


@router.get("/licenses")
async def api_list_licenses(active_only: bool = True):
    """List all license tokens."""
    tokens = await list_tokens(active_only=active_only)
    return {"licenses": tokens, "count": len(tokens)}


@router.post("/licenses/{token_id}/renew")
async def api_renew_license(token_id: str):
    """Renew a license token by extending its expiry."""
    result = await renew_token(token_id)
    if result.get("error"):
        raise HTTPException(status_code=404, detail=result["error"])
    return {"success": True, "renewal": result}


@router.post("/licenses/{token_id}/revoke")
async def api_revoke_license(token_id: str):
    """Revoke a license token."""
    success = await revoke_token(token_id)
    if not success:
        raise HTTPException(status_code=404, detail="Token not found")
    return {"success": True, "revoked": token_id}


@router.post("/licenses/validate")
async def api_validate_license(req: LicenseValidateRequest):
    """Validate a plaintext license token."""
    result = await validate_token(req.token)
    return result


@router.get("/licenses/expiring")
async def api_expiring_licenses(days: int = 90):
    """Get license tokens expiring within N days."""
    tokens = await get_expiring_soon(days=days)
    return {"expiring": tokens, "count": len(tokens), "within_days": days}


# ============================================================================
# CSR — CALL SCRIPTS & INSTALLATION GUIDES
# ============================================================================

@router.post("/csr/call-script")
async def api_generate_call_script(req: CSRCallScriptRequest):
    """Generate an installation/onboarding call script for CSR agents."""
    modules = req.modules or ["gee_analytics", "ingest", "compliance"]

    prompt = f"""Generate a professional phone call script for a Customer Success Representative
calling {req.contact_name} at {req.org_name} about their {req.product.upper()} installation.

Deployment type: {req.deployment_type}
Modules to install: {', '.join(modules)}
Additional notes: {req.notes or 'None'}

The script should include:
1. Professional greeting and introduction
2. Purpose of the call (installation scheduling / onboarding)
3. Technical requirements check
4. Module-by-module walkthrough overview
5. Timeline and next steps
6. Closing and follow-up scheduling

Keep it conversational but professional. Include talking points and potential objection handlers."""

    system_msg = (
        "You are a CSR script writer for Librae AI Labs. "
        "You write clear, professional call scripts for Cahaya environmental intelligence platform installations."
    )

    result = await route_to_gemini(prompt=prompt, system_instruction=system_msg, max_tokens=2000)

    return {
        "success": True,
        "call_script": result.get("text", ""),
        "org_name": req.org_name,
        "contact_name": req.contact_name,
        "model_used": result.get("model", "gemini"),
    }


@router.post("/csr/installation-guide")
async def api_generate_installation_guide(req: CSRInstallationGuideRequest):
    """Generate a Cahaya installation guide tailored to the customer."""
    modules = req.modules or ["gee_analytics", "ingest", "compliance"]

    prompt = f"""Generate a detailed Cahaya installation guide for {req.org_name}.

Environment: {req.os_environment}
Deployment type: {req.deployment_type}
Modules: {', '.join(modules)}

Include:
1. System requirements and prerequisites
2. Step-by-step installation commands
3. Module configuration for each selected module
4. Environment variable setup
5. Verification and health check steps
6. Troubleshooting common issues
7. Post-installation security checklist

Format as clean markdown with code blocks for commands."""

    system_msg = (
        "You are a technical documentation writer for Librae AI Labs. "
        "You write clear, accurate installation guides for the Cahaya environmental intelligence platform."
    )

    result = await route_to_gemini(prompt=prompt, system_instruction=system_msg, max_tokens=4000)

    return {
        "success": True,
        "installation_guide": result.get("text", ""),
        "org_name": req.org_name,
        "deployment_type": req.deployment_type,
        "os_environment": req.os_environment,
        "modules": modules,
        "model_used": result.get("model", "gemini"),
    }


# ============================================================================
# MONTHLY REPORTS — PDF generation, listing, download
# ============================================================================

from report_engine import generate_monthly_reports, list_available_reports, REPORTS_DIR

class ReportGenerateRequest(BaseModel):
    year: Optional[int] = None
    month: Optional[int] = None

@router.post("/api/reports/generate")
async def generate_reports(req: ReportGenerateRequest):
    """Generate monthly PDF reports for all agents."""
    try:
        client = get_bayu_client()
        results = await generate_monthly_reports(client, req.year, req.month)
        return {"success": True, **results}
    except Exception as e:
        logger.error(f"Report generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/reports")
async def get_reports():
    """List all available monthly report folders and their PDFs."""
    try:
        months = list_available_reports()
        return {"success": True, "months": months}
    except Exception as e:
        logger.error(f"List reports failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/reports/{period}/{filename}")
async def download_report(period: str, filename: str):
    """Download a specific agent report PDF."""
    from fastapi.responses import FileResponse
    filepath = os.path.join(REPORTS_DIR, period, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="Report not found")
    return FileResponse(
        filepath,
        media_type="application/pdf",
        filename=filename,
    )


# ============================================================================
# AUTONOMOUS SALES ENGINE — Discovery, Outreach, Pipeline Stats
# ============================================================================

from sales_engine import (
    run_sales_cycle, get_pipeline_stats,
    discover_esri_leads, get_today_outreach_count
)

@router.post("/sales/run")
async def run_sales():
    """Trigger autonomous sales cycle — runs in background via asyncio."""
    client = get_bayu_client()

    async def _run():
        try:
            result = await run_sales_cycle(client, target_closes=10)
            logger.info(f"Sales cycle complete: {result}")
        except Exception as e:
            logger.error(f"Sales cycle error: {e}")

    asyncio.create_task(_run())
    return {
        "success": True,
        "message": "Sales cycle started. Check /api/sales/pipeline for live stats.",
        "target_closes": 10,
    }

@router.get("/sales/pipeline")
async def get_sales_pipeline():
    """
    Real pipeline metrics from Supabase — every number is a real DB row.
    Anti-hallucination: returns 0 when empty, never invented numbers.
    """
    bayu = get_bayu_client()
    stats = {
        "total_leads": 0, "discovered": 0, "contacted": 0,
        "replied": 0, "trial_active": 0, "converted": 0,
        "emails_sent_today": 0, "emails_sent_total": 0,
        "hot_leads": 0, "target_closes": 10, "progress_pct": 0,
    }
    STAGE_MAP = {
        "discovered": "discovered", "new": "discovered",
        "warming_initiated": "contacted", "contacted": "contacted",
        "outreached": "contacted", "email_sent": "contacted",
        "replied": "replied", "engaged": "replied", "meeting_booked": "replied",
        "trial": "trial_active", "trial_active": "trial_active", "trialing": "trial_active",
        "converted": "converted", "customer": "converted",
        "closed_won": "converted", "paid": "converted",
    }
    try:
        leads = await bayu.select("leads", "select=lead_status,metadata", limit=500)
        for row in (leads or []):
            stats["total_leads"] += 1
            raw = (row.get("lead_status") or "discovered").lower()
            stage = STAGE_MAP.get(raw, "discovered")
            stats[stage] += 1
            meta = row.get("metadata") or {}
            if int(meta.get("score", 0) or 0) >= 70:
                stats["hot_leads"] += 1

        today = datetime.now(timezone.utc).date().isoformat()
        out_today = await bayu.select("outreach_log", f"channel=eq.email&sent_at=gte.{today}", limit=500)
        stats["emails_sent_today"] = len(out_today or [])
        out_all = await bayu.select("outreach_log", "channel=eq.email", limit=500)
        stats["emails_sent_total"] = len(out_all or [])
        t = stats["target_closes"]
        stats["progress_pct"] = round(stats["converted"] / t * 100, 1) if t else 0
    except Exception as e:
        logger.error(f"Pipeline stats error: {e}")
    return {"success": True, **stats}

@router.post("/sales/discover")
async def discover_leads_endpoint():
    """Seed verified ESRI ecosystem companies into the leads table."""
    bayu = get_bayu_client()
    seed = [
        {"company_name": "Woolpert", "company_domain": "woolpert.com", "country": "US", "industry": "geospatial consulting"},
        {"company_name": "WSP Global", "company_domain": "wsp.com", "country": "Global", "industry": "environmental engineering"},
        {"company_name": "Tetra Tech", "company_domain": "tetratech.com", "country": "US", "industry": "environmental consulting"},
        {"company_name": "Fugro", "company_domain": "fugro.com", "country": "Global", "industry": "geo-data services"},
        {"company_name": "SLR Consulting", "company_domain": "slrconsulting.com", "country": "Global", "industry": "environmental consulting"},
        {"company_name": "Jacobs Engineering", "company_domain": "jacobs.com", "country": "Global", "industry": "infrastructure"},
        {"company_name": "AECOM", "company_domain": "aecom.com", "country": "Global", "industry": "environmental engineering"},
        {"company_name": "GHD Group", "company_domain": "ghd.com", "country": "Global", "industry": "environmental consulting"},
        {"company_name": "Stantec", "company_domain": "stantec.com", "country": "Global", "industry": "environmental consulting"},
        {"company_name": "Arcadis", "company_domain": "arcadis.com", "country": "Global", "industry": "environmental engineering"},
        {"company_name": "ERM Group", "company_domain": "erm.com", "country": "Global", "industry": "environmental consulting"},
        {"company_name": "Beca Group", "company_domain": "beca.com", "country": "APAC", "industry": "engineering"},
        {"company_name": "Sime Darby Plantation", "company_domain": "simedarbyplantation.com", "country": "Malaysia", "industry": "plantation"},
        {"company_name": "IOI Corporation", "company_domain": "ioigroup.com", "country": "Malaysia", "industry": "plantation"},
        {"company_name": "Ramboll Group", "company_domain": "ramboll.com", "country": "Global", "industry": "engineering"},
        {"company_name": "Burns & McDonnell", "company_domain": "burnsmcd.com", "country": "US", "industry": "engineering"},
        {"company_name": "Davey Resource Group", "company_domain": "davey.com", "country": "US", "industry": "environmental"},
        {"company_name": "ESA Environmental", "company_domain": "esassoc.com", "country": "US", "industry": "environmental consulting"},
        {"company_name": "Ecology and Environment", "company_domain": "ene.com", "country": "Global", "industry": "environmental consulting"},
        {"company_name": "TerraGo Technologies", "company_domain": "terragotech.com", "country": "US", "industry": "GIS solutions"},
    ]
    saved = 0
    existing = await bayu.select("leads", "select=company_name", limit=500)
    existing_names = {r.get("company_name", "").lower() for r in (existing or [])}
    for co in seed:
        if co["company_name"].lower() in existing_names:
            continue
        result = await bayu.insert("leads", {
            "id": str(uuid.uuid4()),
            "company_name": co["company_name"],
            "company_domain": co["company_domain"],
            "is_esri_user": True,
            "geospatial_stack": ["ArcGIS"],
            "lead_status": "discovered",
            "metadata": {"source": "verified_seed", "industry": co["industry"], "country": co["country"]},
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        if result:
            saved += 1
    return {"success": True, "leads_found": len(seed), "leads_saved": saved, "message": f"{saved} new ESRI leads saved to database."}

@router.post("/webhooks/resend")
async def resend_inbound_webhook(request: Request):
    """Inbound email reply handler — updates lead status to 'replied'."""
    try:
        payload = await request.json()
        client = get_bayu_client()
        from_email = payload.get("from", "")
        if isinstance(from_email, dict):
            from_email = from_email.get("email", "")
        subject = payload.get("subject", "")
        text = str(payload.get("text", ""))[:500]
        domain = from_email.split("@")[-1] if "@" in from_email else ""
        if domain:
            lead_result = client.table("leads").select("id, company_name").ilike(
                "company_domain", f"%{domain}%"
            ).limit(1).execute()
            lead = (lead_result.data or [{}])[0]
            if lead.get("id"):
                import uuid as _uuid
                client.table("outreach_log").insert({
                    "id": str(_uuid.uuid4()),
                    "lead_id": lead["id"],
                    "company_name": lead.get("company_name", domain),
                    "company_domain": domain,
                    "channel": "email",
                    "direction": "inbound",
                    "status": "replied",
                    "sent_at": datetime.now(timezone.utc).isoformat(),
                    "message_preview": f"Re: {subject} — {text[:80]}",
                }).execute()
                client.table("leads").update(
                    {"lead_status": "replied"}
                ).eq("id", lead["id"]).execute()
                logger.info(f"Reply from {from_email} — lead updated to replied")
        return {"received": True}
    except Exception as e:
        logger.error(f"Resend webhook error: {e}")
        return {"received": False}

