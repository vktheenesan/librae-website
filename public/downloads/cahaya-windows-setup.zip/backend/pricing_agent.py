"""
LENUDA / Cahaya — Value-Based Dynamic Yield Management Engine v2
================================================================
Full pricing intelligence — three layered engines:

  LAYER 1: Industry Signal Classification    (5 macro-groups → 4 archetypes)
  LAYER 2: Geographic WTP Adjustment         (country → regional budget reality)
  LAYER 3: Seat Volume + Smart Discount/Upsell Engine

Architecture:
  Step 1: Signal Collection
  Step 2: Macro-Group Classification
  Step 3: Archetype Mapping
  Step 4: Yield Optimization (demand-based price positioning)
  Step 5: Geographic WTP Multiplier (country willingness-to-pay)
  Step 6: Seat Volume Discount + Strategic Upsell (net revenue maximiser)
  Step 7: Smart Discount/Exclusivity Engine (hook vs. extract decision)
  Step 8: BAYU Signal Emission (deal-closing intelligence for BAYU agent)

5 Macro-Groups:
  G1  Government, Defense & Public Safety
  G2  Infrastructure, Utilities & Energy
  G3  Natural Resources, Agriculture & Mining
  G4  Commercial, Real Estate & Finance
  G5  Transportation, AEC & Education

4 Pricing Archetypes:
  A1  Sovereign      USD 150,000–1,200,000+/yr  (Airgapped on-prem)
  A2  Heavy Compute  USD 12,000–25,000/yr        (Dedicated cloud)
  A3  Light Compute  USD 3,000–5,000/yr          (Standard SaaS)
  A4  Agri-Compliance USD 3,000/yr + wallet      (Viral self-serve)

Geographic WTP Tiers:
  P1  Ultra-Premium  — UAE, Qatar, KSA, Norway, Switzerland → 1.30–1.40×
  P2  Premium        — US, UK, DE, SG, AU, JP              → 1.10–1.20×
  P3  Standard       — FR, NL, CA, KR, NZ, HK              → 1.00×
  P4  Emerging-High  — MY, BR, TR, ZA, PL, CZ              → 0.80–0.85×
  P5  Developing     — ID, PH, VN, BD, PK, NG              → 0.60–0.70×
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Tuple

logger = logging.getLogger("pricing_agent")

# ─────────────────────────────────────────────────────────────────────────────
# LAYER 1 — Industry Taxonomy
# ─────────────────────────────────────────────────────────────────────────────

MACRO_GROUPS = {
    "G1": {
        "name": "Government, Defense & Public Safety",
        "icon": "🛡️",
        "keywords": ["government", "ministry", "defense", "military", "police", "homeland",
                     "national", "sovereign", "state", "municipality", "city", "public safety",
                     "intelligence", "army", "navy", "airforce", "classified", "cadastral",
                     "civil defense", "emergency management", "fire brigade"],
        "domains": ["aviation", "water", "construction"],
        "email_patterns": [".gov", ".mil", ".gov.my", ".gov.sg", ".gov.au", ".gov.uk",
                           ".mod.uk", ".army", ".navy", "police.", "ministry.", "jabatan."],
        "archetype": "A1",
        "deployment_preference": "airgapped",
        "priority": 100,
    },
    "G2": {
        "name": "Infrastructure, Utilities & Energy",
        "icon": "⚡",
        "keywords": ["utility", "energy", "power", "electricity", "grid", "pipeline",
                     "oil", "gas", "petronas", "shell", "chevron", "tnb", "transmission",
                     "telco", "fiber", "water utility", "sewage", "solar", "wind farm",
                     "renewables", "nuclear"],
        "domains": ["construction", "water", "mining"],
        "email_patterns": ["tnb.", "petronas.", "shell.", "chevron.", "energy.", "power.",
                           "utility.", "grid.", "pipeline.", "electric."],
        "archetype": "A2",
        "deployment_preference": "dedicated_cloud",
        "priority": 90,
    },
    "G3": {
        "name": "Natural Resources, Agriculture & Mining",
        "icon": "🌿",
        "keywords": ["plantation", "palm oil", "rubber", "cocoa", "mining", "quarry",
                     "forestry", "timber", "logging", "carbon", "redd", "mspo", "eudr",
                     "felda", "felcra", "sime", "ioigroup", "kuala lumpur kepong",
                     "subsidence", "tailings", "open pit", "underground mine"],
        "domains": ["agriculture", "forestry", "mining"],
        "email_patterns": ["felda.", "felcra.", "sime.", "ioi.", "kl-kepong.", "agrobank.",
                           "plantation.", "timber.", "mining.", "carbon."],
        "archetype": "A4",
        "deployment_preference": "hybrid",
        "priority": 70,
    },
    "G4": {
        "name": "Commercial, Real Estate & Finance",
        "icon": "🏦",
        "keywords": ["insurance", "reinsurance", "bank", "finance", "fund", "reit",
                     "property", "real estate", "developer", "mortgage", "asset management",
                     "catastrophe", "cat bond", "risk analytics", "underwriting",
                     "investment", "portfolio", "hedge fund", "sovereign wealth"],
        "domains": ["construction", "water", "shipping"],
        "email_patterns": ["bank.", "insurance.", "reinsurance.", "fund.", "reit.", "asset.",
                           "capital.", "investment.", "finance.", "allianz.", "axa.", "swiss-re."],
        "archetype": "A2",
        "deployment_preference": "dedicated_cloud",
        "priority": 85,
    },
    "G5": {
        "name": "Transportation, AEC & Education",
        "icon": "🏗️",
        "keywords": ["construction", "engineering", "architect", "contractor", "survey",
                     "university", "research", "institute", "consultant", "planning",
                     "transport", "highway", "railway", "airport", "port authority",
                     "civil", "structural", "drone", "lidar survey"],
        "domains": ["construction", "aviation", "water"],
        "email_patterns": [".edu", ".ac.", "university.", "college.", "institute.", "utm.",
                           "ukm.", "upm.", "consultant.", "engineering.", "survey.", "contractor."],
        "archetype": "A3",
        "deployment_preference": "saas",
        "priority": 60,
    },
}

ARCHETYPES = {
    "A1": {
        "name": "Sovereign",
        "tier": "Enterprise Airgapped",
        "price_range_usd_yr": (150_000, 1_200_000),
        "price_display": "Custom Sovereign ELA — from USD 150,000/yr",
        "model_tier": "sovereign",
        "compute": "On-Premise Airgapped Container Stack",
        "billing": "Annual ELA + Installation Fee",
        "annual_token": True,
        "cta": "Request Sovereign Deployment",
        "cta_color": "#7c3aed",
        "feature_flags": {
            "airgapped_mode": True, "local_llm_72b": True, "merkle_offline": True,
            "classified_boundary_mode": True, "multi_hazard_simulation": True,
            "unlimited_credits": True,
        },
        "self_serve": False,
        "bayu_priority": "CRITICAL — Route to enterprise sales immediately.",
    },
    "A2": {
        "name": "Heavy Compute",
        "tier": "Enterprise Cloud",
        "price_range_usd_yr": (12_000, 25_000),
        "price_display": "Enterprise Bundle from USD 12,000/yr",
        "model_tier": "standard",
        "compute": "Dedicated Cloud Buckets + Physics Surrogates",
        "billing": "Annual Bundle + Custom Credit Packages",
        "annual_token": True,
        "cta": "Request Enterprise Demo",
        "cta_color": "#0ea5e9",
        "feature_flags": {
            "airgapped_mode": False, "physics_surrogates": True, "insar_subsidence": True,
            "multi_sensor_delta": True, "dedicated_storage_bucket": True,
            "lifecycle_archival": True,
        },
        "self_serve": False,
        "bayu_priority": "HIGH — Schedule demo within 48 hours.",
    },
    "A3": {
        "name": "Light Compute",
        "tier": "Standard SaaS",
        "price_range_usd_yr": (3_000, 5_000),
        "price_display": "USD 3,000–5,000/seat/year  ·  or USD 500/mo",
        "model_tier": "edge",
        "compute": "Shared Multi-Tenant Cloud",
        "billing": "Annual Seat License or Monthly",
        "annual_token": True,
        "cta": "Start Free Trial",
        "cta_color": "#22c55e",
        "feature_flags": {
            "gee_intelligence": True, "ai_compliance_report": True,
            "merkle_audit": True, "simulation_lab": True, "domain_selector": True,
        },
        "self_serve": True,
        "bayu_priority": "MEDIUM — Self-serve onboarding, monitor trial conversion.",
    },
    "A4": {
        "name": "Agri-Compliance",
        "tier": "Self-Serve Viral",
        "price_range_usd_yr": (3_000, 3_000),
        "price_display": "USD 3,000/seat/year  +  USD 250/credit bundle",
        "model_tier": "edge",
        "compute": "Shared Multi-Tenant + Hybrid Credit Gates",
        "billing": "Annual Seat + Pay-As-You-Go Credit Wallets",
        "annual_token": True,
        "cta": "Start Free — Ingest Your First Document",
        "cta_color": "#16a34a",
        "feature_flags": {
            "document_ingest_free": True, "gee_intelligence": True,
            "ai_compliance_report": True, "merkle_audit": True,
            "eudr_module": True, "mspo_module": True, "mpob_tools": True,
        },
        "self_serve": True,
        "bayu_priority": "LOW-AUTOMATED — Trigger ingest-to-paid conversion flow.",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# LAYER 2 — Geographic Willingness-to-Pay (WTP)
# ─────────────────────────────────────────────────────────────────────────────
#
# Multiplier is applied AFTER the base yield price is computed.
# This reflects the actual budget reality and procurement norms of each market.
# Ultra-Premium markets: regulatory pressure is high, budgets are vast,
# public-sector contracts routinely hit 7 figures. Extract accordingly.
# Developing markets: volume over margin. Hook them cheap, grow with them.
#
# WTP tiers also influence the discount/exclusivity engine:
# P1/P2 clients → default to PREMIUM mode (never discount first).
# P4/P5 clients → default to HOOK mode (lead with a deal, then upsell).

GEOGRAPHIC_WTP: Dict[str, Dict] = {
    # ── Ultra-Premium (P1) ────────────────────────────────────────────────
    "AE": {"name": "United Arab Emirates",   "tier": "P1", "multiplier": 1.40,
           "note": "Abu Dhabi / Dubai sovereign budgets — extract aggressively"},
    "QA": {"name": "Qatar",                  "tier": "P1", "multiplier": 1.38,
           "note": "QIA / government procurement — massive budgets"},
    "SA": {"name": "Saudi Arabia",           "tier": "P1", "multiplier": 1.35,
           "note": "Vision 2030 / NEOM — massive geospatial spend"},
    "NO": {"name": "Norway",                 "tier": "P1", "multiplier": 1.30,
           "note": "Oil fund / Equinor scale — very high tech spend"},
    "CH": {"name": "Switzerland",            "tier": "P1", "multiplier": 1.28,
           "note": "Private banking + reinsurance (Swiss Re, Zurich)"},
    "BH": {"name": "Bahrain",               "tier": "P1", "multiplier": 1.25},
    "KW": {"name": "Kuwait",                "tier": "P1", "multiplier": 1.25},
    # ── Premium (P2) ─────────────────────────────────────────────────────
    "US": {"name": "United States",          "tier": "P2", "multiplier": 1.20,
           "note": "Fed/state contracts, DoD, insurance market"},
    "GB": {"name": "United Kingdom",         "tier": "P2", "multiplier": 1.18,
           "note": "EA, DEFRA, MOD, Lloyd's market"},
    "DE": {"name": "Germany",               "tier": "P2", "multiplier": 1.15,
           "note": "Siemens, E.ON, Allianz scale"},
    "SG": {"name": "Singapore",             "tier": "P2", "multiplier": 1.15,
           "note": "MAS, JTC, HDB — compact but high-value"},
    "AU": {"name": "Australia",             "tier": "P2", "multiplier": 1.14,
           "note": "Mining majors, state government, insurance"},
    "JP": {"name": "Japan",                 "tier": "P2", "multiplier": 1.12,
           "note": "Trading houses, METI, infrastructure sector"},
    "NL": {"name": "Netherlands",           "tier": "P2", "multiplier": 1.12,
           "note": "Shell, Unilever, port authorities"},
    "SE": {"name": "Sweden",               "tier": "P2", "multiplier": 1.10},
    "DK": {"name": "Denmark",              "tier": "P2", "multiplier": 1.10},
    "FI": {"name": "Finland",              "tier": "P2", "multiplier": 1.10},
    "AT": {"name": "Austria",              "tier": "P2", "multiplier": 1.08},
    "BE": {"name": "Belgium",              "tier": "P2", "multiplier": 1.08},
    "IE": {"name": "Ireland",              "tier": "P2", "multiplier": 1.10},
    # ── Standard (P3) ─────────────────────────────────────────────────────
    "FR": {"name": "France",               "tier": "P3", "multiplier": 1.00},
    "CA": {"name": "Canada",               "tier": "P3", "multiplier": 1.00},
    "KR": {"name": "South Korea",          "tier": "P3", "multiplier": 1.00},
    "NZ": {"name": "New Zealand",          "tier": "P3", "multiplier": 1.00},
    "HK": {"name": "Hong Kong",            "tier": "P3", "multiplier": 1.02},
    "TW": {"name": "Taiwan",               "tier": "P3", "multiplier": 0.98},
    "ES": {"name": "Spain",               "tier": "P3", "multiplier": 0.95},
    "PT": {"name": "Portugal",             "tier": "P3", "multiplier": 0.93},
    "IT": {"name": "Italy",               "tier": "P3", "multiplier": 0.95},
    "CZ": {"name": "Czech Republic",       "tier": "P3", "multiplier": 0.92},
    "PL": {"name": "Poland",              "tier": "P3", "multiplier": 0.90},
    # ── Emerging-High (P4) ─────────────────────────────────────────────────
    "MY": {"name": "Malaysia",             "tier": "P4", "multiplier": 0.82,
           "note": "Home market — MPOB, Petronas, FELDA; strategic pricing"},
    "BR": {"name": "Brazil",              "tier": "P4", "multiplier": 0.80,
           "note": "AgTech, mining (Vale), forestry (IBAMA compliance)"},
    "ZA": {"name": "South Africa",        "tier": "P4", "multiplier": 0.78,
           "note": "Mining majors, Eskom, government"},
    "TR": {"name": "Turkey",              "tier": "P4", "multiplier": 0.80},
    "MX": {"name": "Mexico",              "tier": "P4", "multiplier": 0.80},
    "TH": {"name": "Thailand",            "tier": "P4", "multiplier": 0.80},
    "AR": {"name": "Argentina",           "tier": "P4", "multiplier": 0.75},
    "CO": {"name": "Colombia",            "tier": "P4", "multiplier": 0.75},
    "OM": {"name": "Oman",               "tier": "P4", "multiplier": 0.88,
           "note": "Smaller GCC — mid-tier budget"},
    "EG": {"name": "Egypt",              "tier": "P4", "multiplier": 0.72},
    "PH": {"name": "Philippines",         "tier": "P4", "multiplier": 0.72},
    "IN": {"name": "India",              "tier": "P4", "multiplier": 0.75,
           "note": "Volume market — large enterprise pays P3, SME pays P5"},
    # ── Developing (P5) ─────────────────────────────────────────────────────
    "ID": {"name": "Indonesia",           "tier": "P5", "multiplier": 0.68,
           "note": "Palm oil / forestry volume — hook with Agri-Compliance"},
    "VN": {"name": "Vietnam",             "tier": "P5", "multiplier": 0.65},
    "BD": {"name": "Bangladesh",          "tier": "P5", "multiplier": 0.60},
    "PK": {"name": "Pakistan",            "tier": "P5", "multiplier": 0.62},
    "NG": {"name": "Nigeria",             "tier": "P5", "multiplier": 0.65,
           "note": "Oil sector pays P4, others P5"},
    "GH": {"name": "Ghana",              "tier": "P5", "multiplier": 0.65},
    "KH": {"name": "Cambodia",           "tier": "P5", "multiplier": 0.60},
    "MM": {"name": "Myanmar",            "tier": "P5", "multiplier": 0.58},
}

# WTP defaults for unknown countries
WTP_TIER_DEFAULTS = {
    "P1": 1.32, "P2": 1.15, "P3": 1.00, "P4": 0.78, "P5": 0.65
}
WTP_UNKNOWN_MULTIPLIER = 0.90  # Conservative default for unrecognised country


def _get_wtp(country_code: Optional[str]) -> Tuple[float, str, str]:
    """
    Returns (multiplier, wtp_tier, note) for a given ISO-2 country code.
    """
    if not country_code:
        return WTP_UNKNOWN_MULTIPLIER, "P3", "Country unknown — applying conservative standard rate"
    code = country_code.upper().strip()
    entry = GEOGRAPHIC_WTP.get(code)
    if entry:
        return entry["multiplier"], entry["tier"], entry.get("note", "")
    # Unmapped country — use conservative standard
    return WTP_UNKNOWN_MULTIPLIER, "P3", f"Country {code} not in WTP table — applying 0.90× standard"


# ─────────────────────────────────────────────────────────────────────────────
# LAYER 3a — Seat Volume Discount Engine
# ─────────────────────────────────────────────────────────────────────────────
#
# Bulk seats get a graduated discount on per-seat price.
# BUT: we immediately offset with a strategic upsell bundle
# that costs us nearly nothing but is perceived as high value.
# Net effect: client feels they got a deal; we earn more per account.

SEAT_DISCOUNT_SCHEDULE = [
    # (min_seats, max_seats, base_discount_pct, upsell_items)
    (1,   1,   0.0,  []),
    (2,   3,   5.0,  ["Priority email support"]),
    (4,   9,   10.0, ["Priority email support", "Dedicated onboarding session"]),
    (10,  24,  15.0, ["Priority support", "Dedicated CSM", "Quarterly business review",
                      "500 bonus credits/seat"]),
    (25,  49,  20.0, ["Dedicated CSM", "Monthly business review", "API white-label option",
                      "1,000 bonus credits/seat", "Custom domain subdomain"]),
    (50,  99,  25.0, ["Dedicated CSM", "SLA 99.9% uptime guarantee", "Custom API subdomain",
                      "Unlimited credits (fair use)", "Branded PDF templates"]),
    (100, 9999, 30.0, ["Dedicated infrastructure shard", "SLA 99.95%", "Unlimited credits",
                       "Custom AI prompt library", "White-label full dashboard",
                       "Annual executive briefing with Librae CTO"]),
]

UPSELL_BUNDLES = {
    # Upsell items we offer alongside the discount — perceived value > our cost
    "sim_lab_premium": {
        "label": "Simulation Lab Premium Pack",
        "description": "Unlimited disaster simulations + real-time weather for 1 year",
        "add_pct": 0.12,   # Add 12% to the discounted seat price
        "cost_to_us": "minimal",
    },
    "merkle_plus": {
        "label": "Merkle Audit+ (Public Verification Portal)",
        "description": "White-labeled verification portal for your clients/regulators",
        "add_pct": 0.08,
        "cost_to_us": "minimal",
    },
    "api_access": {
        "label": "Raw API Access Pack",
        "description": "Direct API keys for programmatic access + webhook integrations",
        "add_pct": 0.15,
        "cost_to_us": "minimal",
    },
    "watchlist_unlimited": {
        "label": "Unlimited Watchlist Subscriptions",
        "description": "Subscribe unlimited polygons to automated re-monitoring",
        "add_pct": 0.10,
        "cost_to_us": "minimal",
    },
    "esri_toolbox_pro": {
        "label": "ArcGIS Pro Toolbox + ESRI Marketplace Priority Listing",
        "description": "Direct toolbox integration + priority placement in ESRI marketplace",
        "add_pct": 0.18,
        "cost_to_us": "minimal",
    },
}


def _apply_seat_engine(
    base_price_per_seat: float,
    seat_count: int,
    archetype_key: str,
) -> Dict[str, Any]:
    """
    Computes: discount, upsell bundle recommendation, net revenue per account.
    Returns a structured seat pricing decision.
    """
    seat_count = max(1, seat_count)
    discount_pct = 0.0
    included_upsells: List[str] = []

    for min_s, max_s, disc, upsells in SEAT_DISCOUNT_SCHEDULE:
        if min_s <= seat_count <= max_s:
            discount_pct = disc
            included_upsells = upsells
            break

    discounted_per_seat = base_price_per_seat * (1 - discount_pct / 100)
    base_arr = discounted_per_seat * seat_count

    # Determine recommended upsell bundle based on archetype
    recommended_upsell = None
    upsell_add_arr = 0.0

    if archetype_key == "A1":
        recommended_upsell = None  # Sovereign: everything included, no upsell needed
    elif archetype_key == "A2":
        recommended_upsell = "esri_toolbox_pro"
    elif archetype_key == "A3":
        recommended_upsell = "api_access" if seat_count >= 5 else "sim_lab_premium"
    elif archetype_key == "A4":
        recommended_upsell = "watchlist_unlimited"

    upsell_cfg = UPSELL_BUNDLES.get(recommended_upsell, {}) if recommended_upsell else {}
    if upsell_cfg:
        upsell_add_arr = base_arr * upsell_cfg.get("add_pct", 0)

    net_arr = base_arr + upsell_add_arr

    # Net revenue vs no-discount baseline
    full_price_arr = base_price_per_seat * seat_count
    discount_given_usd = full_price_arr - base_arr
    upsell_recovered_usd = upsell_add_arr
    net_vs_baseline = net_arr - full_price_arr

    return {
        "seat_count": seat_count,
        "discount_pct": discount_pct,
        "discounted_per_seat_usd": round(discounted_per_seat, 2),
        "base_arr_usd": round(base_arr, 2),
        "discount_given_usd": round(discount_given_usd, 2),
        "recommended_upsell_key": recommended_upsell,
        "recommended_upsell_label": upsell_cfg.get("label"),
        "recommended_upsell_description": upsell_cfg.get("description"),
        "upsell_add_pct": upsell_cfg.get("add_pct", 0),
        "upsell_add_usd": round(upsell_add_arr, 2),
        "net_arr_usd": round(net_arr, 2),
        "net_vs_no_discount_usd": round(net_vs_baseline, 2),
        "included_perks": included_upsells,
        "revenue_recovered_by_upsell": upsell_add_arr >= discount_given_usd,
    }


# ─────────────────────────────────────────────────────────────────────────────
# LAYER 3b — Smart Discount / Exclusivity Engine
# ─────────────────────────────────────────────────────────────────────────────
#
# Decides whether to HOOK (offer a deal to acquire) or EXTRACT (charge premium).
# This is the most sensitive part of the engine — it decides the sales posture.
#
# HOOK mode:   Lead with a first-year discount or free pilot. Get them locked in.
#              Revenue from year 2+ is full price. High-renewal strategy.
# PREMIUM mode: No discount. Add an "exclusivity premium" framing instead.
#               Tell them their tier is invitation-only, not publicly listed.
# REBATE mode:  Post-purchase rebate (credit wallet top-up) for multi-year commits.
#               Feels like a reward. Drives multi-year lock-in.

@dataclass
class DiscountDecision:
    mode: str                        # "hook", "premium", "rebate", "standard"
    discount_yr1_pct: float          # First-year discount percentage
    exclusivity_premium_pct: float   # Premium to add if PREMIUM mode
    rebate_credits: int              # Credit wallet top-up if REBATE mode
    rebate_description: str
    rationale: str
    bayu_script: str                 # What BAYU should say to the client


def _smart_discount(
    archetype_key: str,
    wtp_tier: str,
    seat_count: int,
    is_returning: bool,
    confidence_pct: float,
    area_km2: Optional[float],
) -> DiscountDecision:
    """
    Decides the commercial posture: hook, premium, rebate, or standard.
    """
    # ── PREMIUM mode: high-confidence, high-budget, premium market ────────
    # Don't give these clients a discount. Tell them it's exclusive.
    if (archetype_key == "A1" and wtp_tier in ("P1", "P2")) or \
       (archetype_key == "A2" and wtp_tier == "P1") or \
       (confidence_pct >= 80 and wtp_tier in ("P1", "P2")):
        return DiscountDecision(
            mode="premium",
            discount_yr1_pct=0.0,
            exclusivity_premium_pct=15.0,
            rebate_credits=0,
            rebate_description="",
            rationale=f"Premium market ({wtp_tier}) + high confidence ({confidence_pct:.0f}%). "
                       "Exclusivity premium applied — this tier is invitation-only.",
            bayu_script=(
                "This is a restricted-access tier. We only onboard clients who meet our "
                "technical and compliance requirements. I can confirm your organization "
                "qualifies. The investment reflects the dedicated infrastructure and "
                "sovereign-grade AI we provision exclusively for your account."
            ),
        )

    # ── HOOK mode: P4/P5 market OR low confidence OR first-time enterprise ─
    # Lead with a first-year deal to reduce friction. Lock them in. Charge full from year 2.
    if wtp_tier in ("P4", "P5") or \
       (confidence_pct < 55 and archetype_key in ("A3", "A4")) or \
       (archetype_key in ("A1", "A2") and not is_returning and confidence_pct < 70):
        yr1_disc = 20.0 if wtp_tier == "P5" else 15.0
        return DiscountDecision(
            mode="hook",
            discount_yr1_pct=yr1_disc,
            exclusivity_premium_pct=0.0,
            rebate_credits=500,
            rebate_description=f"500 intelligence credits added to your wallet on activation.",
            rationale=f"Emerging market ({wtp_tier}) or low-confidence first-contact. "
                       f"Leading with {yr1_disc}% Year 1 discount to reduce friction.",
            bayu_script=(
                f"To make it easy to get started, we are offering a {yr1_disc:.0f}% "
                "first-year reduction and 500 complimentary intelligence credits. "
                "This is a limited offer for new clients this quarter. "
                "Your renewal from Year 2 continues at full rate with full feature access."
            ),
        )

    # ── REBATE mode: multi-seat, returning client, or P3/P4 mid-tier ──────
    # They've already bought in. Reward loyalty with credits (not cash discount).
    # Credits keep them on the platform. Cash discount just loses revenue.
    if is_returning or seat_count >= 5:
        credits = min(seat_count * 100, 2000)
        return DiscountDecision(
            mode="rebate",
            discount_yr1_pct=0.0,
            exclusivity_premium_pct=0.0,
            rebate_credits=credits,
            rebate_description=f"{credits:,} intelligence credits added to your team wallet on renewal.",
            rationale=f"Returning client or multi-seat ({seat_count} seats). "
                       "Credit rebate drives platform lock-in without cash margin sacrifice.",
            bayu_script=(
                f"As a valued client renewing for another year, we are adding {credits:,} "
                "intelligence credits to your team wallet — that is free GEE analysis, "
                "PDF reports, and simulation runs at no additional cost. "
                "Your team can start using them immediately on activation."
            ),
        )

    # ── STANDARD mode: default, no adjustment ────────────────────────────
    return DiscountDecision(
        mode="standard",
        discount_yr1_pct=0.0,
        exclusivity_premium_pct=0.0,
        rebate_credits=0,
        rebate_description="",
        rationale="Standard pricing applies. No special discount or premium warranted.",
        bayu_script=(
            "Your account is configured on our standard plan. "
            "You have full access to all features in your tier immediately on activation."
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Signal Collection
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PricingSignals:
    """All observable signals from a user session."""
    user_id: str
    domain: Optional[str] = None
    active_domains: List[str] = field(default_factory=list)
    area_km2: Optional[float] = None
    email_domain: Optional[str] = None
    org_name: Optional[str] = None
    ip_country: Optional[str] = None        # ISO-2 country code
    num_sessions: int = 1
    num_reports: int = 0
    credit_balance: int = 0
    seat_count: int = 1                     # NEW: number of seats requested/purchased
    is_returning_customer: bool = False     # NEW: has an existing paid account?
    used_simulation: bool = False
    ran_conflict_scenario: bool = False
    uploaded_classified_data: bool = False
    requested_airgap: bool = False
    user_agent: Optional[str] = None
    free_text_context: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# Classification Engine
# ─────────────────────────────────────────────────────────────────────────────

def _score_macro_group(signals: PricingSignals) -> Dict[str, float]:
    scores: Dict[str, float] = {k: 0.0 for k in MACRO_GROUPS}
    for group_key, cfg in MACRO_GROUPS.items():
        score = 0.0
        if signals.email_domain:
            for pat in cfg["email_patterns"]:
                if pat.lower() in signals.email_domain.lower():
                    score += 30; break
        if signals.org_name:
            for kw in cfg["keywords"]:
                if kw.lower() in signals.org_name.lower():
                    score += 25; break
        if signals.free_text_context:
            text = signals.free_text_context.lower()
            for kw in cfg["keywords"]:
                if kw.lower() in text:
                    score += 15; break
        if signals.domain and signals.domain in cfg["domains"]:
            score += 20
        if group_key == "G1":
            if signals.requested_airgap: score += 40
            if signals.uploaded_classified_data: score += 35
            if signals.ran_conflict_scenario: score += 30
        if group_key == "G2":
            if signals.area_km2 and signals.area_km2 > 500: score += 20
        if group_key == "G3":
            if signals.domain in ("agriculture", "forestry", "mining"): score += 15
        if group_key == "G4":
            if signals.num_reports > 5: score += 10
        score += cfg["priority"] * 0.01
        scores[group_key] = score
    return scores


def _apply_yield_optimizer(
    archetype_key: str,
    signals: PricingSignals,
    group_score: float,
) -> Tuple[float, float, str]:
    cfg = ARCHETYPES[archetype_key]
    low, high = cfg["price_range_usd_yr"]
    range_span = high - low
    rationale_factors = []
    yield_position = 0.30

    if signals.area_km2:
        if signals.area_km2 > 10_000:
            yield_position += 0.35; rationale_factors.append("country-scale geometry")
        elif signals.area_km2 > 1_000:
            yield_position += 0.20; rationale_factors.append("regional-scale geometry")
        elif signals.area_km2 > 100:
            yield_position += 0.10; rationale_factors.append("multi-site footprint")
    if signals.requested_airgap:
        yield_position += 0.30; rationale_factors.append("airgap requirement")
    if signals.ran_conflict_scenario:
        yield_position += 0.25; rationale_factors.append("conflict/security scenario")
    if signals.uploaded_classified_data:
        yield_position += 0.25; rationale_factors.append("classified data handling")
    if signals.num_reports > 20:
        yield_position += 0.15; rationale_factors.append("high-volume reporting")

    yield_position = min(yield_position, 1.0)
    price_point = low + (range_span * yield_position)
    price_floor = max(low, price_point * 0.85)
    price_ceiling = min(high, price_point * 1.15) if high < 10_000_000 else price_point * 1.2

    rationale = (
        f"Yield at {yield_position*100:.0f}% of range "
        f"based on: {', '.join(rationale_factors) or 'baseline signals'}."
    )
    return round(price_floor, -2), round(price_ceiling, -2), rationale


# ─────────────────────────────────────────────────────────────────────────────
# Final Output
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PricingDecision:
    """Complete output of the 3-layer pricing engine."""
    user_id: str
    # Layer 1 — Industry
    macro_group_key: str
    macro_group_name: str
    macro_group_icon: str
    archetype_key: str
    archetype_name: str
    archetype_tier: str
    # Layer 1+2 — Base price (before geo) + geo-adjusted price
    price_floor_usd_yr: float
    price_ceiling_usd_yr: float
    geo_floor_usd_yr: float
    geo_ceiling_usd_yr: float
    price_display: str
    yield_rationale: str
    # Layer 2 — Geography
    wtp_multiplier: float
    wtp_tier: str
    wtp_country: Optional[str]
    wtp_note: str
    # Layer 3a — Seat volume
    seat_pricing: Dict[str, Any]
    # Layer 3b — Discount/exclusivity
    discount_decision: DiscountDecision
    # Final effective price (geo × seat × discount/premium)
    final_floor_usd_yr: float
    final_ceiling_usd_yr: float
    final_per_seat_display: str
    # Deployment + features
    model_tier: str
    deployment_preference: str
    compute_description: str
    billing_model: str
    cta_label: str
    cta_color: str
    feature_flags: Dict[str, bool]
    self_serve: bool
    annual_token_required: bool
    # BAYU
    bayu_priority: str
    bayu_signals: List[str]
    confidence_pct: float
    generated_at: str


def classify(signals: PricingSignals) -> PricingDecision:
    """
    Full 3-layer pricing classification, modified to accumulate pricing additively per active domain.
    """
    domains = signals.active_domains if signals.active_domains else ([signals.domain] if signals.domain else ["agriculture"])
    
    total_price_floor = 0.0
    total_price_ceiling = 0.0
    total_geo_floor = 0.0
    total_geo_ceiling = 0.0
    
    archetype_keys = []
    macro_group_keys = []
    yield_rationales = []
    
    # Resolve geographic multiplier
    wtp_mult, wtp_tier, wtp_note = _get_wtp(signals.ip_country)
    
    # ── Sum up pricing elements for each domain ────────────────────────
    for dom in domains:
        # Create a single-domain signal for sub-scoring
        sub_sig = PricingSignals(
            user_id=signals.user_id,
            domain=dom,
            area_km2=signals.area_km2,
            email_domain=signals.email_domain,
            org_name=signals.org_name,
            ip_country=signals.ip_country,
            num_sessions=signals.num_sessions,
            num_reports=signals.num_reports,
            credit_balance=signals.credit_balance,
            seat_count=signals.seat_count,
            is_returning_customer=signals.is_returning_customer,
            used_simulation=signals.used_simulation,
            ran_conflict_scenario=signals.ran_conflict_scenario,
            uploaded_classified_data=signals.uploaded_classified_data,
            requested_airgap=signals.requested_airgap,
            user_agent=signals.user_agent,
            free_text_context=signals.free_text_context,
            extra=signals.extra
        )
        
        group_scores = _score_macro_group(sub_sig)
        top_group_key = max(group_scores, key=lambda k: group_scores[k])
        top_score = group_scores[top_group_key]
        
        group_cfg = MACRO_GROUPS[top_group_key]
        archetype_key = group_cfg["archetype"]
        
        archetype_keys.append(archetype_key)
        macro_group_keys.append(top_group_key)
        
        price_floor, price_ceiling, yield_rationale = _apply_yield_optimizer(
            archetype_key, sub_sig, top_score
        )
        
        total_price_floor += price_floor
        total_price_ceiling += price_ceiling
        
        geo_floor = round(price_floor * wtp_mult, -2)
        geo_ceiling = round(price_ceiling * wtp_mult, -2)
        total_geo_floor += geo_floor
        total_geo_ceiling += geo_ceiling
        
        yield_rationales.append(f"{dom.upper()} ({archetype_key}): {yield_rationale}")

    # Determine primary archetype (highest tier priority: A1 > A2 > A3 > A4)
    primary_arch_key = "A4"
    for ak in ["A3", "A2", "A1"]:
        if ak in archetype_keys:
            primary_arch_key = ak
            
    # Determine primary macro group
    primary_group_key = macro_group_keys[0] if macro_group_keys else "G3"
    for gk in ["G5", "G4", "G2", "G1"]:
        if gk in macro_group_keys:
            primary_group_key = gk

    group_cfg = MACRO_GROUPS[primary_group_key]
    arch_cfg = ARCHETYPES[primary_arch_key]
    
    # ── Unified stats across the session ─────────────────────────────────
    group_scores_all = _score_macro_group(signals)
    top_group_key_all = max(group_scores_all, key=lambda k: group_scores_all[k])
    top_score_all = group_scores_all[top_group_key_all]
    total_score_all = sum(group_scores_all.values()) or 1.0
    confidence_pct = round((top_score_all / total_score_all) * 100, 1)

    geo_mid = (total_geo_floor + total_geo_ceiling) / 2

    # ── Layer 3a: Seat volume ──────────────────────────────────────────────
    seat_pricing = _apply_seat_engine(geo_mid, signals.seat_count, primary_arch_key)

    # ── Layer 3b: Smart discount / exclusivity ─────────────────────────────
    discount_decision = _smart_discount(
        archetype_key=primary_arch_key,
        wtp_tier=wtp_tier,
        seat_count=signals.seat_count,
        is_returning=signals.is_returning_customer,
        confidence_pct=confidence_pct,
        area_km2=signals.area_km2,
    )

    # ── Final effective price ──────────────────────────────────────────────
    disc_mult = 1.0
    if discount_decision.mode == "hook":
        disc_mult = 1.0 - (discount_decision.discount_yr1_pct / 100)
    elif discount_decision.mode == "premium":
        disc_mult = 1.0 + (discount_decision.exclusivity_premium_pct / 100)

    final_floor = round(seat_pricing["net_arr_usd"] * disc_mult * 0.90, -2)
    final_ceiling = round(seat_pricing["net_arr_usd"] * disc_mult * 1.10, -2)

    if signals.seat_count > 1:
        final_per_seat = round(seat_pricing["discounted_per_seat_usd"] * disc_mult, -1)
        final_per_seat_display = (
            f"USD {final_per_seat:,.0f}/seat/yr × {signals.seat_count} seats "
            f"({seat_pricing['discount_pct']:.0f}% volume discount)"
        )
    else:
        final_per_seat_display = f"USD {total_geo_floor:,.0f}–{total_geo_ceiling:,.0f}/yr"

    # ── BAYU signals ───────────────────────────────────────────────────────
    bayu_signals = [arch_cfg["bayu_priority"]]
    if signals.requested_airgap:
        bayu_signals.append("AIRGAP_REQUEST — Requires sovereign deployment consultation.")
    if signals.ran_conflict_scenario:
        bayu_signals.append("SECURITY_USE_CASE — Government or defense buyer likely.")
    if wtp_tier == "P1":
        bayu_signals.append(f"ULTRA_PREMIUM_MARKET ({signals.ip_country}) — Apply exclusivity framing. No discounts.")
    if wtp_tier == "P5":
        bayu_signals.append(f"DEVELOPING_MARKET ({signals.ip_country}) — Lead with hook offer and credit bundle.")
    if signals.seat_count >= 10:
        bayu_signals.append(f"BULK_SEAT_DEAL ({signals.seat_count} seats) — Volume discount applied. Upsell: {seat_pricing.get('recommended_upsell_label', 'N/A')}.")
    if confidence_pct < 50:
        bayu_signals.append("LOW_CONFIDENCE — Request qualification call.")
    if signals.area_km2 and signals.area_km2 > 5000:
        bayu_signals.append("LARGE_FOOTPRINT — National/regional scale operator.")
    if primary_arch_key in ("A1", "A2") and not signals.is_returning_customer:
        bayu_signals.append("NEW_ENTERPRISE_LEAD — First contact. Prioritize outreach within 24h.")
    if discount_decision.mode == "hook":
        bayu_signals.append(f"HOOK_OFFER — Lead with {discount_decision.discount_yr1_pct:.0f}% Y1 discount. Script: '{discount_decision.bayu_script[:80]}...'")
    if discount_decision.mode == "premium":
        bayu_signals.append("PREMIUM_FRAME — Do not mention price first. Lead with exclusivity and restricted access.")
        
    unified_yield_rationale = "; ".join(yield_rationales)

    logger.info(
        f"[PricingAgent] {signals.user_id} ({len(domains)} domains) → "
        f"{group_cfg['name']} / {arch_cfg['name']} | "
        f"GEO({signals.ip_country}/{wtp_tier}/{wtp_mult}×) | "
        f"Seats({signals.seat_count}/-{seat_pricing['discount_pct']:.0f}%) | "
        f"Mode({discount_decision.mode}) | "
        f"Final USD {final_floor:,.0f}–{final_ceiling:,.0f}/yr"
    )

    return PricingDecision(
        user_id=signals.user_id,
        macro_group_key=primary_group_key,
        macro_group_name=group_cfg["name"],
        macro_group_icon=group_cfg["icon"],
        archetype_key=primary_arch_key,
        archetype_name=arch_cfg["name"],
        archetype_tier=arch_cfg["tier"],
        price_floor_usd_yr=total_price_floor,
        price_ceiling_usd_yr=total_price_ceiling,
        geo_floor_usd_yr=total_geo_floor,
        geo_ceiling_usd_yr=total_geo_ceiling,
        price_display=arch_cfg["price_display"],
        yield_rationale=unified_yield_rationale,
        wtp_multiplier=wtp_mult,
        wtp_tier=wtp_tier,
        wtp_country=signals.ip_country,
        wtp_note=wtp_note,
        seat_pricing=seat_pricing,
        discount_decision=discount_decision,
        final_floor_usd_yr=final_floor,
        final_ceiling_usd_yr=final_ceiling,
        final_per_seat_display=final_per_seat_display,
        model_tier=arch_cfg["model_tier"],
        deployment_preference=group_cfg["deployment_preference"],
        compute_description=arch_cfg["compute"],
        billing_model=arch_cfg["billing"],
        cta_label=arch_cfg["cta"],
        cta_color=arch_cfg["cta_color"],
        feature_flags=arch_cfg["feature_flags"],
        self_serve=arch_cfg["self_serve"],
        annual_token_required=arch_cfg["annual_token"],
        bayu_priority=arch_cfg["bayu_priority"],
        bayu_signals=bayu_signals,
        confidence_pct=confidence_pct,
        generated_at=datetime.now(timezone.utc).isoformat(),
    )


def classify_from_dict(data: dict) -> PricingDecision:
    """Convenience wrapper: construct signals from a plain dict and classify."""
    signals = PricingSignals(
        user_id=data.get("user_id", "unknown"),
        domain=data.get("domain"),
        active_domains=data.get("active_domains", []),
        area_km2=data.get("area_km2"),
        email_domain=data.get("email_domain"),
        org_name=data.get("org_name"),
        ip_country=data.get("ip_country"),
        num_sessions=data.get("num_sessions", 1),
        num_reports=data.get("num_reports", 0),
        credit_balance=data.get("credit_balance", 0),
        seat_count=data.get("seat_count", 1),
        is_returning_customer=data.get("is_returning_customer", False),
        used_simulation=data.get("used_simulation", False),
        ran_conflict_scenario=data.get("ran_conflict_scenario", False),
        uploaded_classified_data=data.get("uploaded_classified_data", False),
        requested_airgap=data.get("requested_airgap", False),
        user_agent=data.get("user_agent"),
        free_text_context=data.get("free_text_context"),
        extra=data.get("extra", {}),
    )
    return classify(signals)
