"""
CAHAYA Sovereign — Document Intelligence Engine
================================================
Powered by LlamaIndex + ChromaDB + local Ollama embeddings.

Users upload PDFs/DOCX/reports via the CAHAYA left panel.
This engine indexes them locally into ChromaDB and enables
natural language Q&A against their own documents.

All processing is local — works in air-gapped mode.
No document data leaves the user's machine.

Usage:
    engine = DocumentIntelligenceEngine()
    await engine.ingest_file("/path/to/eudr_report.pdf")
    answer = await engine.query("What is the deforestation baseline date?")
"""

import os
import json
import logging
import hashlib
from pathlib import Path
from typing import Optional, List, Dict, Any

logger = logging.getLogger("doc_intelligence")

# ── Storage Paths ──────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.parent
CHROMA_DIR = BASE_DIR / "data" / "chromadb"
DOCUMENTS_DIR = BASE_DIR / "data" / "documents"
CHROMA_DIR.mkdir(parents=True, exist_ok=True)
DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)

# ── Lazy imports (only load if packages installed) ────────────────────────────
def _check_dependencies() -> Dict[str, bool]:
    deps = {}
    try:
        import chromadb  # noqa
        deps["chromadb"] = True
    except ImportError:
        deps["chromadb"] = False
    try:
        from llama_index.core import SimpleDirectoryReader  # noqa
        deps["llama_index"] = True
    except ImportError:
        deps["llama_index"] = False
    try:
        import pypdf  # noqa
        deps["pypdf"] = True
    except ImportError:
        deps["pypdf"] = False
    return deps


class DocumentIntelligenceEngine:
    """
    Local-first document Q&A engine using ChromaDB + Ollama embeddings.
    Falls back to simple keyword search if packages not installed.
    """

    def __init__(self, collection_name: str = "cahaya_documents"):
        self.collection_name = collection_name
        self._client = None
        self._collection = None
        self._deps = _check_dependencies()
        logger.info(f"Doc Intelligence init — deps: {self._deps}")

    def _get_collection(self):
        if self._collection is not None:
            return self._collection
        if not self._deps.get("chromadb"):
            return None
        import chromadb
        self._client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self._collection = self._client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        return self._collection

    # ── File Ingestion ─────────────────────────────────────────────────────────
    async def ingest_file(
        self, file_path: str, metadata: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Ingest a document (PDF, DOCX, TXT, MD) into the local vector store.
        Chunks the document, generates embeddings via Ollama, stores in ChromaDB.
        Returns: {success, chunks_added, file_hash}
        """
        path = Path(file_path)
        if not path.exists():
            return {"success": False, "error": f"File not found: {file_path}"}

        # Compute file hash to avoid re-ingesting
        with open(path, "rb") as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()

        collection = self._get_collection()
        if collection is None:
            return await self._fallback_ingest(path, file_hash, metadata)

        # Check if already ingested
        existing = collection.get(where={"file_hash": file_hash})
        if existing["ids"]:
            logger.info(f"Document already indexed: {path.name}")
            return {
                "success": True,
                "chunks_added": 0,
                "file_hash": file_hash,
                "already_indexed": True,
            }

        # Extract text based on file type
        text = await self._extract_text(path)
        if not text:
            return {"success": False, "error": "Could not extract text from document"}

        # Chunk the text
        chunks = self._chunk_text(text, chunk_size=512, overlap=64)
        logger.info(f"Ingesting {path.name}: {len(chunks)} chunks")

        # Generate embeddings via Ollama
        from ollama_router import get_ollama_embedding

        ids, embeddings, documents, metadatas = [], [], [], []
        for i, chunk in enumerate(chunks):
            chunk_id = f"{file_hash}_{i}"
            embedding = await get_ollama_embedding(chunk)
            if not embedding:
                continue
            ids.append(chunk_id)
            embeddings.append(embedding)
            documents.append(chunk)
            metadatas.append({
                "file_name": path.name,
                "file_hash": file_hash,
                "chunk_index": i,
                "total_chunks": len(chunks),
                **(metadata or {}),
            })

        if ids:
            collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=documents,
                metadatas=metadatas,
            )

        # Save manifest
        self._update_manifest(path.name, file_hash, len(ids))

        return {
            "success": True,
            "chunks_added": len(ids),
            "file_hash": file_hash,
            "file_name": path.name,
        }

    # ── Query ──────────────────────────────────────────────────────────────────
    async def query(
        self,
        question: str,
        n_results: int = 5,
        filter_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Answer a question using retrieved document context.
        Returns the AI answer plus the source chunks used.
        """
        collection = self._get_collection()
        if collection is None:
            return await self._fallback_query(question)

        from ollama_router import get_ollama_embedding, route_to_ollama

        # Get question embedding
        q_embedding = await get_ollama_embedding(question)
        if not q_embedding:
            return {"answer": "", "error": "Could not generate embedding"}

        # Retrieve relevant chunks
        where_filter = {"file_name": filter_file} if filter_file else None
        results = collection.query(
            query_embeddings=[q_embedding],
            n_results=min(n_results, collection.count() or 1),
            where=where_filter,
            include=["documents", "metadatas", "distances"],
        )

        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]

        if not docs:
            return {
                "answer": "No relevant documents found. Please upload documents first.",
                "sources": [],
            }

        # Build context for AI
        context_parts = []
        sources = []
        for doc, meta, dist in zip(docs, metas, distances):
            relevance = round(1 - dist, 3)
            if relevance > 0.3:  # Only use relevant chunks
                context_parts.append(f"[From: {meta.get('file_name', 'Unknown')}]\n{doc}")
                sources.append({
                    "file": meta.get("file_name"),
                    "chunk": meta.get("chunk_index"),
                    "relevance": relevance,
                })

        if not context_parts:
            return {
                "answer": "I found documents but none seem directly relevant to your question.",
                "sources": [],
            }

        context = "\n\n---\n\n".join(context_parts)
        prompt = (
            f"Using ONLY the following document extracts, answer this question precisely:\n\n"
            f"QUESTION: {question}\n\n"
            f"DOCUMENT CONTEXT:\n{context}\n\n"
            f"If the answer is not in the documents, say so clearly. "
            f"Cite which document you used. Be concise and accurate."
        )

        response = await route_to_ollama(
            prompt=prompt,
            system_message=(
                "You are Librae Document Intelligence. You answer questions strictly based "
                "on provided document context. Never speculate beyond the documents."
            ),
            temperature=0.3,
        )

        return {
            "answer": response.get("text", ""),
            "sources": sources,
            "model": response.get("model"),
            "context_chunks": len(context_parts),
        }

    # ── List Indexed Documents ─────────────────────────────────────────────────
    def list_documents(self) -> List[Dict]:
        manifest_path = CHROMA_DIR / "manifest.json"
        if manifest_path.exists():
            try:
                with open(manifest_path) as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    # ── Delete Document ────────────────────────────────────────────────────────
    def delete_document(self, file_hash: str) -> Dict[str, Any]:
        collection = self._get_collection()
        if collection is None:
            return {"success": False, "error": "ChromaDB not available"}
        collection.delete(where={"file_hash": file_hash})
        self._remove_from_manifest(file_hash)
        return {"success": True, "file_hash": file_hash}

    # ── Helpers ────────────────────────────────────────────────────────────────
    async def _extract_text(self, path: Path) -> str:
        suffix = path.suffix.lower()
        try:
            if suffix == ".txt" or suffix == ".md":
                return path.read_text(encoding="utf-8", errors="ignore")

            elif suffix == ".pdf":
                if self._deps.get("pypdf"):
                    import pypdf
                    reader = pypdf.PdfReader(str(path))
                    return "\n".join(
                        page.extract_text() or "" for page in reader.pages
                    )

            elif suffix in (".docx", ".doc"):
                try:
                    from docx import Document
                    doc = Document(str(path))
                    return "\n".join(p.text for p in doc.paragraphs)
                except ImportError:
                    logger.warning("python-docx not installed")

            elif suffix == ".json":
                return json.dumps(json.loads(path.read_text()), indent=2)

        except Exception as e:
            logger.error(f"Text extraction error for {path.name}: {e}")
        return ""

    def _chunk_text(
        self, text: str, chunk_size: int = 512, overlap: int = 64
    ) -> List[str]:
        words = text.split()
        chunks = []
        start = 0
        while start < len(words):
            end = min(start + chunk_size, len(words))
            chunks.append(" ".join(words[start:end]))
            start += chunk_size - overlap
        return [c for c in chunks if len(c.strip()) > 20]

    def _update_manifest(self, file_name: str, file_hash: str, chunks: int):
        manifest_path = CHROMA_DIR / "manifest.json"
        manifest = self.list_documents()
        manifest = [m for m in manifest if m.get("file_hash") != file_hash]
        manifest.append({
            "file_name": file_name,
            "file_hash": file_hash,
            "chunks": chunks,
            "ingested_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
        })
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)

    def _remove_from_manifest(self, file_hash: str):
        manifest_path = CHROMA_DIR / "manifest.json"
        manifest = [m for m in self.list_documents() if m.get("file_hash") != file_hash]
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)

    async def _fallback_ingest(self, path: Path, file_hash: str, metadata) -> Dict:
        """Simple text storage fallback when ChromaDB not available."""
        text = await self._extract_text(path)
        dest = DOCUMENTS_DIR / f"{file_hash}.txt"
        dest.write_text(text, encoding="utf-8")
        self._update_manifest(path.name, file_hash, 1)
        return {"success": True, "chunks_added": 1, "file_hash": file_hash, "mode": "fallback"}

    async def _fallback_query(self, question: str) -> Dict:
        """Keyword search fallback when ChromaDB not available."""
        from ollama_router import route_to_ollama
        docs = list(DOCUMENTS_DIR.glob("*.txt"))
        if not docs:
            return {"answer": "No documents indexed yet. Upload documents via the left panel.", "sources": []}
        # Simple keyword match
        keywords = question.lower().split()
        best_doc, best_score = None, 0
        for doc in docs:
            text = doc.read_text(encoding="utf-8", errors="ignore")
            score = sum(1 for k in keywords if k in text.lower())
            if score > best_score:
                best_score, best_doc = score, text
        if not best_doc:
            return {"answer": "No relevant content found.", "sources": []}
        context = best_doc[:3000]
        response = await route_to_ollama(
            prompt=f"Based on: {context}\n\nAnswer: {question}",
            temperature=0.3,
        )
        return {"answer": response.get("text", ""), "sources": [], "mode": "fallback"}


# ── Singleton ──────────────────────────────────────────────────────────────────
_engine_instance: Optional[DocumentIntelligenceEngine] = None

def get_doc_engine() -> DocumentIntelligenceEngine:
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = DocumentIntelligenceEngine()
    return _engine_instance
