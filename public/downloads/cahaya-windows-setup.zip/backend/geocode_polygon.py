"""
geocode_polygon.py — Librae Location Search & Auto-Polygon Engine
==================================================================
Allows users to type a city name, industrial park name, or area name
and automatically:
  1. Geocode the location (lat/lon centroid)
  2. Pull the administrative boundary polygon from OpenStreetMap (Nominatim/Overpass)
  3. Return it as a GeoJSON polygon ready for GEE analysis + Shapefile export

Uses only free, open APIs — no API key required:
  - Nominatim (OpenStreetMap geocoding)
  - Overpass API (OSM boundary polygon fetch)

Falls back to a bounding box if no admin boundary is found.
"""

import json
import time
import requests


NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URL  = "https://overpass-api.de/api/interpreter"
HEADERS       = {"User-Agent": "LibraeIntelligence/3.0 (lenuda.librae.work)"}


# ─────────────────────────────────────────────────────────────────────────────
# 1. GEOCODE: get lat/lon + OSM place_id from a name
# ─────────────────────────────────────────────────────────────────────────────

def geocode_location(place_name: str) -> dict:
    """
    Search for a place name using Nominatim.
    Returns the top match with lat, lon, display name, OSM type, and OSM ID.

    Example:
        geocode_location("Kulim Hi-Tech Park, Kedah")
        → {'lat': 5.38, 'lon': 100.56, 'osm_type': 'relation', 'osm_id': 12345, ...}
    """
    try:
        params = {
            "q": place_name,
            "format": "json",
            "limit": 5,
            "polygon_geojson": 0,
            "addressdetails": 1,
        }
        resp = requests.get(NOMINATIM_URL, params=params, headers=HEADERS, timeout=10)
        resp.raise_for_status()
        results = resp.json()

        if not results:
            return {"status": "not_found", "query": place_name}

        # Prefer relation > way > node for boundary polygons
        best = None
        for r in results:
            if r.get("osm_type") == "relation":
                best = r
                break
        if not best:
            best = results[0]

        return {
            "status": "ok",
            "display_name": best.get("display_name"),
            "lat": float(best.get("lat")),
            "lon": float(best.get("lon")),
            "osm_type": best.get("osm_type"),
            "osm_id": int(best.get("osm_id", 0)),
            "boundingbox": best.get("boundingbox"),  # [south, north, west, east]
            "place_class": best.get("class"),
            "place_type": best.get("type"),
        }
    except Exception as e:
        return {"status": f"geocode_error: {e}"}


# ─────────────────────────────────────────────────────────────────────────────
# 2. FETCH ADMIN BOUNDARY POLYGON from OSM Overpass
# ─────────────────────────────────────────────────────────────────────────────

def fetch_osm_boundary(osm_type: str, osm_id: int) -> dict:
    """
    Fetch the actual boundary polygon for an OSM relation/way.
    Returns a GeoJSON FeatureCollection.

    NOTE: Works well for administrative boundaries (districts, cities, parks).
    Industrial parks that are NOT mapped in OSM will fall back to bounding box.
    """
    try:
        # Overpass query to get the boundary polygon
        if osm_type == "relation":
            query = f"""
            [out:json][timeout:30];
            relation({osm_id});
            out geom;
            """
        elif osm_type == "way":
            query = f"""
            [out:json][timeout:30];
            way({osm_id});
            out geom;
            """
        else:
            return {"status": "unsupported_osm_type", "osm_type": osm_type}

        resp = requests.post(OVERPASS_URL, data={"data": query}, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        data = resp.json()

        elements = data.get("elements", [])
        if not elements:
            return {"status": "no_geometry", "osm_id": osm_id}

        # Parse geometry from Overpass response
        coords = []
        el = elements[0]

        if osm_type == "way" and "geometry" in el:
            coords = [[pt["lon"], pt["lat"]] for pt in el["geometry"]]

        elif osm_type == "relation":
            # Relations have members; find the outer ring
            for member in el.get("members", []):
                if member.get("role") == "outer" and "geometry" in member:
                    coords = [[pt["lon"], pt["lat"]] for pt in member["geometry"]]
                    break
            # Close the ring
            if coords and coords[0] != coords[-1]:
                coords.append(coords[0])

        if not coords or len(coords) < 4:
            return {"status": "insufficient_geometry"}

        geojson = {
            "type": "FeatureCollection",
            "features": [{
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [coords]
                },
                "properties": {
                    "osm_id": osm_id,
                    "osm_type": osm_type,
                    "source": "OpenStreetMap Overpass"
                }
            }]
        }

        return {"status": "ok", "geojson": geojson, "point_count": len(coords)}

    except Exception as e:
        return {"status": f"overpass_error: {e}"}


# ─────────────────────────────────────────────────────────────────────────────
# 3. BOUNDING BOX FALLBACK (when no OSM polygon exists)
# ─────────────────────────────────────────────────────────────────────────────

def boundingbox_to_geojson(boundingbox: list, display_name: str) -> dict:
    """
    Convert Nominatim bounding box [south, north, west, east] to
    a rectangular GeoJSON polygon. Used when no OSM relation/way is found.
    """
    try:
        south = float(boundingbox[0])
        north = float(boundingbox[1])
        west  = float(boundingbox[2])
        east  = float(boundingbox[3])

        coords = [
            [west, south],
            [east, south],
            [east, north],
            [west, north],
            [west, south],  # close ring
        ]

        geojson = {
            "type": "FeatureCollection",
            "features": [{
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [coords]
                },
                "properties": {
                    "name": display_name,
                    "source": "Nominatim bounding box (fallback)",
                    "note": "No precise OSM polygon found. Bounding box used."
                }
            }]
        }

        # Area estimate (rough, in km²)
        lat_span = (north - south) * 111.0
        lon_span = (east - west) * 111.0 * abs(math.cos(math.radians((north + south) / 2)))
        area_km2 = round(lat_span * lon_span, 2)

        return {"status": "ok", "geojson": geojson, "area_km2": area_km2, "method": "bounding_box"}

    except Exception as e:
        return {"status": f"bbox_error: {e}"}


import math


# ─────────────────────────────────────────────────────────────────────────────
# 4. MASTER: Search → Polygon (one-shot function)
# ─────────────────────────────────────────────────────────────────────────────

def search_and_get_polygon(place_name: str) -> dict:
    """
    Full pipeline: 
      1. Geocode the place name.
      2. Try to fetch the OSM admin boundary polygon.
      3. Fall back to bounding box if no polygon found.

    Returns dict with:
      - display_name: human-readable matched name
      - lat, lon: centroid coordinates
      - geojson: GeoJSON polygon (for map display + GEE analysis)
      - area_km2: estimated area
      - method: 'osm_polygon' or 'bounding_box'

    Usage:
        result = search_and_get_polygon("Iskandar Puteri, Johor")
        geojson = result['geojson']
    """
    # Step 1: Geocode
    geo = geocode_location(place_name)
    if geo.get("status") != "ok":
        return {"status": "not_found", "query": place_name, "error": geo.get("status")}

    time.sleep(0.5)  # Rate limit Nominatim (1 req/sec)

    # Step 2: Try OSM polygon
    osm_type = geo.get("osm_type")
    osm_id   = geo.get("osm_id")
    polygon_result = {"status": "skipped"}

    if osm_type in ("relation", "way") and osm_id:
        polygon_result = fetch_osm_boundary(osm_type, osm_id)

    # Step 3: Fall back to bounding box
    method = "osm_polygon"
    if polygon_result.get("status") != "ok":
        bb = geo.get("boundingbox")
        if bb:
            polygon_result = boundingbox_to_geojson(bb, geo["display_name"])
            method = "bounding_box"
        else:
            return {"status": "no_geometry_available", "geocode": geo}

    return {
        "status": "ok",
        "display_name": geo["display_name"],
        "lat": geo["lat"],
        "lon": geo["lon"],
        "place_class": geo.get("place_class"),
        "place_type": geo.get("place_type"),
        "geojson": polygon_result.get("geojson"),
        "area_km2": polygon_result.get("area_km2"),
        "point_count": polygon_result.get("point_count"),
        "method": method,
        "note": "Auto-polygon generated from OpenStreetMap. Refine boundary by uploading custom KML for higher precision."
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. CONVERT GeoJSON polygon → GEE geometry (for satellite analysis)
# ─────────────────────────────────────────────────────────────────────────────

def geojson_to_ee_geometry(geojson: dict, ee_module):
    """
    Convert a GeoJSON polygon dict to an ee.Geometry for use in GEE analysis.
    """
    try:
        ee = ee_module
        feature = geojson["features"][0]
        coords = feature["geometry"]["coordinates"]
        return ee.Geometry.Polygon(coords)
    except Exception as e:
        return None
