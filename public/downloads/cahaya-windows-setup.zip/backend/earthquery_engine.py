"""
earthquery_engine.py — Librae EarthQuery™ Intelligence Engine
==============================================================
Module 5: Natural Language Earth Observation

"Ask the planet a question. Get a satellite answer."

The user types a natural language query such as:
  - "Check for oil spills in the Malacca Straits"
  - "Diagnose the water health of the Kinta River"
  - "Search for plastic debris near Penang coastline"
  - "Monitor illegal sand mining in the upper Perak River"
  - "Detect recent coral bleaching near Tioman Island"

This engine:
  1. Uses Gemini to parse the intent → location, target, satellite strategy
  2. Geocodes the location using our geocode_polygon module
  3. Selects and runs the correct GEE satellite bands
  4. Returns structured findings for the AI narrative engine

Available monitoring targets and their satellite recipes:
  - Oil spills       → Sentinel-1 SAR (damped backscatter on water)
  - Water quality    → Sentinel-2 (NDWI, turbidity, chlorophyll proxy)
  - Plastic/debris   → Sentinel-2 (NDWI + floating debris index FDI)
  - River health     → Sentinel-3 OLCI / Sentinel-2 (TSM, color index)
  - Coral bleaching  → Sentinel-2 (water column + SST anomaly)
  - Sand mining      → Sentinel-1 SAR + Sentinel-2 (turbidity plume)
  - Forest fire      → MODIS/VIIRS active fire + Sentinel-2 burn scar
  - Flooding         → Sentinel-1 SAR (open water detection)
  - Air quality      → Sentinel-5P TROPOMI (NO2, SO2, CO, Aerosol)
  - Heat events      → Landsat 9 (LST anomalies)
"""

import json
import math


# ─────────────────────────────────────────────────────────────────────────────
# INTENT REGISTRY: known query types and their GEE strategies
# ─────────────────────────────────────────────────────────────────────────────

INTENT_REGISTRY = {
    "oil_spill": {
        "keywords": ["oil spill", "oil slick", "petroleum", "crude oil", "hydrocarbon"],
        "satellite_strategy": "sentinel1_sar_water + sentinel2_water_contrast",
        "sensors": ["Sentinel-1 (SAR C-band)", "Sentinel-2 SR"],
        "description": "Oil on water appears as anomalously smooth (low backscatter) patches in SAR imagery. Optical contrast used for visual confirmation.",
        "gee_function": "run_oil_spill_detection",
    },
    "water_quality": {
        "keywords": ["water quality", "river health", "water health", "diagnose river", "water pollution", "turbidity", "kinta", "perak river", "pahang river"],
        "satellite_strategy": "sentinel2_turbidity + ndwi + chlorophyll_proxy",
        "sensors": ["Sentinel-2 SR (10m)", "Sentinel-3 OLCI"],
        "description": "Turbidity, chlorophyll-a proxy, and NDWI for water body extent and health.",
        "gee_function": "run_water_quality_analysis",
    },
    "plastic_debris": {
        "keywords": ["plastic", "debris", "floating", "garbage", "waste", "litter", "pollution coastline"],
        "satellite_strategy": "sentinel2_fdi + ndwi_water_extraction",
        "sensors": ["Sentinel-2 SR (10m)"],
        "description": "Floating Debris Index (FDI) — floating plastics and organic debris have a distinct spectral signal between NIR and SWIR.",
        "gee_function": "run_floating_debris_detection",
    },
    "sand_mining": {
        "keywords": ["sand mining", "dredging", "river bed", "turbidity plume", "sediment extraction"],
        "satellite_strategy": "sentinel1_sar_water + sentinel2_turbidity_plume",
        "sensors": ["Sentinel-1 SAR", "Sentinel-2 SWIR"],
        "description": "Sand mining creates distinct turbidity plumes (milky water) in Sentinel-2 red/SWIR bands and alters SAR texture.",
        "gee_function": "run_water_quality_analysis",  # reuses turbidity
    },
    "deforestation": {
        "keywords": ["deforestation", "logging", "illegal clearing", "tree loss", "forest loss", "illegal logging"],
        "satellite_strategy": "hansen_gfc + sentinel2_ndvi_change + palsar_fnf",
        "sensors": ["Landsat (Hansen GFC)", "Sentinel-2", "ALOS PALSAR"],
        "description": "Multi-temporal forest loss detection using Hansen GFC and NDVI change detection.",
        "gee_function": "run_deforestation_check",
    },
    "fire": {
        "keywords": ["fire", "burn", "burning", "wildfire", "peat fire", "slash and burn", "active fire"],
        "satellite_strategy": "viirs_active_fire + modis_firms + sentinel2_nbr",
        "sensors": ["VIIRS FIRMS", "MODIS", "Sentinel-2 (NBR)"],
        "description": "Active fire detection using VIIRS heat signatures. Burn scar extent from Sentinel-2 Normalized Burn Ratio (NBR).",
        "gee_function": "run_fire_detection",
    },
    "flooding": {
        "keywords": ["flood", "flooding", "inundation", "waterlogged", "submerged"],
        "satellite_strategy": "sentinel1_sar_flood_water + dem_flow",
        "sensors": ["Sentinel-1 SAR (flood detection)", "Copernicus DEM"],
        "description": "SAR flood mapping: open water appears as very low backscatter (dark) in Sentinel-1 IW VV imagery.",
        "gee_function": "run_flood_detection",
    },
    "air_quality": {
        "keywords": ["air quality", "air pollution", "haze", "smog", "emission", "no2", "so2", "pm2.5", "aerosol", "aod"],
        "satellite_strategy": "s5p_no2 + s5p_so2 + s5p_aerosol",
        "sensors": ["Sentinel-5P TROPOMI (1km)"],
        "description": "Tropospheric NO₂, SO₂, CO, HCHO and Aerosol Optical Depth from TROPOMI.",
        "gee_function": "run_air_quality_scan",
    },
    "heat": {
        "keywords": ["heat", "hot spot", "temperature", "heat wave", "urban heat", "lst", "thermal"],
        "satellite_strategy": "landsat9_lst + viirs_dnb_thermal",
        "sensors": ["Landsat 9 (Thermal Band 10)", "VIIRS"],
        "description": "Land Surface Temperature (LST) using Landsat 9 thermal band, identifying hotspots and heat island anomalies.",
        "gee_function": "run_heat_analysis",
    },
    "coral": {
        "keywords": ["coral", "bleaching", "reef", "sea temperature", "sst", "tioman", "perhentian", "redang", "sipadan"],
        "satellite_strategy": "sentinel2_water_column + noaa_sst + pace_ocean",
        "sensors": ["Sentinel-2 SR", "NOAA Coral Reef Watch SST"],
        "description": "Coral bleaching risk from Sea Surface Temperature anomaly + water turbidity and depth-corrected spectral indices.",
        "gee_function": "run_coral_health_check",
    },
}


def parse_query_intent(query: str) -> dict:
    """
    Parse a natural language query to identify the monitoring intent.
    Returns the matched intent dict from INTENT_REGISTRY.
    Falls back to 'water_quality' as default for ambiguous water queries.
    """
    query_lower = query.lower()
    
    # Score each intent by keyword matches
    scores = {}
    for intent_key, intent_data in INTENT_REGISTRY.items():
        score = sum(1 for kw in intent_data["keywords"] if kw in query_lower)
        if score > 0:
            scores[intent_key] = score
    
    if not scores:
        # Default fallback
        return {
            "intent": "general_observation",
            "confidence": "low",
            "matched_intent": None,
            "sensors": ["Sentinel-2 SR", "Sentinel-1 SAR"],
            "description": "General Earth observation scan — running NDVI, NDWI, and SAR analysis.",
            "note": "No specific monitoring target identified. Running broad-spectrum analysis."
        }
    
    best_intent = max(scores, key=scores.get)
    intent_data = INTENT_REGISTRY[best_intent]
    
    return {
        "intent": best_intent,
        "confidence": "high" if scores[best_intent] > 1 else "moderate",
        "matched_intent": intent_data,
        "sensors": intent_data.get("sensors", []),
        "satellite_strategy": intent_data.get("satellite_strategy"),
        "description": intent_data.get("description"),
        "gee_function": intent_data.get("gee_function"),
    }


# ─────────────────────────────────────────────────────────────────────────────
# SATELLITE ANALYSIS FUNCTIONS (GEE)
# ─────────────────────────────────────────────────────────────────────────────

def run_water_quality_analysis(ee_geom, ee_module) -> dict:
    """
    Sentinel-2 water quality: turbidity, NDWI, and chlorophyll proxy.
    Works for rivers, lakes, coastal areas, and estuaries.
    """
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        start = (now - dt_lib.timedelta(days=30)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        s2 = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
              .filterBounds(ee_geom)
              .filterDate(start, end)
              .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
              .median())

        # NDWI = (Green - NIR) / (Green + NIR) — positive = water
        green = s2.select('B3').divide(10000)
        nir   = s2.select('B8').divide(10000)
        red   = s2.select('B4').divide(10000)
        swir  = s2.select('B11').divide(10000)
        blue  = s2.select('B2').divide(10000)

        ndwi = green.subtract(nir).divide(green.add(nir)).rename('NDWI')
        
        # Turbidity proxy: Red band reflectance (higher red = more suspended sediment)
        turbidity_proxy = red.rename('TURB')
        
        # Chlorophyll proxy (blue/green ratio — lower = healthier)
        chl_proxy = blue.divide(green).rename('CHL')

        def mean(img, band):
            return img.reduceRegion(
                reducer=ee.Reducer.mean(), geometry=ee_geom,
                scale=10, maxPixels=1e10
            ).get(band).getInfo()

        ndwi_val = mean(ndwi, 'NDWI')
        turb_val = mean(turbidity_proxy, 'TURB')
        chl_val  = mean(chl_proxy, 'CHL')

        # Interpret turbidity
        turb_status = "Not computed"
        if turb_val is not None:
            if turb_val > 0.15:
                turb_status = "🔴 High Turbidity — severe sediment load or pollution"
            elif turb_val > 0.08:
                turb_status = "🟠 Moderate Turbidity — elevated sediment, possible upstream disturbance"
            elif turb_val > 0.04:
                turb_status = "🟡 Low-Moderate — normal for tropical rivers after rain"
            else:
                turb_status = "🟢 Clear Water — low suspended sediment"

        water_detected = ndwi_val > 0.0 if ndwi_val else False

        return {
            "analysis_type": "Water Quality",
            "water_body_detected": water_detected,
            "ndwi": round(ndwi_val, 4) if ndwi_val else None,
            "turbidity_proxy": round(turb_val, 4) if turb_val else None,
            "turbidity_status": turb_status,
            "chlorophyll_proxy": round(chl_val, 4) if chl_val else None,
            "satellite": "Sentinel-2 SR Harmonized (10m)",
            "period": "30-day median",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Water Quality", "status": f"error: {e}"}


def run_oil_spill_detection(ee_geom, ee_module) -> dict:
    """
    Sentinel-1 SAR oil spill detection.
    Oil on water creates anomalously low backscatter (smooth surface = no waves).
    """
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        start = (now - dt_lib.timedelta(days=14)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        s1 = (ee.ImageCollection('COPERNICUS/S1_GRD')
              .filterBounds(ee_geom)
              .filterDate(start, end)
              .filter(ee.Filter.eq('instrumentMode', 'IW'))
              .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
              .select('VV')
              .median())

        mean_vv = s1.reduceRegion(
            reducer=ee.Reducer.mean(), geometry=ee_geom,
            scale=10, maxPixels=1e10
        ).get('VV').getInfo()

        min_vv = s1.reduceRegion(
            reducer=ee.Reducer.min(), geometry=ee_geom,
            scale=10, maxPixels=1e10
        ).get('VV').getInfo()

        # Oil spill: VV < -20dB with normal sea around -10dB
        # Anomaly = regions significantly darker than mean
        spill_risk = "Not computed"
        anomaly_detected = False
        if mean_vv is not None and min_vv is not None:
            contrast = mean_vv - min_vv
            if min_vv < -22:
                spill_risk = "🔴 Potential oil/contaminant signature detected — anomalously low SAR return"
                anomaly_detected = True
            elif min_vv < -18:
                spill_risk = "🟠 Low backscatter anomaly detected — investigate biogenic film or vessel activity"
            else:
                spill_risk = "🟢 No significant dark patch anomaly detected in this period"

        return {
            "analysis_type": "Oil Spill / SAR Anomaly",
            "mean_vv_backscatter_db": round(mean_vv, 2) if mean_vv else None,
            "min_vv_backscatter_db": round(min_vv, 2) if min_vv else None,
            "oil_anomaly_detected": anomaly_detected,
            "spill_risk_assessment": spill_risk,
            "satellite": "Sentinel-1 IW VV (10m SAR)",
            "period": "14-day scan",
            "note": "SAR dark patches can also be caused by low wind, biogenic films, or vessel wakes. Visual optical cross-reference recommended.",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Oil Spill Detection", "status": f"error: {e}"}


def run_floating_debris_detection(ee_geom, ee_module) -> dict:
    """
    Sentinel-2 Floating Debris Index (FDI) for plastic / marine debris.
    FDI = NIR - (RedEdge + SWIR * factor) — plastic has different spectral response.
    """
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        start = (now - dt_lib.timedelta(days=30)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        s2 = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
              .filterBounds(ee_geom)
              .filterDate(start, end)
              .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 15))
              .median())

        nir   = s2.select('B8').divide(10000)
        re1   = s2.select('B6').divide(10000)  # Red Edge 1
        swir  = s2.select('B11').divide(10000)
        green = s2.select('B3').divide(10000)

        # FDI (Biermann et al. 2020)
        # FDI = NIR - (RE1 + (SWIR - RE1) * 6 * (833-665)/(1610-665))
        factor = 6.0 * (833 - 665) / (1610 - 665)
        fdi = nir.subtract(
            re1.add(swir.subtract(re1).multiply(factor))
        ).rename('FDI')

        ndwi = green.subtract(nir).divide(green.add(nir)).rename('NDWI')

        mean_fdi = fdi.reduceRegion(
            reducer=ee.Reducer.mean(), geometry=ee_geom,
            scale=10, maxPixels=1e10
        ).get('FDI').getInfo()

        max_fdi = fdi.reduceRegion(
            reducer=ee.Reducer.max(), geometry=ee_geom,
            scale=10, maxPixels=1e10
        ).get('FDI').getInfo()

        # Debris interpretation
        debris_status = "Not computed"
        if mean_fdi is not None:
            if mean_fdi > 0.05:
                debris_status = "🔴 Elevated FDI — possible floating debris or algae bloom detected"
            elif mean_fdi > 0.02:
                debris_status = "🟠 Moderate FDI — low-density debris or foam present"
            elif mean_fdi > 0.0:
                debris_status = "🟡 Trace signal — minor surface anomaly, observe next pass"
            else:
                debris_status = "🟢 Clear surface — no significant floating debris detected"

        return {
            "analysis_type": "Floating Debris / Marine Plastic",
            "mean_fdi": round(mean_fdi, 5) if mean_fdi else None,
            "max_fdi": round(max_fdi, 5) if max_fdi else None,
            "debris_status": debris_status,
            "satellite": "Sentinel-2 SR Harmonized (10m)",
            "method": "Floating Debris Index (FDI) — Biermann et al. 2020",
            "period": "30-day median",
            "limitation": "FDI detects floating material >10m patches. Micro-plastic and submerged debris require in-situ sampling.",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Floating Debris", "status": f"error: {e}"}


def run_fire_detection(ee_geom, ee_module) -> dict:
    """VIIRS active fire + Sentinel-2 NBR burn scar."""
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        start = (now - dt_lib.timedelta(days=30)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        firms = (ee.ImageCollection('FIRMS')
                 .filterBounds(ee_geom)
                 .filterDate(start, end))

        fire_count = firms.size().getInfo()

        # NBR burn scar from Sentinel-2
        s2 = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
              .filterBounds(ee_geom)
              .filterDate(start, end)
              .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
              .median())

        nir  = s2.select('B8').divide(10000)
        swir = s2.select('B12').divide(10000)
        nbr  = nir.subtract(swir).divide(nir.add(swir)).rename('NBR')

        mean_nbr = nbr.reduceRegion(
            reducer=ee.Reducer.mean(), geometry=ee_geom,
            scale=20, maxPixels=1e10
        ).get('NBR').getInfo()

        fire_status = "🔴 Active fire detections confirmed" if fire_count > 0 else "🟢 No active fire detections in this period"
        burn_status = "Not computed"
        if mean_nbr is not None:
            if mean_nbr < -0.1:
                burn_status = "🔴 Significant burn scar present"
            elif mean_nbr < 0.1:
                burn_status = "🟡 Low vegetation recovery — possible recent burn"
            else:
                burn_status = "🟢 No significant burn scar detected"

        return {
            "analysis_type": "Fire and Burn Scar Detection",
            "viirs_active_fire_detections": fire_count,
            "fire_detection_status": fire_status,
            "mean_nbr": round(mean_nbr, 4) if mean_nbr else None,
            "burn_scar_status": burn_status,
            "satellite": "VIIRS FIRMS + Sentinel-2 NBR",
            "period": "30-day scan",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Fire Detection", "status": f"error: {e}"}


def run_flood_detection(ee_geom, ee_module) -> dict:
    """Sentinel-1 SAR open water flood detection."""
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        post_start = (now - dt_lib.timedelta(days=7)).strftime('%Y-%m-%d')
        pre_start  = (now - dt_lib.timedelta(days=60)).strftime('%Y-%m-%d')
        pre_end    = (now - dt_lib.timedelta(days=30)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        def get_s1(date_start, date_end):
            return (ee.ImageCollection('COPERNICUS/S1_GRD')
                    .filterBounds(ee_geom)
                    .filterDate(date_start, date_end)
                    .filter(ee.Filter.eq('instrumentMode', 'IW'))
                    .filter(ee.Filter.listContains('transmitterReceiverPolarisation','VV'))
                    .select('VV').median())

        pre  = get_s1(pre_start, pre_end)
        post = get_s1(post_start, end)

        def mean_vv(img):
            return img.reduceRegion(
                reducer=ee.Reducer.mean(), geometry=ee_geom,
                scale=10, maxPixels=1e10
            ).get('VV').getInfo()

        pre_vv  = mean_vv(pre)
        post_vv = mean_vv(post)

        flood_status = "Not computed"
        change = None
        if pre_vv and post_vv:
            change = post_vv - pre_vv
            if change < -3:
                flood_status = "🔴 Significant backscatter decrease — likely flood inundation detected"
            elif change < -1.5:
                flood_status = "🟠 Moderate change — possible waterlogging or shallow flooding"
            else:
                flood_status = "🟢 No significant water level change detected"

        return {
            "analysis_type": "Flood / Inundation Detection",
            "pre_flood_vv_db": round(pre_vv, 2) if pre_vv else None,
            "post_flood_vv_db": round(post_vv, 2) if post_vv else None,
            "backscatter_change_db": round(change, 2) if change else None,
            "flood_status": flood_status,
            "satellite": "Sentinel-1 IW VV (10m SAR)",
            "method": "Pre/Post SAR backscatter change detection",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Flood Detection", "status": f"error: {e}"}


def run_coral_health_check(ee_geom, ee_module) -> dict:
    """Sentinel-2 coastal water quality proxy for coral bleaching risk."""
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        start = (now - dt_lib.timedelta(days=60)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        s2 = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
              .filterBounds(ee_geom)
              .filterDate(start, end)
              .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
              .median())

        blue  = s2.select('B2').divide(10000)
        green = s2.select('B3').divide(10000)
        red   = s2.select('B4').divide(10000)

        # Relative Coral Bleaching Index: bleached coral reflects more and looks "bright"
        rcbi = blue.add(green).add(red).divide(ee.Image(3.0)).rename('RCBI')

        mean_rcbi = rcbi.reduceRegion(
            reducer=ee.Reducer.mean(), geometry=ee_geom,
            scale=10, maxPixels=1e10
        ).get('RCBI').getInfo()

        bleach_status = "Not computed"
        if mean_rcbi is not None:
            if mean_rcbi > 0.12:
                bleach_status = "⚠️ Elevated brightness — possible bleaching or turbid shallow water. Field verification required."
            elif mean_rcbi > 0.07:
                bleach_status = "🟡 Moderate reflectance — moderate stress possible. Monitor SST data."
            else:
                bleach_status = "🟢 Normal spectral signature — no bleaching detected optically."

        return {
            "analysis_type": "Coral Health / Bleaching Risk",
            "mean_rcbi": round(mean_rcbi, 5) if mean_rcbi else None,
            "bleaching_optical_status": bleach_status,
            "satellite": "Sentinel-2 SR Harmonized (10m)",
            "note": "Optical methods detect severe bleaching. In-situ transects required for reef-level assessment.",
            "limitation": "Resolution (10m) insufficient for individual coral head assessment.",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Coral Health", "status": f"error: {e}"}


def run_air_quality_scan(ee_geom, ee_module) -> dict:
    """Sentinel-5P full air quality scan: NO₂, SO₂, CO, Aerosol."""
    try:
        ee = ee_module
        import datetime as dt_lib
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        start = (now - dt_lib.timedelta(days=30)).strftime('%Y-%m-%d')
        end = now.strftime('%Y-%m-%d')

        def get_s5p_mean(collection_id, band):
            img = (ee.ImageCollection(collection_id)
                   .filterBounds(ee_geom)
                   .filterDate(start, end)
                   .select(band)
                   .median())
            return img.reduceRegion(
                reducer=ee.Reducer.mean(), geometry=ee_geom,
                scale=1000, maxPixels=1e10
            ).get(band).getInfo()

        no2 = get_s5p_mean('COPERNICUS/S5P/NRTI/L3_NO2', 'NO2_column_number_density')
        so2 = get_s5p_mean('COPERNICUS/S5P/NRTI/L3_SO2', 'SO2_column_number_density')
        aer = get_s5p_mean('COPERNICUS/S5P/NRTI/L3_AER_AI', 'absorbing_aerosol_index')

        return {
            "analysis_type": "Air Quality Scan",
            "no2_mol_m2": round(no2, 8) if no2 else None,
            "so2_mol_m2": round(so2, 8) if so2 else None,
            "aerosol_index": round(aer, 4) if aer else None,
            "no2_status": "🔴 Elevated" if (no2 or 0) > 0.0001 else "🟢 Within limits",
            "so2_status": "🔴 Elevated" if (so2 or 0) > 0.001 else "🟢 Within limits",
            "haze_risk": "🟠 Haze risk" if (aer or 0) > 1.0 else "🟢 Clear",
            "satellite": "Sentinel-5P TROPOMI (1km)",
            "period": "30-day median",
            "status": "ok"
        }
    except Exception as e:
        return {"analysis_type": "Air Quality", "status": f"error: {e}"}


def run_heat_analysis(ee_geom, ee_module) -> dict:
    """Landsat 9 LST heat anomaly."""
    from urbantrace_engine import get_urban_heat_island
    return get_urban_heat_island(ee_geom, ee_module)


# ─────────────────────────────────────────────────────────────────────────────
# MASTER RUNNER
# ─────────────────────────────────────────────────────────────────────────────

GEE_FUNCTION_MAP = {
    "run_water_quality_analysis":     run_water_quality_analysis,
    "run_oil_spill_detection":        run_oil_spill_detection,
    "run_floating_debris_detection":  run_floating_debris_detection,
    "run_fire_detection":             run_fire_detection,
    "run_flood_detection":            run_flood_detection,
    "run_coral_health_check":         run_coral_health_check,
    "run_air_quality_scan":           run_air_quality_scan,
    "run_heat_analysis":              run_heat_analysis,
}

def run_earthquery(query: str, ee_geom, ee_module) -> dict:
    """
    Master EarthQuery runner.
    1. Parses the query intent.
    2. Runs the appropriate GEE analysis function.
    3. Returns structured results for Gemini narrative + DOCX generation.
    """
    intent = parse_query_intent(query)
    gee_fn_name = intent.get("gee_function") or "run_water_quality_analysis"
    gee_fn = GEE_FUNCTION_MAP.get(gee_fn_name, run_water_quality_analysis)

    satellite_results = gee_fn(ee_geom, ee_module)

    return {
        "module": "earthquery",
        "query": query,
        "parsed_intent": intent.get("intent"),
        "confidence": intent.get("confidence"),
        "sensors_used": intent.get("sensors"),
        "satellite_strategy": intent.get("satellite_strategy"),
        "description": intent.get("description"),
        "satellite_findings": satellite_results,
        "status": "complete"
    }
