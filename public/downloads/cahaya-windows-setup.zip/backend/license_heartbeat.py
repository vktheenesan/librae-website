#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAHAYA™ — License Heartbeat Service
Location: backend/license_heartbeat.py

Background asyncio task that pings the licensing server every 7 days.
Tracks consecutive failures and falls back to offline JWT mode on the 3rd.

Usage (in main.py startup_event):
    from license_heartbeat import start_heartbeat_service
    asyncio.create_task(start_heartbeat_service())
"""

import asyncio
import hashlib
import logging
import os
from datetime import datetime, timezone
from typing import Optional

import httpx

logger = logging.getLogger("license_heartbeat")

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

CAHAYA_VERSION = os.environ.get("CAHAYA_VERSION", "2.0.0")

# Heartbeat interval — 7 days in seconds.  Override via env for testing.
HEARTBEAT_INTERVAL_SECONDS = int(
    os.environ.get("CAHAYA_HEARTBEAT_INTERVAL", str(7 * 24 * 3600))
)

# How many consecutive failures before switching to offline JWT mode
MAX_CONSECUTIVE_FAILURES = 3

# Internal state (module-level singletons)
_consecutive_failures: int = 0
_offline_mode: bool = False
_heartbeat_task: Optional[asyncio.Task] = None

# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────


async def start_heartbeat_service(
    org_id: str = "",
    hardware_fingerprint: str = "",
    license_token: str = "",
) -> None:
    """
    Start the background heartbeat loop.

    Typically called once from FastAPI's startup_event:

        asyncio.create_task(start_heartbeat_service(
            org_id=MY_ORG_ID,
            hardware_fingerprint=get_hardware_fingerprint(),
            license_token=raw_license_token,
        ))

    If org_id / license_token are not supplied they are resolved from the
    local cahaya_secure.json / environment variables.
    """
    global _heartbeat_task

    # Resolve defaults if not supplied
    org_id            = org_id            or _resolve_org_id()
    license_token     = license_token     or _resolve_license_token()
    hardware_fingerprint = hardware_fingerprint or _resolve_hardware_fingerprint()

    logger.info(
        f"[Heartbeat] Service starting — org={org_id or '(unknown)'}, "
        f"interval={HEARTBEAT_INTERVAL_SECONDS}s"
    )

    _heartbeat_task = asyncio.current_task()  # so callers can cancel if needed

    while True:
        await _run_heartbeat(org_id, hardware_fingerprint, license_token)
        await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)


def is_offline_mode() -> bool:
    """Returns True if 3+ consecutive heartbeat failures have forced offline mode."""
    return _offline_mode


def reset_heartbeat_state() -> None:
    """Reset failure counters (useful for testing or after a successful manual renewal)."""
    global _consecutive_failures, _offline_mode
    _consecutive_failures = 0
    _offline_mode = False
    logger.info("[Heartbeat] State reset — returning to online mode.")


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────


async def _run_heartbeat(
    org_id: str,
    hardware_fingerprint: str,
    license_token: str,
) -> None:
    """Execute a single heartbeat ping and update Supabase on success."""
    global _consecutive_failures, _offline_mode

    token_hash = hashlib.sha256(license_token.encode()).hexdigest() if license_token else ""
    payload = {
        "org_id":               org_id,
        "hardware_fingerprint": hardware_fingerprint,
        "license_token_hash":   token_hash,
        "cahaya_version":       CAHAYA_VERSION,
        "timestamp":            datetime.now(timezone.utc).isoformat(),
    }

    success, response_data = await _post_heartbeat(payload)

    if success:
        _consecutive_failures = 0
        if _offline_mode:
            logger.info("[Heartbeat] ✅ Connection restored — exiting offline mode.")
            _offline_mode = False

        # Update Supabase last_heartbeat_at + log entry
        await _record_heartbeat_success(org_id, hardware_fingerprint, response_data)

    else:
        _consecutive_failures += 1
        logger.warning(
            f"[Heartbeat] ⚠️  Failure #{_consecutive_failures}/{MAX_CONSECUTIVE_FAILURES}: "
            f"{response_data.get('error', 'unknown error')}"
        )

        # Log failure to Supabase heartbeat log
        await _record_heartbeat_failure(org_id, hardware_fingerprint, response_data)

        if _consecutive_failures >= MAX_CONSECUTIVE_FAILURES and not _offline_mode:
            _offline_mode = True
            logger.warning(
                "[Heartbeat] 🔴 3 consecutive failures — switching to OFFLINE JWT mode. "
                "License will be validated locally from cached cahaya_secure.json."
            )


async def _post_heartbeat(payload: dict) -> tuple[bool, dict]:
    """
    Post the heartbeat payload.

    Priority:
      1. CAHAYA_HEARTBEAT_URL env var (custom edge function endpoint)
      2. SUPABASE_URL + /functions/v1/license-heartbeat (standard Supabase Edge Function)
      3. Internal backend endpoint (localhost)

    Returns (success: bool, response_data: dict).
    """
    endpoints = _build_endpoint_list()

    for url in endpoints:
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.post(
                    url,
                    json=payload,
                    headers={"Content-Type": "application/json"},
                )
                if resp.status_code in (200, 201, 204):
                    try:
                        data = resp.json()
                    except Exception:
                        data = {"status": "ok"}
                    logger.info(f"[Heartbeat] ✅ Pinged {url} → {resp.status_code}")
                    return True, data
                else:
                    logger.debug(f"[Heartbeat] Non-2xx from {url}: {resp.status_code}")
        except httpx.ConnectError:
            logger.debug(f"[Heartbeat] Connection refused: {url}")
        except httpx.TimeoutException:
            logger.debug(f"[Heartbeat] Timeout: {url}")
        except Exception as exc:
            logger.debug(f"[Heartbeat] Error calling {url}: {exc}")

    return False, {"error": "All heartbeat endpoints unreachable"}


def _build_endpoint_list() -> "list[str]":
    """Return ordered list of heartbeat URLs to try."""
    urls: "list[str]" = []

    custom = os.environ.get("CAHAYA_HEARTBEAT_URL", "")
    if custom:
        urls.append(custom)

    supabase_url = os.environ.get("SUPABASE_URL", "")
    if supabase_url:
        urls.append(f"{supabase_url.rstrip('/')}/functions/v1/license-heartbeat")

    # Fallback: self-hosted backend (useful in airgapped deployments)
    local_port = os.environ.get("PORT", "8000")
    urls.append(f"http://localhost:{local_port}/api/license/heartbeat-internal")

    return urls


async def _record_heartbeat_success(
    org_id: str,
    hardware_fingerprint: str,
    response_data: dict,
) -> None:
    """Update last_heartbeat_at on the matching installation and write a log entry."""
    try:
        from supabase_client import get_lenuda_client
        client = get_lenuda_client()
        if not client.is_configured:
            return

        now_iso = datetime.now(timezone.utc).isoformat()

        # Find the installation record
        rows = await client.select(
            "license_installations",
            f"org_id=eq.{org_id}&hardware_fingerprint=eq.{hardware_fingerprint}&is_active=eq.true",
            limit=1,
        )
        if not rows:
            return

        installation_id = rows[0]["id"]

        # Update heartbeat timestamp and reset failure counter
        await client.update(
            "license_installations",
            f"id=eq.{installation_id}",
            {
                "last_heartbeat_at": now_iso,
                "heartbeat_failures": 0,
            },
        )

        # Write log entry
        await client.insert(
            "license_heartbeat_log",
            {
                "installation_id": installation_id,
                "status": "ok",
                "response_data": response_data,
                "created_at": now_iso,
            },
        )

    except Exception as exc:
        logger.debug(f"[Heartbeat] Could not record success in Supabase: {exc}")


async def _record_heartbeat_failure(
    org_id: str,
    hardware_fingerprint: str,
    response_data: dict,
) -> None:
    """Increment heartbeat_failures on the installation and write a failure log entry."""
    try:
        from supabase_client import get_lenuda_client
        client = get_lenuda_client()
        if not client.is_configured:
            return

        now_iso = datetime.now(timezone.utc).isoformat()

        rows = await client.select(
            "license_installations",
            f"org_id=eq.{org_id}&hardware_fingerprint=eq.{hardware_fingerprint}&is_active=eq.true",
            limit=1,
        )
        if not rows:
            return

        installation_id = rows[0]["id"]
        current_failures = rows[0].get("heartbeat_failures", 0) + 1

        await client.update(
            "license_installations",
            f"id=eq.{installation_id}",
            {"heartbeat_failures": current_failures},
        )

        status = "revoked" if response_data.get("revoked") else "failed"
        await client.insert(
            "license_heartbeat_log",
            {
                "installation_id": installation_id,
                "status": status,
                "response_data": response_data,
                "created_at": now_iso,
            },
        )

    except Exception as exc:
        logger.debug(f"[Heartbeat] Could not record failure in Supabase: {exc}")


# ─────────────────────────────────────────────────────────────────────────────
# Local resolution helpers
# ─────────────────────────────────────────────────────────────────────────────


def _resolve_org_id() -> str:
    return os.environ.get("CAHAYA_ORG_ID", "")


def _resolve_license_token() -> str:
    """Read raw token from env or local cahaya.lic."""
    token = os.environ.get("CAHAYA_LICENSE_TOKEN", "")
    if token:
        return token
    for path in ("/app/cahaya.lic", "./cahaya.lic"):
        if os.path.exists(path):
            try:
                return open(path).read().strip()
            except Exception:
                pass
    return ""


def _resolve_hardware_fingerprint() -> str:
    """Compute hardware fingerprint using the enhanced function in licensing.py."""
    try:
        from licensing import get_hardware_fingerprint
        return get_hardware_fingerprint()
    except Exception:
        return ""
