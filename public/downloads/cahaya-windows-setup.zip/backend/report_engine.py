"""
Monthly Agent Report Generator
=================================
Generates professional PDF reports for each BAYU agent summarizing their monthly work,
with human-equivalence cost analysis and charity impact tracking.

Why this exists:
- Gives the founder clear visibility into what each AI agent accomplished
- Quantifies the value by comparing to human worker costs
- Enables charity donation planning (savings = human cost - AI cost)
"""

import os
import json
import hashlib
from datetime import datetime, timedelta
from pathlib import Path

# PDF generation
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT

# ─── Agent Definitions ───
AGENT_PROFILES = {
    "cfo": {
        "title": "Chief Financial Officer",
        "model": "GPT-4o",
        "color": "#ffb703",
        "human_role": "Financial Analyst / Revenue Operations Manager",
        "human_salary_monthly": 8500,  # USD, average for this role
        "responsibilities": [
            "Revenue pipeline analysis & LTV modeling",
            "Deal pricing & proposal economics",
            "Cash flow forecasting & budget monitoring",
            "SWIFT payment verification & compliance",
        ]
    },
    "cto": {
        "title": "Chief Technology Officer",
        "model": "Claude Sonnet",
        "color": "#00b4d8",
        "human_role": "Solutions Architect / DevOps Lead",
        "human_salary_monthly": 12000,
        "responsibilities": [
            "Architecture design & security audits",
            "Cahaya CLI deployment & versioning",
            "Infrastructure monitoring & patching",
            "License token cryptography & validation",
        ]
    },
    "cmo": {
        "title": "Chief Marketing Officer",
        "model": "Gemini",
        "color": "#ff007f",
        "human_role": "Growth Marketing Manager / SDR Lead",
        "human_salary_monthly": 7500,
        "responsibilities": [
            "Lead discovery & qualification (ESRI focus)",
            "LinkedIn outreach campaign management",
            "Content & brand positioning strategy",
            "Reply rate optimization & A/B testing",
        ]
    },
    "coo": {
        "title": "Chief Operations Officer",
        "model": "Qwen",
        "color": "#a855f7",
        "human_role": "Operations Manager / Project Coordinator",
        "human_salary_monthly": 7000,
        "responsibilities": [
            "10-layer orchestration & scheduling",
            "Trial monitoring & adoption scoring",
            "SLA management & delivery tracking",
            "Renewal pipeline & win-back campaigns",
        ]
    },
    "csr": {
        "title": "Customer Success Representative",
        "model": "GPT-4o",
        "color": "#10b981",
        "human_role": "Customer Success Manager / Support Specialist",
        "human_salary_monthly": 5500,
        "responsibilities": [
            "Installation guidance & onboarding calls",
            "Call script generation for client walkthroughs",
            "Support ticket management & resolution",
            "Client health monitoring & satisfaction",
        ]
    },
}

# Reports storage directory
REPORTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "reports"))


def ensure_reports_dir():
    """Create reports directory structure if needed."""
    os.makedirs(REPORTS_DIR, exist_ok=True)


async def get_agent_monthly_data(supabase_client, agent_key: str, year: int, month: int) -> dict:
    """
    Fetch all activity data for an agent in a given month from Supabase.
    
    Why we query multiple tables: Each table captures a different dimension of
    agent activity — sub-agents for task delegation, budget for cost tracking,
    learning log for outcome analysis, and war room messages for direct contributions.
    """
    start_date = f"{year}-{month:02d}-01"
    if month == 12:
        end_date = f"{year + 1}-01-01"
    else:
        end_date = f"{year}-{month + 1:02d}-01"

    data = {
        "sub_agents": [],
        "budget_logs": [],
        "learning_logs": [],
        "programs": [],
        "warroom_messages": [],
    }

    try:
        # Sub-agents created by this agent
        result = supabase_client.table("sub_agents").select("*").eq(
            "parent_agent", agent_key
        ).gte("created_at", start_date).lt("created_at", end_date).execute()
        data["sub_agents"] = result.data or []
    except Exception:
        pass

    try:
        # Budget usage
        result = supabase_client.table("agent_budget_log").select("*").eq(
            "agent_key", agent_key
        ).gte("log_date", start_date).lt("log_date", end_date).execute()
        data["budget_logs"] = result.data or []
    except Exception:
        pass

    try:
        # Learning outcomes
        result = supabase_client.table("agent_learning_log").select("*").eq(
            "agent_key", agent_key
        ).gte("created_at", start_date).lt("created_at", end_date).execute()
        data["learning_logs"] = result.data or []
    except Exception:
        pass

    try:
        # Programs created
        result = supabase_client.table("agent_programs").select("*").eq(
            "created_by", agent_key
        ).gte("created_at", start_date).lt("created_at", end_date).execute()
        data["programs"] = result.data or []
    except Exception:
        pass

    try:
        # War room contributions
        result = supabase_client.table("warroom_messages").select("*").eq(
            "agent_key", agent_key
        ).gte("created_at", start_date).lt("created_at", end_date).execute()
        data["warroom_messages"] = result.data or []
    except Exception:
        pass

    return data


def calculate_metrics(agent_key: str, data: dict) -> dict:
    """
    Calculate performance metrics from raw data.
    
    Why these metrics matter:
    - Tasks completed shows productivity volume
    - Success rate shows quality of work
    - Total cost shows AI operational expense
    - Human equivalence shows the value generated
    """
    profile = AGENT_PROFILES.get(agent_key, {})

    # Count completed sub-agents
    total_sub_agents = len(data["sub_agents"])
    completed = sum(1 for s in data["sub_agents"] if s.get("status") == "completed")
    failed = sum(1 for s in data["sub_agents"] if s.get("status") == "failed")

    # Budget totals
    total_tokens = sum(b.get("tokens_used", 0) for b in data["budget_logs"])
    total_cost = sum(float(b.get("cost_usd", 0)) for b in data["budget_logs"])
    active_days = len(data["budget_logs"])

    # Learning outcomes
    total_actions = len(data["learning_logs"])
    successes = sum(1 for l in data["learning_logs"] if l.get("outcome") == "success")
    success_rate = (successes / total_actions * 100) if total_actions > 0 else 0

    # War room participation
    warroom_msgs = len(data["warroom_messages"])

    # Programs created
    programs_created = len(data["programs"])

    # Human equivalence calculation
    # Based on: how many hours would a human need to do the same work?
    # Conservative estimate: each sub-agent task = 2 hours human work
    # Each war room contribution = 0.5 hours of research + drafting
    # Each program = 4 hours of creating reusable process
    estimated_human_hours = (
        total_sub_agents * 2 +
        warroom_msgs * 0.5 +
        programs_created * 4 +
        total_actions * 1
    )
    human_monthly_hours = 160  # standard work month
    human_salary = profile.get("human_salary_monthly", 7000)
    human_hourly = human_salary / human_monthly_hours
    human_equivalent_cost = estimated_human_hours * human_hourly
    humans_needed = max(0.1, estimated_human_hours / human_monthly_hours)

    # Charity potential = human cost - AI cost
    charity_potential = max(0, human_equivalent_cost - total_cost)

    return {
        "total_sub_agents": total_sub_agents,
        "completed_tasks": completed,
        "failed_tasks": failed,
        "success_rate": round(success_rate, 1),
        "total_tokens": total_tokens,
        "total_cost_usd": round(total_cost, 2),
        "active_days": active_days,
        "total_actions": total_actions,
        "warroom_contributions": warroom_msgs,
        "programs_created": programs_created,
        "estimated_human_hours": round(estimated_human_hours, 1),
        "humans_needed": round(humans_needed, 2),
        "human_role": profile.get("human_role", "Office Worker"),
        "human_salary_monthly": human_salary,
        "human_equivalent_cost": round(human_equivalent_cost, 2),
        "charity_potential": round(charity_potential, 2),
    }


def generate_agent_pdf(agent_key: str, year: int, month: int, metrics: dict) -> str:
    """
    Generate a professional PDF report for one agent.
    
    Why PDF: Universal format, printable, archivable. Each report tells the story
    of what the agent did, quantifies the value, and shows charity impact.
    
    Returns the file path of the generated PDF.
    """
    ensure_reports_dir()
    month_name = datetime(year, month, 1).strftime("%B")
    profile = AGENT_PROFILES.get(agent_key, {})
    agent_color = HexColor(profile.get("color", "#00e5ff"))

    # Create month directory
    month_dir = os.path.join(REPORTS_DIR, f"{year}-{month:02d}")
    os.makedirs(month_dir, exist_ok=True)

    filename = f"{agent_key}_report_{year}_{month:02d}.pdf"
    filepath = os.path.join(month_dir, filename)

    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        rightMargin=20 * mm,
        leftMargin=20 * mm,
        topMargin=25 * mm,
        bottomMargin=20 * mm,
    )

    # ─── Styles ───
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="ReportTitle",
        fontName="Helvetica-Bold",
        fontSize=22,
        textColor=agent_color,
        spaceAfter=6,
    ))
    styles.add(ParagraphStyle(
        name="ReportSubtitle",
        fontName="Helvetica",
        fontSize=11,
        textColor=HexColor("#666666"),
        spaceAfter=16,
    ))
    styles.add(ParagraphStyle(
        name="SectionHeader",
        fontName="Helvetica-Bold",
        fontSize=13,
        textColor=HexColor("#1a1a2e"),
        spaceBefore=16,
        spaceAfter=8,
    ))
    styles.add(ParagraphStyle(
        name="BodyText2",
        fontName="Helvetica",
        fontSize=10,
        textColor=HexColor("#333333"),
        leading=14,
        spaceAfter=6,
    ))
    styles.add(ParagraphStyle(
        name="MetricValue",
        fontName="Helvetica-Bold",
        fontSize=18,
        textColor=agent_color,
        alignment=TA_CENTER,
    ))
    styles.add(ParagraphStyle(
        name="MetricLabel",
        fontName="Helvetica",
        fontSize=8,
        textColor=HexColor("#999999"),
        alignment=TA_CENTER,
    ))
    styles.add(ParagraphStyle(
        name="CharityHeader",
        fontName="Helvetica-Bold",
        fontSize=14,
        textColor=HexColor("#10b981"),
        spaceBefore=20,
        spaceAfter=8,
    ))

    # ─── Build Story ───
    story = []

    # Header
    story.append(Paragraph(
        f"LIBRAE AI LABS — MONTHLY AGENT REPORT",
        ParagraphStyle(name="OrgHeader", fontName="Helvetica-Bold", fontSize=9,
                       textColor=HexColor("#999999"), spaceAfter=4)
    ))
    story.append(Paragraph(
        f"{profile.get('title', agent_key.upper())} · {month_name} {year}",
        styles["ReportTitle"]
    ))
    story.append(Paragraph(
        f"Agent: {agent_key.upper()} | Model: {profile.get('model', 'N/A')} | "
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        styles["ReportSubtitle"]
    ))
    story.append(HRFlowable(width="100%", thickness=1, color=agent_color, spaceAfter=12))

    # Executive Summary
    story.append(Paragraph("EXECUTIVE SUMMARY", styles["SectionHeader"]))
    story.append(Paragraph(
        f"This report summarizes the activities and performance of the <b>{profile.get('title', agent_key.upper())}</b> "
        f"agent during <b>{month_name} {year}</b>. The agent was active for <b>{metrics['active_days']} days</b>, "
        f"completed <b>{metrics['completed_tasks']} tasks</b> via sub-agents, contributed "
        f"<b>{metrics['warroom_contributions']} strategic analyses</b> in War Room sessions, "
        f"and created <b>{metrics['programs_created']} reusable programs</b>.",
        styles["BodyText2"]
    ))

    # Key Metrics Grid
    story.append(Spacer(1, 10))
    story.append(Paragraph("KEY PERFORMANCE METRICS", styles["SectionHeader"]))

    metrics_data = [
        [
            [Paragraph(str(metrics["completed_tasks"]), styles["MetricValue"]),
             Paragraph("Tasks Completed", styles["MetricLabel"])],
            [Paragraph(f"{metrics['success_rate']}%", styles["MetricValue"]),
             Paragraph("Success Rate", styles["MetricLabel"])],
            [Paragraph(str(metrics["active_days"]), styles["MetricValue"]),
             Paragraph("Active Days", styles["MetricLabel"])],
            [Paragraph(f"${metrics['total_cost_usd']:.2f}", styles["MetricValue"]),
             Paragraph("Total AI Cost", styles["MetricLabel"])],
        ]
    ]
    metrics_table = Table(metrics_data, colWidths=[doc.width / 4] * 4)
    metrics_table.setStyle(TableStyle([
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), 0.5, HexColor("#dddddd")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, HexColor("#eeeeee")),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(metrics_table)

    # Responsibilities
    story.append(Spacer(1, 8))
    story.append(Paragraph("RESPONSIBILITIES COVERED", styles["SectionHeader"]))
    for resp in profile.get("responsibilities", []):
        story.append(Paragraph(f"• {resp}", styles["BodyText2"]))

    # Activity Breakdown
    story.append(Paragraph("ACTIVITY BREAKDOWN", styles["SectionHeader"]))
    activity_data = [
        ["Activity", "Count", "Notes"],
        ["Sub-Agents Spawned", str(metrics["total_sub_agents"]),
         f"{metrics['completed_tasks']} completed, {metrics['failed_tasks']} failed"],
        ["War Room Contributions", str(metrics["warroom_contributions"]),
         "Strategic analyses delivered in council"],
        ["Reusable Programs Created", str(metrics["programs_created"]),
         "Templates, workflows, analysis tools"],
        ["Learning Actions Logged", str(metrics["total_actions"]),
         f"{metrics['success_rate']}% success rate"],
        ["Tokens Consumed", f"{metrics['total_tokens']:,}", "Across all LLM calls"],
    ]
    activity_table = Table(activity_data, colWidths=[doc.width * 0.35, doc.width * 0.15, doc.width * 0.50])
    activity_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), agent_color),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (1, -1), "CENTER"),
        ("BOX", (0, 0), (-1, -1), 0.5, HexColor("#dddddd")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, HexColor("#eeeeee")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [HexColor("#fafafa"), white]),
    ]))
    story.append(activity_table)

    # Human Equivalence Section
    story.append(Spacer(1, 10))
    story.append(Paragraph("💼 HUMAN EQUIVALENCE ANALYSIS", styles["SectionHeader"]))
    story.append(Paragraph(
        f"To accomplish the same volume and quality of work this month, you would need "
        f"approximately <b>{metrics['humans_needed']:.1f} full-time {metrics['human_role']}(s)</b>.",
        styles["BodyText2"]
    ))

    equiv_data = [
        ["Metric", "AI Agent", "Human Equivalent"],
        ["Hours of Work", f"24/7 automated", f"{metrics['estimated_human_hours']:.0f} hours"],
        ["Monthly Cost", f"${metrics['total_cost_usd']:.2f}", f"${metrics['human_equivalent_cost']:,.2f}"],
        ["Workers Needed", "1 AI agent", f"{metrics['humans_needed']:.1f} person(s)"],
        ["Role Equivalent", profile.get("model", "AI"), metrics["human_role"]],
        ["Avg Monthly Salary", "—", f"${metrics['human_salary_monthly']:,}/mo"],
    ]
    equiv_table = Table(equiv_data, colWidths=[doc.width * 0.33, doc.width * 0.33, doc.width * 0.34])
    equiv_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HexColor("#1a1a2e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BOX", (0, 0), (-1, -1), 0.5, HexColor("#dddddd")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, HexColor("#eeeeee")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [HexColor("#f8f8f8"), white]),
    ]))
    story.append(equiv_table)

    # Charity Impact Section
    story.append(Spacer(1, 10))
    story.append(Paragraph("🌿 CHARITY IMPACT POTENTIAL", styles["CharityHeader"]))
    story.append(HRFlowable(width="100%", thickness=1, color=HexColor("#10b981"), spaceAfter=8))
    story.append(Paragraph(
        f"By using AI agents instead of hiring human workers for these tasks, "
        f"Librae AI Labs saved approximately <b>${metrics['charity_potential']:,.2f}</b> this month.",
        styles["BodyText2"]
    ))
    story.append(Paragraph(
        f"This amount represents the difference between the human equivalent cost "
        f"(${metrics['human_equivalent_cost']:,.2f}) and the actual AI operational cost "
        f"(${metrics['total_cost_usd']:.2f}). At the founder's discretion, this saving "
        f"can be allocated to charitable causes.",
        styles["BodyText2"]
    ))

    charity_data = [
        ["", "Amount"],
        ["Human Equivalent Cost", f"${metrics['human_equivalent_cost']:,.2f}"],
        ["AI Operational Cost", f"${metrics['total_cost_usd']:.2f}"],
        ["Net Savings (Charity Potential)", f"${metrics['charity_potential']:,.2f}"],
    ]
    charity_table = Table(charity_data, colWidths=[doc.width * 0.6, doc.width * 0.4])
    charity_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HexColor("#10b981")),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BACKGROUND", (0, -1), (-1, -1), HexColor("#ecfdf5")),
        ("BOX", (0, 0), (-1, -1), 0.5, HexColor("#10b981")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, HexColor("#d1fae5")),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
    ]))
    story.append(charity_table)

    # Footer
    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=HexColor("#cccccc"), spaceAfter=8))
    story.append(Paragraph(
        f"This report was automatically generated by BAYU · CEO-001 Autonomous Operating System · "
        f"Librae AI Labs © {year}. All metrics derived from operational telemetry.",
        ParagraphStyle(name="Footer", fontName="Helvetica", fontSize=7,
                       textColor=HexColor("#aaaaaa"), alignment=TA_CENTER)
    ))

    # Build PDF
    doc.build(story)
    return filepath


async def generate_monthly_reports(supabase_client, year: int = None, month: int = None) -> dict:
    """
    Generate reports for ALL agents for a given month.
    Returns a summary dict with file paths and metrics.
    
    Why all agents at once: The founder wants to see the full picture —
    total organizational output, combined human equivalence, and aggregate charity potential.
    """
    if year is None or month is None:
        # Default to previous month
        today = datetime.now()
        first_of_month = today.replace(day=1)
        last_month = first_of_month - timedelta(days=1)
        year = last_month.year
        month = last_month.month

    month_name = datetime(year, month, 1).strftime("%B %Y")
    results = {
        "period": f"{year}-{month:02d}",
        "period_name": month_name,
        "agents": {},
        "totals": {
            "total_ai_cost": 0,
            "total_human_equivalent": 0,
            "total_charity_potential": 0,
            "total_humans_needed": 0,
            "total_tasks": 0,
        }
    }

    for agent_key in AGENT_PROFILES:
        data = await get_agent_monthly_data(supabase_client, agent_key, year, month)
        metrics = calculate_metrics(agent_key, data)
        filepath = generate_agent_pdf(agent_key, year, month, metrics)

        results["agents"][agent_key] = {
            "title": AGENT_PROFILES[agent_key]["title"],
            "model": AGENT_PROFILES[agent_key]["model"],
            "pdf_path": filepath,
            "pdf_filename": os.path.basename(filepath),
            "download_url": f"/api/reports/{year}-{month:02d}/{os.path.basename(filepath)}",
            "metrics": metrics,
        }

        # Accumulate totals
        results["totals"]["total_ai_cost"] += metrics["total_cost_usd"]
        results["totals"]["total_human_equivalent"] += metrics["human_equivalent_cost"]
        results["totals"]["total_charity_potential"] += metrics["charity_potential"]
        results["totals"]["total_humans_needed"] += metrics["humans_needed"]
        results["totals"]["total_tasks"] += metrics["completed_tasks"]

    # Round totals
    for k in results["totals"]:
        results["totals"][k] = round(results["totals"][k], 2)

    return results


def list_available_reports() -> list:
    """
    List all available report months and their files.
    Scans the reports directory for generated PDFs.
    """
    ensure_reports_dir()
    months = []
    
    if not os.path.exists(REPORTS_DIR):
        return months

    for entry in sorted(os.listdir(REPORTS_DIR), reverse=True):
        month_dir = os.path.join(REPORTS_DIR, entry)
        if os.path.isdir(month_dir) and len(entry) == 7:  # "2026-06" format
            files = []
            for f in sorted(os.listdir(month_dir)):
                if f.endswith(".pdf"):
                    agent_key = f.split("_report_")[0] if "_report_" in f else "unknown"
                    profile = AGENT_PROFILES.get(agent_key, {})
                    files.append({
                        "filename": f,
                        "agent_key": agent_key,
                        "agent_title": profile.get("title", agent_key.upper()),
                        "color": profile.get("color", "#00e5ff"),
                        "download_url": f"/api/reports/{entry}/{f}",
                        "size_kb": round(os.path.getsize(os.path.join(month_dir, f)) / 1024, 1),
                    })
            months.append({
                "period": entry,
                "period_name": datetime.strptime(entry, "%Y-%m").strftime("%B %Y"),
                "files": files,
                "file_count": len(files),
            })
    
    return months
