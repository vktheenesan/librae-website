#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAHAYA Enterprise Patch System — Client-Side Patch Loader
Location: backend/patch_loader.py

Loaded at CAHAYA startup. Scans the plugins/ directory for .cpatch files,
validates each one cryptographically, decrypts the payload, and registers
backend routes and frontend injections.

Security guarantees:
  - RSA-2048 signature verification using embedded Librae public key
  - AES-256-GCM payload decryption
  - Hardware fingerprint binding (org-specific machine lock)
  - Expiry enforcement
  - Restricted Python execution via RestrictedPython
  - File I/O within backend modules limited to data/patch_sandbox/
  - Decrypted payload code is NEVER logged
"""

from __future__ import annotations

import os
import sys
import json
import base64
import hashlib
import logging
import importlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("patch_loader")

# ---------------------------------------------------------------------------
# Dependency guard
# ---------------------------------------------------------------------------
try:
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.serialization import load_pem_public_key
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _CRYPTO_AVAILABLE = True
except ImportError:
    _CRYPTO_AVAILABLE = False
    logger.warning(
        "⚠️  'cryptography' package not available — enterprise patches disabled. "
        "Install with: pip install cryptography"
    )

# RestrictedPython is optional but strongly recommended for production
try:
    from RestrictedPython import compile_restricted, safe_globals, safe_builtins
    from RestrictedPython.Guards import safe_iter_unpack_sequence
    _RESTRICTED_PYTHON = True
except ImportError:
    _RESTRICTED_PYTHON = False
    logger.warning(
        "⚠️  'RestrictedPython' not installed — falling back to custom sandbox. "
        "For production: pip install RestrictedPython"
    )

# ---------------------------------------------------------------------------
# Constants & paths
# ---------------------------------------------------------------------------
_BASE_DIR = Path(__file__).resolve().parent

PATCH_DIR          = _BASE_DIR.parent / "plugins"
PUBLIC_KEY_PATH    = _BASE_DIR / "librae_public.pem"
SANDBOX_DIR        = _BASE_DIR.parent / "data" / "patch_sandbox"

MIN_FORMAT_VERSION = "1"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    valid:  bool
    reason: str = "OK"


@dataclass
class LoadedPatch:
    patch_id:     str
    org_id:       str
    version:      str
    expiry:       str
    capabilities: list[str]
    # Internal — never exposed externally
    _backend_modules:  dict[str, str] = field(default_factory=dict, repr=False)
    _frontend_modules: dict[str, str] = field(default_factory=dict, repr=False)

    def to_public_dict(self) -> dict:
        """Serializable metadata — NEVER includes module code."""
        return {
            "patch_id":     self.patch_id,
            "org_id":       self.org_id,
            "version":      self.version,
            "expiry":       self.expiry,
            "capabilities": self.capabilities,
        }


# ---------------------------------------------------------------------------
# Hardware fingerprint
# ---------------------------------------------------------------------------

def get_hardware_fingerprint() -> str:
    """
    Returns this machine's hardware fingerprint, consistent with the value
    used by the licensing system (licensing.py → get_local_uuid).
    """
    possible_paths = [
        "/app/product_uuid",
        "/app/machine-id",
        "/sys/class/dmi/id/product_uuid",
        "/etc/machine-id",
    ]
    for path in possible_paths:
        if os.path.exists(path):
            try:
                val = open(path).read().strip()
                if val:
                    return val
            except Exception:
                pass

    if sys.platform == "darwin":
        try:
            import subprocess
            cmd = (
                "ioreg -d2 -c IOPlatformExpertDevice "
                "| awk -F\\\" '/IOPlatformUUID/{print $(NF-1)}'"
            )
            output = subprocess.check_output(cmd, shell=True).decode().strip()
            if output:
                return output
        except Exception:
            pass

    try:
        import uuid
        return str(uuid.getnode())
    except Exception:
        return "UNKNOWN_HW_UUID"


def _get_org_id_from_license() -> Optional[str]:
    """
    Reads org_id from the installation's cahaya_secure.json license receipt.
    Returns None if the file is absent or malformed.
    """
    license_paths = [
        _BASE_DIR.parent / "cahaya_secure.json",
        _BASE_DIR / "cahaya_secure.json",
    ]
    for lp in license_paths:
        if lp.exists():
            try:
                receipt = json.loads(lp.read_text(encoding="utf-8"))
                # Field name used in licensing.py is "org_id" or "org_name"
                return receipt.get("org_id") or receipt.get("org_name")
            except Exception:
                pass
    return None


# ---------------------------------------------------------------------------
# Crypto helpers
# ---------------------------------------------------------------------------

def _derive_aes_key_from_fingerprint(hardware_fp: str) -> bytes:
    return hashlib.pbkdf2_hmac(
        "sha256",
        hardware_fp.encode("utf-8"),
        b"CAHAYA_PATCH_KDF_SALT_V1",
        iterations=200_000,
        dklen=32,
    )


# ---------------------------------------------------------------------------
# Restricted exec sandbox
# ---------------------------------------------------------------------------

# Allowlist of builtins permitted inside patch modules
_SAFE_BUILTINS_ALLOWLIST = {
    "None", "True", "False",
    "abs", "all", "any", "bin", "bool", "bytes", "callable",
    "chr", "dict", "dir", "divmod", "enumerate", "filter",
    "float", "format", "frozenset", "getattr", "hasattr",
    "hash", "hex", "int", "isinstance", "issubclass", "iter",
    "len", "list", "map", "max", "min", "next", "object",
    "oct", "ord", "pow", "print", "range", "repr", "reversed",
    "round", "set", "setattr", "slice", "sorted", "str", "sum",
    "tuple", "type", "vars", "zip",
}

# Blocklist of module-level imports forbidden in patch modules
_BLOCKED_MODULES = {
    "os", "sys", "subprocess", "socket", "shutil", "importlib",
    "ctypes", "pickle", "shelve", "marshal", "pty", "signal",
    "multiprocessing", "threading", "concurrent",
    "_thread", "builtins", "importlib",
}


def _make_restricted_builtins(sandbox_dir: Path) -> dict:
    """
    Constructs a restricted builtins dict for use in exec().
    Replaces 'open' with a sandboxed version limited to sandbox_dir.
    """
    import builtins as _builtins

    def _safe_open(file, mode="r", *args, **kwargs):
        """Sandbox-limited file open — only sandbox_dir is accessible."""
        requested = Path(file).resolve()
        allowed   = sandbox_dir.resolve()
        if not str(requested).startswith(str(allowed)):
            raise PermissionError(
                f"[PATCH SANDBOX] File access denied outside sandbox: {file}"
            )
        sandbox_dir.mkdir(parents=True, exist_ok=True)
        return _builtins.open(requested, mode, *args, **kwargs)

    def _safe_import(name, *args, **kwargs):
        """Block imports of dangerous modules."""
        top_level = name.split(".")[0]
        if top_level in _BLOCKED_MODULES:
            raise ImportError(
                f"[PATCH SANDBOX] Import of '{name}' is not permitted in patch modules."
            )
        return __import__(name, *args, **kwargs)

    restricted = {b: getattr(_builtins, b) for b in _SAFE_BUILTINS_ALLOWLIST if hasattr(_builtins, b)}
    restricted["open"]     = _safe_open
    restricted["__import__"] = _safe_import
    return restricted


# ---------------------------------------------------------------------------
# PatchLoader
# ---------------------------------------------------------------------------

class PatchLoader:
    """
    Loads, validates, decrypts, and executes enterprise .cpatch modules.
    All crypto operations require the 'cryptography' package.
    """

    PATCH_DIR        = PATCH_DIR
    PUBLIC_KEY_PATH  = PUBLIC_KEY_PATH
    SANDBOX_DIR      = SANDBOX_DIR

    def __init__(self):
        self._public_key = None
        self._hardware_fp: Optional[str] = None
        self._org_id: Optional[str]      = None
        self._loaded_patches: list[LoadedPatch] = []

        # Pre-load crypto assets (fail softly so CAHAYA still starts)
        if _CRYPTO_AVAILABLE:
            self._load_public_key()
        self._hardware_fp = get_hardware_fingerprint()
        self._org_id      = _get_org_id_from_license()
        SANDBOX_DIR.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_all_patches(self, app=None) -> list[LoadedPatch]:
        """
        Scans PATCH_DIR for *.cpatch files, validates each, decrypts, and
        optionally registers backend routes against the FastAPI `app`.

        Returns a list of successfully loaded LoadedPatch instances.
        """
        loaded: list[LoadedPatch] = []

        if not _CRYPTO_AVAILABLE:
            logger.warning("Enterprise patches disabled — 'cryptography' not installed.")
            return loaded

        if not self.PATCH_DIR.exists():
            logger.info("Plugins directory not found: %s — skipping patch load.", self.PATCH_DIR)
            return loaded

        patch_files = sorted(self.PATCH_DIR.glob("*.cpatch"))
        if not patch_files:
            logger.info("No .cpatch files found in %s", self.PATCH_DIR)
            return loaded

        logger.info("Found %d .cpatch file(s) in %s", len(patch_files), self.PATCH_DIR)

        for pf in patch_files:
            logger.info("Processing patch: %s", pf.name)
            try:
                result = self.validate_patch(str(pf))
                if not result.valid:
                    logger.warning("⚠️  Patch rejected [%s]: %s", pf.name, result.reason)
                    continue

                raw = json.loads(pf.read_text(encoding="utf-8"))
                modules = self.decrypt_payload(raw, self._hardware_fp)
                if modules is None:
                    logger.warning("⚠️  Payload decryption failed for %s — skipping.", pf.name)
                    continue

                header = raw["header"]
                patch  = LoadedPatch(
                    patch_id     = header["patch_id"],
                    org_id       = header["org_id"],
                    version      = header.get("version", "?"),
                    expiry       = header.get("expiry", "?"),
                    capabilities = header.get("capabilities", []),
                    _backend_modules  = modules.get("backend_modules", {}),
                    _frontend_modules = modules.get("frontend_modules", {}),
                )

                # Register backend routes if FastAPI app is provided
                if app is not None:
                    for mod_name, mod_code in patch._backend_modules.items():
                        self.execute_backend_module(mod_code, app, source_hint=mod_name)

                loaded.append(patch)
                logger.info(
                    "✅  Loaded patch: %s | org=%s | caps=%s",
                    patch.patch_id, patch.org_id,
                    ", ".join(patch.capabilities) or "(none)",
                )

            except Exception as exc:
                logger.error("❌  Unexpected error loading %s: %s", pf.name, exc, exc_info=False)

        self._loaded_patches = loaded
        return loaded

    def validate_patch(self, patch_path: str) -> ValidationResult:
        """
        Full cryptographic validation of a .cpatch file.
        Does NOT decrypt the payload — only signature/expiry/org/hw checks.
        """
        try:
            raw = json.loads(Path(patch_path).read_text(encoding="utf-8"))
        except Exception as exc:
            return ValidationResult(False, f"JSON parse error: {exc}")

        header        = raw.get("header")
        payload_b64   = raw.get("payload", "")
        signature_b64 = raw.get("signature", "")

        if not header or not payload_b64 or not signature_b64:
            return ValidationResult(False, "Missing required fields (header/payload/signature)")

        # 1. RSA signature
        if self._public_key is None:
            return ValidationResult(False, "Librae public key not loaded — cannot verify signature")

        header_json = json.dumps(header, separators=(",", ":"))
        digest      = hashlib.sha256((header_json + payload_b64).encode("utf-8")).digest()
        try:
            self._public_key.verify(
                base64.b64decode(signature_b64),
                digest,
                padding.PKCS1v15(),
                hashes.Prehashed(hashes.SHA256()),
            )
        except Exception:
            return ValidationResult(False, "RSA signature verification failed — patch may be tampered")

        # 2. Expiry
        expiry_str = header.get("expiry", "")
        if expiry_str:
            try:
                expiry_dt = datetime.fromisoformat(expiry_str).replace(tzinfo=timezone.utc)
                if datetime.now(timezone.utc) > expiry_dt:
                    return ValidationResult(False, f"Patch expired on {expiry_str}")
            except ValueError:
                return ValidationResult(False, f"Cannot parse expiry date: {expiry_str}")

        # 3. Org ID
        patch_org = header.get("org_id")
        if self._org_id and patch_org and self._org_id != patch_org:
            return ValidationResult(
                False,
                f"org_id mismatch: license={self._org_id}, patch={patch_org}",
            )

        # 4. Hardware fingerprint
        patch_hw = header.get("hardware_fingerprint")
        if patch_hw and self._hardware_fp and patch_hw != self._hardware_fp:
            return ValidationResult(False, "Hardware fingerprint mismatch")

        return ValidationResult(True, "OK")

    def decrypt_payload(self, patch: dict, hardware_fp: str) -> Optional[dict]:
        """
        Unwraps the AES key using hardware_fp, then decrypts the AES-256-GCM payload.
        Returns the decoded module dict, or None on failure.
        Decrypted code is NEVER logged.
        """
        encrypted_key_b64 = patch.get("encrypted_key", "")
        payload_b64       = patch.get("payload", "")

        if not encrypted_key_b64 or not payload_b64:
            logger.error("decrypt_payload: missing encrypted_key or payload")
            return None

        try:
            # Unwrap AES key
            wrapping_key = _derive_aes_key_from_fingerprint(hardware_fp)
            raw_wrapped   = base64.b64decode(encrypted_key_b64)
            wrap_iv       = raw_wrapped[:12]
            wrapped_key   = raw_wrapped[12:]
            aes_key       = AESGCM(wrapping_key).decrypt(wrap_iv, wrapped_key, None)

            # Decrypt payload
            raw_payload  = base64.b64decode(payload_b64)
            payload_iv   = raw_payload[:12]
            ciphertext   = raw_payload[12:]
            plaintext    = AESGCM(aes_key).decrypt(payload_iv, ciphertext, None)

            return json.loads(plaintext.decode("utf-8"))
        except Exception as exc:
            logger.error("Payload decryption error (details suppressed for security): %s", type(exc).__name__)
            return None

    def execute_backend_module(self, module_code: str, app, source_hint: str = "<patch>") -> None:
        """
        Execute a Python module string in a restricted namespace.
        The module may register new FastAPI routes via the injected `app` object.
        File I/O is sandboxed to SANDBOX_DIR.
        """
        if _RESTRICTED_PYTHON:
            self._exec_restricted_python(module_code, app, source_hint)
        else:
            self._exec_custom_sandbox(module_code, app, source_hint)

    def inject_frontend_module(self, js_code: str) -> str:
        """
        Returns a JS snippet that runs the module code inside a sandboxed
        iframe-context wrapper, preventing access to parent document internals.
        """
        # Wrap in an IIFE with a restricted global scope
        wrapped = (
            "(function(window, document, XMLHttpRequest, fetch) {\n"
            "  'use strict';\n"
            "  // Enterprise patch module — sandboxed execution\n"
            + js_code + "\n"
            "})(undefined, undefined, undefined, undefined);"
        )
        return wrapped

    def get_loaded_patches_metadata(self) -> list[dict]:
        """Returns public metadata for all loaded patches (no code exposed)."""
        return [p.to_public_dict() for p in self._loaded_patches]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_public_key(self) -> None:
        if not self.PUBLIC_KEY_PATH.exists():
            logger.warning(
                "Librae public key not found at %s — enterprise patches cannot be verified.",
                self.PUBLIC_KEY_PATH,
            )
            return
        try:
            self._public_key = load_pem_public_key(self.PUBLIC_KEY_PATH.read_bytes())
            logger.info("✅  Librae public key loaded from %s", self.PUBLIC_KEY_PATH)
        except Exception as exc:
            logger.error("Failed to load public key: %s", exc)

    def _exec_restricted_python(self, code: str, app, source_hint: str) -> None:
        """Execute using RestrictedPython (preferred)."""
        try:
            byte_code = compile_restricted(code, filename=source_hint, mode="exec")
        except SyntaxError as exc:
            logger.error("Patch module syntax error in %s: %s", source_hint, exc)
            return

        glb = safe_globals.copy()
        glb["__builtins__"] = safe_builtins
        glb["_getiter_"]    = iter
        glb["_getattr_"]    = getattr
        glb["_write_"]      = lambda x: x  # allow attribute writes inside module
        glb["_inplacevar_"] = lambda op, x, y: x  # allow augmented assignment
        glb["_iter_unpack_sequence_"] = safe_iter_unpack_sequence
        glb["app"]          = app           # FastAPI app for route registration
        glb["logger"]       = logging.getLogger(f"patch.{source_hint}")

        loc: dict = {}
        try:
            exec(byte_code, glb, loc)  # noqa: S102
            # Call on_load(app) if the module defines it
            on_load = loc.get("on_load") or glb.get("on_load")
            if callable(on_load):
                on_load(app)
        except Exception as exc:
            logger.error("Patch module execution error in %s: %s", source_hint, exc)

    def _exec_custom_sandbox(self, code: str, app, source_hint: str) -> None:
        """
        Fallback sandbox when RestrictedPython is not installed.
        Uses a restricted builtins dict and blocks dangerous imports.
        """
        restricted_builtins = _make_restricted_builtins(self.SANDBOX_DIR)

        glb = {
            "__builtins__": restricted_builtins,
            "__name__":     f"cahaya_patch.{source_hint}",
            "app":          app,
            "logger":       logging.getLogger(f"patch.{source_hint}"),
        }
        loc: dict = {}
        try:
            compiled = compile(code, source_hint, "exec")
            exec(compiled, glb, loc)  # noqa: S102
            on_load = loc.get("on_load") or glb.get("on_load")
            if callable(on_load):
                on_load(app)
        except Exception as exc:
            logger.error("Patch module execution error in %s: %s", source_hint, exc)
