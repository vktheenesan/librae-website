"""
LENUDA™ Premium 2.0 — Token Service
======================================
Handles credit/token management for LENUDA users.
Adapted from legacy credits.py — uses env vars + Supabase REST instead of config.py imports.

Functions:
  - get_token_balance()    → fetch user's current token balance
  - deduct_tokens()        → atomically deduct tokens for an analysis
  - add_tokens()           → credit tokens (after purchase, promo, etc.)
  - get_token_history()    → get transaction history
  - calculate_token_cost() → determine cost based on analysis type and domain
"""

import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from enum import Enum

from supabase_client import get_lenuda_client

logger = logging.getLogger("token_service")


# ============================================================================
# TOKEN COST TABLE
# ============================================================================

class AnalysisType(str, Enum):
    QUICK_SCAN = "quick_scan"         # Basic NDVI/EVI only
    STANDARD = "standard"             # Full satellite stack
    PREMIUM = "premium"               # Phase C + all sensors
    FORENSIC = "forensic"             # Forensic delta tracking
    DOSSIER = "dossier"               # Full compliance dossier
    URBANTRACE = "urbantrace"         # Urban analysis
    MARITIME = "maritime"             # Maritime tracking


# Token costs per analysis type
TOKEN_COSTS = {
    AnalysisType.QUICK_SCAN: 1,
    AnalysisType.STANDARD: 3,
    AnalysisType.PREMIUM: 5,
    AnalysisType.FORENSIC: 8,
    AnalysisType.DOSSIER: 10,
    AnalysisType.URBANTRACE: 5,
    AnalysisType.MARITIME: 5,
}

# Free tier limits
FREE_TIER_TOKENS = 5
FREE_TIER_MONTHLY_RESET = True


# ============================================================================
# TOKEN BALANCE
# ============================================================================

async def get_token_balance(user_id: str) -> Dict[str, Any]:
    """
    Fetch current token balance for a user.
    Returns dict with balance, tier, and usage stats.
    """
    client = get_lenuda_client()
    if not client.is_configured:
        return {"balance": 0, "error": "Supabase not configured"}

    try:
        # Try RPC for atomic read
        result = await client.rpc("get_credit_balance", {"p_user_id": user_id})
        if result is not None:
            if isinstance(result, (int, float)):
                return {"balance": int(result), "user_id": user_id}
            elif isinstance(result, dict):
                return {
                    "balance": result.get("balance", 0),
                    "user_id": user_id,
                    "tier": result.get("tier", "free"),
                    "monthly_used": result.get("monthly_used", 0),
                }

        # Fallback: query credits table directly
        rows = await client.select("credits", f"user_id=eq.{user_id}", limit=1)
        if rows:
            row = rows[0]
            return {
                "balance": row.get("balance", 0),
                "user_id": user_id,
                "tier": row.get("tier", "free"),
            }

        # No record found — new user gets free tier
        return {
            "balance": FREE_TIER_TOKENS,
            "user_id": user_id,
            "tier": "free",
            "is_new": True,
        }
    except Exception as e:
        logger.error(f"Error getting token balance: {e}")
        return {"balance": 0, "error": str(e)}


# ============================================================================
# DEDUCT TOKENS
# ============================================================================

async def deduct_tokens(
    user_id: str,
    amount: int,
    reason: str = "",
    report_id: str = "",
) -> Dict[str, Any]:
    """
    Atomically deduct tokens from a user's balance.
    Returns success/failure and new balance.
    """
    client = get_lenuda_client()
    if not client.is_configured:
        return {"success": False, "error": "Supabase not configured"}

    try:
        # Try RPC for atomic deduction
        result = await client.rpc("deduct_credits", {
            "p_user_id": user_id,
            "p_amount": amount,
            "p_reason": reason or f"Analysis: {report_id}",
        })

        if result is not None:
            if isinstance(result, dict):
                return {
                    "success": result.get("success", True),
                    "new_balance": result.get("new_balance", 0),
                    "amount_deducted": amount,
                }
            elif isinstance(result, (int, float)):
                return {
                    "success": True,
                    "new_balance": int(result),
                    "amount_deducted": amount,
                }

        # Fallback: manual deduction
        balance_info = await get_token_balance(user_id)
        current_balance = balance_info.get("balance", 0)

        if current_balance < amount:
            return {
                "success": False,
                "error": "Insufficient tokens",
                "balance": current_balance,
                "required": amount,
            }

        new_balance = current_balance - amount
        updated = await client.update(
            "credits",
            f"user_id=eq.{user_id}",
            {"balance": new_balance, "updated_at": datetime.now(timezone.utc).isoformat()},
        )

        if updated:
            # Log the transaction
            await client.insert("credit_transactions", {
                "user_id": user_id,
                "amount": -amount,
                "reason": reason or f"Analysis: {report_id}",
                "report_id": report_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
            })

            return {
                "success": True,
                "new_balance": new_balance,
                "amount_deducted": amount,
            }

        return {"success": False, "error": "Failed to update balance"}
    except Exception as e:
        logger.error(f"Error deducting tokens: {e}")
        return {"success": False, "error": str(e)}


# ============================================================================
# ADD TOKENS
# ============================================================================

async def add_tokens(
    user_id: str,
    amount: int,
    reason: str = "purchase",
    source: str = "stripe",
) -> Dict[str, Any]:
    """
    Add tokens to a user's balance (after purchase, promo, admin grant, etc.).
    Returns new balance.
    """
    client = get_lenuda_client()
    if not client.is_configured:
        return {"success": False, "error": "Supabase not configured"}

    try:
        # Try RPC for atomic addition
        result = await client.rpc("add_credits", {
            "p_user_id": user_id,
            "p_amount": amount,
            "p_reason": reason,
        })

        if result is not None:
            if isinstance(result, dict):
                return {
                    "success": True,
                    "new_balance": result.get("new_balance", amount),
                    "amount_added": amount,
                }
            elif isinstance(result, (int, float)):
                return {
                    "success": True,
                    "new_balance": int(result),
                    "amount_added": amount,
                }

        # Fallback: manual addition
        balance_info = await get_token_balance(user_id)
        current_balance = balance_info.get("balance", 0)
        new_balance = current_balance + amount

        # Upsert via update or insert
        existing = await client.select("credits", f"user_id=eq.{user_id}", limit=1)
        if existing:
            updated = await client.update(
                "credits",
                f"user_id=eq.{user_id}",
                {"balance": new_balance, "updated_at": datetime.now(timezone.utc).isoformat()},
            )
        else:
            result = await client.insert("credits", {
                "user_id": user_id,
                "balance": new_balance,
                "tier": "free",
                "created_at": datetime.now(timezone.utc).isoformat(),
            })
            updated = result is not None

        if updated:
            # Log the transaction
            await client.insert("credit_transactions", {
                "user_id": user_id,
                "amount": amount,
                "reason": reason,
                "source": source,
                "created_at": datetime.now(timezone.utc).isoformat(),
            })

            return {
                "success": True,
                "new_balance": new_balance,
                "amount_added": amount,
            }

        return {"success": False, "error": "Failed to update balance"}
    except Exception as e:
        logger.error(f"Error adding tokens: {e}")
        return {"success": False, "error": str(e)}


# ============================================================================
# TOKEN HISTORY
# ============================================================================

async def get_token_history(user_id: str, limit: int = 50) -> list:
    """Get token transaction history for a user."""
    client = get_lenuda_client()
    if not client.is_configured:
        return []

    try:
        rows = await client.select(
            "credit_transactions",
            f"user_id=eq.{user_id}&order=created_at.desc",
            limit=limit,
        )
        return rows
    except Exception as e:
        logger.error(f"Error getting token history: {e}")
        return []


# ============================================================================
# COST CALCULATOR
# ============================================================================

def calculate_token_cost(
    analysis_type: str,
    domain: str = "",
    area_ha: float = 0,
) -> int:
    """
    Calculate the token cost for an analysis based on type, domain, and area.
    Larger areas cost more tokens.
    """
    base_cost = TOKEN_COSTS.get(analysis_type, TOKEN_COSTS.get(AnalysisType.STANDARD, 3))

    # Area multiplier (larger sites cost more)
    area_multiplier = 1.0
    if area_ha > 10000:
        area_multiplier = 2.0
    elif area_ha > 5000:
        area_multiplier = 1.5
    elif area_ha > 1000:
        area_multiplier = 1.2

    total = int(base_cost * area_multiplier)
    return max(1, total)  # Minimum 1 token
