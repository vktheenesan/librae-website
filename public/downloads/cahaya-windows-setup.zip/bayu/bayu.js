// LENUDA Premium - Dynamic Licensing & Pricing Quoting Engine

let ledgerBlockIndex = 1;
let currentActiveTier = 1;
let activeSatsVal = 0;
let activeAgentsVal = 0;
let activeVolumeVal = 0.0;

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  // UI bindings safeguarded against null
  const copyBtn = document.getElementById("btn-copy-billing-output");
  if (copyBtn) copyBtn.onclick = copyBillingOutput;
  
  const tierUI = document.getElementById("tier-ref-1");
  if (tierUI) {
    updatePricingTierUI(0, 0, 0, 0, "TIER 1 (SME / TESTING)");
  }
});

// 1. Transaction Log Receiver (Runs in memory only, UI updates safeguarded)
window.bayuLogTransaction = async function(data) {
  const satBands = data.satellites || 0;
  const agents = data.agents || 0;
  const volume = data.volume || 0.0;
  
  activeSatsVal = satBands;
  activeAgentsVal = agents;
  activeVolumeVal = volume;
  
  const score = (satBands * 0.5) + (agents * 0.02) + (volume * 0.3);
  
  let tier = "TIER 1 (SME / TESTING)";
  let targetTierNum = 1;
  if (score >= 5.0 && score <= 15.0) {
    tier = "TIER 2 (MID-MARKET DEPLOYMENT)";
    targetTierNum = 2;
  } else if (score > 15.0) {
    tier = "TIER 3 (NATIONAL / SOVEREIGN LEVEL)";
    targetTierNum = 3;
  }
  
  currentActiveTier = targetTierNum;
  
  const timestamp = new Date().toISOString();
  const rawPayload = JSON.stringify({
    blockIndex: ledgerBlockIndex,
    timestamp: timestamp,
    action: data.action,
    metrics: { satellites: satBands, agents: agents, data_volume_gb: volume },
    score: score.toFixed(4),
    billingTier: tier
  });
  
  const checksum = await getSHA256Hash(rawPayload);
  
  // Update UI Counters if they exist (safeguarded)
  const elSats = document.getElementById("bayu-metric-satellites");
  const elAgents = document.getElementById("bayu-metric-agents");
  const elVol = document.getElementById("bayu-metric-volume");
  const elScore = document.getElementById("bayu-calculated-score");
  const elTier = document.getElementById("bayu-calculated-tier");
  
  if (elSats) elSats.textContent = satBands;
  if (elAgents) elAgents.textContent = agents;
  if (elVol) elVol.textContent = `${volume.toFixed(2)} GB`;
  if (elScore) elScore.textContent = score.toFixed(2);
  if (elTier) elTier.textContent = tier;
  
  // Set active header status tier badge
  const tierHeaderBadge = document.getElementById("compute-savings");
  if (tierHeaderBadge) {
    if (targetTierNum === 1) {
      tierHeaderBadge.textContent = "50.0% ($4,820/day) | SME SaaS";
      tierHeaderBadge.className = "telemetry-value text-glow green-glow";
    } else if (targetTierNum === 2) {
      tierHeaderBadge.textContent = "50.0% ($9,640/day) | Mid-Market";
      tierHeaderBadge.className = "telemetry-value text-glow";
    } else {
      tierHeaderBadge.textContent = "50.0% ($48,200/day) | Sovereign";
      tierHeaderBadge.className = "telemetry-value text-glow text-glow-red";
    }
  }
  
  // Append to Immutable UI Terminal (safeguarded)
  appendLedgerLine(data.action, satBands, agents, volume, checksum);
  
  // Update billing template output
  generateBillingOutput(data.action, score, targetTierNum, timestamp, checksum);
  
  // Highlight active Reference Tier Box
  updatePricingTierUI(satBands, agents, volume, score, tier);
};

// 2. Cryptographic SHA-256 Engine
async function getSHA256Hash(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 3. UI Terminal Append
function appendLedgerLine(action, sats, agents, volume, hash) {
  const terminal = document.getElementById("bayu-ledger-terminal");
  if (!terminal) return;
  
  const div = document.createElement("div");
  div.className = "ledger-line transaction-line";
  
  const timeStr = new Date().toLocaleTimeString();
  
  div.innerHTML = `
    <span class="ledger-block-indicator">BLOCK #${ledgerBlockIndex}</span>
    <span class="ledger-timestamp">[${timeStr}]</span>
    <span class="ledger-meta">Executed <span class="ledger-detail">${action}</span></span><br>
    <span class="ledger-meta">Metric: SATS(${sats}) AGENTS(${agents}) VOL(${volume.toFixed(2)}GB)</span>
    <span class="ledger-hash">SHA256: ${hash}</span>
  `;
  
  terminal.appendChild(div);
  terminal.scrollTop = terminal.scrollHeight;
  ledgerBlockIndex++;
}

// 4. Billing Output Generators (SaaS, Corporate, Sovereign LLM MSA)
function generateBillingOutput(action, score, tierNum, timestamp, hash) {
  const typeBadge = document.getElementById("billing-output-type");
  const content = document.getElementById("billing-output-content");
  const copyBtn = document.getElementById("btn-copy-billing-output");
  
  if (!typeBadge || !content || !copyBtn) return;
  
  copyBtn.disabled = false;
  
  if (tierNum === 1) {
    typeBadge.textContent = "SAAS VERIFICATION TOKEN";
    typeBadge.style.color = "#02c39a";
    
    const token = "tok_" + Math.random().toString(36).substr(2, 24);
    const cost = (score * 0.15).toFixed(2);
    
    content.textContent = `{
  "provider": "saas_billing",
  "client_auth_token": "${token}",
  "timestamp": "${timestamp}",
  "transaction_hash": "${hash}",
  "compute_metrics": {
    "computation_score": ${score.toFixed(4)},
    "unit_price_usd": 0.15,
    "calculated_cost_usd": ${cost}
  },
  "billing_status": "authorized_payment"
}`;
  } else if (tierNum === 2) {
    typeBadge.textContent = "CORPORATE INVOICE";
    typeBadge.style.color = "#4cc9f0";
    
    const invoiceNum = "INV-LEN-" + Math.floor(Math.random() * 90000 + 10000);
    const balance = (score * 1250.0).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    
    content.textContent = `=================================================
INVOICE: ${invoiceNum}
=================================================
DATE: ${timestamp.split('T')[0]}
TERMS: Net 30 Days
COMPUTE LOG: ${action}
TRANSACTION LOCK HASH: ${hash}

LINE ITEM:
Geospatial Simulation Engine Framework
Total Ingress Volume & Multi-Spectral Calcs
Computed Rating Metric Score: ${score.toFixed(3)}
Corporate Factor Rate: $1,250.00 / score unit

TOTAL AMOUNT USD: $${balance}
=================================================`;
  } else {
    typeBadge.textContent = "SOVEREIGN MSA GENERATOR";
    typeBadge.style.color = "#e63946";
    
    const contractNum = "MSA-SOV-" + Math.floor(Math.random() * 900000 + 100000);
    const pricingBand = (score * 25000.0).toLocaleString('en-US', {maximumFractionDigits: 0});
    
    content.textContent = `-------------------------------------------------
MASTER SERVICE DEPLOYMENT AGREEMENT: ${contractNum}
-------------------------------------------------
CONTRACT STAMP: ${timestamp}
CRYPTOGRAPHIC DB SEAL: ${hash}

BETWEEN:
1. LENUDA Sovereign Systems (Security Air-Gapped Stack)
2. National Infrastructure Directorate Operations

SEC. 4.1 MILESTONE PRICING & CLOUD CALCULATIONS
The Customer authorizes deployment of offline stack images:
* RyanCodrai/turbovec 4-bit memory optimization
* opendataloader-pdf government spec ingestion
* Local active 30 FPS rendering profile

COMPUTE TARGET PRICING BAND: $${pricingBand} USD
(Milestone 1: Intake calibration ($100K) | Milestone 2: GPU calcs)

GOVERNING LAW: Air-Gapped Treaty Protocol
EXECUTION ROUTE: MSA generator auto-sealed.`;
  }
}

// 5. Billing Reference UI updates
function updatePricingTierUI(sats, agents, volume, score, tier) {
  const t1 = document.getElementById("tier-ref-1");
  const t2 = document.getElementById("tier-ref-2");
  const t3 = document.getElementById("tier-ref-3");
  if (!t1 || !t2 || !t3) return;
  
  t1.classList.remove("active");
  t2.classList.remove("active");
  t3.classList.remove("active");
  
  if (currentActiveTier === 1) {
    t1.classList.add("active");
  } else if (currentActiveTier === 2) {
    t2.classList.add("active");
  } else {
    t3.classList.add("active");
  }
}

// 6. Copy Clipboard Output
function copyBillingOutput() {
  const content = document.getElementById("billing-output-content");
  if (!content) return;
  navigator.clipboard.writeText(content.textContent).then(() => {
    alert("Billing output payload copied to clipboard successfully!");
    if (window.logConsole) window.logConsole("Copied active transaction invoice signature token.");
  });
}

// 7. Domain Request & Justification Quoter
// 7. Domain Request & Justification Quoter (Additive Pricing Model)
window.recalculateRequestQuote = function() {
  const intentSelect = document.getElementById("request-intent-select");
  const scaleRange = document.getElementById("request-scale-range");
  const agentsRange = document.getElementById("request-agents-range");
  
  if (!intentSelect || !scaleRange || !agentsRange) return;
  
  const intent = intentSelect.value;
  const scale = parseInt(scaleRange.value);
  const agents = parseInt(agentsRange.value);
  
  document.getElementById("lbl-request-scale").textContent = `${scale} GB`;
  document.getElementById("lbl-request-agents").textContent = `${agents} NPCs`;
  
  let baseFee = 5000;
  let intentName = "Commercial SaaS SLA (STANDARD)";
  let scaleMultiplier = 15;
  let agentMultiplier = 5;
  
  if (intent === "research") {
    baseFee = 1500;
    intentName = "Research & Evaluation Sandbox (EDGE)";
    scaleMultiplier = 5;
    agentMultiplier = 1;
  } else if (intent === "sovereign") {
    baseFee = 25000;
    intentName = "National Defense & Crisis Response (SOVEREIGN)";
    scaleMultiplier = 50;
    agentMultiplier = 10;
  }
  
  // Track active domains and proposed domain
  if (!window.activeLicensedDomains) {
    window.activeLicensedDomains = ['agriculture'];
  }
  const requestingDom = window.currentRequestingDomainId || "mining";
  const proposedDomains = Array.from(new Set([...window.activeLicensedDomains, requestingDom]));
  
  let totalBaseFee = 0;
  let totalScaleCost = 0;
  let totalAgentCost = 0;
  
  proposedDomains.forEach(d => {
    totalBaseFee += baseFee;
    totalScaleCost += (scale * scaleMultiplier);
    totalAgentCost += (agents * agentMultiplier);
  });
  
  const finalFee = totalBaseFee + totalScaleCost + totalAgentCost;
  
  document.getElementById("request-quote-price").textContent = `$${finalFee.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})} USD`;
  
  const justification = document.getElementById("request-quote-justification");
  justification.innerHTML = `
    <strong>CAHAYA Value Quoting Engine:</strong> Ingesting specs for <em>${intentName}</em>.<br>
    - Proposed Active Domains (${proposedDomains.length}): ${proposedDomains.map(d => d.toUpperCase()).join(", ")}<br>
    - Base Domain Licensing Fees: $${totalBaseFee.toLocaleString()} USD ($${baseFee.toLocaleString()} per domain)<br>
    - Spatial Ingestion channels (${scale} GB volume): $${totalScaleCost.toLocaleString()} USD<br>
    - Sim Core Patrol agents (${agents} NPCs): $${totalAgentCost.toLocaleString()} USD<br>
    <span style="color: #02c39a; font-weight: 600;">Pricing calculated additively: adding more domains (e.g. Construction, Utilities) accumulates license rates.</span>
  `;
};

window.submitDomainRequest = function() {
  const intent = document.getElementById("request-intent-select").value;
  const scale = parseInt(document.getElementById("request-scale-range").value);
  const agents = parseInt(document.getElementById("request-agents-range").value);
  
  let tier = "STANDARD";
  if (intent === "research") {
    tier = "EDGE";
  } else if (intent === "sovereign") {
    tier = "SOVEREIGN";
  }
  
  const activeDom = window.currentRequestingDomainId || "mining";
  if (!window.activeLicensedDomains) {
    window.activeLicensedDomains = ['agriculture'];
  }
  window.activeLicensedDomains = Array.from(new Set([...window.activeLicensedDomains, activeDom]));
  
  const domainTokenStr = activeDom.toUpperCase();
  const token = `SECURE-TOKEN-${tier}-${domainTokenStr}-2026`;
  
  document.getElementById("generated-token-text").textContent = token;
  document.getElementById("generated-token-placeholder").textContent = token;
  document.getElementById("request-token-box").style.display = "block";
  document.getElementById("btn-submit-domain-request").style.display = "none";
  
  const score = (scale * 0.3) + (agents * 0.02);
  if (window.bayuLogTransaction) {
    window.bayuLogTransaction({
      action: `Requested Vertical Access Token [${activeDom.toUpperCase()}]`,
      satellites: 3,
      agents: agents,
      volume: scale,
      score: score.toFixed(4)
    });
  }
  
  if (window.logConsole) {
    window.logConsole(`Access request approved. License token for vertical ${activeDom.toUpperCase()} generated.`);
  }
};

window.copyRequestedToken = function() {
  const token = document.getElementById("generated-token-text").textContent;
  navigator.clipboard.writeText(token).then(() => {
    alert("License key token copied to clipboard! Paste it into the CLI console or your terminal to activate.");
    if (window.logConsole) {
      window.logConsole(`Copied licensing key token: ${token}`);
    }
  });
};

// Government License Token Generator
window.generateGovToken = async function() {
  const domain = document.getElementById("token-domain").value;
  const tier = document.getElementById("token-tier").value;
  const vram = document.getElementById("token-vram").value;
  const maxNodes = parseInt(document.getElementById("token-nodes").value || "10");
  const hardwareLockInput = document.getElementById("token-hardware-lock");
  const hardwareLock = hardwareLockInput ? hardwareLockInput.value.trim() : "";
  
  const displayBox = document.getElementById("gov-token-display-box");
  const keySpan = document.getElementById("gov-token-key");
  
  try {
    const response = await fetch('/api/token/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        tier: tier,
        vram_profile: vram,
        max_nodes: maxNodes,
        valid_days: 365,
        domain: domain,
        hardware_lock: hardwareLock || null
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      if (data.success && data.token) {
        keySpan.textContent = data.token;
        displayBox.style.display = "block";
        
        // Add to active log list
        const logContainer = document.getElementById("marketing-autopilot-log");
        if (logContainer) {
          const div = document.createElement("div");
          div.style.color = "#ffb703";
          div.textContent = `[${new Date().toLocaleTimeString()}] Issued official government license: ${tier} (${domain.toUpperCase()}) node key.`;
          logContainer.insertBefore(div, logContainer.firstChild);
        }
        if (window.fetchAdminLicenses) window.fetchAdminLicenses();
      }
    } else {
      throw new Error(`HTTP status ${response.status}`);
    }
  } catch (err) {
    console.warn("[Gov Token] Backend generate failed, generating offline signed mock token:", err.message);
    const mockToken = `SECURE-TOKEN-${tier}-${domain.toUpperCase()}-2026`;
    keySpan.textContent = mockToken;
    displayBox.style.display = "block";
  }
};

window.copyGovToken = function() {
  const token = document.getElementById("gov-token-key").textContent;
  navigator.clipboard.writeText(token).then(() => {
    alert("Government license token copied to clipboard successfully!");
  });
};

// Fetch live user behavior telemetry updates from the backend
async function updateTelemetryStats() {
  const elGis = document.getElementById("telemetry-gis-time");
  const elIngest = document.getElementById("telemetry-ingest-time");
  const elSim = document.getElementById("telemetry-sim-time");
  const elCahaya = document.getElementById("telemetry-cahaya-time");
  
  if (!elGis || !elIngest || !elSim || !elCahaya) return;
  
  try {
    const resp = await fetch("/api/telemetry/stats");
    if (resp.ok) {
      const data = await resp.json();
      if (data.success && data.time_spent) {
        const stats = data.time_spent;
        const gisTime = stats.gis || 0;
        const ingestTime = stats.ingest || 0;
        const simTime = stats.sim || 0;
        const cahayaTime = stats.cahaya || 0;
        
        elGis.setAttribute("data-sec", gisTime);
        elIngest.setAttribute("data-sec", ingestTime);
        elSim.setAttribute("data-sec", simTime);
        elCahaya.setAttribute("data-sec", cahayaTime);
        
        const total = Math.max(1, gisTime + ingestTime + simTime + cahayaTime);
        
        const formatTime = (sec) => {
          const m = Math.floor(sec / 60);
          const s = sec % 60;
          return `${m}m ${s}s`;
        };
        
        elGis.textContent = `${formatTime(gisTime)} (${Math.round(gisTime/total*100)}%)`;
        elIngest.textContent = `${formatTime(ingestTime)} (${Math.round(ingestTime/total*100)}%)`;
        elSim.textContent = `${formatTime(simTime)} (${Math.round(simTime/total*100)}%)`;
        elCahaya.textContent = `${formatTime(cahayaTime)} (${Math.round(cahayaTime/total*100)}%)`;
        return; // Success!
      }
    }
  } catch (err) {
    console.warn("Failed to fetch live telemetry, using fallback simulation:", err);
  }
  
  // Fallback local simulation if backend fails or doesn't return data
  let gisTime = parseInt(elGis.getAttribute("data-sec") || "2535");
  let ingestTime = parseInt(elIngest.getAttribute("data-sec") || "700");
  let simTime = parseInt(elSim.getAttribute("data-sec") || "170");
  let cahayaTime = parseInt(elCahaya.getAttribute("data-sec") || "0");
  
  gisTime += Math.random() > 0.3 ? 2 : 0;
  ingestTime += Math.random() > 0.6 ? 1 : 0;
  simTime += Math.random() > 0.9 ? 1 : 0;
  
  elGis.setAttribute("data-sec", gisTime);
  elIngest.setAttribute("data-sec", ingestTime);
  elSim.setAttribute("data-sec", simTime);
  elCahaya.setAttribute("data-sec", cahayaTime);
  
  const total = gisTime + ingestTime + simTime + cahayaTime;
  
  const formatTime = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s}s`;
  };
  
  elGis.textContent = `${formatTime(gisTime)} (${Math.round(gisTime/total*100)}%)`;
  elIngest.textContent = `${formatTime(ingestTime)} (${Math.round(ingestTime/total*100)}%)`;
  elSim.textContent = `${formatTime(simTime)} (${Math.round(simTime/total*100)}%)`;
  elCahaya.textContent = `${formatTime(cahayaTime)} (${Math.round(cahayaTime/total*100)}%)`;
}

setInterval(updateTelemetryStats, 3000);

// Periodically append automated marketing campaign logs in the Autopilot terminal panel
const marketingCampaignEvents = [
  { color: "#02c39a", msg: "Composed custom proposal document for Gamuda Berhad using Gemini 3.1 PDF engine." },
  { color: "var(--text-dim)", msg: "Scraped Sabah Forest Industries contact directory. Found 3 key stakeholders." },
  { color: "#00b4d8", msg: "Initiated automated LinkedIn connection request to Head of GIS at Sarawak Energy." },
  { color: "#ffd166", msg: "Dispatched automated follow-up via Resend: 'Canopy Density Optimization case-study' for GenTing Plantations." },
  { color: "#02c39a", msg: "Analyzed target Petronas Gas pipeline length. Prepared custom pricing estimate: $95,000 MRR." },
  { color: "var(--marketing-color)", msg: "Outreach alarm: Boustead Plantations lead status cold. Rescheduling sequence." }
];

setInterval(() => {
  const logContainer = document.getElementById("marketing-autopilot-log");
  if (logContainer) {
    const event = marketingCampaignEvents[Math.floor(Math.random() * marketingCampaignEvents.length)];
    const div = document.createElement("div");
    div.style.color = event.color;
    div.textContent = `[${new Date().toLocaleTimeString()}] ${event.msg}`;
    logContainer.insertBefore(div, logContainer.firstChild);
    if (logContainer.children.length > 20) {
      logContainer.removeChild(logContainer.lastChild);
    }
  }
}, 12000);

// Admin Licenses
window.fetchAdminLicenses = async function() {
  const tbody = document.getElementById("licenses-table-body");
  if (!tbody) return;
  
  try {
    const resp = await fetch("/api/admin/licenses");
    if (resp.ok) {
      const data = await resp.json();
      tbody.innerHTML = "";
      data.forEach(lic => {
        const tr = document.createElement("tr");
        let statusBadge = `<span class="badge" style="background:rgba(2,195,154,0.15); color:#02c39a;">${lic.status}</span>`;
        if (lic.status === "OFFLINE") {
          statusBadge = `<span class="badge" style="background:rgba(255, 183, 3, 0.15); color:var(--admin-color);">${lic.status}</span>`;
        } else if (lic.status === "REVOKED") {
          statusBadge = `<span class="badge" style="background:rgba(230, 57, 70, 0.15); color:#e63946;">${lic.status}</span>`;
        }
        
        tr.innerHTML = `
          <td><strong style="font-family:var(--font-mono); font-size:10px;">${lic.token_prefix}</strong><br><span style="font-size:9px; color:var(--text-dim);">${lic.id}</span></td>
          <td>${lic.domain}</td>
          <td><span class="badge badge-model">${lic.tier}</span> <span style="font-size:9px;">${lic.vram} / ${lic.nodes} Nodes</span></td>
          <td>${statusBadge}</td>
          <td>${lic.last_seen}</td>
          <td>
            <button class="btn btn-secondary btn-small" onclick="revokeLicense('${lic.id}')" ${lic.status === 'REVOKED' ? 'disabled' : ''}>Revoke</button>
            <button class="btn btn-secondary btn-small" onclick="reissueLicense('${lic.domain}', '${lic.tier}', '${lic.vram}', ${lic.nodes})">Re-Issue</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
      // Trigger lucide icon rendering if new DOM elements have icons
      if (window.lucide) {
        window.lucide.createIcons();
      }
    }
  } catch(err) {
    console.error("Failed to fetch licenses", err);
  }
};

window.revokeLicense = async function(id) {
  if (!confirm("Are you sure you want to revoke this license key? Offline nodes will be locked out.")) return;
  try {
    await fetch("/api/admin/licenses/revoke", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: id })
    });
    fetchAdminLicenses();
  } catch(err) {
    console.error(err);
  }
};

window.reissueLicense = function(domain, tier, vram, nodes) {
  document.getElementById("token-domain").value = domain.toLowerCase();
  document.getElementById("token-tier").value = tier;
  document.getElementById("token-vram").value = vram;
  document.getElementById("token-nodes").value = nodes;
  window.generateGovToken();
  setTimeout(fetchAdminLicenses, 1000);
};

// Initial load
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("licenses-table-body")) {
    fetchAdminLicenses();
  }
});

