import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';

const supabase = SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY 
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY) 
  : null;

/**
 * AGENTIC VALUE-PACKAGING & PRICING ENGINE
 * 
 * Supports dual AI backends:
 * - Directs Decider & Strategy logic to OpenAI GPT-4o/GPT-5 if OPENAI_API_KEY is present.
 * - Falls back to Gemini 2.5 Flash if OpenAI credentials are not set.
 */
export async function generateDynamicPricing(leadProfile) {
  const {
    company_name = 'Unknown',
    company_domain = '',
    headquarters_country = '',
    headquarters_city = '',
    estimated_revenue = '',
    industry = '',
    is_esri_user = false,
    geospatial_stack = [],
    compliance_needs = [],
    metadata = {}
  } = leadProfile;

  // 1. Fetch package blueprints from Supabase
  let blueprints = [];
  if (supabase) {
    try {
      const { data } = await supabase.from('package_blueprints').select('industry, package_name, modules');
      if (data) blueprints = data;
    } catch (err) {
      console.warn('⚠️ Could not fetch package blueprints from Supabase:', err.message);
    }
  }

  const blueprintsContext = blueprints.length > 0
    ? blueprints.map(b => `- Industry: "${b.industry}" => Package: "${b.package_name}", Modules: [${b.modules.join(', ')}]`).join('\n')
    : `- Industry: "plantation" => Package: "Plantation Intelligence Suite", Modules: [EUDR, MSPO, Carbon, NDVI]\n- Industry: "environmental consultancy" => Package: "Consultancy White-Label Portal", Modules: [White-Label Portal, NDVI, EUDR, Carbon, Audit Reporting]`;

  // Determine geographic tier
  const tier1Countries = ['United States', 'United Kingdom', 'Germany', 'France', 'Netherlands', 'Switzerland', 'Australia', 'Canada', 'Japan', 'Singapore', 'UAE', 'Norway', 'Sweden', 'Denmark'];
  const tier2Countries = ['Malaysia', 'Indonesia', 'Thailand', 'India', 'Brazil', 'Mexico', 'South Africa', 'Philippines', 'Vietnam', 'Colombia'];
  
  const geoTier = tier1Countries.some(c => 
    headquarters_country.toLowerCase().includes(c.toLowerCase())
  ) ? 'TIER_1_PREMIUM' : 
  tier2Countries.some(c => 
    headquarters_country.toLowerCase().includes(c.toLowerCase())
  ) ? 'TIER_2_GROWTH' : 'TIER_3_EMERGING';

  const prompt = `
You are the Enterprise Pricing & Value-Packaging Agent for Lenuda (by Librae AI Labs).
Your task is to analyze the prospect's profile, match them to a packaging blueprint, evaluate their key enterprise scoring indexes, and produce a value packaging recommendation.

PROSPECT PROFILE:
- Company: ${company_name} (${company_domain})
- HQ Location: ${headquarters_city}, ${headquarters_country}
- Geographic Pricing Tier: ${geoTier}
- Industry: ${industry}
- Estimated Revenue: ${estimated_revenue || 'Unknown'}
- Is Esri/ArcGIS User: ${is_esri_user} (Highly valuable: Esri users are trained buyers!)
- Detected Geospatial Stack: ${(geospatial_stack || []).join(', ') || 'None detected'}
- Compliance Requirements: ${(compliance_needs || []).join(', ') || 'General ESG'}
- Additional Context: ${JSON.stringify(metadata)}

AVAILABLE PACKAGE BLUEPRINTS:
${blueprintsContext}

PRICING RULE GUIDELINES:
1. TIER_1_PREMIUM: Base price at $1,000-$3,000 per report range. Propose custom enterprise agreement of $5,000-$15,000/mo.
2. TIER_2_GROWTH: Use Malaysian base prices (Growth subscription starts at $500/mo).
3. Large enterprises (revenue > $1B): Propose custom enterprise agreements of $5,000-$15,000/mo.
4. Small consultancies (< 50 employees): Offer starter package, $300-$500/mo.
5. If EUDR compliance is needed: Add urgency premium (+15%).
6. If carbon credit pathway needed: Add value premium (+20%).

EVALUATE 4 SCORING ENGINES (0-100):
1. Budget Power Score: Financial capability of target (revenue, employee size).
2. Esri Maturity Score: High if they have Esri/ArcGIS stack (e.g. ArcGIS Pro, Portal), low/zero if not.
3. Procurement Complexity Score: Higher for large corporations, government agencies, and regulated industries.
4. Expansion Potential Score: High if they have multiple global estates, subsidiaries, or whitespaces.

COMPUTE LEAD VALUE INDEX (LVI):
LVI = (Budget Power * 0.3) + (Esri Maturity * 0.3) + ((100 - Procurement Complexity) * 0.1) + (Expansion Potential * 0.3)

OUTPUT SCHEMA (Return STRICTLY raw JSON):
{
  "package_name": "Match blueprint or customize based on industry",
  "modules": ["Array of modules: e.g. EUDR, MSPO, Carbon, NDVI, White-Label Portal"],
  "recommended_tier": "standard|professional|enterprise|custom_enterprise",
  "monthly_price_usd": number,
  "annual_price_usd": number,
  "credit_rate_usd": number,
  "credits_included_monthly": number,
  "expected_monthly_range": "e.g., $10K-$20K/month",
  "one_liner_value_prop": "A single sentence explaining why this package and price is fair for THIS specific company",
  "competitor_comparison": "What they'd pay elsewhere for manual audits vs Lenuda",
  "urgency_factor": "none|moderate|high|critical",
  "budget_power_score": number,
  "esri_maturity_score": number,
  "procurement_complexity_score": number,
  "expansion_potential_score": number,
  "lead_value_index": number,
  "confidence_score": number,
  "confidence_reasons": ["Array of strings explaining Bayu's confidence in this scoring"],
  "reasoning": "Brief pricing formulation rationale"
}

Respond ONLY with raw JSON. No markdown formatting or code blocks.
`;

  // 1. Try OpenAI if key is present
  if (OPENAI_API_KEY) {
    console.log(`🧠 OpenAI: Generating value package for ${company_name}...`);
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: [{ role: 'user', content: prompt }],
          response_format: { type: "json_object" }
        })
      });

      if (response.ok) {
        const resData = await response.json();
        const pricing = JSON.parse(resData.choices[0].message.content.trim());
        console.log(`💰 Value package generated via OpenAI for ${company_name}:`, pricing);
        return pricing;
      } else {
        const errText = await response.text();
        console.warn(`⚠️ OpenAI returned status ${response.status}: ${errText}. Falling back to Gemini...`);
      }
    } catch (err) {
      console.warn(`⚠️ OpenAI connection failed: ${err.message}. Falling back to Gemini...`);
    }
  }

  // 2. Fallback to Gemini
  if (!GEMINI_API_KEY) {
    console.warn('⚠️ GEMINI_API_KEY missing. Returning default fallback pricing.');
    return getDefaultPricing(geoTier, industry, is_esri_user);
  }

  try {
    console.log(`🧠 Gemini: Generating value package for ${company_name}...`);
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(geminiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" }
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error(`❌ Gemini Pricing Agent error ${response.status}: ${errText}`);
      return getDefaultPricing(geoTier, industry, is_esri_user);
    }

    const data = await response.json();
    const candidates = data.candidates;
    if (!candidates || candidates.length === 0 || !candidates[0].content?.parts?.[0]?.text) {
      console.error('❌ Gemini returned no pricing candidates.');
      return getDefaultPricing(geoTier, industry, is_esri_user);
    }

    const pricing = JSON.parse(candidates[0].content.parts[0].text.trim());
    console.log(`💰 Value package generated via Gemini for ${company_name}:`, pricing);
    return pricing;

  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`❌ Pricing agent failed: ${message}`);
    return getDefaultPricing(geoTier, industry, is_esri_user);
  }
}

function getDefaultPricing(geoTier, industry, is_esri_user) {
  const isPlantation = (industry || '').toLowerCase().includes('plantation') || (industry || '').toLowerCase().includes('palm');
  const packageName = isPlantation ? 'Plantation Intelligence Suite' : 'SaaS Spatial ESG Suite';
  const modules = isPlantation ? ['EUDR', 'MSPO', 'Carbon', 'NDVI'] : ['NDVI', 'Carbon', 'ESG Reporting'];

  const basePrice = geoTier === 'TIER_1_PREMIUM' ? 1500 : 500;
  const expectedRange = geoTier === 'TIER_1_PREMIUM' ? '$10K-$20K/month' : '$500-$1,500/month';
  const esriScore = is_esri_user ? 95 : 10;
  const budgetScore = geoTier === 'TIER_1_PREMIUM' ? 80 : 40;
  const procScore = geoTier === 'TIER_1_PREMIUM' ? 70 : 30;
  const expScore = 50;

  const lvi = Math.round((budgetScore * 0.3) + (esriScore * 0.3) + ((100 - procScore) * 0.1) + (expScore * 0.3));

  return {
    package_name: packageName,
    modules: modules,
    recommended_tier: geoTier === 'TIER_1_PREMIUM' ? 'custom_enterprise' : 'standard',
    monthly_price_usd: basePrice,
    annual_price_usd: basePrice * 10,
    credit_rate_usd: geoTier === 'TIER_1_PREMIUM' ? 35 : 15,
    credits_included_monthly: 30,
    expected_monthly_range: expectedRange,
    one_liner_value_prop: 'Satellite-verified compliance automation and continuous monitoring.',
    competitor_comparison: 'Manual environmental audits cost $5,000-$15,000 per report.',
    urgency_factor: 'moderate',
    budget_power_score: budgetScore,
    esri_maturity_score: esriScore,
    procurement_complexity_score: procScore,
    expansion_potential_score: expScore,
    lead_value_index: lvi,
    confidence_score: 75,
    confidence_reasons: ['Based on geography tier and known industry vertical'],
    reasoning: 'Fallback pricing calculations applied.'
  };
}
