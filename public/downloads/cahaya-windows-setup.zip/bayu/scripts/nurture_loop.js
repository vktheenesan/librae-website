// nurture_loop.js
// Monthly automated outreach cron. Reads warming leads, generates domain-specific
// Earth Engine analytics tips, and sends personalized emails via Resend.

import { bayuClient as supabase } from '../lib/supabase.js';
import { callGemini } from '../lib/ai.js';
import { sendEmail } from '../lib/outreach.js';

/**
 * Generates email content using Gemini based on lead industry and geospatial stack.
 */
async function generateNurtureContent(lead) {
  const prompt = `
    Write a professional, highly-technical, and compelling email body to nurture a lead.
    Lead details:
    - Name: ${lead.contact_name || 'GIS Director'}
    - Company: ${lead.company_name}
    - Industry: ${lead.metadata?.industry || 'Geospatial Engineering'}
    - Known Tech/Stack: ${lead.geospatial_stack?.join(', ') || 'ArcGIS Pro, Google Earth Engine'}
    
    Requirements:
    1. Mention a modern Earth Engine dataset relevant to their industry (e.g., GEDI canopy height for forestry, PALSAR for mining, JRC Transition Map for carbon, Sentinel-5P for emissions).
    2. Briefly explain how our unified "LENUDA Premium" workspace accelerates report generation by compiling multi-spectral analytics with a single-click.
    3. Keep the tone elite, helpful, and non-spammy.
    4. Avoid placeholder text. Provide the complete email body text.
    5. Include a clear, zero-friction call to action to try our sandbox.
    
    Respond with only the email text, starting from "Subject:".
  `;

  try {
    const result = await callGemini(
      'You are an expert geospatial technology email copywriter for Librae AI Labs.',
      prompt
    );
    return result.trim();
  } catch (error) {
    console.error('[-] Gemini email generation failed:', error.message);
    return `Hello ${lead.contact_name || 'Partner'},\n\nHope your GIS teams are doing great. Check out our latest GEE datasets for ${lead.company_name}.`;
  }
}

/**
 * Execute the monthly nurture run.
 */
export async function runNurtureLoop() {
  console.log('[+] Starting monthly lead nurture sequence...');

  // Fetch warming leads
  const { data: leads, error } = await supabase
    .from('leads')
    .select('*, organizations(*)')
    .eq('pipeline_status', 'warming');
    
  if (error) {
    console.error('[-] Error fetching warming leads:', error);
    return;
  }
  
  if (!leads || leads.length === 0) {
    console.log('[+] No leads in "warming" status found. Standby.');
    return;
  }
  
  console.log(`[+] Found ${leads.length} warm leads. Generating customized outreach briefs...`);
  
  for (const lead of leads) {
    console.log(`[+] Processing lead for ${lead.company_name}...`);
    
    const emailBody = await generateNurtureContent(lead);
    if (!emailBody) continue;
    
    // Parse Subject
    let subject = `New GEE Analytics Pipeline for ${lead.company_name}`;
    let bodyText = emailBody;
    
    if (emailBody.startsWith('Subject:')) {
      const lines = emailBody.split('\n');
      subject = lines[0].replace('Subject:', '').trim();
      bodyText = lines.slice(1).join('\n').trim();
    }
    
    const targetEmail = lead.email || 'oneedusmartresources@gmail.com';
    
    try {
      console.log(`[+] Sending email to ${targetEmail} via Resend...`);
      await sendEmail(targetEmail, subject, bodyText);
      
      // Log outreach interaction in Supabase
      await supabase.from('interactions').insert({
        lead_id: lead.id,
        channel: 'email',
        direction: 'outbound',
        content: bodyText,
        sentiment: 'neutral',
        metadata: { subject: subject, campaign: 'monthly_nurture_v1' }
      });
      
      // Update last contacted time
      await supabase.from('leads').update({
        last_contacted_at: new Date().toISOString()
      }).eq('id', lead.id);
      
      console.log(`[+] Successfully emailed ${lead.company_name}.`);
    } catch (sendErr) {
      console.error(`[-] Failed to send email to ${targetEmail}:`, sendErr.message || sendErr);
    }
  }
  console.log('[+] Monthly nurture sequence finished.');
}

// Auto-run if executed directly
const isMainModule = import.meta.url === `file://${process.argv[1]}`;
if (isMainModule) {
  runNurtureLoop();
}
