// swift_audit.js
// Watches incoming emails via Unipile webhook, parses SWIFT bank advice PDFs using Gemini Vision,
// matches wire references against the pipeline registry, and updates status to PAID.

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { bayuClient as supabase } from '../lib/supabase.js';
import { callGemini } from '../lib/ai.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Parses SWIFT bank advice using Gemini Vision API (REST).
 * @param {Buffer} fileBuffer - PDF file buffer
 * @param {string} mimeType - mime type of the attachment
 */
export async function parseSwiftPdf(fileBuffer, mimeType = 'application/pdf') {
  try {
    const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
    if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY not set');

    const base64Data = fileBuffer.toString('base64');

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    
    const prompt = `
      Analyze this SWIFT bank advice document and extract the following transaction details in JSON format:
      {
        "wire_reference": "Unique reference or transaction ID (e.g., TRN, UETR, Sender Reference)",
        "amount": "The numeric transfer amount",
        "currency": "The 3-letter currency code (e.g. USD, EUR)",
        "remitter_name": "Name of the sender / ordering customer",
        "value_date": "Value date of the transaction (YYYY-MM-DD)"
      }
      Respond with ONLY the raw JSON block. No markdown formatting, no backticks, no comments.
    `;

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [
            {
              inlineData: {
                mimeType,
                data: base64Data
              }
            },
            { text: prompt }
          ]
        }]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Gemini Vision API returned ${response.status}: ${errText}`);
    }

    const data = await response.json();
    const candidates = data.candidates;
    if (!candidates || candidates.length === 0 || !candidates[0].content?.parts?.[0]?.text) {
      throw new Error('No valid candidates in Gemini response');
    }

    const responseText = candidates[0].content.parts[0].text.trim();
    // Clean potential markdown wrapping
    const cleanJson = responseText.replace(/^```json\s*/i, '').replace(/```$/, '');
    return JSON.parse(cleanJson);
  } catch (error) {
    console.error('[-] Error parsing SWIFT document via Gemini:', error.message);
    return null;
  }
}

/**
 * Main handler for webhook payload.
 */
export async function handleUnipileEmailWebhook(payload) {
  console.log('[+] Processing Unipile email event...');
  
  const attachments = payload.attachments || [];
  const swiftAttachment = attachments.find(att => 
    att.filename && (att.filename.toLowerCase().includes('swift') || att.filename.toLowerCase().includes('advice') || att.filename.toLowerCase().endsWith('.pdf'))
  );
  
  if (!swiftAttachment) {
    console.log('[-] No potential SWIFT/bank advice attachments found.');
    return;
  }
  
  console.log(`[+] Found bank advice attachment: ${swiftAttachment.filename}. Downloading...`);
  
  // Download the attachment using native fetch
  let fileBuffer;
  try {
    const response = await fetch(swiftAttachment.url || 'http://localhost/mock-pdf');
    const arrayBuffer = await response.arrayBuffer();
    fileBuffer = Buffer.from(arrayBuffer);
  } catch (err) {
    console.warn(`[-] Could not download file from Unipile URL. Using mock buffer for local validation.`);
    fileBuffer = Buffer.from('%PDF-1.4 mock pdf structure');
  }
  
  // Parse PDF using Gemini Vision
  const txData = await parseSwiftPdf(fileBuffer, swiftAttachment.contentType || 'application/pdf');
  
  if (!txData || !txData.wire_reference) {
    console.log('[-] SWIFT parsing failed or no reference found.');
    return;
  }
  
  console.log('[+] SWIFT Advice Extracted:', txData);
  
  // Query pipeline registry for matching wire reference
  const { data: pipelineEntry, error } = await supabase
    .from('pipeline_registry')
    .select('*')
    .eq('wire_reference', txData.wire_reference)
    .single();
    
  if (error || !pipelineEntry) {
    console.log(`[-] No matching transaction found for wire reference: ${txData.wire_reference}`);
    return;
  }
  
  if (pipelineEntry.pipeline_status === 'PAID' || pipelineEntry.pipeline_status === 'ACTIVE_TOKEN') {
    console.log(`[!] Transaction ${txData.wire_reference} already marked as PAID/ACTIVE.`);
    return;
  }
  
  console.log(`[+] Match found! Updating pipeline status to PAID...`);
  
  // Update pipeline registry
  const { error: updateError } = await supabase
    .from('pipeline_registry')
    .update({ 
      pipeline_status: 'PAID', 
      updated_at: new Date().toISOString() 
    })
    .eq('id', pipelineEntry.id);
    
  if (updateError) {
    console.error('[-] Failed to update pipeline status:', updateError);
    return;
  }
  
  console.log('[+] Pipeline status updated successfully.');
  
  // Trigger local token generation by calling the backend API
  try {
    console.log('[+] Requesting token generation from LENUDA backend...');
    const backendUrl = process.env.API_BASE_URL || 'http://localhost:8000';
    const tokenResponse = await fetch(`${backendUrl}/api/token/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.SESSION_SECRET}`
      },
      body: JSON.stringify({
        tier: 'SOVEREIGN',
        vram_profile: '24GB',
        max_nodes: 5,
        valid_days: 365,
        domain: 'agriculture'
      })
    });
    
    if (tokenResponse.ok) {
      const tokenData = await tokenResponse.json();
      if (tokenData && tokenData.token) {
        console.log(`[+] SUCCESS: Generated token: ${tokenData.token.substring(0, 30)}...`);
        // In production, dispatch this token to the client's email via Resend
      }
    } else {
      console.error(`[-] Token generation returned ${tokenResponse.status}`);
    }
  } catch (apiErr) {
    console.error('[-] Failed to trigger token generation on backend:', apiErr.message);
  }
}

// Auto-run if executed directly
const isMainModule = import.meta.url === `file://${process.argv[1]}`;
if (isMainModule) {
  // Example: simulate a webhook payload for local testing
  console.log('[swift_audit] Running in standalone mode — provide webhook payload via API integration.');
}
