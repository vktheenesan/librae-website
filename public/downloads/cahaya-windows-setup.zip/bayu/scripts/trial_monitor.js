// trial_monitor.js — Layer 6: Daily trial monitoring, adoption scoring, email sequences
// Usage: node bayu/scripts/trial_monitor.js

import { dualAI, callGemini } from '../lib/ai.js';
import { bayuClient } from '../lib/supabase.js';
import { sendEmail } from '../lib/outreach.js';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../../.env') });

// ─── Adoption Score Weights ──────────────────────────────────────────────────
const ADOPTION_WEIGHTS = {
  login_frequency: 0.30,
  feature_breadth: 0.25,
  upload_volume: 0.20,
  projects_created: 0.15,
  api_calls: 0.10
};

// ─── Email sequence day triggers ─────────────────────────────────────────────
const EMAIL_SEQUENCES = [3, 7, 14, 20, 25, 28];

/**
 * Compute an adoption score (0-100) from usage metrics.
 * @param {object} usage - Raw usage data for this trial
 * @returns {{ score: number, breakdown: object, risk: string }}
 */
function computeAdoptionScore(usage) {
  // Normalize each metric to 0-100 scale
  const loginScore = Math.min(100, (usage.login_count || 0) * 10);           // 10 logins = 100
  const featureScore = Math.min(100, (usage.features_used || 0) * 14.3);     // 7 features = 100
  const uploadScore = Math.min(100, (usage.upload_count || 0) * 5);          // 20 uploads = 100
  const projectScore = Math.min(100, (usage.projects_created || 0) * 20);    // 5 projects = 100
  const apiScore = Math.min(100, (usage.api_calls || 0) * 0.1);             // 1000 calls = 100

  const score = Math.round(
    loginScore * ADOPTION_WEIGHTS.login_frequency +
    featureScore * ADOPTION_WEIGHTS.feature_breadth +
    uploadScore * ADOPTION_WEIGHTS.upload_volume +
    projectScore * ADOPTION_WEIGHTS.projects_created +
    apiScore * ADOPTION_WEIGHTS.api_calls
  );

  const risk = score > 60 ? 'healthy' : score > 30 ? 'at_risk' : 'dormant';

  return {
    score,
    breakdown: {
      login_frequency: Math.round(loginScore),
      feature_breadth: Math.round(featureScore),
      upload_volume: Math.round(uploadScore),
      projects_created: Math.round(projectScore),
      api_calls: Math.round(apiScore)
    },
    risk
  };
}

/**
 * Generate mock usage data for trials without telemetry.
 * Used during early rollout before real telemetry is connected.
 */
function generateMockUsage(dayNumber) {
  // Simulate realistic usage decay over time
  const baseActivity = Math.max(0, 1 - (dayNumber / 40));
  const randomFactor = 0.5 + Math.random();

  return {
    login_count: Math.round(dayNumber * baseActivity * randomFactor * 1.5),
    features_used: Math.min(7, Math.round(dayNumber * 0.3 * randomFactor)),
    upload_count: Math.round(dayNumber * baseActivity * randomFactor * 0.8),
    projects_created: Math.min(5, Math.round(dayNumber * 0.15 * randomFactor)),
    api_calls: Math.round(dayNumber * baseActivity * randomFactor * 50),
    last_login: dayNumber <= 2 ? null : new Date(Date.now() - Math.round(Math.random() * dayNumber * 12 * 60 * 60 * 1000)).toISOString(),
    data_uploaded_mb: Math.round(dayNumber * baseActivity * randomFactor * 25)
  };
}

/**
 * Generate and send the appropriate email for the trial day.
 */
async function sendSequenceEmail(trial, lead, dayNumber, adoptionScore, usage) {
  const orgName = lead?.company_name || 'Customer';
  const contactEmail = lead?.metadata?.contact_email || lead?.metadata?.email || `info@${lead?.company_domain || 'customer.com'}`;
  const product = trial.product || 'cahaya';
  const modulesStr = (trial.modules_enabled || []).join(', ');
  const expiryDate = new Date(trial.expiry_date).toISOString().split('T')[0];

  let subject = '';
  let promptContext = '';

  switch (dayNumber) {
    case 3:
      subject = `💡 Quick tips to get the most from Lenuda — Day 3`;
      promptContext = `Generate a Day 3 "Quick Tips" email for ${orgName} who is trialing Lenuda ${product}. Modules: ${modulesStr}. Share 3-5 actionable tips to help them get started fast. Tone: helpful, energetic.`;
      break;

    case 7:
      subject = `👋 How's your first week with Lenuda, ${orgName}?`;
      promptContext = `Generate a Day 7 check-in email for ${orgName}. Their adoption score is ${adoptionScore.score}/100 (${adoptionScore.risk}). They've used ${usage.features_used || 0} features and created ${usage.projects_created || 0} projects. ${adoptionScore.risk === 'dormant' ? 'They seem inactive — gently encourage them to try key features.' : 'They are engaging well — acknowledge their progress and suggest advanced features.'}`;
      break;

    case 14:
      subject = `📊 Your Lenuda Trial — Week 2 Report`;
      promptContext = `Generate a Week 2 report email for ${orgName}. Adoption score: ${adoptionScore.score}/100. Breakdown: ${JSON.stringify(adoptionScore.breakdown)}. Modules available: ${modulesStr}. Features used: ${usage.features_used || 0}. Highlight what they've accomplished, suggest features they haven't tried yet, and encourage deeper engagement.`;
      break;

    case 20:
      subject = `🎯 Let's talk about your Lenuda production setup — 10 days left`;
      promptContext = `Generate a Day 20 conversion prompt email for ${orgName}. Their trial has 10 days left (expires ${expiryDate}). Adoption score: ${adoptionScore.score}/100. This email should: 1) Summarize their trial usage positively, 2) Introduce production pricing naturally, 3) Offer to generate a custom proposal, 4) Include a CTA to schedule a call. Mention that a dedicated proposal will be prepared based on their specific usage patterns.`;
      break;

    case 25:
      subject = `⏰ Only 5 days left on your Lenuda trial, ${orgName}`;
      promptContext = `Generate a Day 25 urgency email for ${orgName}. Only 5 days remaining (expires ${expiryDate}). Adoption score: ${adoptionScore.score}/100. Create urgency without being pushy. Mention: 1) What they'll lose access to, 2) Seamless transition to production, 3) Data continuity guarantee, 4) Special trial-to-production pricing. Include link placeholder for renewal.`;
      break;

    case 28:
      subject = `🚨 Your Lenuda trial expires in 2 days — ${orgName}`;
      promptContext = `Generate a Day 28 final reminder email for ${orgName}. Trial expires in 2 DAYS on ${expiryDate}. This is the last chance email. Be direct but respectful. Include: 1) Final call to action, 2) Invoice link placeholder, 3) Offer a brief extension if they need more time to evaluate, 4) Direct contact for questions. Sign off as Theenesan VK, Founder.`;
      break;

    default:
      return; // No email for this day
  }

  try {
    const emailContent = await callGemini(
      'You are the customer success manager for Lenuda (Librae AI Labs). Write professional, personalized emails. Sign as "Theenesan VK, Founder — Librae AI Labs". Output clean HTML for email body. No markdown.',
      promptContext
    );

    const htmlBody = `
<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">
  ${emailContent}
  <div style="border-top: 1px solid #e2e8f0; padding-top: 16px; margin-top: 24px;">
    <p style="color: #64748b; font-size: 12px;">Lenuda Trial · Expires ${expiryDate} · <a href="mailto:theenesanvk@librae.work">Contact Support</a></p>
  </div>
</div>`;

    await sendEmail(contactEmail, subject, htmlBody);
    console.log(`      📧 Day ${dayNumber} email sent to ${contactEmail}: "${subject}"`);
  } catch (err) {
    console.error(`      ❌ Failed to send Day ${dayNumber} email: ${err.message}`);
  }
}

/**
 * Send re-engagement email for dormant trials (no login 7+ days).
 */
async function sendReengagementEmail(trial, lead, daysSinceLogin) {
  const orgName = lead?.company_name || 'there';
  const contactEmail = lead?.metadata?.contact_email || lead?.metadata?.email || `info@${lead?.company_domain || 'customer.com'}`;

  try {
    const reengageContent = await callGemini(
      'You are the customer success lead for Lenuda. Write a warm re-engagement email.',
      `Write a re-engagement email for ${orgName} who hasn't logged into their Lenuda trial in ${daysSinceLogin} days. Be empathetic — they might be busy. Offer: 1) A quick 15-min guided walkthrough, 2) Pre-built templates for their industry, 3) Direct access to the founder for questions. Keep it short and personal. Output clean HTML.`
    );

    await sendEmail(
      contactEmail,
      `🔄 We miss you, ${orgName} — let's get your Lenuda trial back on track`,
      `<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">${reengageContent}</div>`
    );
    console.log(`      📧 Re-engagement email sent to ${contactEmail} (${daysSinceLogin} days inactive)`);
  } catch (err) {
    console.error(`      ❌ Re-engagement email failed: ${err.message}`);
  }
}

/**
 * Monitor ALL active trials — main daily job.
 */
export async function monitorAllTrials() {
  console.log('\n📊 BAYU TRIAL MONITOR — Daily Scan');
  console.log('═══════════════════════════════════════════════════════\n');

  try {
    // ── 1. Fetch all active trials ──────────────────────────────────────────
    const { data: trials, error: trialErr } = await bayuClient
      .from('trials')
      .select('*')
      .eq('status', 'active');

    if (trialErr) {
      console.error(`❌ Failed to fetch trials: ${trialErr.message}`);
      return;
    }

    if (!trials || trials.length === 0) {
      console.log('💤 No active trials found.');
      return;
    }

    console.log(`📋 Found ${trials.length} active trial(s)\n`);

    let healthyCount = 0;
    let atRiskCount = 0;
    let dormantCount = 0;
    let hotLeads = [];

    for (const trial of trials) {
      const startDate = new Date(trial.start_date);
      const now = new Date();
      const dayNumber = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
      const daysRemaining = Math.floor((new Date(trial.expiry_date) - now) / (1000 * 60 * 60 * 24));

      console.log(`──────────────────────────────────────────────`);
      console.log(`   🔑 Trial ${trial.id} | Product: ${trial.product}`);
      console.log(`   📅 Day ${dayNumber}/30 | ${daysRemaining} days remaining`);

      // ── 2a. Fetch lead for this trial ────────────────────────────────────
      let lead = null;
      if (trial.lead_id) {
        const { data: leadData } = await bayuClient
          .from('leads')
          .select('*')
          .eq('id', trial.lead_id)
          .single();
        lead = leadData;
      }

      const orgName = lead?.company_name || 'Unknown Org';
      console.log(`   🏢 ${orgName}`);

      // ── 2b. Fetch usage data (or generate mock) ─────────────────────────
      let usage;
      const { data: existingUsage } = await bayuClient
        .from('trial_usage')
        .select('*')
        .eq('trial_id', trial.id)
        .order('recorded_date', { ascending: false })
        .limit(1);

      if (existingUsage && existingUsage.length > 0) {
        usage = existingUsage[0];
      } else {
        usage = generateMockUsage(dayNumber);
        console.log(`   ⚠️ No telemetry — using simulated usage data`);
      }

      // ── 2c. Compute adoption score ──────────────────────────────────────
      const adoptionScore = computeAdoptionScore(usage);
      console.log(`   📈 Adoption Score: ${adoptionScore.score}/100 (${adoptionScore.risk.toUpperCase()})`);
      console.log(`      Login: ${adoptionScore.breakdown.login_frequency} | Features: ${adoptionScore.breakdown.feature_breadth} | Uploads: ${adoptionScore.breakdown.upload_volume} | Projects: ${adoptionScore.breakdown.projects_created} | API: ${adoptionScore.breakdown.api_calls}`);

      // Track risk distribution
      if (adoptionScore.risk === 'healthy') healthyCount++;
      else if (adoptionScore.risk === 'at_risk') atRiskCount++;
      else dormantCount++;

      // ── 2d. Upsert trial_usage row for today ───────────────────────────
      const today = now.toISOString().split('T')[0];
      const { error: upsertErr } = await bayuClient
        .from('trial_usage')
        .upsert({
          trial_id: trial.id,
          recorded_date: today,
          adoption_score: adoptionScore.score,
          risk_level: adoptionScore.risk,
          login_count: usage.login_count || 0,
          features_used: usage.features_used || 0,
          upload_count: usage.upload_count || 0,
          projects_created: usage.projects_created || 0,
          api_calls: usage.api_calls || 0,
          data_uploaded_mb: usage.data_uploaded_mb || 0,
          score_breakdown: adoptionScore.breakdown
        }, { onConflict: 'trial_id,recorded_date' });

      if (upsertErr) {
        console.warn(`      ⚠️ Failed to upsert usage: ${upsertErr.message}`);
      }

      // ── 2e. Check day number and send appropriate email ─────────────────
      if (EMAIL_SEQUENCES.includes(dayNumber)) {
        console.log(`      📬 Day ${dayNumber} email sequence triggered`);
        await sendSequenceEmail(trial, lead, dayNumber, adoptionScore, usage);
      }

      // ── 2f. Dormant re-engagement (no login 7+ days) ───────────────────
      if (usage.last_login) {
        const daysSinceLogin = Math.floor((now - new Date(usage.last_login)) / (1000 * 60 * 60 * 24));
        if (daysSinceLogin >= 7 && adoptionScore.risk === 'dormant') {
          console.log(`      😴 Dormant: ${daysSinceLogin} days since last login — sending re-engagement`);
          await sendReengagementEmail(trial, lead, daysSinceLogin);
        }
      }

      // ── 2g. Hot lead detection (daily heavy use) ────────────────────────
      if (adoptionScore.score >= 80 && (usage.login_count || 0) >= dayNumber * 0.8) {
        console.log(`      🔥 HOT LEAD — flagging for sales call`);
        hotLeads.push({ trial, lead, adoptionScore });

        // Update lead metadata with hot flag
        if (lead) {
          await bayuClient
            .from('leads')
            .update({
              metadata: {
                ...lead.metadata,
                hot_lead: true,
                hot_flagged_at: now.toISOString(),
                adoption_score: adoptionScore.score
              }
            })
            .eq('id', lead.id);
        }
      }

      // Check if trial has expired
      if (daysRemaining <= 0) {
        console.log(`      ⏰ Trial EXPIRED — marking as expired`);
        await bayuClient
          .from('trials')
          .update({ status: 'expired' })
          .eq('id', trial.id);
      }
    }

    // ── Summary ─────────────────────────────────────────────────────────────
    console.log(`\n═══════════════════════════════════════════════════════`);
    console.log(`📊 Trial Monitor Summary`);
    console.log(`   Total Active:  ${trials.length}`);
    console.log(`   ✅ Healthy:    ${healthyCount}`);
    console.log(`   ⚠️ At Risk:    ${atRiskCount}`);
    console.log(`   😴 Dormant:    ${dormantCount}`);
    console.log(`   🔥 Hot Leads:  ${hotLeads.length}`);
    if (hotLeads.length > 0) {
      console.log(`   Hot leads requiring sales call:`);
      hotLeads.forEach(h => console.log(`     → ${h.lead?.company_name} (Score: ${h.adoptionScore.score})`));
    }
    console.log(`═══════════════════════════════════════════════════════\n`);

  } catch (err) {
    console.error(`❌ monitorAllTrials failed: ${err.message}`);
  }
}

/**
 * Generate a weekly executive summary for a specific trial.
 */
export async function generateTrialReport(trialId) {
  console.log(`\n📝 Generating trial report for ${trialId}...`);

  try {
    const { data: trial, error: trialErr } = await bayuClient
      .from('trials')
      .select('*')
      .eq('id', trialId)
      .single();

    if (trialErr || !trial) {
      console.error(`❌ Trial not found: ${trialErr?.message || 'No data'}`);
      return null;
    }

    // Fetch all usage records for this trial
    const { data: usageHistory } = await bayuClient
      .from('trial_usage')
      .select('*')
      .eq('trial_id', trialId)
      .order('recorded_date', { ascending: true });

    // Fetch lead info
    let lead = null;
    if (trial.lead_id) {
      const { data: leadData } = await bayuClient
        .from('leads')
        .select('*')
        .eq('id', trial.lead_id)
        .single();
      lead = leadData;
    }

    const startDate = new Date(trial.start_date);
    const now = new Date();
    const dayNumber = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));

    // Compute trend
    const scores = (usageHistory || []).map(u => u.adoption_score || 0);
    const trend = scores.length >= 2
      ? (scores[scores.length - 1] - scores[0] > 0 ? 'improving' : scores[scores.length - 1] - scores[0] < 0 ? 'declining' : 'stable')
      : 'insufficient_data';

    const latestScore = scores.length > 0 ? scores[scores.length - 1] : 0;
    const latestRisk = latestScore > 60 ? 'healthy' : latestScore > 30 ? 'at_risk' : 'dormant';

    const reportPrompt = `Generate a concise weekly executive trial report in JSON format with keys: executive_summary, key_metrics, risk_assessment, recommendation.

TRIAL DATA:
- Organization: ${lead?.company_name || 'Unknown'}
- Product: ${trial.product}
- Day: ${dayNumber}/30
- Latest Adoption Score: ${latestScore}/100
- Score Trend: ${trend}
- Risk Level: ${latestRisk}
- Modules Enabled: ${(trial.modules_enabled || []).join(', ')}
- Usage History (last 7 days): ${JSON.stringify((usageHistory || []).slice(-7))}

REQUIREMENTS:
1. executive_summary: 2-3 sentence overview of trial health
2. key_metrics: Object with score, trend, engagement_level, days_remaining
3. risk_assessment: Paragraph on churn risk and mitigation
4. recommendation: Specific next action (e.g., "Schedule demo call", "Send pricing proposal", "Trigger re-engagement")

Output ONLY valid JSON.`;

    const report = await callGemini(
      'You are a customer success analyst for Lenuda. Generate data-driven trial reports.',
      reportPrompt,
      { json: true }
    );

    const parsedReport = typeof report === 'string' ? JSON.parse(report) : report;
    console.log(`✅ Trial report generated for ${lead?.company_name || trialId}`);
    console.log(`   Score: ${latestScore} | Trend: ${trend} | Risk: ${latestRisk}`);

    return {
      trial_id: trialId,
      organization: lead?.company_name,
      generated_at: now.toISOString(),
      day_number: dayNumber,
      ...parsedReport
    };

  } catch (err) {
    console.error(`❌ generateTrialReport failed: ${err.message}`);
    return null;
  }
}

// ─── Self-run ─────────────────────────────────────────────────────────────────
const isMainModule = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMainModule) {
  console.log('🚀 BAYU TRIAL MONITOR — Layer 6');
  console.log('═══════════════════════════════════════════════════════\n');
  monitorAllTrials()
    .then(() => console.log('✅ Trial monitoring cycle complete.'))
    .catch(err => console.error('🚨 Fatal error:', err));
}
