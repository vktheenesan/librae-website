import { bayuClient as supabase } from '../lib/supabase.js';
import { getGeminiEmbedding } from '../lib/ai.js';
import { sendViaUnipile, shouldRouteToApproval, stageForReview } from '../lib/outreach.js';
import { generateDynamicPricing } from './pricing_agent.js';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const UNIPILE_API_KEY = process.env.UNIPILE_API_KEY || '';
const UNIPILE_API_URL = process.env.UNIPILE_API_URL || 'https://api35.unipile.com:16586/api/v1';

const hasConfig = (process.env.SUPABASE_URL || process.env.BAYU_SUPABASE_URL) && (GEMINI_API_KEY || OPENAI_API_KEY);

// Connected Unipile account IDs
const UNIPILE_ACCOUNTS = {
  linkedin: 'L0TraRXlTd6ba_B1lK6hAA',    // Theenesan Kunjaayappan
  email: 'NPCV_dQbRkmioJ82qunPKA',         // theenesanvk@librae.work
  whatsapp: 'k07n_-tTTsSaEkVF9feFiA'       // +60182639800
};

// Rich country priority list — these get processed first
const TIER_1_COUNTRIES = [
  'united states', 'united kingdom', 'germany', 'france', 'netherlands',
  'switzerland', 'australia', 'canada', 'japan', 'singapore', 'uae',
  'united arab emirates', 'norway', 'sweden', 'denmark', 'finland',
  'belgium', 'austria', 'new zealand', 'ireland', 'israel', 'south korea'
];

/**
 * Determines the optimal outreach channel for a lead based on:
 * - Geography (LinkedIn for US/EU, WhatsApp for SEA/Middle East warm follow-ups)
 * - Lead stage (WhatsApp only for warm leads)
 * - Available contact data
 */
function selectChannel(lead) {
  const country = (lead.metadata?.headquarters_country || '').toLowerCase();
  const stage = lead.pipeline_status;
  
  // WhatsApp for warm follow-ups only (never for cold outreach)
  const isWarm = ['warming_initiated', 'warming_relations', 'trial_activated'].includes(stage);
  const isSEA = ['malaysia', 'indonesia', 'thailand', 'philippines', 'vietnam', 'india'].some(c => country.includes(c));
  const isMiddleEast = ['uae', 'saudi', 'qatar', 'bahrain', 'oman', 'kuwait'].some(c => country.includes(c));
  
  if (isWarm && (isSEA || isMiddleEast)) {
    return 'whatsapp';
  }
  
  // LinkedIn for initial outreach to executives in all markets
  if (['discovered', 'trial_ready'].includes(stage)) {
    return 'linkedin';
  }
  
  // Email for follow-ups and when LinkedIn isn't ideal
  return 'email';
}

/**
 * Gets the Unipile account ID for a given channel
 */
function getUnipileAccountId(channel) {
  return UNIPILE_ACCOUNTS[channel] || UNIPILE_ACCOUNTS.email;
}

/**
 * Main outbound execution loop with:
 * - Multi-channel dispatch (LinkedIn, Email, WhatsApp)
 * - Value-Based Packaging and Advanced Scoring Analysis
 * - Discovery-First Cold Messaging (No pricing in cold outreach)
 * - Prefer OpenAI GPT-4o for Decider/Drafting tasks (Gemini fallback)
 * - Founder-led personal voice
 */
async function executeFounderOutreach() {
  console.log('🚀 BAYU FOUNDER-LED OUTBOUND VALUE-PACKAGING ENGINE v3.1');
  console.log('═══════════════════════════════════════════════════════\n');

  if (!hasConfig) {
    console.log('❌ Missing configuration. Set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, GEMINI_API_KEY or OPENAI_API_KEY in .env');
    return;
  }

  try {
    // 1. Fetch leads requiring outreach — prioritize by geography
    const { data: allLeads, error: lErr } = await supabase
      .from('leads')
      .select('id, org_id, company_name, company_domain, is_esri_user, geospatial_stack, pipeline_status, trial_token, metadata, raw_markdown_profile, email')
      .in('pipeline_status', ['discovered', 'trial_ready', 'warming_relations'])
      .limit(10);

    if (lErr || !allLeads || allLeads.length === 0) {
      console.log('💤 No outstanding leads found. Standing down.');
      return;
    }

    // Sort: rich-country leads first
    const sortedLeads = allLeads.sort((a, b) => {
      const aCountry = (a.metadata?.headquarters_country || '').toLowerCase();
      const bCountry = (b.metadata?.headquarters_country || '').toLowerCase();
      const aIsTier1 = TIER_1_COUNTRIES.some(c => aCountry.includes(c));
      const bIsTier1 = TIER_1_COUNTRIES.some(c => bCountry.includes(c));
      if (aIsTier1 && !bIsTier1) return -1;
      if (!aIsTier1 && bIsTier1) return 1;
      return 0;
    });

    console.log(`📋 Processing ${sortedLeads.length} leads (rich-country-first ordering):\n`);

    for (const lead of sortedLeads) {
      const country = lead.metadata?.headquarters_country || 'Unknown';
      const channel = selectChannel(lead);
      const isColdOutreach = ['discovered', 'trial_ready'].includes(lead.pipeline_status);
      
      console.log(`──────────────────────────────────────────────`);
      console.log(`🏢 ${lead.company_name} (${lead.company_domain})`);
      console.log(`   📍 ${country} | 📡 Channel: ${channel.toUpperCase()} | 📊 Status: ${lead.pipeline_status}`);

      // 2. Generate dynamic pricing & value-packaging recommendation
      console.log(`   💰 Analyzing value-based packaging & LVI...`);
      const pricing = await generateDynamicPricing({
        company_name: lead.company_name,
        company_domain: lead.company_domain,
        headquarters_country: country,
        headquarters_city: lead.metadata?.headquarters_city || '',
        estimated_revenue: lead.metadata?.estimated_revenue || '',
        industry: lead.metadata?.industry || '',
        is_esri_user: lead.is_esri_user,
        geospatial_stack: lead.geospatial_stack,
        compliance_needs: lead.metadata?.compliance_needs || [],
        metadata: lead.metadata || {}
      });

      console.log(`   🛡️ Package: "${pricing.package_name}" | Modules: [${(pricing.modules || []).join(', ')}]`);
      console.log(`   📈 LVI (Lead Value Index): ${pricing.lead_value_index}/100 | Confidence: ${pricing.confidence_score}%`);

      // 3. Vector similarity lookback for winning templates
      let successTemplate = "No prior winning template. Use founder voice.";
      try {
        const stack = lead.geospatial_stack || [];
        const searchContext = `Target: ${lead.company_name}, stack: ${stack.join(', ')}, Esri: ${lead.is_esri_user}`;
        const embeddingVector = await getGeminiEmbedding(searchContext);

        const { data: geneticMatch } = await supabase.rpc('match_victory_vectors', {
          query_embedding: embeddingVector,
          match_threshold: 0.70,
          match_count: 1,
          filter_org_id: lead.org_id
        });

        if (geneticMatch && geneticMatch.length > 0) {
          successTemplate = geneticMatch[0].winning_message;
          console.log(`   ✨ Gene transfer: Retained winning pattern from Vault.`);
        }
      } catch (err) {
        console.log(`   ⚠️ Victory Vault lookback skipped: ${err.message}`);
      }

      // 4. Pull live knowledge assets for context injection
      const { data: assets } = await supabase
        .from('knowledge_assets')
        .select('asset_name, content')
        .eq('org_id', lead.org_id);

      const knowledgeContext = assets && assets.length > 0
        ? assets.map(a => `${a.asset_name}: ${a.content}`).join('\n')
        : "Lenuda is a geospatial compliance intelligence platform by Librae AI Labs.";

      // 5. Generate personalized founder-voice message
      let messageBody = "";
      
      const promptInstruction = `
You are Theenesan VK, Founder & Lead System Architect of Librae AI Labs.
You are personally writing a ${channel === 'whatsapp' ? 'brief WhatsApp message' : channel === 'linkedin' ? 'LinkedIn connection message' : 'professional email'} to the executive team at ${lead.company_name}.

THIS IS NOT AUTOMATED MARKETING. You are personally reaching out as founder-to-founder / founder-to-executive.

CHANNEL: ${channel.toUpperCase()}
${channel === 'linkedin' ? 'Keep it to 280 characters max — LinkedIn connection message limit.' : ''}
${channel === 'whatsapp' ? 'Keep it brief, conversational, and warm — max 3 short paragraphs.' : ''}
${channel === 'email' ? 'Professional but personal. Subject line + body. Direct engineering posture.' : ''}

PROSPECT PROFILE:
- Company: ${lead.company_name} (${lead.company_domain})
- Location: ${country}
- Industry: ${lead.metadata?.industry || 'Unknown'}
- Is ArcGIS/Esri User: ${lead.is_esri_user}
- Detected Stack: ${(lead.geospatial_stack || []).join(', ')}

TARGET VALUE PACKAGING:
- Recommended Package Name: ${pricing.package_name}
- Scope Modules: ${(pricing.modules || []).join(', ')}
- Expected Range: ${pricing.expected_monthly_range}
- Value Proposition: ${pricing.one_liner_value_prop}

LENUDA PRODUCT INTELLIGENCE:
${knowledgeContext.substring(0, 4000)}

HISTORICAL WINNING TEMPLATE FOR REFERENCE:
"${successTemplate}"

CRITICAL OUTBOUND RULES:
1. Write as Theenesan VK, founder. First person. Personal tone.
2. DO NOT mention UE5, Unreal Engine, 60fps, or rendering — these are WRONG. Lenuda is an ESG compliance intelligence platform.
3. If they are in plantation/forestry: focus on MSPO/EUDR compliance automation.
4. If they are a consultancy: focus on white-label portals serving 100+ clients.
5. If they are investors/PE: focus on due diligence speed (30 min vs 3 weeks).
6. Sign off as "Theenesan VK, Librae AI Labs"

CRITICAL COMMERCIAL POSTURE RULES:
- Lead status: ${lead.pipeline_status}
- IS COLD OUTREACH: ${isColdOutreach}
- IF IS COLD OUTREACH: DO NOT MENTION ANY PRICING, DOLLAR FIGURES, OR NUMBERS AT ALL in this message. Instead, pitch discovery and target their workflow pain points. Say that you appreciate their work and ask how they currently manage their "${(pricing.modules || []).join(' / ')}" workflows. Focus on learning about their process first.
- IF WARM OUTREACH (not cold): You may reference pricing naturally as a monthly range (e.g. "between ${pricing.expected_monthly_range}"), presenting it as a highly cost-effective alternative compared to standard manual audits.

Respond ONLY with the clean message. No markdown. No backticks.
${channel === 'email' ? 'Format as: SUBJECT: [subject line]\\n\\n[body]' : ''}
`;

      // 5a. Call OpenAI if key is present
      if (OPENAI_API_KEY) {
        console.log(`   🧠 OpenAI: Drafting connection message via GPT-4o...`);
        try {
          const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${OPENAI_API_KEY}`
            },
            body: JSON.stringify({
              model: 'gpt-4o',
              messages: [{ role: 'user', content: promptInstruction }]
            })
          });

          if (response.ok) {
            const resData = await response.json();
            messageBody = resData.choices[0].message.content.trim();
          } else {
            const errText = await response.text();
            console.warn(`   ⚠️ OpenAI returned status ${response.status}: ${errText}. Falling back to Gemini...`);
          }
        } catch (err) {
          console.warn(`   ⚠️ OpenAI drafting failed: ${err.message}. Falling back to Gemini...`);
        }
      }

      // 5b. Fallback to Gemini if OpenAI skipped or failed
      if (!messageBody && GEMINI_API_KEY) {
        console.log(`   🧠 Gemini: Drafting connection message via Gemini...`);
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
        const response = await fetch(geminiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: promptInstruction }] }]
          })
        });

        if (response.ok) {
          const geminiOutput = await response.json();
          const candidates = geminiOutput.candidates;
          if (candidates && candidates.length > 0 && candidates[0].content?.parts?.[0]?.text) {
            messageBody = candidates[0].content.parts[0].text;
          }
        } else {
          const errBody = await response.text();
          console.warn(`   ⚠️ Gemini returned ${response.status}: ${errBody}`);
        }
      }

      if (!messageBody) {
        if (isColdOutreach) {
          messageBody = `Hi — I'm Theenesan, founder of Librae AI Labs. I noticed ${lead.company_name} is active in ${lead.metadata?.industry || 'geospatial compliance'}. I appreciate your work and would love to learn more about your current ${ (pricing.modules || ['EUDR', 'ESG']).join(' / ') } workflows. — Theenesan VK`;
        } else {
          messageBody = `Hi — I'm Theenesan, founder of Librae AI Labs. We've built Lenuda, a satellite-powered ESG compliance platform. Following up on our custom ${pricing.package_name}. We estimate this fits in the ${pricing.expected_monthly_range} range, saving 10x over manual consultancies. Let's do a demo. — Theenesan VK`;
        }
      }

      // 6. Stage the interaction in our database
      const { error: insertErr } = await supabase
        .from('interactions')
        .insert({
          lead_id: lead.id,
          channel: channel,
          direction: 'outbound',
          content: messageBody,
          metadata: {
            is_automated: true,
            stage: isColdOutreach ? 'initial_outreach' : 'follow_up',
            package_name: pricing.package_name,
            modules: pricing.modules,
            pricing_tier: pricing.recommended_tier,
            pricing_monthly: pricing.monthly_price_usd,
            pricing_annual: pricing.annual_price_usd,
            expected_monthly_range: pricing.expected_monthly_range,
            unipile_account_id: getUnipileAccountId(channel),
            budget_power_score: pricing.budget_power_score,
            esri_maturity_score: pricing.esri_maturity_score,
            procurement_complexity_score: pricing.procurement_complexity_score,
            expansion_potential_score: pricing.expansion_potential_score,
            lead_value_index: pricing.lead_value_index,
            confidence_score: pricing.confidence_score,
            confidence_reasons: pricing.confidence_reasons,
            channel_selected_reason: `${channel} selected based on geography (${country}) and stage (${lead.pipeline_status})`
          }
        });

      if (insertErr) {
        console.error(`   ❌ Failed to insert interaction: ${insertErr.message}`);
        continue;
      }

      // 6b. Dispatch via Unipile or route to CEO-001 approval
      if (shouldRouteToApproval(lead, channel)) {
        await stageForReview('outreach_sovereign', lead.id, lead.org_id, `First outreach to ${lead.company_name} via ${channel}`);
        console.log(`   🔒 Routed to CEO-001 approval queue (sovereign lead)`);
      } else {
        // Actually dispatch via Unipile
        try {
          await sendViaUnipile(channel, getUnipileAccountId(channel), lead.metadata?.linkedin_url || lead.email, messageBody);
          console.log(`   📤 DISPATCHED via Unipile ${channel.toUpperCase()}`);
        } catch (e) {
          console.warn(`   ⚠️ Unipile dispatch failed: ${e.message}`);
        }
      }

      // 7. Advance lead status & record scores on the lead metadata
      const nextStatus = channel === 'linkedin' ? 'warming_initiated' : 
                         channel === 'whatsapp' ? 'warm_followup_sent' :
                         'warming_initiated';
      
      const { error: updateErr } = await supabase
        .from('leads')
        .update({ 
          pipeline_status: nextStatus,
          metadata: {
            ...lead.metadata,
            package_name: pricing.package_name,
            modules: pricing.modules,
            expected_monthly_range: pricing.expected_monthly_range,
            budget_power_score: pricing.budget_power_score,
            esri_maturity_score: pricing.esri_maturity_score,
            procurement_complexity_score: pricing.procurement_complexity_score,
            expansion_potential_score: pricing.expansion_potential_score,
            lead_value_index: pricing.lead_value_index,
            confidence_score: pricing.confidence_score,
            confidence_reasons: pricing.confidence_reasons,
            valued_at: new Date().toISOString()
          }
        })
        .eq('id', lead.id);
      
      if (updateErr) {
        console.warn(`   ⚠️ Failed to update lead status: ${updateErr.message}`);
      }

      console.log(`   📨 Message generated (${messageBody.length} chars)`);
      if (isColdOutreach) {
        console.log(`   🔒 Posture: DISCOVERY-FIRST (pricing hidden)`);
      } else {
        console.log(`   💰 Range: ${pricing.expected_monthly_range} (quote presented)`);
      }
      console.log(`   ✅ Staged to ${channel.toUpperCase()} via Unipile account ${getUnipileAccountId(channel)}`);
      console.log(`   📊 Status advanced: ${lead.pipeline_status} → ${nextStatus}`);
    }

    console.log(`\n═══════════════════════════════════════════════════════`);
    console.log(`✅ Outbound cycle complete. ${sortedLeads.length} leads processed.`);
    console.log(`═══════════════════════════════════════════════════════\n`);

  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error('🚨 Outbound Engine Error:', message);
  }
}

executeFounderOutreach();
