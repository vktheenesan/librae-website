import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import crypto from 'node:crypto';

dotenv.config();

const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const FIRECRAWL_API_KEY = process.env.FIRECRAWL_API_KEY || '';

const hasConfig = SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && GEMINI_API_KEY && FIRECRAWL_API_KEY;
const supabase = hasConfig ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY) : null;

/**
 * TIER 1 TARGET DISCOVERY ENGINE
 * 
 * High-value ESG/compliance companies in rich countries.
 * These are real companies that need satellite-verified compliance intelligence.
 * 
 * Categories:
 * 1. Environmental Consultancies (white-label opportunity)
 * 2. Plantation/Forestry Groups (direct compliance users)
 * 3. PE/Investment Firms (due diligence speed)
 * 4. Carbon Project Developers (VCS/Gold Standard pathway)
 */
const TIER_1_TARGETS = [
  // Environmental Consultancies — US/EU (white-label opportunity)
  { url: 'https://www.erm.com', country: 'United Kingdom', city: 'London', vertical: 'Environmental Consultancy' },
  { url: 'https://www.ramboll.com', country: 'Denmark', city: 'Copenhagen', vertical: 'Environmental Consultancy' },
  { url: 'https://www.wsp.com', country: 'Canada', city: 'Montreal', vertical: 'Environmental Consultancy' },
  { url: 'https://www.aecom.com', country: 'United States', city: 'Dallas, TX', vertical: 'Environmental Consultancy' },
  { url: 'https://www.jacobs.com', country: 'United States', city: 'Dallas, TX', vertical: 'Environmental Consultancy' },
  
  // Sustainability / ESG Advisory
  { url: 'https://www.southpole.com', country: 'Switzerland', city: 'Zurich', vertical: 'Carbon Advisory' },
  { url: 'https://www.carbontrust.com', country: 'United Kingdom', city: 'London', vertical: 'Carbon Advisory' },
  { url: 'https://www.trucost.com', country: 'United Kingdom', city: 'London', vertical: 'ESG Data Provider' },
  
  // Plantation Groups — SE Asia (direct compliance users, MSPO/EUDR)
  { url: 'https://www.simedarby.com', country: 'Malaysia', city: 'Kuala Lumpur', vertical: 'Plantation' },
  { url: 'https://www.kwantas.com.my', country: 'Malaysia', city: 'Johor Bahru', vertical: 'Plantation' },
  { url: 'https://www.felda.gov.my', country: 'Malaysia', city: 'Kuala Lumpur', vertical: 'Plantation' },
  { url: 'https://www.musimmas.com', country: 'Indonesia', city: 'Medan', vertical: 'Plantation' },
  
  // PE / Impact Investment (due diligence speed)
  { url: 'https://www.responsability.com', country: 'Switzerland', city: 'Zurich', vertical: 'Impact Investment' },
  { url: 'https://www.bluecircle.vc', country: 'Singapore', city: 'Singapore', vertical: 'Climate Tech VC' },
  
  // Australian / NZ — Forestry & Environmental
  { url: 'https://www.suez.com', country: 'France', city: 'Paris', vertical: 'Environmental Services' },
];

async function callFirecrawlScrape(url) {
  console.log(`   🕷️ Scraping: ${url}...`);
  try {
    const response = await fetch('https://api.firecrawl.dev/v1/scrape', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${FIRECRAWL_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        url: url,
        formats: ['markdown'],
        onlyMainContent: true,
        waitFor: 3000
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`);
    }

    const json = await response.json();
    if (json.success && json.data) {
      return json.data.markdown || '';
    }
  } catch (err) {
    console.error(`   ❌ Scrape failed for ${url}: ${err.message}`);
  }
  return '';
}

async function analyzeWithGeminiV3(markdown, target) {
  console.log(`   🧠 Gemini: Extracting enhanced profile...`);
  const domain = new URL(target.url).hostname.replace('www.', '');
  
  const prompt = `
You are an elite sales intelligence analyst for Lenuda — a geospatial ESG compliance intelligence platform.
Analyze the following scraped website content and extract an enriched prospect profile.

SCRAPED CONTENT:
\`\`\`
${markdown.substring(0, 15000)}
\`\`\`

KNOWN CONTEXT:
- URL: ${target.url}
- Known Country: ${target.country}
- Known City: ${target.city}
- Known Vertical: ${target.vertical}

Extract the following as a valid JSON object:
{
  "company_name": "Common company name",
  "company_domain": "${domain}",
  "headquarters_country": "${target.country}",
  "headquarters_city": "${target.city}",
  "is_esri_user": true/false (mentions of ArcGIS, Esri, spatial mapping, satellite, GIS, geodatabases, shapefiles),
  "geospatial_stack": ["array of detected tools: ArcGIS, QGIS, Sentinel-2, Google Earth Engine, GPS Tracking, etc."],
  "industry": "${target.vertical}",
  "estimated_revenue": "estimated annual revenue range if detectable, else 'Unknown'",
  "employee_count": "estimated employee count if detectable, else 'Unknown'",
  "compliance_needs": ["array: EUDR, MSPO, ESG, Carbon Credits, Sustainability Reporting, NDPE, etc."],
  "key_services": ["array: top 3-5 services this company offers"],
  "outreach_angle": "A single sentence describing WHY Lenuda would be valuable to this specific company"
}

Respond ONLY with the raw JSON. No markdown backticks.
`;

  try {
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(geminiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" }
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`);
    }

    const data = await response.json();
    const candidates = data.candidates;
    if (!candidates || candidates.length === 0 || !candidates[0].content?.parts?.[0]?.text) {
      throw new Error('No valid candidates returned');
    }
    
    return JSON.parse(candidates[0].content.parts[0].text.trim());
  } catch (err) {
    console.error(`   ❌ Gemini analysis failed: ${err.message}`);
    return {
      company_name: domain.split('.')[0].toUpperCase(),
      company_domain: domain,
      headquarters_country: target.country,
      headquarters_city: target.city,
      is_esri_user: false,
      geospatial_stack: ['GPS Tracking'],
      industry: target.vertical,
      estimated_revenue: 'Unknown',
      employee_count: 'Unknown',
      compliance_needs: ['ESG'],
      key_services: [],
      outreach_angle: `${target.vertical} company that could benefit from automated ESG compliance reporting.`
    };
  }
}

async function discoverTargets() {
  console.log('🎯 BAYU TARGET DISCOVERY ENGINE v3.0');
  console.log('═══════════════════════════════════════════════════════');
  console.log(`📋 ${TIER_1_TARGETS.length} high-value targets queued across ${new Set(TIER_1_TARGETS.map(t => t.country)).size} countries\n`);

  if (!hasConfig) {
    console.error('❌ Missing configuration. Set all API keys in .env');
    return;
  }

  // Get Organization ID
  const { data: org, error: orgErr } = await supabase
    .from('organizations')
    .select('id')
    .eq('primary_domain', 'librae.ai')
    .single();

  if (orgErr || !org) {
    console.error('❌ Failed to resolve Librae AI organization.');
    return;
  }

  const orgId = org.id;
  let discovered = 0;
  let updated = 0;
  let skipped = 0;

  for (const target of TIER_1_TARGETS) {
    console.log(`\n──────────────────────────────────────────────`);
    console.log(`🏢 ${target.url} (${target.country} — ${target.vertical})`);

    // Rate limit: 2 second pause between scrapes
    await new Promise(resolve => setTimeout(resolve, 2000));

    const markdown = await callFirecrawlScrape(target.url);
    if (!markdown) {
      console.warn(`   ⚠️ Skipping — scrape returned empty.`);
      skipped++;
      continue;
    }

    const leadInfo = await analyzeWithGeminiV3(markdown, target);
    if (!leadInfo) {
      skipped++;
      continue;
    }

    console.log(`   📊 Profile: ${leadInfo.company_name} | Revenue: ${leadInfo.estimated_revenue} | Esri: ${leadInfo.is_esri_user}`);
    console.log(`   🎯 Angle: ${leadInfo.outreach_angle}`);

    // Check if lead exists
    const { data: existingLead } = await supabase
      .from('leads')
      .select('id')
      .eq('company_domain', leadInfo.company_domain)
      .single();

    if (existingLead) {
      console.log(`   ♻️ Already exists — updating profile with enriched data.`);
      const { error: updateErr } = await supabase
        .from('leads')
        .update({
          is_esri_user: leadInfo.is_esri_user,
          geospatial_stack: leadInfo.geospatial_stack,
          raw_markdown_profile: markdown.substring(0, 50000),
          metadata: {
            industry: leadInfo.industry,
            headquarters_country: leadInfo.headquarters_country,
            headquarters_city: leadInfo.headquarters_city,
            estimated_revenue: leadInfo.estimated_revenue,
            employee_count: leadInfo.employee_count,
            compliance_needs: leadInfo.compliance_needs,
            key_services: leadInfo.key_services,
            outreach_angle: leadInfo.outreach_angle,
            enriched_at: new Date().toISOString()
          }
        })
        .eq('id', existingLead.id);
      
      if (updateErr) console.error(`   ❌ Update failed: ${updateErr.message}`);
      else updated++;
    } else {
      console.log(`   💾 New lead — inserting...`);
      const { error: insertErr } = await supabase
        .from('leads')
        .insert({
          org_id: orgId,
          company_name: leadInfo.company_name,
          company_domain: leadInfo.company_domain,
          is_esri_user: leadInfo.is_esri_user,
          geospatial_stack: leadInfo.geospatial_stack,
          lead_status: 'discovered',
          raw_markdown_profile: markdown.substring(0, 50000),
          metadata: {
            industry: leadInfo.industry,
            headquarters_country: leadInfo.headquarters_country,
            headquarters_city: leadInfo.headquarters_city,
            estimated_revenue: leadInfo.estimated_revenue,
            employee_count: leadInfo.employee_count,
            compliance_needs: leadInfo.compliance_needs,
            key_services: leadInfo.key_services,
            outreach_angle: leadInfo.outreach_angle,
            ingested_at: new Date().toISOString()
          }
        });

      if (insertErr) {
        console.error(`   ❌ Insert failed: ${insertErr.message}`);
        skipped++;
      } else {
        console.log(`   🎉 Lead ingested!`);
        discovered++;
      }
    }
  }

  console.log(`\n═══════════════════════════════════════════════════════`);
  console.log(`📊 Discovery Complete!`);
  console.log(`   🆕 New leads discovered: ${discovered}`);
  console.log(`   ♻️ Existing leads enriched: ${updated}`);
  console.log(`   ⚠️ Skipped/failed: ${skipped}`);
  console.log(`\n🔜 Next: Run "node scripts/founder_outbound_v3.js" to execute personalized outreach.`);
  console.log(`═══════════════════════════════════════════════════════\n`);
}

discoverTargets();
