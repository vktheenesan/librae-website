// ceo_001.js — CEO-001 Executive Intelligence: 4-agent analysis for critical decisions
// Usage: node bayu/scripts/ceo_001.js

import { callGPT, callClaude, callGemini, callQwen } from '../lib/ai.js';
import { bayuClient } from '../lib/supabase.js';
import { sendEmail } from '../lib/outreach.js';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../../.env') });

// ─── The 4 Executive Agents ─────────────────────────────────────────────────
const EXECUTIVE_AGENTS = {
  cfo: {
    name: 'CFO Agent',
    model: 'gpt',
    systemPrompt: `You are the Chief Financial Officer of Librae AI Labs. Analyze this business decision from a financial perspective. Consider: revenue impact, pricing competitiveness, margin analysis, cash flow implications, payment risk, and ROI projections. Be data-driven and conservative. Output JSON: { "verdict": "approve"|"caution"|"reject", "confidence": 0-100, "analysis": "...", "recommendations": ["..."] }`
  },
  cto: {
    name: 'CTO Agent',
    model: 'claude',
    systemPrompt: `You are the Chief Technology Officer of Librae AI Labs. Analyze this business decision from a technical perspective. Consider: deployment complexity, infrastructure requirements, security implications, scalability, integration risk, and technical feasibility. Output JSON: { "verdict": "approve"|"caution"|"reject", "confidence": 0-100, "analysis": "...", "recommendations": ["..."] }`
  },
  cmo: {
    name: 'CMO Agent',
    model: 'gemini',
    systemPrompt: `You are the Chief Marketing Officer of Librae AI Labs. Analyze this business decision from a brand and positioning perspective. Consider: message quality, brand alignment, competitive positioning, market timing, and customer perception. Output JSON: { "verdict": "approve"|"caution"|"reject", "confidence": 0-100, "analysis": "...", "recommendations": ["..."] }`
  },
  coo: {
    name: 'COO Agent',
    model: 'qwen',
    systemPrompt: `You are the Chief Operating Officer of Librae AI Labs. Analyze this business decision from an operations perspective. Consider: delivery timeline, resource allocation, SLA compliance, operational risk, and process efficiency. Output JSON: { "verdict": "approve"|"caution"|"reject", "confidence": 0-100, "analysis": "...", "recommendations": ["..."] }`
  }
};

// ─── Auto-approve rules — these bypass the queue ─────────────────────────────
function shouldAutoApprove(item) {
  // Auto-approve: standard outreach to private sector
  if (item.item_type === 'outreach_standard') return true;

  // Auto-approve: trial activation for cloud (non-critical)
  if (item.item_type === 'trial_cloud' && item.priority !== 'critical') return true;

  // Auto-approve: nurture emails
  if (item.item_type === 'nurture_email') return true;

  // Check deal value from ai_analysis or summary
  const dealValue = item.ai_analysis?.deal_value_usd || 0;

  // Auto-approve: deals < $10K that aren't sensitive types
  const sensitiveTypes = ['government_letter', 'partnership_offer', 'outreach_sovereign'];
  if (dealValue < 10000 && !sensitiveTypes.includes(item.item_type)) return true;

  return false;
}

/**
 * Parse AI agent result, handling failures gracefully.
 */
function parseResult(result) {
  if (result.status === 'rejected') {
    return {
      verdict: 'caution',
      confidence: 0,
      analysis: `Agent failed: ${result.reason?.message || result.reason || 'Unknown error'}`,
      recommendations: ['Manual review recommended due to agent failure']
    };
  }

  try {
    const value = result.value;
    if (typeof value === 'object' && value !== null && value.verdict) {
      return value;
    }
    if (typeof value === 'string') {
      // Try to extract JSON from the string
      const jsonMatch = value.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    }
    return {
      verdict: 'caution',
      confidence: 50,
      analysis: typeof value === 'string' ? value : JSON.stringify(value),
      recommendations: []
    };
  } catch {
    return {
      verdict: 'caution',
      confidence: 50,
      analysis: typeof result.value === 'string' ? result.value : 'Unparseable response',
      recommendations: []
    };
  }
}

/**
 * Run all 4 executive agents in parallel on a queue item.
 * @param {string} queueItemId - UUID of the approval_queue item
 * @returns {object} Analysis results from all 4 agents
 */
export async function runCEOAnalysis(queueItemId) {
  try {
    const { data: item, error: fetchErr } = await bayuClient
      .from('approval_queue')
      .select('*')
      .eq('id', queueItemId)
      .single();

    if (fetchErr || !item) {
      throw new Error(`Queue item ${queueItemId} not found: ${fetchErr?.message || 'No data'}`);
    }

    console.log(`\n🧠 CEO-001: Running executive analysis`);
    console.log(`   Type: ${item.item_type}`);
    console.log(`   Priority: ${item.priority}`);
    console.log(`   Org: ${item.org_id || 'N/A'}`);
    console.log(`   Summary: ${item.summary}`);

    const contextPrompt = `DECISION ITEM:
Type: ${item.item_type}
Priority: ${item.priority}
Summary: ${item.summary}
${item.ai_analysis ? `\nAdditional Context:\n${JSON.stringify(item.ai_analysis, null, 2)}` : ''}

Analyze this decision for Librae AI Labs. Consider the company sells Lenuda, a geospatial ESG compliance intelligence platform, to enterprises globally.`;

    // Run all 4 agents in parallel
    console.log(`   ⚡ Dispatching to 4 executive agents in parallel...`);

    const [cfoResult, ctoResult, cmoResult, cooResult] = await Promise.allSettled([
      callGPT(EXECUTIVE_AGENTS.cfo.systemPrompt, contextPrompt, { json: true }),
      callClaude(EXECUTIVE_AGENTS.cto.systemPrompt, contextPrompt, { json: true }),
      callGemini(EXECUTIVE_AGENTS.cmo.systemPrompt, contextPrompt, { json: true }),
      callQwen(EXECUTIVE_AGENTS.coo.systemPrompt, contextPrompt, { json: true })
    ]);

    // Parse all results
    const analysis = {
      cfo: parseResult(cfoResult),
      cto: parseResult(ctoResult),
      cmo: parseResult(cmoResult),
      coo: parseResult(cooResult)
    };

    // Log individual verdicts
    console.log(`\n   ════════════════════════════════════════════`);
    console.log(`   📊 EXECUTIVE ANALYSIS RESULTS`);
    console.log(`   ────────────────────────────────────────────`);
    console.log(`   💰 CFO (GPT):     ${analysis.cfo.verdict.toUpperCase()} (${analysis.cfo.confidence}% confidence)`);
    console.log(`   🔧 CTO (Claude):  ${analysis.cto.verdict.toUpperCase()} (${analysis.cto.confidence}% confidence)`);
    console.log(`   📢 CMO (Gemini):  ${analysis.cmo.verdict.toUpperCase()} (${analysis.cmo.confidence}% confidence)`);
    console.log(`   ⚙️ COO (Qwen):    ${analysis.coo.verdict.toUpperCase()} (${analysis.coo.confidence}% confidence)`);
    console.log(`   ════════════════════════════════════════════`);

    // Compute consensus
    const verdicts = [analysis.cfo.verdict, analysis.cto.verdict, analysis.cmo.verdict, analysis.coo.verdict];
    const approveCount = verdicts.filter(v => v === 'approve').length;
    const rejectCount = verdicts.filter(v => v === 'reject').length;
    const avgConfidence = Math.round(
      (analysis.cfo.confidence + analysis.cto.confidence + analysis.cmo.confidence + analysis.coo.confidence) / 4
    );

    const consensus = approveCount >= 3 ? 'strong_approve' :
                      approveCount >= 2 ? 'lean_approve' :
                      rejectCount >= 3 ? 'strong_reject' :
                      rejectCount >= 2 ? 'lean_reject' : 'split_decision';

    console.log(`\n   🎯 Consensus: ${consensus.toUpperCase()} (${approveCount}/4 approve, avg confidence: ${avgConfidence}%)`);

    // Update the queue item with analysis
    const { error: updateErr } = await bayuClient
      .from('approval_queue')
      .update({
        ai_analysis: {
          ...item.ai_analysis,
          executive_review: analysis,
          consensus,
          avg_confidence: avgConfidence,
          approve_count: approveCount,
          reject_count: rejectCount,
          analyzed_at: new Date().toISOString()
        },
        cfo_review: analysis.cfo,
        cto_review: analysis.cto,
        cmo_review: analysis.cmo
      })
      .eq('id', queueItemId);

    if (updateErr) {
      console.warn(`   ⚠️ Failed to update queue item: ${updateErr.message}`);
    }

    // Check if auto-approve applies
    if (shouldAutoApprove(item)) {
      console.log(`   ✅ Auto-approve criteria met — executing approval`);
      await executeDecision(queueItemId, 'approve', 'Auto-approved by CEO-001 (meets auto-approval criteria)', 'auto_ceo');
    } else {
      console.log(`   ⏳ Requires human review — item remains pending`);
    }

    console.log(`\n✅ CEO-001 analysis complete for ${item.item_type}`);
    return analysis;

  } catch (err) {
    console.error(`❌ runCEOAnalysis failed: ${err.message}`);
    return null;
  }
}

/**
 * Execute a decision (approve/reject) and trigger downstream actions.
 * @param {string} queueItemId - UUID of the approval_queue item
 * @param {string} decision - 'approve' | 'reject' | 'revise'
 * @param {string} notes - Decision rationale
 * @param {string} decidedBy - Who made the decision ('founder' | 'auto_ceo')
 */
export async function executeDecision(queueItemId, decision, notes, decidedBy = 'founder') {
  console.log(`\n⚡ CEO-001: Executing decision — ${decision.toUpperCase()}`);

  try {
    // ── 1. Update approval_queue status ─────────────────────────────────────
    const statusMap = { approve: 'approved', reject: 'rejected', revise: 'revised' };
    const { error: updateErr } = await bayuClient
      .from('approval_queue')
      .update({
        status: statusMap[decision] || 'revised',
        decision_by: decidedBy,
        decision_notes: notes,
        decided_at: new Date().toISOString()
      })
      .eq('id', queueItemId);

    if (updateErr) {
      console.error(`   ❌ Failed to update queue status: ${updateErr.message}`);
    }

    // ── 2. Record in executive_decisions audit trail ─────────────────────────
    const { error: auditErr } = await bayuClient
      .from('executive_decisions')
      .insert({
        queue_item_id: queueItemId,
        decision,
        rationale: notes,
        decided_by: decidedBy,
        decided_at: new Date().toISOString()
      });

    if (auditErr) {
      console.warn(`   ⚠️ Failed to record audit trail: ${auditErr.message}`);
    }

    // ── 3. If approved, trigger the downstream action ───────────────────────
    if (decision === 'approve') {
      const { data: item } = await bayuClient
        .from('approval_queue')
        .select('*')
        .eq('id', queueItemId)
        .single();

      if (item) {
        console.log(`   ✅ CEO-001 approved: ${item.item_type}`);
        console.log(`   🔄 Triggering downstream action...`);

        // Downstream triggers based on item type
        switch (item.item_type) {
          case 'proposal':
          case 'outreach_sovereign':
            console.log(`   → Proposal/Outreach approved — ready for dispatch via Unipile`);
            break;
          case 'renewal_invoice':
            console.log(`   → Renewal invoice approved — ready to send to customer`);
            break;
          case 'large_deal_closed':
            console.log(`   → Large deal recorded — CEO acknowledged`);
            break;
          case 'swift_wire_confirmation':
            console.log(`   → SWIFT wire approved — license issuance authorized`);
            break;
          case 'expansion_opportunity':
            console.log(`   → Expansion opportunity approved — upsell outreach authorized`);
            break;
          case 'government_letter':
            console.log(`   → Government letter approved — formal dispatch authorized`);
            break;
          case 'partnership_offer':
            console.log(`   → Partnership offer approved — engagement authorized`);
            break;
          default:
            console.log(`   → Generic approval recorded for ${item.item_type}`);
        }
      }
    } else if (decision === 'reject') {
      console.log(`   ❌ Decision rejected: ${notes}`);
    } else {
      console.log(`   📝 Decision requires revision: ${notes}`);
    }

    console.log(`   📋 Decision by: ${decidedBy}`);
    console.log(`   📝 Notes: ${notes}`);

  } catch (err) {
    console.error(`❌ executeDecision failed: ${err.message}`);
  }
}

/**
 * Get pending items and metrics for the CEO dashboard.
 * @returns {object} Dashboard data
 */
export async function getCEODashboard() {
  console.log('\n📊 CEO-001 Dashboard');
  console.log('═══════════════════════════════════════════════════════\n');

  try {
    // Pending approvals
    const { data: pending } = await bayuClient
      .from('approval_queue')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    // Recent decisions
    const { data: recent } = await bayuClient
      .from('executive_decisions')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(20);

    // Organization metrics
    const { data: orgs } = await bayuClient
      .from('organizations')
      .select('status');

    const activeCustomers = orgs?.filter(o => o.status === 'active').length || 0;
    const trials = orgs?.filter(o => o.status === 'trial').length || 0;
    const expired = orgs?.filter(o => o.status === 'expired').length || 0;

    // Pipeline value
    const { data: pipeline } = await bayuClient
      .from('proposals')
      .select('amount, status')
      .in('status', ['pending', 'pending_approval', 'sent']);

    const pipelineValue = (pipeline || []).reduce((sum, p) => sum + (p.amount || 0), 0);

    // Payment metrics
    const { data: payments } = await bayuClient
      .from('payments')
      .select('amount, currency, payment_status')
      .eq('payment_status', 'completed');

    const totalRevenue = (payments || []).reduce((sum, p) => sum + (p.amount || 0), 0);

    const dashboard = {
      pending_approvals: pending || [],
      recent_decisions: recent || [],
      metrics: {
        active_customers: activeCustomers,
        active_trials: trials,
        expired_licenses: expired,
        pipeline_value_usd: pipelineValue,
        total_revenue_usd: totalRevenue,
        pending_decisions: pending?.length || 0
      }
    };

    // Print dashboard
    console.log(`   📋 Pending Approvals:   ${dashboard.metrics.pending_decisions}`);
    console.log(`   🏢 Active Customers:    ${dashboard.metrics.active_customers}`);
    console.log(`   🔑 Active Trials:       ${dashboard.metrics.active_trials}`);
    console.log(`   ⛔ Expired Licenses:    ${dashboard.metrics.expired_licenses}`);
    console.log(`   💰 Pipeline Value:      $${dashboard.metrics.pipeline_value_usd.toLocaleString()}`);
    console.log(`   📈 Total Revenue:       $${dashboard.metrics.total_revenue_usd.toLocaleString()}`);

    if (pending && pending.length > 0) {
      console.log(`\n   ⏳ Pending Items:`);
      pending.forEach(p => {
        const emoji = p.priority === 'critical' ? '🚨' : p.priority === 'high' ? '🔴' : '🟡';
        console.log(`      ${emoji} [${p.priority.toUpperCase()}] ${p.item_type}: ${p.summary?.substring(0, 80)}...`);
      });
    }

    console.log(`\n═══════════════════════════════════════════════════════\n`);
    return dashboard;

  } catch (err) {
    console.error(`❌ getCEODashboard failed: ${err.message}`);
    return { pending_approvals: [], recent_decisions: [], metrics: {} };
  }
}

/**
 * Send digest of pending approvals to the founder via email.
 */
export async function sendPendingApprovalsDigest() {
  console.log('\n📧 CEO-001: Sending pending approvals digest...');

  try {
    const { data: pending } = await bayuClient
      .from('approval_queue')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    if (!pending || pending.length === 0) {
      console.log('   💤 No pending approvals — skipping digest.');
      return;
    }

    const critical = pending.filter(p => p.priority === 'critical');
    const high = pending.filter(p => p.priority === 'high');
    const medium = pending.filter(p => p.priority === 'medium');
    const low = pending.filter(p => !['critical', 'high', 'medium'].includes(p.priority));

    const subject = critical.length > 0
      ? `🚨 ${critical.length} CRITICAL approval(s) pending — CEO-001`
      : `📋 ${pending.length} approval(s) pending — CEO-001`;

    // Build HTML digest
    const buildSection = (items, label, color) => {
      if (items.length === 0) return '';
      return `
        <div style="margin-bottom: 16px;">
          <h3 style="color: ${color}; margin: 0 0 8px 0;">${label} (${items.length})</h3>
          ${items.map(p => `
            <div style="background: #f8fafc; padding: 12px; border-radius: 6px; margin-bottom: 8px; border-left: 4px solid ${color};">
              <strong>${p.item_type}</strong>
              <p style="margin: 4px 0 0 0; color: #64748b; font-size: 13px;">${p.summary || 'No summary'}</p>
              <p style="margin: 4px 0 0 0; color: #94a3b8; font-size: 12px;">Created: ${new Date(p.created_at).toLocaleString()}</p>
            </div>
          `).join('')}
        </div>`;
    };

    const htmlBody = `
<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">
  <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; padding: 24px; border-radius: 12px; margin-bottom: 24px;">
    <h2 style="margin: 0;">🧠 CEO-001 Digest</h2>
    <p style="margin: 8px 0 0 0; opacity: 0.8;">${pending.length} item(s) awaiting your decision</p>
  </div>

  ${buildSection(critical, '🚨 Critical', '#dc2626')}
  ${buildSection(high, '🔴 High Priority', '#ea580c')}
  ${buildSection(medium, '🟡 Medium Priority', '#ca8a04')}
  ${buildSection(low, '🟢 Standard', '#16a34a')}

  <div style="background: #eff6ff; padding: 16px; border-radius: 8px; margin-top: 16px;">
    <p style="margin: 0; color: #1e40af; font-size: 14px;">
      Reply to this email with decisions, or access the CEO dashboard to review items with full executive analysis.
    </p>
  </div>

  <div style="border-top: 1px solid #e2e8f0; padding-top: 16px; margin-top: 24px;">
    <p style="color: #64748b; font-size: 12px;">CEO-001 Executive Intelligence · Librae AI Labs</p>
  </div>
</div>`;

    await sendEmail('theenesanvk@librae.work', subject, htmlBody);
    console.log(`   📧 CEO-001 digest sent: ${pending.length} items pending`);
    console.log(`      🚨 Critical: ${critical.length} | 🔴 High: ${high.length} | 🟡 Medium: ${medium.length}`);

  } catch (err) {
    console.error(`❌ sendPendingApprovalsDigest failed: ${err.message}`);
  }
}

/**
 * Process all pending items: run executive analysis on each.
 */
async function processAllPending() {
  console.log('\n🧠 CEO-001: Processing all pending items...');

  try {
    const { data: pending } = await bayuClient
      .from('approval_queue')
      .select('id, item_type, priority, summary')
      .eq('status', 'pending')
      .is('cfo_review', null) // Only items not yet analyzed
      .order('created_at', { ascending: true });

    if (!pending || pending.length === 0) {
      console.log('   💤 No unanalyzed pending items.');
      return;
    }

    console.log(`   📋 Found ${pending.length} item(s) to analyze\n`);

    for (const item of pending) {
      console.log(`──────────────────────────────────────────────`);
      console.log(`📋 Analyzing: [${item.priority.toUpperCase()}] ${item.item_type}`);
      console.log(`   ${item.summary?.substring(0, 100)}`);

      await runCEOAnalysis(item.id);

      // Rate limit between analyses
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    // Send digest after processing
    await sendPendingApprovalsDigest();

  } catch (err) {
    console.error(`❌ processAllPending failed: ${err.message}`);
  }
}

// ─── Self-run ─────────────────────────────────────────────────────────────────
const isMainModule = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMainModule) {
  console.log('🧠 BAYU CEO-001 — Executive Intelligence Layer');
  console.log('═══════════════════════════════════════════════════════\n');

  const args = process.argv.slice(2);
  const command = args[0] || 'dashboard';

  switch (command) {
    case 'analyze':
      if (args[1]) {
        runCEOAnalysis(args[1])
          .then(() => console.log('✅ Analysis complete.'))
          .catch(err => console.error('🚨 Fatal error:', err));
      } else {
        processAllPending()
          .then(() => console.log('✅ All pending items processed.'))
          .catch(err => console.error('🚨 Fatal error:', err));
      }
      break;

    case 'decide':
      if (args[1] && args[2]) {
        executeDecision(args[1], args[2], args[3] || 'CLI decision', 'founder')
          .then(() => console.log('✅ Decision executed.'))
          .catch(err => console.error('🚨 Fatal error:', err));
      } else {
        console.log('Usage: node ceo_001.js decide <queue_item_id> <approve|reject> [notes]');
      }
      break;

    case 'digest':
      sendPendingApprovalsDigest()
        .then(() => console.log('✅ Digest sent.'))
        .catch(err => console.error('🚨 Fatal error:', err));
      break;

    case 'dashboard':
    default:
      getCEODashboard()
        .then(() => console.log('✅ Dashboard loaded.'))
        .catch(err => console.error('🚨 Fatal error:', err));
      break;
  }
}
