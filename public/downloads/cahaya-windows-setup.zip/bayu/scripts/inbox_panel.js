/**
 * BAYU Inbox Panel — scripts/inbox_panel.js
 * ==========================================
 * Client-side JavaScript module for the Inbox tab in the CEO-001 panel.
 *
 * Features:
 *   - Fetches and renders pending inbox drafts in a review panel
 *   - Email card: sender, subject, urgency badge, intent, AI confidence
 *   - Expandable card: original body + AI draft side-by-side
 *   - Action buttons: Approve & Send | Edit & Send | Reject
 *   - Real-time updates via Supabase Realtime subscription
 *   - Badge count on Inbox nav item shows pending count
 *   - HIGH urgency emails trigger a visual alert banner
 *
 * Usage: <script src="inbox_panel.js"></script>
 * Requires: Supabase JS v2 in page scope (window.supabase) or loaded separately
 *
 * API calls go to /api/inbox/* — ensure the backend has inbox_api.js routes registered.
 */

(function () {
  'use strict';

  // ─── Config ──────────────────────────────────────────────────────────────
  const API_BASE = '/api/inbox';
  const POLL_INTERVAL_MS = 60 * 1000; // 1-min fallback poll if realtime fails

  // ─── State ───────────────────────────────────────────────────────────────
  let inboxEmails = [];
  let realtimeChannel = null;
  let pollTimer = null;
  let expandedEmailId = null;

  // ─── Urgency config ───────────────────────────────────────────────────────
  const URGENCY = {
    high:   { badge: '🔴 HIGH',   cls: 'urgency-high',   color: '#ef4444' },
    medium: { badge: '🟡 MED',    cls: 'urgency-medium', color: '#f59e0b' },
    low:    { badge: '🟢 LOW',    cls: 'urgency-low',    color: '#10b981' },
  };

  const INTENT_LABELS = {
    PROSPECT_REPLY:   '🤝 Prospect',
    CUSTOMER_SUPPORT: '🛠️ Support',
    TRIAL_INQUIRY:    '🔑 Trial',
    PAYMENT_QUERY:    '💳 Payment',
    UNSUBSCRIBE:      '🚫 Unsub',
    SPAM:             '🗑️ Spam',
    OTHER:            '📋 Other',
  };

  // ─── CSS Injection ────────────────────────────────────────────────────────
  function injectStyles() {
    if (document.getElementById('inbox-panel-styles')) return;

    const style = document.createElement('style');
    style.id = 'inbox-panel-styles';
    style.textContent = `
      /* ════════════════════════════════════════════════════
         INBOX NAV BADGE
      ════════════════════════════════════════════════════ */
      #inbox-nav-btn {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(0,229,255,0.06);
        border: 1px solid rgba(0,229,255,0.12);
        color: rgba(0,229,255,0.7);
        font-family: 'JetBrains Mono', monospace;
        font-size: 9px;
        font-weight: 600;
        letter-spacing: 1px;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.2s;
      }
      #inbox-nav-btn:hover {
        background: rgba(0,229,255,0.12);
        color: #00e5ff;
        border-color: rgba(0,229,255,0.25);
      }
      #inbox-nav-btn.active {
        background: rgba(0,229,255,0.15);
        color: #00e5ff;
        border-color: rgba(0,229,255,0.3);
      }
      .inbox-nav-badge {
        background: #ef4444;
        color: #fff;
        font-size: 8px;
        font-weight: 700;
        padding: 1px 5px;
        border-radius: 10px;
        min-width: 16px;
        text-align: center;
        animation: badge-pulse 2s ease-in-out infinite;
        display: none;
      }
      .inbox-nav-badge.visible { display: inline-block; }
      @keyframes badge-pulse {
        0%, 100% { box-shadow: 0 0 0 0 rgba(239,68,68,0.4); }
        50%       { box-shadow: 0 0 0 4px rgba(239,68,68,0); }
      }

      /* ════════════════════════════════════════════════════
         INBOX PANEL OVERLAY
      ════════════════════════════════════════════════════ */
      #inbox-panel {
        position: fixed;
        inset: 0;
        background: rgba(3, 2, 8, 0.92);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        z-index: 300;
        display: none;
        flex-direction: column;
        overflow: hidden;
      }
      #inbox-panel.open { display: flex; }

      .inbox-panel-header {
        display: flex;
        align-items: center;
        padding: 14px 20px;
        background: rgba(12, 11, 26, 0.98);
        border-bottom: 1px solid rgba(0,229,255,0.08);
        gap: 12px;
        flex-shrink: 0;
      }
      .inbox-panel-title {
        font-family: 'JetBrains Mono', monospace;
        font-size: 10px;
        font-weight: 700;
        color: #00e5ff;
        letter-spacing: 2px;
        flex: 1;
      }
      .inbox-panel-stats {
        display: flex;
        gap: 16px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 8px;
        color: rgba(255,255,255,0.25);
      }
      .inbox-panel-stats span { display: flex; align-items: center; gap: 4px; }
      .inbox-panel-stats .stat-val {
        font-weight: 700;
        font-size: 11px;
        color: rgba(255,255,255,0.6);
      }
      .inbox-close-btn {
        background: none;
        border: 1px solid rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.3);
        width: 28px;
        height: 28px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s;
      }
      .inbox-close-btn:hover {
        color: #fff;
        border-color: rgba(255,255,255,0.2);
      }

      /* Filter bar */
      .inbox-filter-bar {
        display: flex;
        gap: 8px;
        padding: 10px 20px;
        background: rgba(6,5,14,0.6);
        border-bottom: 1px solid rgba(255,255,255,0.03);
        flex-shrink: 0;
        overflow-x: auto;
      }
      .inbox-filter-btn {
        font-family: 'JetBrains Mono', monospace;
        font-size: 8px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 4px;
        border: 1px solid rgba(255,255,255,0.08);
        background: transparent;
        color: rgba(255,255,255,0.35);
        cursor: pointer;
        white-space: nowrap;
        transition: all 0.15s;
      }
      .inbox-filter-btn.active, .inbox-filter-btn:hover {
        color: #00e5ff;
        border-color: rgba(0,229,255,0.25);
        background: rgba(0,229,255,0.06);
      }

      /* Main content area */
      .inbox-body {
        flex: 1;
        display: grid;
        grid-template-columns: 340px 1fr;
        overflow: hidden;
      }
      @media (max-width: 768px) {
        .inbox-body { grid-template-columns: 1fr; }
        .inbox-detail-panel { display: none; }
        .inbox-body.expanded .inbox-list-panel { display: none; }
        .inbox-body.expanded .inbox-detail-panel { display: flex; }
      }

      /* Email list panel */
      .inbox-list-panel {
        border-right: 1px solid rgba(255,255,255,0.03);
        overflow-y: auto;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .inbox-list-panel::-webkit-scrollbar { width: 3px; }
      .inbox-list-panel::-webkit-scrollbar-thumb {
        background: rgba(0,229,255,0.1);
        border-radius: 2px;
      }

      /* Email card */
      .inbox-email-card {
        background: rgba(255,255,255,0.02);
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 8px;
        padding: 12px;
        cursor: pointer;
        transition: all 0.2s;
        position: relative;
        overflow: hidden;
      }
      .inbox-email-card::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 3px;
        background: var(--card-urgency-color, rgba(255,255,255,0.1));
        border-radius: 8px 0 0 8px;
      }
      .inbox-email-card:hover {
        border-color: rgba(0,229,255,0.15);
        background: rgba(0,229,255,0.03);
      }
      .inbox-email-card.selected {
        border-color: rgba(0,229,255,0.25);
        background: rgba(0,229,255,0.06);
      }

      /* HIGH urgency alert styling */
      .inbox-email-card.urgency-high-card {
        --card-urgency-color: #ef4444;
        border-color: rgba(239,68,68,0.15);
        box-shadow: 0 0 12px rgba(239,68,68,0.06);
      }
      .inbox-email-card.urgency-high-card:hover {
        border-color: rgba(239,68,68,0.3);
      }

      .card-top {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-bottom: 6px;
      }
      .card-from {
        font-size: 10px;
        font-weight: 600;
        color: rgba(255,255,255,0.8);
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .card-urgency-badge {
        font-family: 'JetBrains Mono', monospace;
        font-size: 7px;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 4px;
        flex-shrink: 0;
      }
      .urgency-high   { background: rgba(239,68,68,0.15);  color: #ef4444; border: 1px solid rgba(239,68,68,0.2); }
      .urgency-medium { background: rgba(245,158,11,0.15); color: #f59e0b; border: 1px solid rgba(245,158,11,0.2); }
      .urgency-low    { background: rgba(16,185,129,0.15); color: #10b981; border: 1px solid rgba(16,185,129,0.2); }

      .card-subject {
        font-size: 10px;
        color: rgba(255,255,255,0.55);
        margin-bottom: 6px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .card-meta {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 8px;
        font-family: 'JetBrains Mono', monospace;
      }
      .card-intent {
        color: rgba(255,255,255,0.4);
        background: rgba(255,255,255,0.04);
        padding: 2px 6px;
        border-radius: 3px;
      }
      .card-confidence {
        color: rgba(0,229,255,0.5);
        margin-left: auto;
      }
      .card-confidence.high { color: #10b981; }
      .card-time {
        color: rgba(255,255,255,0.15);
        font-size: 7px;
      }

      /* Empty state */
      .inbox-empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 12px;
        padding: 40px 20px;
        color: rgba(255,255,255,0.2);
        font-family: 'JetBrains Mono', monospace;
        font-size: 10px;
      }
      .inbox-empty-state .empty-icon { font-size: 32px; opacity: 0.5; }

      /* Loading state */
      .inbox-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px;
        color: rgba(255,255,255,0.2);
        font-size: 10px;
        font-family: 'JetBrains Mono', monospace;
        gap: 8px;
      }
      .inbox-spinner {
        width: 16px;
        height: 16px;
        border: 2px solid rgba(0,229,255,0.1);
        border-top-color: rgba(0,229,255,0.6);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      /* ════════════════════════════════════════════════════
         DETAIL PANEL (right side)
      ════════════════════════════════════════════════════ */
      .inbox-detail-panel {
        display: flex;
        flex-direction: column;
        overflow: hidden;
        background: rgba(6,5,14,0.4);
      }
      .inbox-detail-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        gap: 12px;
        color: rgba(255,255,255,0.15);
        font-family: 'JetBrains Mono', monospace;
        font-size: 10px;
      }

      .detail-top {
        padding: 16px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.04);
        flex-shrink: 0;
      }
      .detail-email-from {
        font-size: 13px;
        font-weight: 600;
        color: #fff;
        margin-bottom: 4px;
      }
      .detail-email-subject {
        font-size: 11px;
        color: rgba(255,255,255,0.45);
        margin-bottom: 8px;
      }
      .detail-email-meta {
        display: flex;
        gap: 10px;
        align-items: center;
        font-size: 8px;
        font-family: 'JetBrains Mono', monospace;
      }
      .detail-tag {
        padding: 2px 8px;
        border-radius: 4px;
        font-weight: 700;
        letter-spacing: 0.5px;
      }
      .detail-tag.intent { background: rgba(168,85,247,0.12); color: #a855f7; border: 1px solid rgba(168,85,247,0.2); }
      .detail-tag.time   { color: rgba(255,255,255,0.2); }
      .detail-tag.lead   { background: rgba(0,245,212,0.1); color: #00f5d4; border: 1px solid rgba(0,245,212,0.15); }

      /* Side-by-side email content */
      .detail-content-grid {
        flex: 1;
        display: grid;
        grid-template-columns: 1fr 1fr;
        overflow: hidden;
        gap: 1px;
        background: rgba(255,255,255,0.03);
      }
      @media (max-width: 900px) {
        .detail-content-grid { grid-template-columns: 1fr; }
      }

      .detail-pane {
        display: flex;
        flex-direction: column;
        overflow: hidden;
        background: rgba(6,5,14,0.4);
      }
      .detail-pane-header {
        padding: 8px 16px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 8px;
        font-weight: 700;
        letter-spacing: 1.5px;
        color: rgba(255,255,255,0.25);
        border-bottom: 1px solid rgba(255,255,255,0.03);
        flex-shrink: 0;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .pane-label-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        flex-shrink: 0;
      }
      .detail-pane-body {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
        font-size: 12px;
        line-height: 1.7;
        color: rgba(255,255,255,0.5);
        white-space: pre-wrap;
        word-break: break-word;
      }
      .detail-pane-body::-webkit-scrollbar { width: 3px; }
      .detail-pane-body::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.06);
        border-radius: 2px;
      }

      /* AI draft pane */
      .draft-pane .detail-pane-header { color: rgba(0,229,255,0.6); }
      .draft-pane .detail-pane-body   { color: rgba(255,255,255,0.8); }

      /* Confidence bar */
      .confidence-bar-wrap {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .confidence-bar {
        width: 60px;
        height: 4px;
        background: rgba(255,255,255,0.06);
        border-radius: 2px;
        overflow: hidden;
      }
      .confidence-bar-fill {
        height: 100%;
        border-radius: 2px;
        background: #10b981;
        transition: width 0.4s ease;
      }
      .confidence-bar-fill.medium { background: #f59e0b; }
      .confidence-bar-fill.low    { background: #ef4444; }
      .confidence-val {
        font-size: 8px;
        color: rgba(255,255,255,0.3);
        font-family: 'JetBrains Mono', monospace;
      }

      /* Edit textarea */
      #inbox-edit-textarea {
        width: 100%;
        flex: 1;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(0,229,255,0.12);
        border-radius: 6px;
        color: rgba(255,255,255,0.85);
        font-size: 12px;
        font-family: 'Inter', sans-serif;
        line-height: 1.7;
        padding: 12px;
        resize: none;
        outline: none;
        transition: border-color 0.2s;
        box-sizing: border-box;
        margin: 12px 16px;
        width: calc(100% - 32px);
        min-height: 200px;
      }
      #inbox-edit-textarea:focus { border-color: rgba(0,229,255,0.25); }

      /* ════════════════════════════════════════════════════
         ACTION BAR
      ════════════════════════════════════════════════════ */
      .inbox-action-bar {
        padding: 12px 20px;
        border-top: 1px solid rgba(255,255,255,0.04);
        display: flex;
        gap: 8px;
        align-items: center;
        background: rgba(0,0,0,0.3);
        flex-shrink: 0;
      }
      .inbox-action-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border-radius: 6px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 0.5px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: all 0.2s;
        white-space: nowrap;
      }
      .inbox-action-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .btn-approve {
        background: rgba(16,185,129,0.12);
        border-color: rgba(16,185,129,0.25);
        color: #10b981;
      }
      .btn-approve:hover:not(:disabled) {
        background: rgba(16,185,129,0.2);
        box-shadow: 0 0 12px rgba(16,185,129,0.15);
      }
      .btn-edit {
        background: rgba(0,229,255,0.08);
        border-color: rgba(0,229,255,0.15);
        color: #00e5ff;
      }
      .btn-edit:hover:not(:disabled) {
        background: rgba(0,229,255,0.15);
        box-shadow: 0 0 12px rgba(0,229,255,0.1);
      }
      .btn-reject {
        background: rgba(239,68,68,0.08);
        border-color: rgba(239,68,68,0.15);
        color: #ef4444;
        margin-left: auto;
      }
      .btn-reject:hover:not(:disabled) {
        background: rgba(239,68,68,0.15);
      }
      .btn-send-edit {
        background: rgba(16,185,129,0.12);
        border-color: rgba(16,185,129,0.25);
        color: #10b981;
        display: none;
      }
      .btn-send-edit.visible { display: flex; }
      .btn-cancel-edit {
        background: rgba(255,255,255,0.04);
        border-color: rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.4);
        display: none;
      }
      .btn-cancel-edit.visible { display: flex; }

      /* Action feedback toast */
      .inbox-toast {
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%) translateY(80px);
        background: rgba(12,11,26,0.98);
        border: 1px solid rgba(0,229,255,0.2);
        border-radius: 8px;
        padding: 10px 20px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 10px;
        color: #00e5ff;
        z-index: 400;
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        pointer-events: none;
        white-space: nowrap;
      }
      .inbox-toast.show { transform: translateX(-50%) translateY(0); }
      .inbox-toast.error { border-color: rgba(239,68,68,0.3); color: #ef4444; }
      .inbox-toast.success { border-color: rgba(16,185,129,0.3); color: #10b981; }

      /* HIGH urgency banner */
      .inbox-urgent-banner {
        display: none;
        padding: 8px 20px;
        background: rgba(239,68,68,0.08);
        border-bottom: 1px solid rgba(239,68,68,0.15);
        font-family: 'JetBrains Mono', monospace;
        font-size: 9px;
        color: #ef4444;
        align-items: center;
        gap: 8px;
        flex-shrink: 0;
      }
      .inbox-urgent-banner.visible { display: flex; }
      .urgent-pulse {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #ef4444;
        box-shadow: 0 0 8px #ef4444;
        animation: pulse 1s ease-in-out infinite alternate;
        flex-shrink: 0;
      }
    `;
    document.head.appendChild(style);
  }

  // ─── DOM Builder ──────────────────────────────────────────────────────────
  function buildInboxPanel() {
    if (document.getElementById('inbox-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'inbox-panel';
    panel.innerHTML = `
      <!-- Header -->
      <div class="inbox-panel-header">
        <div class="inbox-panel-title">📬 AGENTIC INBOX — BAYU</div>
        <div class="inbox-panel-stats">
          <span><span class="stat-val" id="inbox-stat-pending">—</span> PENDING</span>
          <span><span class="stat-val" id="inbox-stat-unread">—</span> UNREAD</span>
          <span><span class="stat-val" id="inbox-stat-sent">—</span> SENT TODAY</span>
          <span><span class="stat-val" id="inbox-stat-rt">—</span> AVG RESPONSE</span>
        </div>
        <button class="inbox-close-btn" id="inbox-close-btn">✕</button>
      </div>

      <!-- HIGH urgency banner -->
      <div class="inbox-urgent-banner" id="inbox-urgent-banner">
        <div class="urgent-pulse"></div>
        <span id="inbox-urgent-text">HIGH URGENCY EMAIL REQUIRES IMMEDIATE REVIEW</span>
      </div>

      <!-- Filter bar -->
      <div class="inbox-filter-bar">
        <button class="inbox-filter-btn active" data-filter="pending">⏳ Pending Review</button>
        <button class="inbox-filter-btn" data-filter="all">📋 All Emails</button>
        <button class="inbox-filter-btn" data-filter="high">🔴 High Urgency</button>
        <button class="inbox-filter-btn" data-filter="replied">✅ Replied</button>
        <button class="inbox-filter-btn" data-filter="ignored">❌ Rejected</button>
      </div>

      <!-- Body: list + detail -->
      <div class="inbox-body" id="inbox-body">
        <!-- Email list -->
        <div class="inbox-list-panel" id="inbox-list-panel">
          <div class="inbox-loading">
            <div class="inbox-spinner"></div>
            LOADING...
          </div>
        </div>

        <!-- Detail panel -->
        <div class="inbox-detail-panel" id="inbox-detail-panel">
          <div class="inbox-detail-empty">
            <div style="font-size: 28px; opacity: 0.4;">📭</div>
            <div>Select an email to review</div>
          </div>
        </div>
      </div>

      <!-- Toast -->
      <div class="inbox-toast" id="inbox-toast"></div>
    `;

    document.body.appendChild(panel);

    // Wire up close
    document.getElementById('inbox-close-btn').addEventListener('click', closeInboxPanel);

    // Wire up filters
    panel.querySelectorAll('.inbox-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        panel.querySelectorAll('.inbox-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        loadEmails(btn.dataset.filter);
      });
    });
  }

  // ─── Nav Button ───────────────────────────────────────────────────────────
  function injectNavButton() {
    // Check if already added
    if (document.getElementById('inbox-nav-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'inbox-nav-btn';
    btn.innerHTML = `📬 INBOX <span class="inbox-nav-badge" id="inbox-nav-badge">0</span>`;
    btn.addEventListener('click', openInboxPanel);

    // Try to append to topbar or body
    const topbar = document.querySelector('.topbar');
    if (topbar) {
      // Insert before back-link if it exists
      const backLink = topbar.querySelector('.back-link');
      if (backLink) {
        topbar.insertBefore(btn, backLink);
      } else {
        topbar.appendChild(btn);
      }
    } else {
      // Fallback: floating button
      btn.style.cssText = 'position:fixed;top:8px;right:80px;z-index:250;';
      document.body.appendChild(btn);
    }
  }

  // ─── Panel open/close ─────────────────────────────────────────────────────
  function openInboxPanel() {
    document.getElementById('inbox-panel').classList.add('open');
    document.getElementById('inbox-nav-btn')?.classList.add('active');
    loadEmails('pending');
    loadStats();
  }

  function closeInboxPanel() {
    document.getElementById('inbox-panel').classList.remove('open');
    document.getElementById('inbox-nav-btn')?.classList.remove('active');
  }

  // ─── Load Stats ───────────────────────────────────────────────────────────
  async function loadStats() {
    try {
      const res = await fetch(`${API_BASE}/stats`);
      if (!res.ok) return;
      const stats = await res.json();

      setText('inbox-stat-pending', stats.pending_review ?? '0');
      setText('inbox-stat-unread', stats.unread ?? '0');
      setText('inbox-stat-sent', stats.sent_today ?? '0');
      setText('inbox-stat-rt',
        stats.avg_response_time_minutes != null
          ? `${stats.avg_response_time_minutes}m`
          : '—'
      );

      // Update nav badge
      const pending = stats.pending_review || 0;
      const badge = document.getElementById('inbox-nav-badge');
      if (badge) {
        badge.textContent = pending;
        badge.classList.toggle('visible', pending > 0);
      }
    } catch (_) { /* ignore */ }
  }

  // ─── Load Emails ──────────────────────────────────────────────────────────
  async function loadEmails(filter = 'pending') {
    const listEl = document.getElementById('inbox-list-panel');
    if (!listEl) return;

    listEl.innerHTML = `<div class="inbox-loading"><div class="inbox-spinner"></div>LOADING...</div>`;

    try {
      let url = `${API_BASE}?limit=30`;

      if (filter === 'pending') {
        // Fetch drafts with pending status
        url = `${API_BASE}?limit=30`;
      } else if (filter === 'high') {
        url = `${API_BASE}?limit=30&status=triaged`;
      } else if (filter === 'replied') {
        url = `${API_BASE}?limit=30&status=replied`;
      } else if (filter === 'ignored') {
        url = `${API_BASE}?limit=30&status=ignored`;
      }

      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      let emails = data.emails || [];

      // Client-side filter
      if (filter === 'pending') {
        emails = emails.filter(e =>
          e.inbox_drafts?.some(d => d.status === 'pending')
        );
      } else if (filter === 'high') {
        emails = emails.filter(e => e.urgency === 'high');
      }

      inboxEmails = emails;
      renderEmailList(emails, filter);

      // High urgency banner
      const highUrgency = emails.filter(e =>
        e.urgency === 'high' && e.inbox_drafts?.some(d => d.status === 'pending')
      );
      const banner = document.getElementById('inbox-urgent-banner');
      if (banner) {
        if (highUrgency.length > 0) {
          banner.classList.add('visible');
          setText('inbox-urgent-text',
            `🚨 ${highUrgency.length} HIGH URGENCY EMAIL(S) REQUIRE IMMEDIATE REVIEW`
          );
        } else {
          banner.classList.remove('visible');
        }
      }

    } catch (err) {
      listEl.innerHTML = `<div class="inbox-empty-state">
        <div class="empty-icon">⚠️</div>
        <div>Failed to load: ${err.message}</div>
      </div>`;
    }
  }

  // ─── Render Email List ────────────────────────────────────────────────────
  function renderEmailList(emails, filter) {
    const listEl = document.getElementById('inbox-list-panel');
    if (!listEl) return;

    if (emails.length === 0) {
      listEl.innerHTML = `<div class="inbox-empty-state">
        <div class="empty-icon">📭</div>
        <div>No emails in this view</div>
        <div style="font-size:8px;opacity:0.5;margin-top:4px;">BAYU checks every 10 minutes</div>
      </div>`;
      return;
    }

    listEl.innerHTML = '';

    for (const email of emails) {
      const urgencyConfig = URGENCY[email.urgency] || URGENCY.medium;
      const draft = email.inbox_drafts?.[0];
      const confidence = draft?.ai_confidence;
      const confPct = confidence != null ? `${(confidence * 100).toFixed(0)}%` : '—';
      const confClass = confidence >= 0.85 ? 'high' : '';
      const timeStr = formatRelativeTime(email.received_at);
      const intentLabel = INTENT_LABELS[email.intent] || '📋 Other';

      const card = document.createElement('div');
      card.className = `inbox-email-card ${email.urgency === 'high' ? 'urgency-high-card' : ''}`;
      card.dataset.emailId = email.id;
      card.style.setProperty('--card-urgency-color', urgencyConfig.color);

      card.innerHTML = `
        <div class="card-top">
          <div class="card-from">${escHtml(email.from_name || email.from_email)}</div>
          <div class="card-urgency-badge ${urgencyConfig.cls}">${urgencyConfig.badge}</div>
        </div>
        <div class="card-subject">${escHtml(email.subject || '(no subject)')}</div>
        <div class="card-meta">
          <span class="card-intent">${intentLabel}</span>
          <span class="card-time">${timeStr}</span>
          <span class="card-confidence ${confClass}">🤖 ${confPct}</span>
        </div>
      `;

      card.addEventListener('click', () => selectEmail(email.id));
      listEl.appendChild(card);
    }

    // Auto-select first if nothing selected
    if (!expandedEmailId && emails.length > 0) {
      selectEmail(emails[0].id);
    }
  }

  // ─── Select & Render Detail ───────────────────────────────────────────────
  function selectEmail(emailId) {
    expandedEmailId = emailId;

    // Highlight selected card
    document.querySelectorAll('.inbox-email-card').forEach(c => {
      c.classList.toggle('selected', c.dataset.emailId === emailId);
    });

    const email = inboxEmails.find(e => e.id === emailId);
    if (!email) return;

    const detailEl = document.getElementById('inbox-detail-panel');
    const draft = email.inbox_drafts?.[0];
    const confidence = draft?.ai_confidence;
    const confPct = confidence != null ? `${(confidence * 100).toFixed(0)}%` : '—';
    const confClass = confidence >= 0.85 ? '' : confidence >= 0.7 ? 'medium' : 'low';
    const intentLabel = INTENT_LABELS[email.intent] || 'Other';
    const urgencyConfig = URGENCY[email.urgency] || URGENCY.medium;
    const timeStr = formatDateTime(email.received_at);
    const leadBadge = email.lead_id
      ? `<span class="detail-tag lead">🤝 KNOWN LEAD</span>`
      : '';

    detailEl.innerHTML = `
      <!-- Email header -->
      <div class="detail-top">
        <div class="detail-email-from">${escHtml(email.from_name || '')} &lt;${escHtml(email.from_email)}&gt;</div>
        <div class="detail-email-subject">${escHtml(email.subject || '(no subject)')}</div>
        <div class="detail-email-meta">
          <span class="detail-tag intent">${intentLabel}</span>
          <span class="card-urgency-badge ${urgencyConfig.cls}">${urgencyConfig.badge}</span>
          ${leadBadge}
          <span class="detail-tag time">${timeStr}</span>
        </div>
      </div>

      <!-- Side-by-side content -->
      <div class="detail-content-grid">
        <!-- Original email -->
        <div class="detail-pane">
          <div class="detail-pane-header">
            <div class="pane-label-dot" style="background:rgba(255,255,255,0.2)"></div>
            ORIGINAL EMAIL
          </div>
          <div class="detail-pane-body">${escHtml(email.body_text || '(empty body)')}</div>
        </div>

        <!-- AI draft -->
        <div class="detail-pane draft-pane">
          <div class="detail-pane-header">
            <div class="pane-label-dot" style="background:#00e5ff"></div>
            BAYU DRAFT REPLY
            <div class="confidence-bar-wrap">
              <div class="confidence-bar">
                <div class="confidence-bar-fill ${confClass}" style="width:${confidence != null ? (confidence * 100) : 0}%"></div>
              </div>
              <span class="confidence-val">${confPct}</span>
            </div>
          </div>
          <div class="detail-pane-body">${escHtml(draft?.draft_body || '(no draft generated)')}</div>
          ${draft ? `<textarea id="inbox-edit-textarea" style="display:none;" placeholder="Edit reply...">${escHtml(draft.draft_body || '')}</textarea>` : ''}
        </div>
      </div>

      <!-- Action bar -->
      ${draft && draft.status === 'pending' ? `
      <div class="inbox-action-bar">
        <button class="inbox-action-btn btn-approve" id="btn-approve-${draft.id}" onclick="window.inboxPanel.approveDraft('${draft.id}')">
          ✅ Approve &amp; Send
        </button>
        <button class="inbox-action-btn btn-edit" id="btn-edit-${draft.id}" onclick="window.inboxPanel.toggleEdit('${draft.id}')">
          ✏️ Edit &amp; Send
        </button>
        <button class="inbox-action-btn btn-send-edit" id="btn-send-edit-${draft.id}" onclick="window.inboxPanel.sendEdited('${draft.id}')">
          ✅ Send Edited
        </button>
        <button class="inbox-action-btn btn-cancel-edit" id="btn-cancel-edit-${draft.id}" onclick="window.inboxPanel.cancelEdit('${draft.id}')">
          Cancel
        </button>
        <button class="inbox-action-btn btn-reject" onclick="window.inboxPanel.rejectDraft('${draft.id}')">
          ❌ Reject
        </button>
      </div>` : `
      <div class="inbox-action-bar" style="justify-content:center;">
        <span style="font-family:'JetBrains Mono',monospace;font-size:9px;color:rgba(255,255,255,0.2);">
          ${draft?.status === 'sent' ? '✅ SENT' : draft?.status === 'rejected' ? '❌ REJECTED' : 'NO DRAFT'}
        </span>
      </div>`}
    `;
  }

  // ─── Actions ──────────────────────────────────────────────────────────────
  async function approveDraft(draftId) {
    disableActionButtons(draftId);
    try {
      const res = await fetch(`${API_BASE}/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ draft_id: draftId, approved_by: 'founder' }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || `HTTP ${res.status}`);
      }

      showToast('✅ Email sent successfully', 'success');
      await loadEmails(getActiveFilter());
      await loadStats();

    } catch (err) {
      showToast(`❌ Send failed: ${err.message}`, 'error');
      enableActionButtons(draftId);
    }
  }

  function toggleEdit(draftId) {
    const textarea = document.getElementById('inbox-edit-textarea');
    const draftPane = textarea?.closest('.draft-pane');
    const paneBody = draftPane?.querySelector('.detail-pane-body');

    if (!textarea) return;

    const isEditing = textarea.style.display !== 'none';

    if (isEditing) {
      cancelEdit(draftId);
    } else {
      if (paneBody) paneBody.style.display = 'none';
      textarea.style.display = 'block';
      textarea.focus();

      document.getElementById(`btn-edit-${draftId}`)?.classList.add('active');
      document.getElementById(`btn-send-edit-${draftId}`)?.classList.add('visible');
      document.getElementById(`btn-cancel-edit-${draftId}`)?.classList.add('visible');
    }
  }

  function cancelEdit(draftId) {
    const textarea = document.getElementById('inbox-edit-textarea');
    const draftPane = textarea?.closest('.draft-pane');
    const paneBody = draftPane?.querySelector('.detail-pane-body');

    if (textarea) textarea.style.display = 'none';
    if (paneBody) paneBody.style.display = '';

    document.getElementById(`btn-edit-${draftId}`)?.classList.remove('active');
    document.getElementById(`btn-send-edit-${draftId}`)?.classList.remove('visible');
    document.getElementById(`btn-cancel-edit-${draftId}`)?.classList.remove('visible');
  }

  async function sendEdited(draftId) {
    const textarea = document.getElementById('inbox-edit-textarea');
    const editedBody = textarea?.value?.trim();

    if (!editedBody) {
      showToast('⚠️ Reply body cannot be empty', 'error');
      return;
    }

    disableActionButtons(draftId);

    try {
      const res = await fetch(`${API_BASE}/edit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ draft_id: draftId, edited_body: editedBody, approved_by: 'founder' }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || `HTTP ${res.status}`);
      }

      showToast('✅ Edited email sent', 'success');
      await loadEmails(getActiveFilter());
      await loadStats();

    } catch (err) {
      showToast(`❌ Send failed: ${err.message}`, 'error');
      enableActionButtons(draftId);
    }
  }

  async function rejectDraft(draftId) {
    if (!confirm('Reject this draft? The email will be marked as ignored.')) return;

    disableActionButtons(draftId);

    try {
      const res = await fetch(`${API_BASE}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ draft_id: draftId, rejected_by: 'founder' }),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      showToast('🗑️ Draft rejected', 'success');
      expandedEmailId = null;
      await loadEmails(getActiveFilter());
      await loadStats();

    } catch (err) {
      showToast(`❌ Reject failed: ${err.message}`, 'error');
      enableActionButtons(draftId);
    }
  }

  // ─── Realtime Subscription ────────────────────────────────────────────────
  function subscribeRealtime() {
    // Try to use Supabase realtime if available on window
    const supabaseUrl = document.querySelector('meta[name="supabase-url"]')?.content;
    const supabaseKey = document.querySelector('meta[name="supabase-key"]')?.content;

    if (!supabaseUrl || !supabaseKey) return;

    try {
      // eslint-disable-next-line no-undef
      const supabase = window.supabase?.createClient?.(supabaseUrl, supabaseKey);
      if (!supabase) return;

      realtimeChannel = supabase
        .channel('inbox-changes')
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'inbox_emails',
        }, () => {
          loadStats();
          if (document.getElementById('inbox-panel')?.classList.contains('open')) {
            loadEmails(getActiveFilter());
          }
        })
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'inbox_drafts',
        }, () => {
          loadStats();
          if (document.getElementById('inbox-panel')?.classList.contains('open')) {
            loadEmails(getActiveFilter());
          }
        })
        .subscribe();

      console.log('[inbox-panel] 📡 Realtime subscription active');
    } catch (_) {
      // Fallback to polling
    }

    // Fallback polling
    pollTimer = setInterval(() => {
      loadStats();
    }, POLL_INTERVAL_MS);
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────
  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  function escHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatRelativeTime(isoStr) {
    if (!isoStr) return '—';
    const diff = Date.now() - new Date(isoStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  }

  function formatDateTime(isoStr) {
    if (!isoStr) return '—';
    const d = new Date(isoStr);
    return d.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  function getActiveFilter() {
    return document.querySelector('.inbox-filter-btn.active')?.dataset?.filter || 'pending';
  }

  function disableActionButtons(draftId) {
    ['btn-approve', 'btn-edit', 'btn-send-edit', 'btn-cancel-edit', 'btn-reject'].forEach(cls => {
      const el = document.getElementById(`${cls}-${draftId}`)
        || document.querySelector(`.${cls}`);
      if (el) el.disabled = true;
    });
  }

  function enableActionButtons(draftId) {
    ['btn-approve', 'btn-edit', 'btn-send-edit', 'btn-cancel-edit', 'btn-reject'].forEach(cls => {
      const el = document.getElementById(`${cls}-${draftId}`)
        || document.querySelector(`.${cls}`);
      if (el) el.disabled = false;
    });
  }

  let toastTimer = null;
  function showToast(msg, type = '') {
    const toast = document.getElementById('inbox-toast');
    if (!toast) return;

    toast.textContent = msg;
    toast.className = `inbox-toast ${type}`;
    toast.classList.add('show');

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
  }

  // ─── Init ──────────────────────────────────────────────────────────────────
  function init() {
    injectStyles();
    buildInboxPanel();
    injectNavButton();
    loadStats();
    subscribeRealtime();
  }

  // Expose public API
  window.inboxPanel = {
    open: openInboxPanel,
    close: closeInboxPanel,
    approveDraft,
    toggleEdit,
    cancelEdit,
    sendEdited,
    rejectDraft,
    refresh: () => {
      loadEmails(getActiveFilter());
      loadStats();
    },
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
