// payment_handler.js — Layer 8: Stripe + SWIFT payment processing, license issuance
// Usage: node bayu/scripts/payment_handler.js

import { callClaude, dualAI } from '../lib/ai.js';
import { bayuClient } from '../lib/supabase.js';
import { sendEmail, stageForReview } from '../lib/outreach.js';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../../.env') });

const TOKEN_API_BASE = process.env.API_BASE_URL || 'http://localhost:8000';
const ADMIN_KEY = process.env.SESSION_SECRET || process.env.ADMIN_KEY || '';
const STRIPE_KEY = process.env.STRIPE_RESTRICTED_KEY || '';
const CEO_THRESHOLD_USD = 50000;

/**
 * Generate invoice number: INV-YYYY-XXXX
 */
export function generateInvoiceNumber() {
  const year = new Date().getFullYear();
  const seq = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
  return `INV-${year}-${seq}`;
}

/**
 * Issue a production JWT license (365 days) via backend API.
 * @returns {Promise<string|null>} The license token, or null on failure.
 */
async function issueProductionLicense(org, proposal, validDays = 365) {
  console.log(`   🔐 Issuing ${validDays}-day production license...`);

  try {
    const payload = {
      admin_key: ADMIN_KEY,
      org_id: org.id,
      org_name: org.name,
      domain: org.primary_domain || org.domain || 'unknown.com',
      tier: proposal?.pricing_tier || 'professional',
      seats: proposal?.seats || 10,
      vram_target: proposal?.vram_target || '24GB',
      hardware_lock: proposal?.deployment_type === 'air_gapped',
      valid_days: validDays,
      modules: proposal?.modules || ['NDVI', 'EUDR', 'Carbon']
    };

    const res = await fetch(`${TOKEN_API_BASE}/api/token/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${ADMIN_KEY}`
      },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const data = await res.json();
      const token = data.token || data.license_token || null;
      console.log(`   ✅ License issued: ${token ? token.substring(0, 40) + '...' : 'N/A'}`);
      return token;
    } else {
      const errText = await res.text();
      console.warn(`   ⚠️ Token API returned ${res.status}: ${errText}`);
      // Fallback placeholder
      const fallback = `PROD-${Date.now()}-${org.id?.substring(0, 8) || 'unknown'}`;
      console.log(`   📌 Using placeholder license: ${fallback}`);
      return fallback;
    }
  } catch (err) {
    console.warn(`   ⚠️ Token API unreachable: ${err.message}`);
    return `PROD-${Date.now()}-${org.id?.substring(0, 8) || 'unknown'}`;
  }
}

/**
 * Generate contract content via Claude.
 */
async function generateContract(org, proposal, paymentAmount, licenseToken) {
  console.log(`   📄 Generating contract document...`);

  try {
    const contractPrompt = `Generate a software license agreement summary for Lenuda (by Librae AI Labs). Output as JSON with keys: contract_summary, key_terms, sla_highlights, support_tier.

CONTRACT DETAILS:
- Licensor: Librae AI Labs Sdn Bhd
- Licensee: ${org.name}
- Domain: ${org.primary_domain || 'N/A'}
- Product: Lenuda Geospatial Intelligence Platform
- Tier: ${proposal?.pricing_tier || 'Professional'}
- Modules: ${(proposal?.modules || ['Full Suite']).join(', ')}
- Seats: ${proposal?.seats || 10}
- License Duration: 365 days from activation
- Payment Amount: $${paymentAmount?.toLocaleString() || 'N/A'} USD
- Deployment: ${proposal?.deployment_type || 'Cloud'}
- License Token: ${licenseToken?.substring(0, 20)}... (full token delivered separately)

Include: license scope, usage restrictions, support SLA (based on tier), data ownership, termination clauses.
Output ONLY valid JSON.`;

    const result = await callClaude(
      'You are a legal contract assistant for a B2B SaaS company. Generate clear, professional license agreement summaries.',
      contractPrompt,
      { json: true }
    );

    return typeof result === 'string' ? JSON.parse(result) : result;
  } catch (err) {
    console.warn(`   ⚠️ Contract generation failed: ${err.message}`);
    return {
      contract_summary: `License agreement for ${org.name} — Lenuda Platform, ${proposal?.pricing_tier || 'Professional'} tier.`,
      key_terms: ['365-day license', `${proposal?.seats || 10} seats`, 'Standard SLA'],
      sla_highlights: '99.5% uptime, 24h response for critical issues',
      support_tier: proposal?.pricing_tier || 'professional'
    };
  }
}

/**
 * Handle a completed Stripe checkout session (called by webhook handler).
 * @param {object} event - Stripe webhook event object
 */
export async function handleStripePayment(event) {
  if (event.type !== 'checkout.session.completed') {
    console.log(`   ℹ️ Ignoring Stripe event: ${event.type}`);
    return;
  }

  const session = event.data?.object;
  if (!session) {
    console.error('❌ No session data in Stripe event');
    return;
  }

  console.log('\n💳 STRIPE PAYMENT RECEIVED');
  console.log('═══════════════════════════════════════════════════════');

  try {
    const customerEmail = session.customer_email || session.customer_details?.email;
    const amountTotal = (session.amount_total || 0) / 100; // Stripe uses cents
    const currency = (session.currency || 'usd').toUpperCase();
    const proposalId = session.metadata?.proposal_id;

    console.log(`   📧 Customer: ${customerEmail}`);
    console.log(`   💰 Amount: ${currency} ${amountTotal.toLocaleString()}`);
    console.log(`   📋 Proposal ID: ${proposalId || 'N/A'}`);

    // ── 1. Find matching proposal ───────────────────────────────────────────
    let proposal = null;
    let org = null;

    if (proposalId) {
      const { data: proposalData } = await bayuClient
        .from('proposals')
        .select('*, organizations(*)')
        .eq('id', proposalId)
        .single();

      if (proposalData) {
        proposal = proposalData;
        org = proposalData.organizations;
      }
    }

    // Fallback: find org by customer email domain
    if (!org && customerEmail) {
      const domain = customerEmail.split('@')[1];
      const { data: orgData } = await bayuClient
        .from('organizations')
        .select('*')
        .eq('primary_domain', domain)
        .single();
      org = orgData;
    }

    if (!org) {
      console.error(`   ❌ Cannot find organization for payment. Email: ${customerEmail}`);
      // Stage for manual review
      await stageForReview({
        type: 'unmatched_payment',
        priority: 'critical',
        summary: `Stripe payment of ${currency} ${amountTotal} from ${customerEmail} — no matching org found`,
        data: { session_id: session.id, amount: amountTotal, email: customerEmail }
      });
      return;
    }

    console.log(`   🏢 Organization: ${org.name}`);

    // ── 2. Issue production license (365 days) ──────────────────────────────
    const licenseToken = await issueProductionLicense(org, proposal);

    // ── 3. Generate contract ────────────────────────────────────────────────
    const contract = await generateContract(org, proposal, amountTotal, licenseToken);

    // ── 4. Create payment record ────────────────────────────────────────────
    const invoiceNumber = generateInvoiceNumber();
    const licenseStart = new Date();
    const licenseEnd = new Date(licenseStart.getTime() + 365 * 24 * 60 * 60 * 1000);

    const { data: payment, error: paymentErr } = await bayuClient
      .from('payments')
      .insert({
        org_id: org.id,
        proposal_id: proposalId || null,
        stripe_session_id: session.id,
        stripe_payment_intent: session.payment_intent,
        invoice_number: invoiceNumber,
        amount: amountTotal,
        currency,
        payment_method: 'stripe',
        payment_status: 'completed',
        license_token: licenseToken,
        license_start: licenseStart.toISOString(),
        license_end: licenseEnd.toISOString(),
        contract_json: contract,
        customer_email: customerEmail
      })
      .select()
      .single();

    if (paymentErr) {
      console.error(`   ❌ Failed to create payment record: ${paymentErr.message}`);
    } else {
      console.log(`   💾 Payment recorded: ${invoiceNumber} (ID: ${payment.id})`);
    }

    // ── 5. Update proposal status → 'accepted' ──────────────────────────────
    if (proposalId) {
      await bayuClient
        .from('proposals')
        .update({ status: 'accepted', accepted_at: new Date().toISOString() })
        .eq('id', proposalId);
      console.log(`   📋 Proposal ${proposalId} → accepted`);
    }

    // ── 6. Update organization status → 'active' ────────────────────────────
    await bayuClient
      .from('organizations')
      .update({
        status: 'active',
        license_token: licenseToken,
        license_start: licenseStart.toISOString(),
        license_end: licenseEnd.toISOString(),
        plan_tier: proposal?.pricing_tier || 'professional'
      })
      .eq('id', org.id);
    console.log(`   🏢 Organization ${org.name} → active`);

    // ── 7. Migrate trial → 'converted' if exists ────────────────────────────
    const { data: existingTrial } = await bayuClient
      .from('trials')
      .select('id')
      .eq('org_id', org.id)
      .eq('status', 'active')
      .single();

    if (existingTrial) {
      await bayuClient
        .from('trials')
        .update({
          status: 'converted',
          converted_at: new Date().toISOString(),
          payment_id: payment?.id
        })
        .eq('id', existingTrial.id);
      console.log(`   🔄 Trial ${existingTrial.id} → converted`);
    }

    // ── 8. Send license + contract + onboarding email ────────────────────────
    console.log(`   📧 Sending license delivery email...`);
    const emailBody = `
<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">
  <div style="background: linear-gradient(135deg, #059669 0%, #047857 100%); color: white; padding: 32px; border-radius: 12px; margin-bottom: 24px;">
    <h1 style="margin: 0 0 8px 0; font-size: 24px;">🎉 Welcome to Lenuda — Production License Active</h1>
    <p style="margin: 0; opacity: 0.8;">Invoice ${invoiceNumber} · ${currency} ${amountTotal.toLocaleString()}</p>
  </div>

  <div style="margin-bottom: 24px;">
    <p style="line-height: 1.6; color: #334155;">Dear ${org.name} Team,</p>
    <p style="line-height: 1.6; color: #334155;">Thank you for your purchase. Your production license for Lenuda is now active. Below are your license details and onboarding resources.</p>
  </div>

  <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 20px; border-radius: 8px; margin-bottom: 24px;">
    <h3 style="margin: 0 0 12px 0; color: #166534;">🔑 Production License</h3>
    <code style="background: #0f172a; color: #22c55e; padding: 12px 16px; border-radius: 6px; display: block; word-break: break-all; font-size: 13px;">${licenseToken}</code>
    <div style="margin-top: 12px; font-size: 13px; color: #166534;">
      <p style="margin: 4px 0;">📅 Valid: ${licenseStart.toISOString().split('T')[0]} → ${licenseEnd.toISOString().split('T')[0]}</p>
      <p style="margin: 4px 0;">📦 Tier: ${proposal?.pricing_tier || 'Professional'}</p>
      <p style="margin: 4px 0;">🧩 Modules: ${(proposal?.modules || ['Full Suite']).join(', ')}</p>
      <p style="margin: 4px 0;">👥 Seats: ${proposal?.seats || 10}</p>
    </div>
  </div>

  <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 24px;">
    <h3 style="margin: 0 0 12px 0; color: #0f172a;">📄 License Agreement Summary</h3>
    <p style="color: #334155; line-height: 1.6;">${contract.contract_summary}</p>
    <p style="color: #334155; font-size: 13px;"><strong>SLA:</strong> ${contract.sla_highlights}</p>
  </div>

  <div style="margin-bottom: 24px;">
    <h3 style="color: #0f172a;">🚀 Next Steps</h3>
    <ol style="color: #334155; line-height: 2;">
      <li>Activate your license token in your Lenuda deployment</li>
      <li>Invite team members (up to ${proposal?.seats || 10} seats)</li>
      <li>Schedule your onboarding call with our team</li>
      <li>Join the Lenuda support channel</li>
    </ol>
  </div>

  <div style="border-top: 1px solid #e2e8f0; padding-top: 16px;">
    <p style="color: #64748b; font-size: 13px;">Need help? Contact <a href="mailto:theenesanvk@librae.work">theenesanvk@librae.work</a></p>
    <p style="color: #64748b; font-size: 13px;">— Theenesan VK, Founder · Librae AI Labs</p>
  </div>
</div>`;

    try {
      await sendEmail(
        customerEmail,
        `🎉 Lenuda Production License Active — ${invoiceNumber}`,
        emailBody
      );
      console.log(`   ✅ License email sent to ${customerEmail}`);
    } catch (emailErr) {
      console.error(`   ❌ Email failed: ${emailErr.message}`);
    }

    // ── 9. Route large deals through CEO-001 ─────────────────────────────────
    if (amountTotal >= CEO_THRESHOLD_USD) {
      console.log(`   🧠 Deal ≥ $${CEO_THRESHOLD_USD.toLocaleString()} — routing through CEO-001`);
      await bayuClient.from('approval_queue').insert({
        item_type: 'large_deal_closed',
        priority: 'high',
        org_id: org.id,
        summary: `Large deal closed: ${org.name} — ${currency} ${amountTotal.toLocaleString()} (${invoiceNumber})`,
        status: 'pending',
        ai_analysis: {
          deal_value_usd: amountTotal,
          customer: org.name,
          invoice: invoiceNumber
        }
      });
    }

    // ── 10. Log complete payment details ─────────────────────────────────────
    console.log(`\n   ════════════════════════════════════════════`);
    console.log(`   ✅ STRIPE PAYMENT PROCESSED SUCCESSFULLY`);
    console.log(`   ────────────────────────────────────────────`);
    console.log(`   Invoice:        ${invoiceNumber}`);
    console.log(`   Organization:   ${org.name}`);
    console.log(`   Amount:         ${currency} ${amountTotal.toLocaleString()}`);
    console.log(`   License:        ${licenseToken?.substring(0, 40)}...`);
    console.log(`   Valid Until:     ${licenseEnd.toISOString().split('T')[0]}`);
    console.log(`   Proposal:       ${proposalId || 'Direct purchase'}`);
    console.log(`   ════════════════════════════════════════════\n`);

  } catch (err) {
    console.error(`❌ handleStripePayment failed: ${err.message}`);
  }
}

/**
 * Handle SWIFT wire confirmation (called from swift_audit.js or manual trigger).
 * @param {object} wireData - { wire_reference, amount, currency, remitter, value_date }
 */
export async function handleSwiftConfirmation(wireData) {
  console.log('\n🏦 SWIFT WIRE CONFIRMATION');
  console.log('═══════════════════════════════════════════════════════');

  const { wire_reference, amount, currency = 'USD', remitter, value_date } = wireData;

  console.log(`   📋 Wire Reference: ${wire_reference}`);
  console.log(`   💰 Amount: ${currency} ${amount?.toLocaleString()}`);
  console.log(`   🏢 Remitter: ${remitter}`);
  console.log(`   📅 Value Date: ${value_date}`);

  try {
    // ── 1. Match wire_reference in payments or pipeline_registry ──────────
    let matchedOrg = null;
    let proposalId = null;

    // Check payments table first
    const { data: existingPayment } = await bayuClient
      .from('payments')
      .select('*, organizations(*)')
      .eq('wire_reference', wire_reference)
      .single();

    if (existingPayment) {
      matchedOrg = existingPayment.organizations;
      proposalId = existingPayment.proposal_id;
      console.log(`   ✅ Matched in payments table: ${matchedOrg?.name}`);
    }

    // Check pipeline_registry if not found
    if (!matchedOrg) {
      const { data: pipeline } = await bayuClient
        .from('pipeline_registry')
        .select('*')
        .eq('wire_reference', wire_reference)
        .single();

      if (pipeline) {
        const { data: org } = await bayuClient
          .from('organizations')
          .select('*')
          .eq('id', pipeline.org_id)
          .single();
        matchedOrg = org;
        proposalId = pipeline.proposal_id;
        console.log(`   ✅ Matched in pipeline_registry: ${matchedOrg?.name}`);
      }
    }

    if (!matchedOrg) {
      console.error(`   ❌ No match found for wire reference: ${wire_reference}`);
      await stageForReview({
        type: 'unmatched_swift_wire',
        priority: 'critical',
        summary: `SWIFT wire ${wire_reference}: ${currency} ${amount?.toLocaleString()} from ${remitter} — no matching record`,
        data: wireData
      });
      return;
    }

    // ── 2. CEO-001 approval for large deals ──────────────────────────────────
    if (amount >= CEO_THRESHOLD_USD) {
      console.log(`   🧠 Wire ≥ $${CEO_THRESHOLD_USD.toLocaleString()} — routing through CEO-001 approval`);
      const { data: queueItem } = await bayuClient
        .from('approval_queue')
        .insert({
          item_type: 'swift_wire_confirmation',
          priority: 'critical',
          org_id: matchedOrg.id,
          summary: `SWIFT wire confirmation: ${currency} ${amount?.toLocaleString()} from ${remitter} (${wire_reference})`,
          status: 'pending',
          ai_analysis: {
            deal_value_usd: amount,
            wire_reference,
            remitter,
            value_date,
            customer: matchedOrg.name
          }
        })
        .select()
        .single();

      console.log(`   📋 Queued for CEO-001: ${queueItem?.id}`);
      // In production, wait for CEO-001 approval before issuing license
      // For now, continue with issuance
    }

    // ── 3. Issue production license ──────────────────────────────────────────
    let proposal = null;
    if (proposalId) {
      const { data: proposalData } = await bayuClient
        .from('proposals')
        .select('*')
        .eq('id', proposalId)
        .single();
      proposal = proposalData;
    }

    const licenseToken = await issueProductionLicense(matchedOrg, proposal);
    const contract = await generateContract(matchedOrg, proposal, amount, licenseToken);

    // ── 4. Create/update payment record ──────────────────────────────────────
    const invoiceNumber = generateInvoiceNumber();
    const licenseStart = new Date();
    const licenseEnd = new Date(licenseStart.getTime() + 365 * 24 * 60 * 60 * 1000);

    const { error: payErr } = await bayuClient
      .from('payments')
      .insert({
        org_id: matchedOrg.id,
        proposal_id: proposalId,
        wire_reference,
        invoice_number: invoiceNumber,
        amount,
        currency,
        payment_method: 'swift',
        payment_status: 'completed',
        license_token: licenseToken,
        license_start: licenseStart.toISOString(),
        license_end: licenseEnd.toISOString(),
        contract_json: contract,
        remitter_name: remitter,
        value_date
      });

    if (payErr) {
      console.error(`   ❌ Failed to create payment record: ${payErr.message}`);
    } else {
      console.log(`   💾 Payment recorded: ${invoiceNumber}`);
    }

    // ── 5. Update org status ─────────────────────────────────────────────────
    await bayuClient
      .from('organizations')
      .update({
        status: 'active',
        license_token: licenseToken,
        license_start: licenseStart.toISOString(),
        license_end: licenseEnd.toISOString()
      })
      .eq('id', matchedOrg.id);

    // ── 6. Migrate trial if exists ───────────────────────────────────────────
    const { data: trial } = await bayuClient
      .from('trials')
      .select('id')
      .eq('org_id', matchedOrg.id)
      .eq('status', 'active')
      .single();

    if (trial) {
      await bayuClient
        .from('trials')
        .update({ status: 'converted', converted_at: new Date().toISOString() })
        .eq('id', trial.id);
      console.log(`   🔄 Trial ${trial.id} → converted`);
    }

    // ── 7. Send license email ────────────────────────────────────────────────
    const contactEmail = matchedOrg.contact_email || `finance@${matchedOrg.primary_domain || 'customer.com'}`;
    try {
      await sendEmail(
        contactEmail,
        `🎉 Payment Confirmed — Lenuda License Active (${invoiceNumber})`,
        `<div style="font-family: Arial, sans-serif; padding: 24px;">
          <h2>Payment Confirmed — License Active</h2>
          <p>Dear ${matchedOrg.name},</p>
          <p>We have confirmed your SWIFT payment of ${currency} ${amount?.toLocaleString()} (Ref: ${wire_reference}).</p>
          <p>Your production license is now active until ${licenseEnd.toISOString().split('T')[0]}.</p>
          <p><strong>License Token:</strong></p>
          <code style="background: #0f172a; color: #22c55e; padding: 12px; display: block; border-radius: 6px; word-break: break-all;">${licenseToken}</code>
          <p style="margin-top: 16px;">— Theenesan VK, Founder · Librae AI Labs</p>
        </div>`
      );
      console.log(`   ✅ License email sent to ${contactEmail}`);
    } catch (emailErr) {
      console.error(`   ❌ Email failed: ${emailErr.message}`);
    }

    console.log(`\n   ════════════════════════════════════════════`);
    console.log(`   ✅ SWIFT PAYMENT PROCESSED SUCCESSFULLY`);
    console.log(`   Invoice: ${invoiceNumber} | Wire: ${wire_reference}`);
    console.log(`   ════════════════════════════════════════════\n`);

  } catch (err) {
    console.error(`❌ handleSwiftConfirmation failed: ${err.message}`);
  }
}

/**
 * Check for pending SWIFT wires that have been confirmed in bank records.
 * Standalone runner for this script.
 */
async function checkPendingPayments() {
  console.log('\n🔍 Checking for pending payments...');

  try {
    const { data: pending } = await bayuClient
      .from('payments')
      .select('*')
      .eq('payment_status', 'pending')
      .order('created_at', { ascending: false });

    if (!pending || pending.length === 0) {
      console.log('💤 No pending payments found.');
      return;
    }

    console.log(`📋 Found ${pending.length} pending payment(s)`);
    pending.forEach(p => {
      console.log(`   • ${p.invoice_number}: ${p.currency} ${p.amount} (${p.payment_method}) — ${p.wire_reference || 'No wire ref'}`);
    });
  } catch (err) {
    console.error(`❌ checkPendingPayments failed: ${err.message}`);
  }
}

// ─── Self-run ─────────────────────────────────────────────────────────────────
const isMainModule = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMainModule) {
  console.log('🚀 BAYU PAYMENT HANDLER — Layer 8');
  console.log('═══════════════════════════════════════════════════════\n');
  checkPendingPayments()
    .then(() => console.log('✅ Payment handler cycle complete.'))
    .catch(err => console.error('🚨 Fatal error:', err));
}
