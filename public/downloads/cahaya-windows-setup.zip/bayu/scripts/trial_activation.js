// trial_activation.js — Layer 5: Auto-provision 30-day trials for qualified leads
// Usage: node bayu/scripts/trial_activation.js

import { callClaude, callGemini, dualAI } from '../lib/ai.js';
import { bayuClient } from '../lib/supabase.js';
import { sendEmail } from '../lib/outreach.js';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../../.env') });

const TOKEN_API_BASE = process.env.API_BASE_URL || 'http://localhost:8000';
const ADMIN_KEY = process.env.SESSION_SECRET || process.env.ADMIN_KEY || '';

// ─── Product module definitions ───────────────────────────────────────────────
const PRODUCT_MODULES = {
  cahaya: ['NDVI', 'Change Detection', 'Land Cover Classification', 'Time-Series Analysis'],
  sentinel: ['SAR Processing', 'Flood Detection', 'Deforestation Monitoring', 'Soil Moisture'],
  carbon: ['Carbon Stock Estimation', 'MRV Dashboard', 'Baseline Assessment', 'Credit Issuance'],
  compliance: ['EUDR Compliance', 'MSPO Verification', 'Traceability Mapping', 'Audit Reporting'],
  full_suite: ['NDVI', 'Change Detection', 'SAR Processing', 'Carbon MRV', 'EUDR', 'MSPO', 'White-Label Portal']
};

/**
 * Activate a 30-day trial for a specific lead.
 * @param {string} leadId - UUID of the lead
 * @param {string} product - Product key (cahaya, sentinel, carbon, compliance, full_suite)
 * @param {string} deploymentType - 'cloud' | 'local' | 'air_gapped'
 */
export async function activateTrial(leadId, product = 'cahaya', deploymentType = 'local') {
  console.log(`\n🔑 Trial Activation: Starting for lead ${leadId}`);
  console.log(`   Product: ${product} | Deployment: ${deploymentType}`);

  try {
    // ── 1. Fetch lead + organization ──────────────────────────────────────────
    const { data: lead, error: leadErr } = await bayuClient
      .from('leads')
      .select('*, organizations(*)')
      .eq('id', leadId)
      .single();

    if (leadErr || !lead) {
      console.error(`❌ Lead ${leadId} not found: ${leadErr?.message || 'No data'}`);
      return null;
    }

    const org = lead.organizations;
    const orgName = org?.name || lead.company_name || 'Unknown Organization';
    const orgDomain = lead.company_domain || 'unknown.com';
    const industry = lead.metadata?.industry || 'general';

    console.log(`   🏢 Organization: ${orgName} (${orgDomain})`);
    console.log(`   🌍 Industry: ${industry}`);

    // ── 2. Generate 30-day trial token via backend API ────────────────────────
    let trialToken = null;
    const modulesEnabled = PRODUCT_MODULES[product] || PRODUCT_MODULES.cahaya;

    try {
      const tokenPayload = {
        admin_key: ADMIN_KEY,
        org_id: org?.id || lead.org_id,
        org_name: orgName,
        domain: orgDomain,
        tier: 'trial',
        seats: 5,
        vram_target: deploymentType === 'air_gapped' ? '24GB' : '16GB',
        hardware_lock: deploymentType === 'air_gapped',
        valid_days: 30,
        modules: modulesEnabled
      };

      console.log(`   🔐 Requesting trial token from ${TOKEN_API_BASE}/api/token/generate...`);
      const tokenRes = await fetch(`${TOKEN_API_BASE}/api/token/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${ADMIN_KEY}`
        },
        body: JSON.stringify(tokenPayload)
      });

      if (tokenRes.ok) {
        const tokenData = await tokenRes.json();
        trialToken = tokenData.token || tokenData.trial_token || null;
        console.log(`   ✅ Trial token generated: ${trialToken ? trialToken.substring(0, 40) + '...' : 'N/A'}`);
      } else {
        const errText = await tokenRes.text();
        console.warn(`   ⚠️ Token API returned ${tokenRes.status}: ${errText}`);
        // Generate a placeholder token for record-keeping
        trialToken = `TRIAL-${Date.now()}-${leadId.substring(0, 8)}`;
        console.log(`   📌 Using placeholder token: ${trialToken}`);
      }
    } catch (tokenErr) {
      console.warn(`   ⚠️ Token API unreachable: ${tokenErr.message}`);
      trialToken = `TRIAL-${Date.now()}-${leadId.substring(0, 8)}`;
      console.log(`   📌 Using placeholder token: ${trialToken}`);
    }

    // ── 3. Create trial row in database ───────────────────────────────────────
    const startDate = new Date();
    const expiryDate = new Date(startDate.getTime() + 30 * 24 * 60 * 60 * 1000);

    const trialRow = {
      org_id: org?.id || lead.org_id,
      lead_id: leadId,
      product,
      trial_token: trialToken,
      deployment_type: deploymentType,
      modules_enabled: modulesEnabled,
      start_date: startDate.toISOString(),
      expiry_date: expiryDate.toISOString(),
      status: 'active'
    };

    const { data: trial, error: trialErr } = await bayuClient
      .from('trials')
      .insert(trialRow)
      .select()
      .single();

    if (trialErr) {
      console.error(`   ❌ Failed to create trial row: ${trialErr.message}`);
      return null;
    }

    console.log(`   💾 Trial created: ID ${trial.id}`);
    console.log(`   📅 Valid: ${startDate.toISOString().split('T')[0]} → ${expiryDate.toISOString().split('T')[0]}`);

    // ── 4. Generate personalized welcome package via Claude ───────────────────
    console.log(`   🧠 Generating personalized welcome package...`);

    const welcomePrompt = `Generate a personalized trial welcome package for a new customer. Output as JSON with keys: welcome_message, quick_start_guide, next_steps.

CUSTOMER CONTEXT:
- Organization: ${orgName}
- Domain/Industry: ${industry}
- Product: Lenuda ${product.charAt(0).toUpperCase() + product.slice(1)}
- Modules: ${modulesEnabled.join(', ')}
- Deployment Type: ${deploymentType}
- Trial Duration: 30 days (expires ${expiryDate.toISOString().split('T')[0]})
${deploymentType === 'air_gapped' ? '- NOTE: This is an AIR-GAPPED deployment. Include offline activation instructions.' : ''}

REQUIREMENTS:
1. welcome_message: 3-4 paragraphs, warm but professional. Reference their specific industry and how Lenuda modules map to their workflows.
2. quick_start_guide: Step-by-step numbered list (5-8 steps) for getting started with ${product}. ${deploymentType === 'local' ? 'Include local installation steps.' : deploymentType === 'air_gapped' ? 'Include offline activation and USB deployment steps.' : 'Include cloud dashboard login steps.'}
3. next_steps: Array of 3-4 milestone suggestions for their first 30 days.

Output ONLY valid JSON. No markdown.`;

    let welcomePackage;
    try {
      const aiResponse = await callClaude(
        'You are the onboarding specialist for Lenuda, a geospatial intelligence platform by Librae AI Labs. Generate warm, industry-specific welcome content.',
        welcomePrompt,
        { json: true }
      );
      welcomePackage = typeof aiResponse === 'string' ? JSON.parse(aiResponse) : aiResponse;
    } catch (aiErr) {
      console.warn(`   ⚠️ Claude generation failed, using fallback: ${aiErr.message}`);
      welcomePackage = {
        welcome_message: `Welcome to Lenuda, ${orgName}! Your 30-day trial of ${product} is now active. You have access to ${modulesEnabled.join(', ')} modules. Let's get started.`,
        quick_start_guide: '1. Log in to your dashboard\n2. Upload your first dataset\n3. Run your first analysis\n4. Review results\n5. Explore additional modules',
        next_steps: [
          'Week 1: Complete onboarding and run first analysis',
          'Week 2: Integrate with existing workflows',
          'Week 3: Generate first compliance report',
          'Week 4: Evaluate ROI and discuss production license'
        ]
      };
    }

    // ── 5. Send welcome email with trial token + guide ────────────────────────
    console.log(`   📧 Sending welcome email...`);

    const contactEmail = lead.metadata?.contact_email || lead.metadata?.email || `info@${orgDomain}`;
    const emailSubject = `🚀 Your Lenuda ${product.charAt(0).toUpperCase() + product.slice(1)} Trial is Active — Welcome, ${orgName}!`;

    const emailBody = `
<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">
  <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; padding: 32px; border-radius: 12px; margin-bottom: 24px;">
    <h1 style="margin: 0 0 8px 0; font-size: 24px;">Welcome to Lenuda</h1>
    <p style="margin: 0; opacity: 0.8; font-size: 14px;">Your 30-day trial is now active</p>
  </div>

  <div style="margin-bottom: 24px;">
    ${welcomePackage.welcome_message.split('\n').map(p => `<p style="line-height: 1.6; color: #334155;">${p}</p>`).join('')}
  </div>

  <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin-bottom: 24px;">
    <h3 style="margin: 0 0 12px 0; color: #0f172a;">🔑 Your Trial Token</h3>
    <code style="background: #0f172a; color: #22c55e; padding: 12px 16px; border-radius: 6px; display: block; word-break: break-all; font-size: 13px;">${trialToken}</code>
    <p style="margin: 12px 0 0 0; font-size: 12px; color: #64748b;">Valid until ${expiryDate.toISOString().split('T')[0]} · Modules: ${modulesEnabled.join(', ')}</p>
  </div>

  <div style="margin-bottom: 24px;">
    <h3 style="color: #0f172a;">📋 Quick Start Guide</h3>
    <div style="color: #334155; line-height: 1.8;">${welcomePackage.quick_start_guide}</div>
  </div>

  <div style="margin-bottom: 24px;">
    <h3 style="color: #0f172a;">🎯 Recommended Milestones</h3>
    <ul style="color: #334155; line-height: 1.8;">
      ${(welcomePackage.next_steps || []).map(s => `<li>${s}</li>`).join('')}
    </ul>
  </div>

  <div style="border-top: 1px solid #e2e8f0; padding-top: 16px; margin-top: 24px;">
    <p style="color: #64748b; font-size: 13px;">
      Need help? Reply to this email or reach out directly at <a href="mailto:theenesanvk@librae.work">theenesanvk@librae.work</a>
    </p>
    <p style="color: #64748b; font-size: 13px;">— Theenesan VK, Founder · Librae AI Labs</p>
  </div>
</div>`;

    try {
      await sendEmail(contactEmail, emailSubject, emailBody);
      console.log(`   ✅ Welcome email sent to ${contactEmail}`);
    } catch (emailErr) {
      console.error(`   ❌ Email failed: ${emailErr.message}`);
    }

    // ── 6. Update lead pipeline_status → 'trial_active' ─────────────────────
    const { error: updateErr } = await bayuClient
      .from('leads')
      .update({
        lead_status: 'trial_active',
        trial_token: trialToken,
        metadata: {
          ...lead.metadata,
          trial_id: trial.id,
          trial_product: product,
          trial_deployment: deploymentType,
          trial_activated_at: startDate.toISOString(),
          trial_expires_at: expiryDate.toISOString()
        }
      })
      .eq('id', leadId);

    if (updateErr) {
      console.warn(`   ⚠️ Failed to update lead status: ${updateErr.message}`);
    } else {
      console.log(`   ✅ Lead status updated → trial_active`);
    }

    // ── 7. Log complete trial details ─────────────────────────────────────────
    console.log(`\n   ════════════════════════════════════════════`);
    console.log(`   ✅ TRIAL ACTIVATION COMPLETE`);
    console.log(`   ────────────────────────────────────────────`);
    console.log(`   Trial ID:       ${trial.id}`);
    console.log(`   Organization:   ${orgName} (${orgDomain})`);
    console.log(`   Product:        ${product}`);
    console.log(`   Deployment:     ${deploymentType}`);
    console.log(`   Modules:        ${modulesEnabled.join(', ')}`);
    console.log(`   Token:          ${trialToken?.substring(0, 40)}...`);
    console.log(`   Start:          ${startDate.toISOString().split('T')[0]}`);
    console.log(`   Expiry:         ${expiryDate.toISOString().split('T')[0]}`);
    console.log(`   Contact:        ${contactEmail}`);
    console.log(`   ════════════════════════════════════════════\n`);

    return trial;

  } catch (err) {
    console.error(`❌ Trial activation failed for lead ${leadId}: ${err.message}`);
    return null;
  }
}

/**
 * Check for qualified leads that are ready for trial activation and auto-activate.
 */
export async function checkAndActivateTrials() {
  console.log('\n🔍 Scanning for leads ready for trial activation...');

  try {
    // Query leads where pipeline_status = 'qualified' and metadata indicates interest
    const { data: readyLeads, error: queryErr } = await bayuClient
      .from('leads')
      .select('id, company_name, company_domain, metadata')
      .eq('lead_status', 'qualified')
      .order('created_at', { ascending: false });

    if (queryErr) {
      console.error(`❌ Failed to query leads: ${queryErr.message}`);
      return;
    }

    if (!readyLeads || readyLeads.length === 0) {
      console.log('💤 No qualified leads found for trial activation.');
      return;
    }

    // Filter to leads marked as interested
    const interestedLeads = readyLeads.filter(lead => {
      const meta = lead.metadata || {};
      return meta.interested === true || meta.trial_requested === true || meta.demo_completed === true;
    });

    if (interestedLeads.length === 0) {
      console.log(`💤 ${readyLeads.length} qualified leads found, but none marked as interested yet.`);
      return;
    }

    console.log(`📋 Found ${interestedLeads.length} interested, qualified leads for trial activation:\n`);

    let activated = 0;
    let failed = 0;

    for (const lead of interestedLeads) {
      console.log(`──────────────────────────────────────────────`);
      console.log(`🏢 ${lead.company_name} (${lead.company_domain})`);

      // Determine product based on industry/compliance needs
      const industry = (lead.metadata?.industry || '').toLowerCase();
      const needs = (lead.metadata?.compliance_needs || []).map(n => n.toLowerCase());
      let product = 'cahaya'; // default
      if (needs.includes('eudr') || needs.includes('mspo') || industry.includes('plantation')) {
        product = 'compliance';
      } else if (needs.includes('carbon') || industry.includes('carbon')) {
        product = 'carbon';
      } else if (industry.includes('mining') || industry.includes('forestry')) {
        product = 'sentinel';
      }

      // Determine deployment type
      const deploymentType = lead.metadata?.deployment_preference || 
                             (lead.metadata?.air_gapped ? 'air_gapped' : 'local');

      const result = await activateTrial(lead.id, product, deploymentType);
      if (result) {
        activated++;
      } else {
        failed++;
      }

      // Rate limit: 3s between activations
      await new Promise(resolve => setTimeout(resolve, 3000));
    }

    console.log(`\n═══════════════════════════════════════════════════════`);
    console.log(`📊 Trial Activation Batch Complete`);
    console.log(`   ✅ Activated: ${activated}`);
    console.log(`   ❌ Failed: ${failed}`);
    console.log(`   📋 Total processed: ${interestedLeads.length}`);
    console.log(`═══════════════════════════════════════════════════════\n`);

  } catch (err) {
    console.error(`❌ checkAndActivateTrials failed: ${err.message}`);
  }
}

// ─── Self-run ─────────────────────────────────────────────────────────────────
const isMainModule = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMainModule) {
  console.log('🚀 BAYU TRIAL ACTIVATION ENGINE — Layer 5');
  console.log('═══════════════════════════════════════════════════════\n');
  checkAndActivateTrials()
    .then(() => console.log('✅ Trial activation cycle complete.'))
    .catch(err => console.error('🚨 Fatal error:', err));
}
