// renewal_engine.js — Layer 10: Automated renewal lifecycle (90 days before expiry)
// Usage: node bayu/scripts/renewal_engine.js

import { dualAI, callClaude } from '../lib/ai.js';
import { bayuClient } from '../lib/supabase.js';
import { sendEmail, stageForReview } from '../lib/outreach.js';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../../.env') });

// ─── Renewal stage progression ───────────────────────────────────────────────
const RENEWAL_STAGES = {
  NOT_STARTED: 'not_started',
  MONITORING: 'monitoring',
  REPORT_GENERATED: 'report_generated',
  NOTICE_SENT: 'notice_sent',
  REMINDER_SENT: 'reminder_sent',
  INVOICE_SENT: 'invoice_sent',
  RENEWED: 'renewed',
  CHURNED: 'churned',
  WINBACK: 'winback'
};

/**
 * Generate a comprehensive renewal report with ROI calculations.
 * @param {string} orgId - Organization UUID
 * @param {string} paymentId - Payment UUID
 * @returns {object|null} Renewal report JSON
 */
export async function generateRenewalReport(orgId, paymentId) {
  console.log(`\n📝 Generating renewal report for org ${orgId}...`);

  try {
    // Fetch org details
    const { data: org } = await bayuClient
      .from('organizations')
      .select('*')
      .eq('id', orgId)
      .single();

    if (!org) {
      console.error(`   ❌ Organization not found: ${orgId}`);
      return null;
    }

    // Fetch payment details
    const { data: payment } = await bayuClient
      .from('payments')
      .select('*')
      .eq('id', paymentId)
      .single();

    // Fetch usage data for the entire license period
    const licenseStart = payment?.license_start || org.license_start;
    const { data: usageHistory } = await bayuClient
      .from('trial_usage')
      .select('*')
      .eq('trial_id', orgId) // or org_id depending on schema
      .gte('recorded_date', licenseStart || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString())
      .order('recorded_date', { ascending: true });

    // Fetch customer health history
    const { data: healthHistory } = await bayuClient
      .from('customer_health')
      .select('*')
      .eq('org_id', orgId)
      .order('month', { ascending: true });

    // Aggregate metrics
    const totalLogins = (usageHistory || []).reduce((sum, u) => sum + (u.login_count || 0), 0);
    const totalProjects = Math.max(...(usageHistory || [{ projects_created: 0 }]).map(u => u.projects_created || 0));
    const totalDataGB = Math.round((usageHistory || []).reduce((sum, u) => sum + (u.data_uploaded_mb || 0), 0) / 1024);
    const totalApiCalls = (usageHistory || []).reduce((sum, u) => sum + (u.api_calls || 0), 0);
    const avgHealthScore = healthHistory && healthHistory.length > 0
      ? Math.round(healthHistory.reduce((sum, h) => sum + (h.health_score || 0), 0) / healthHistory.length)
      : 65;

    // Estimate ROI
    const manualAuditCost = 8000; // Average cost per manual environmental audit
    const estimatedAuditsSaved = Math.max(totalProjects, 4); // Each project = ~1 audit saved
    const estimatedCostAvoided = estimatedAuditsSaved * manualAuditCost;
    const estimatedHoursSaved = totalProjects * 40; // ~40 hours per manual analysis
    const licenseCost = payment?.amount || 0;
    const roi = licenseCost > 0 ? Math.round(((estimatedCostAvoided - licenseCost) / licenseCost) * 100) : 0;

    const reportData = {
      organization: org.name,
      license_period: {
        start: licenseStart,
        end: payment?.license_end || org.license_end
      },
      usage_summary: {
        total_logins: totalLogins,
        projects_completed: totalProjects,
        data_processed_gb: totalDataGB,
        api_calls: totalApiCalls,
        average_health_score: avgHealthScore
      },
      roi_analysis: {
        license_cost_usd: licenseCost,
        estimated_audits_saved: estimatedAuditsSaved,
        cost_avoided_usd: estimatedCostAvoided,
        hours_saved: estimatedHoursSaved,
        roi_percentage: roi
      }
    };

    // Generate narrative via Claude
    const narrativePrompt = `Generate a compelling renewal report narrative for ${org.name}. Output as JSON with keys: executive_summary, key_achievements, roi_narrative, renewal_recommendation.

DATA:
${JSON.stringify(reportData, null, 2)}

REQUIREMENTS:
1. executive_summary: 2-3 sentences highlighting the license period's value
2. key_achievements: Array of 4-5 bullet points on what they accomplished
3. roi_narrative: Paragraph explaining the ROI in business terms
4. renewal_recommendation: Paragraph with specific renewal suggestion (same tier, upgrade, or multi-year discount)

Be specific with numbers. Frame everything positively. Output ONLY valid JSON.`;

    let narrative;
    try {
      const aiResult = await callClaude(
        'You are the customer success director for Lenuda. Generate persuasive, data-driven renewal reports that demonstrate clear ROI.',
        narrativePrompt,
        { json: true }
      );
      narrative = typeof aiResult === 'string' ? JSON.parse(aiResult) : aiResult;
    } catch (aiErr) {
      console.warn(`   ⚠️ Narrative generation failed: ${aiErr.message}`);
      narrative = {
        executive_summary: `Over the past year, ${org.name} has processed ${totalDataGB} GB of geospatial data across ${totalProjects} projects, achieving an estimated ROI of ${roi}%.`,
        key_achievements: [
          `Processed ${totalDataGB} GB of satellite and geospatial data`,
          `Completed ${totalProjects} analysis projects`,
          `Saved an estimated ${estimatedHoursSaved} hours of manual analysis`,
          `Avoided approximately $${estimatedCostAvoided.toLocaleString()} in manual audit costs`
        ],
        roi_narrative: `Your investment of $${licenseCost.toLocaleString()} has generated an estimated ${roi}% return through operational efficiency and compliance automation.`,
        renewal_recommendation: 'We recommend renewing at your current tier with the option to explore additional modules based on your growing usage patterns.'
      };
    }

    const fullReport = { ...reportData, narrative };
    console.log(`   ✅ Renewal report generated: ROI ${roi}%, ${totalProjects} projects, ${totalDataGB} GB processed`);

    return fullReport;

  } catch (err) {
    console.error(`   ❌ generateRenewalReport failed: ${err.message}`);
    return null;
  }
}

/**
 * Scan all active licenses and execute renewal lifecycle actions.
 */
export async function scanRenewals() {
  console.log('\n🔄 BAYU RENEWAL ENGINE — License Scan');
  console.log('═══════════════════════════════════════════════════════\n');

  try {
    // ── 1. Fetch all payments where license is active ───────────────────────
    const { data: payments, error: payErr } = await bayuClient
      .from('payments')
      .select('*, organizations(*)')
      .eq('payment_status', 'completed')
      .not('license_end', 'is', null);

    if (payErr) {
      console.error(`❌ Failed to fetch payments: ${payErr.message}`);
      return;
    }

    if (!payments || payments.length === 0) {
      console.log('💤 No active licenses found.');
      return;
    }

    console.log(`📋 Scanning ${payments.length} license(s)\n`);

    let renewalActions = {
      monitoring: 0,
      reports_generated: 0,
      notices_sent: 0,
      reminders_sent: 0,
      invoices_sent: 0,
      expired: 0,
      winbacks: 0
    };

    for (const payment of payments) {
      const org = payment.organizations;
      const orgName = org?.name || 'Unknown';
      const licenseEnd = new Date(payment.license_end);
      const now = new Date();
      const daysUntilExpiry = Math.floor((licenseEnd - now) / (1000 * 60 * 60 * 24));

      console.log(`──────────────────────────────────────────────`);
      console.log(`🏢 ${orgName} | License expires: ${licenseEnd.toISOString().split('T')[0]} (${daysUntilExpiry} days)`);

      // Check existing renewal record
      const { data: existingRenewal } = await bayuClient
        .from('renewals')
        .select('*')
        .eq('payment_id', payment.id)
        .single();

      const currentStage = existingRenewal?.renewal_stage || RENEWAL_STAGES.NOT_STARTED;
      const contactEmail = org?.contact_email || payment.customer_email || `admin@${org?.primary_domain || 'customer.com'}`;

      // ── Day -90: Start monitoring ─────────────────────────────────────────
      if (daysUntilExpiry <= 90 && daysUntilExpiry > 60 && currentStage === RENEWAL_STAGES.NOT_STARTED) {
        console.log(`   📍 Day -${Math.abs(daysUntilExpiry)}: Creating renewal record → MONITORING`);

        await bayuClient.from('renewals').upsert({
          org_id: org?.id,
          payment_id: payment.id,
          renewal_stage: RENEWAL_STAGES.MONITORING,
          days_until_expiry: daysUntilExpiry,
          license_end: payment.license_end,
          current_amount: payment.amount,
          currency: payment.currency
        }, { onConflict: 'payment_id' });

        renewalActions.monitoring++;
      }

      // ── Day -60: Generate Renewal Report ──────────────────────────────────
      if (daysUntilExpiry <= 60 && daysUntilExpiry > 30 && currentStage === RENEWAL_STAGES.MONITORING) {
        console.log(`   📊 Day -${Math.abs(daysUntilExpiry)}: Generating renewal report`);

        const report = await generateRenewalReport(org?.id, payment.id);

        if (report) {
          await bayuClient.from('renewals').update({
            renewal_stage: RENEWAL_STAGES.REPORT_GENERATED,
            renewal_report_json: report,
            days_until_expiry: daysUntilExpiry
          }).eq('payment_id', payment.id);

          renewalActions.reports_generated++;
        }
      }

      // ── Day -30: Send renewal notice ──────────────────────────────────────
      if (daysUntilExpiry <= 30 && daysUntilExpiry > 14 && 
          (currentStage === RENEWAL_STAGES.REPORT_GENERATED || currentStage === RENEWAL_STAGES.MONITORING)) {
        console.log(`   📬 Day -${Math.abs(daysUntilExpiry)}: Sending renewal notice`);

        const report = existingRenewal?.renewal_report_json || await generateRenewalReport(org?.id, payment.id);

        try {
          const renewalEmailContent = await callClaude(
            'You are the customer success director for Lenuda. Write a professional renewal notice email.',
            `Write a renewal notice email for ${orgName}. Their license expires in ${daysUntilExpiry} days on ${licenseEnd.toISOString().split('T')[0]}.

RENEWAL REPORT HIGHLIGHTS:
${JSON.stringify(report?.narrative || report?.roi_analysis || {}, null, 2)}

Current plan: ${payment.amount} ${payment.currency} (${org?.plan_tier || 'Professional'})

Include:
1. Appreciation for their partnership
2. Key ROI highlights from their usage
3. Renewal pricing (same tier, offer 10% multi-year discount)
4. Link placeholder to renew
5. Mention any new features/modules added since their last renewal

Output clean HTML for email body.`
          );

          await sendEmail(
            contactEmail,
            `🔄 Your Lenuda License Renewal — Expires ${licenseEnd.toISOString().split('T')[0]}`,
            `<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">${renewalEmailContent}</div>`
          );

          await bayuClient.from('renewals').update({
            renewal_stage: RENEWAL_STAGES.NOTICE_SENT,
            notice_sent_at: now.toISOString(),
            days_until_expiry: daysUntilExpiry
          }).eq('payment_id', payment.id);

          console.log(`   ✅ Renewal notice sent to ${contactEmail}`);
          renewalActions.notices_sent++;
        } catch (emailErr) {
          console.error(`   ❌ Renewal notice failed: ${emailErr.message}`);
        }
      }

      // ── Day -14: Send final reminder ──────────────────────────────────────
      if (daysUntilExpiry <= 14 && daysUntilExpiry > 7 && currentStage === RENEWAL_STAGES.NOTICE_SENT) {
        console.log(`   ⏰ Day -${Math.abs(daysUntilExpiry)}: Sending final reminder`);

        try {
          const reminderContent = await callClaude(
            'You are the founder of Librae AI Labs writing a personal renewal reminder.',
            `Write a personal reminder email from Theenesan VK to ${orgName}. Their Lenuda license expires in ${daysUntilExpiry} days.

Include:
1. Personal note from the founder
2. New features and improvements added in the past year
3. Urgency without being pushy
4. Direct reply option for questions
5. Simple renewal link placeholder

Sign as "Theenesan VK, Founder — Librae AI Labs". Output clean HTML.`
          );

          await sendEmail(
            contactEmail,
            `⏰ ${daysUntilExpiry} days until your Lenuda license expires — ${orgName}`,
            `<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">${reminderContent}</div>`
          );

          await bayuClient.from('renewals').update({
            renewal_stage: RENEWAL_STAGES.REMINDER_SENT,
            reminder_sent_at: now.toISOString(),
            days_until_expiry: daysUntilExpiry
          }).eq('payment_id', payment.id);

          console.log(`   ✅ Reminder sent to ${contactEmail}`);
          renewalActions.reminders_sent++;
        } catch (err) {
          console.error(`   ❌ Reminder failed: ${err.message}`);
        }
      }

      // ── Day -7: Auto-generate renewal invoice ─────────────────────────────
      if (daysUntilExpiry <= 7 && daysUntilExpiry > 0 && 
          (currentStage === RENEWAL_STAGES.REMINDER_SENT || currentStage === RENEWAL_STAGES.NOTICE_SENT)) {
        console.log(`   📄 Day -${Math.abs(daysUntilExpiry)}: Generating renewal invoice`);

        try {
          // Create new proposal (version N+1) with renewal pricing
          const renewalAmount = payment.amount; // Same pricing for renewal
          const { data: renewalProposal, error: propErr } = await bayuClient
            .from('proposals')
            .insert({
              org_id: org?.id,
              proposal_type: 'renewal',
              pricing_tier: org?.plan_tier || 'professional',
              amount: renewalAmount,
              currency: payment.currency,
              modules: payment.modules || ['Full Suite'],
              valid_days: 365,
              status: 'pending_approval',
              metadata: {
                renewal_of_payment: payment.id,
                previous_amount: payment.amount,
                version: (existingRenewal?.renewal_version || 0) + 1
              }
            })
            .select()
            .single();

          if (propErr) {
            console.error(`   ❌ Failed to create renewal proposal: ${propErr.message}`);
          } else {
            console.log(`   📋 Renewal proposal created: ${renewalProposal.id}`);

            // Route through CEO-001 for strategic pricing approval
            console.log(`   🧠 Routing to CEO-001 for pricing approval`);
            await bayuClient.from('approval_queue').insert({
              item_type: 'renewal_invoice',
              priority: renewalAmount >= 50000 ? 'critical' : 'high',
              org_id: org?.id,
              summary: `Renewal invoice for ${orgName}: ${payment.currency} ${renewalAmount?.toLocaleString()} (${org?.plan_tier || 'Professional'})`,
              status: 'pending',
              ai_analysis: {
                deal_value_usd: renewalAmount,
                customer: orgName,
                current_tier: org?.plan_tier,
                days_until_expiry: daysUntilExpiry,
                proposal_id: renewalProposal.id
              }
            });
          }

          await bayuClient.from('renewals').update({
            renewal_stage: RENEWAL_STAGES.INVOICE_SENT,
            invoice_sent_at: now.toISOString(),
            renewal_proposal_id: renewalProposal?.id,
            days_until_expiry: daysUntilExpiry
          }).eq('payment_id', payment.id);

          renewalActions.invoices_sent++;
        } catch (err) {
          console.error(`   ❌ Invoice generation failed: ${err.message}`);
        }
      }

      // ── Day 0: License expires ────────────────────────────────────────────
      if (daysUntilExpiry <= 0 && daysUntilExpiry > -7 && currentStage !== RENEWAL_STAGES.RENEWED && currentStage !== RENEWAL_STAGES.CHURNED) {
        console.log(`   ⛔ Day 0: License EXPIRED`);

        await bayuClient
          .from('organizations')
          .update({ status: 'expired' })
          .eq('id', org?.id);

        await bayuClient.from('renewals').update({
          renewal_stage: RENEWAL_STAGES.CHURNED,
          churned_at: now.toISOString(),
          days_until_expiry: daysUntilExpiry
        }).eq('payment_id', payment.id);

        renewalActions.expired++;
      }

      // ── Day +7: Win-back sequence ─────────────────────────────────────────
      if (daysUntilExpiry <= -7 && currentStage === RENEWAL_STAGES.CHURNED) {
        console.log(`   💌 Day +${Math.abs(daysUntilExpiry)}: Initiating win-back sequence`);

        try {
          const winbackContent = await callClaude(
            'You are Theenesan VK, founder of Librae AI Labs, writing a sincere win-back email.',
            `Write a win-back email for ${orgName} whose Lenuda license expired ${Math.abs(daysUntilExpiry)} days ago.

Include:
1. Acknowledge they may have had reasons not to renew
2. Offer a special re-engagement discount (20% off annual renewal)
3. Highlight 2-3 major improvements since they last used the platform
4. Offer a free 14-day re-activation to evaluate new features
5. Personal touch — mention you value their business
6. Simple CTA to reply or click a link

Be genuine, not desperate. Output clean HTML. Sign as "Theenesan VK, Founder — Librae AI Labs".`
          );

          await sendEmail(
            contactEmail,
            `We'd love to have you back, ${orgName} — Special offer inside`,
            `<div style="font-family: 'Inter', Arial, sans-serif; max-width: 640px; margin: 0 auto; padding: 24px;">${winbackContent}</div>`
          );

          await bayuClient.from('renewals').update({
            renewal_stage: RENEWAL_STAGES.WINBACK,
            winback_sent_at: now.toISOString()
          }).eq('payment_id', payment.id);

          console.log(`   ✅ Win-back email sent to ${contactEmail}`);
          renewalActions.winbacks++;
        } catch (err) {
          console.error(`   ❌ Win-back email failed: ${err.message}`);
        }
      }
    }

    // ── Summary ─────────────────────────────────────────────────────────────
    console.log(`\n═══════════════════════════════════════════════════════`);
    console.log(`🔄 Renewal Engine Summary`);
    console.log(`   Total Licenses Scanned: ${payments.length}`);
    console.log(`   📍 Started Monitoring:  ${renewalActions.monitoring}`);
    console.log(`   📊 Reports Generated:   ${renewalActions.reports_generated}`);
    console.log(`   📬 Notices Sent:        ${renewalActions.notices_sent}`);
    console.log(`   ⏰ Reminders Sent:      ${renewalActions.reminders_sent}`);
    console.log(`   📄 Invoices Generated:  ${renewalActions.invoices_sent}`);
    console.log(`   ⛔ Expired:             ${renewalActions.expired}`);
    console.log(`   💌 Win-back Attempts:   ${renewalActions.winbacks}`);
    console.log(`═══════════════════════════════════════════════════════\n`);

  } catch (err) {
    console.error(`❌ scanRenewals failed: ${err.message}`);
  }
}

// ─── Self-run ─────────────────────────────────────────────────────────────────
const isMainModule = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMainModule) {
  console.log('🚀 BAYU RENEWAL ENGINE — Layer 10');
  console.log('═══════════════════════════════════════════════════════\n');
  scanRenewals()
    .then(() => console.log('✅ Renewal scan complete.'))
    .catch(err => console.error('🚨 Fatal error:', err));
}
