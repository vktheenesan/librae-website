/**
 * BAYU Inbox API Routes — scripts/inbox_api.js
 * =============================================
 * Express-compatible route handlers for the Agentic Inbox system.
 *
 * Routes:
 *   GET  /api/inbox         — paginated list of inbox_emails with drafts
 *   GET  /api/inbox/stats   — counts: unread, pending_review, sent_today, avg_response_time
 *   GET  /api/inbox/:id     — single email + draft
 *   POST /api/inbox/send    — approve and send a draft
 *   POST /api/inbox/reject  — reject a draft
 *   POST /api/inbox/edit    — edit body then send
 *
 * All write operations require body: { draft_id, ... }
 * No auto-sending — all require explicit founder action.
 */

import { bayuClient } from '../lib/supabase.js';
import {
  sendApprovedDraft,
  rejectDraft,
  getInboxStats,
} from '../lib/agentic_inbox.js';

// ─── Helper ───────────────────────────────────────────────────────────────────
function sendJSON(res, status, data) {
  res.status(status).json(data);
}

function asyncHandler(fn) {
  return async (req, res, next) => {
    try {
      await fn(req, res, next);
    } catch (err) {
      console.error(`[inbox-api] ❌ ${err.message}`);
      sendJSON(res, 500, { error: err.message });
    }
  };
}

// ─── GET /api/inbox/stats ─────────────────────────────────────────────────────
export const getStats = asyncHandler(async (req, res) => {
  const stats = await getInboxStats();
  sendJSON(res, 200, stats);
});

// ─── GET /api/inbox ───────────────────────────────────────────────────────────
export const listEmails = asyncHandler(async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  const limit = Math.min(50, parseInt(req.query.limit || '20', 10));
  const offset = (page - 1) * limit;
  const status = req.query.status; // optional filter: unread|triaged|replied|ignored|spam

  let query = bayuClient
    .from('inbox_emails')
    .select(`
      id, message_id, from_email, from_name, subject,
      received_at, status, intent, urgency, sentiment,
      ai_confidence, lead_id, thread_id, created_at,
      inbox_drafts (
        id, draft_subject, draft_body, ai_confidence, status, edited_body, sent_at, approved_by, created_at
      )
    `, { count: 'exact' })
    .order('received_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error, count } = await query;

  if (error) {
    return sendJSON(res, 500, { error: error.message });
  }

  sendJSON(res, 200, {
    emails: data || [],
    pagination: {
      page,
      limit,
      total: count || 0,
      pages: Math.ceil((count || 0) / limit),
    },
  });
});

// ─── GET /api/inbox/:id ───────────────────────────────────────────────────────
export const getEmail = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const { data, error } = await bayuClient
    .from('inbox_emails')
    .select(`
      *,
      inbox_drafts (*)
    `)
    .eq('id', id)
    .single();

  if (error || !data) {
    return sendJSON(res, 404, { error: 'Email not found' });
  }

  sendJSON(res, 200, data);
});

// ─── POST /api/inbox/send ─────────────────────────────────────────────────────
// Approve and send a draft as-is
export const sendDraft = asyncHandler(async (req, res) => {
  const { draft_id, approved_by = 'founder' } = req.body;

  if (!draft_id) {
    return sendJSON(res, 400, { error: 'draft_id is required' });
  }

  const result = await sendApprovedDraft(draft_id, approved_by, null);
  sendJSON(res, 200, { success: true, ...result });
});

// ─── POST /api/inbox/edit ─────────────────────────────────────────────────────
// Edit draft body then send
export const editAndSend = asyncHandler(async (req, res) => {
  const { draft_id, edited_body, approved_by = 'founder' } = req.body;

  if (!draft_id) {
    return sendJSON(res, 400, { error: 'draft_id is required' });
  }
  if (!edited_body || edited_body.trim().length === 0) {
    return sendJSON(res, 400, { error: 'edited_body is required and cannot be empty' });
  }

  // Update draft as edited before sending
  await bayuClient
    .from('inbox_drafts')
    .update({ status: 'edited', edited_body: edited_body.trim() })
    .eq('id', draft_id);

  const result = await sendApprovedDraft(draft_id, approved_by, edited_body.trim());
  sendJSON(res, 200, { success: true, ...result });
});

// ─── POST /api/inbox/reject ───────────────────────────────────────────────────
export const rejectDraftRoute = asyncHandler(async (req, res) => {
  const { draft_id, rejected_by = 'founder' } = req.body;

  if (!draft_id) {
    return sendJSON(res, 400, { error: 'draft_id is required' });
  }

  const result = await rejectDraft(draft_id, rejected_by);
  sendJSON(res, 200, result);
});

// ─── REGISTER ROUTES (Express Router) ────────────────────────────────────────

/**
 * Register all inbox API routes on an Express router or app.
 *
 * Usage in your main server:
 *   import { registerInboxRoutes } from './scripts/inbox_api.js';
 *   registerInboxRoutes(app);
 *
 * Or with a prefix:
 *   const router = express.Router();
 *   registerInboxRoutes(router);
 *   app.use('/api', router);
 */
export function registerInboxRoutes(router) {
  router.get('/inbox/stats', getStats);
  router.get('/inbox', listEmails);
  router.get('/inbox/:id', getEmail);
  router.post('/inbox/send', sendDraft);
  router.post('/inbox/edit', editAndSend);
  router.post('/inbox/reject', rejectDraftRoute);

  console.log('[inbox-api] ✅ Inbox API routes registered:');
  console.log('   GET  /api/inbox');
  console.log('   GET  /api/inbox/stats');
  console.log('   GET  /api/inbox/:id');
  console.log('   POST /api/inbox/send');
  console.log('   POST /api/inbox/edit');
  console.log('   POST /api/inbox/reject');
}
