-- ============================================================================
-- Migration 005: Sub-Agents, Agent Programs, Budget, Licensing & Learning
-- ============================================================================
-- BAYU Commercial OS — Sprint 20
-- Applied to: ifkurcuwplbftjaubvda (BAYU Supabase)
-- ============================================================================

-- Sub-Agents Registry
CREATE TABLE IF NOT EXISTS sub_agents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  parent_agent TEXT NOT NULL, -- 'cfo', 'cto', 'cmo', 'coo', 'csr'
  name TEXT NOT NULL,
  task_description TEXT NOT NULL,
  model TEXT DEFAULT 'gpt-4o',
  status TEXT DEFAULT 'active', -- 'active', 'completed', 'archived', 'failed'
  result JSONB,
  tokens_used INTEGER DEFAULT 0,
  cost_usd NUMERIC(10,4) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  archived_at TIMESTAMPTZ
);

-- Agent Programs (reusable logic created by agents)
CREATE TABLE IF NOT EXISTS agent_programs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_by TEXT NOT NULL, -- parent agent key
  name TEXT NOT NULL,
  description TEXT,
  program_code TEXT NOT NULL, -- stored as prompt template or JS snippet
  program_type TEXT DEFAULT 'prompt_template', -- 'prompt_template', 'workflow', 'analysis'
  usage_count INTEGER DEFAULT 0,
  last_used TIMESTAMPTZ,
  effectiveness_score NUMERIC(5,2) DEFAULT 0, -- 0-100 learning score
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent Budget Log (daily spend tracking)
CREATE TABLE IF NOT EXISTS agent_budget_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  agent_key TEXT NOT NULL,
  log_date DATE DEFAULT CURRENT_DATE,
  tokens_used INTEGER DEFAULT 0,
  cost_usd NUMERIC(10,4) DEFAULT 0,
  ceiling_usd NUMERIC(10,2) DEFAULT 10.00,
  sub_agents_spawned INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(agent_key, log_date)
);

-- License Tokens for Cahaya
CREATE TABLE IF NOT EXISTS license_tokens (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  organization_name TEXT NOT NULL,
  contact_email TEXT,
  token_hash TEXT NOT NULL UNIQUE, -- SHA-256 hash of the actual token
  token_preview TEXT, -- first 8 chars for display
  license_tier TEXT DEFAULT '1yr', -- '1yr', '5yr', '10yr', '25yr'
  issued_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  grace_period_days INTEGER DEFAULT 90,
  is_active BOOLEAN DEFAULT TRUE,
  renewal_count INTEGER DEFAULT 0,
  last_renewed_at TIMESTAMPTZ,
  annual_service_fee NUMERIC(12,2),
  escalation_percent NUMERIC(5,2) DEFAULT 5.00, -- yearly price increase %
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent Learning Log (outcome tracking for prompt refinement)
CREATE TABLE IF NOT EXISTS agent_learning_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  agent_key TEXT NOT NULL,
  action_type TEXT NOT NULL, -- 'outreach', 'proposal', 'call_script', 'analysis'
  input_summary TEXT,
  output_summary TEXT,
  outcome TEXT, -- 'success', 'failure', 'partial', 'pending'
  outcome_details JSONB,
  learning_extracted TEXT, -- what the agent learned
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_sub_agents_parent ON sub_agents(parent_agent);
CREATE INDEX IF NOT EXISTS idx_sub_agents_status ON sub_agents(status);
CREATE INDEX IF NOT EXISTS idx_agent_programs_creator ON agent_programs(created_by);
CREATE INDEX IF NOT EXISTS idx_agent_budget_date ON agent_budget_log(agent_key, log_date);
CREATE INDEX IF NOT EXISTS idx_license_tokens_active ON license_tokens(is_active);
CREATE INDEX IF NOT EXISTS idx_license_tokens_expires ON license_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_agent_learning_agent ON agent_learning_log(agent_key);
