-- ============================================================================
-- Migration 003: Agentic Inbox System
-- ============================================================================
-- BAYU Commercial OS — Agentic Inbox Layer
-- Applied to: ifkurcuwplbftjaubvda (BAYU Supabase)
-- 
-- Creates:
--   - inbox_emails   : Raw incoming emails with AI triage metadata
--   - inbox_drafts   : AI-generated draft replies awaiting approval
--   - Indexes, RLS policies, updated_at triggers
-- ============================================================================

-- ─── inbox_emails ─────────────────────────────────────────────────────────────
-- Stores every inbound email read by BAYU from theenesanvk@librae.work

CREATE TABLE IF NOT EXISTS inbox_emails (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id    TEXT        UNIQUE,                    -- RFC 2822 Message-ID header
  from_email    TEXT        NOT NULL,
  from_name     TEXT,
  subject       TEXT,
  body_text     TEXT,
  received_at   TIMESTAMPTZ,
  
  -- Status lifecycle: unread → triaged → replied/ignored/spam
  status        TEXT        NOT NULL DEFAULT 'unread'
    CHECK (status IN ('unread', 'triaged', 'replied', 'ignored', 'spam')),
  
  -- AI triage results
  intent        TEXT
    CHECK (intent IN (
      'PROSPECT_REPLY', 'CUSTOMER_SUPPORT', 'TRIAL_INQUIRY',
      'PAYMENT_QUERY', 'UNSUBSCRIBE', 'SPAM', 'OTHER'
    )),
  urgency       TEXT        NOT NULL DEFAULT 'medium'
    CHECK (urgency IN ('high', 'medium', 'low')),
  sentiment     TEXT
    CHECK (sentiment IN ('positive', 'neutral', 'negative', 'objection')),
  
  -- CRM linkage
  lead_id       UUID        REFERENCES leads(id) ON DELETE SET NULL,
  thread_id     TEXT,       -- For email threading (In-Reply-To / References)
  
  -- AI draft
  draft_reply   TEXT,
  ai_confidence FLOAT,
  
  -- Timestamps
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE inbox_emails IS 'Inbound emails managed by BAYU Agentic Inbox — theenesanvk@librae.work';
COMMENT ON COLUMN inbox_emails.intent IS 'AI-classified email intent category';
COMMENT ON COLUMN inbox_emails.urgency IS 'AI-assessed response urgency level';
COMMENT ON COLUMN inbox_emails.ai_confidence IS '0.0–1.0 confidence score for the AI draft reply';


-- ─── inbox_drafts ─────────────────────────────────────────────────────────────
-- AI-generated reply drafts awaiting founder approval via CEO-001

CREATE TABLE IF NOT EXISTS inbox_drafts (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  inbox_email_id  UUID        NOT NULL REFERENCES inbox_emails(id) ON DELETE CASCADE,
  
  -- Draft content
  draft_subject   TEXT,
  draft_body      TEXT,
  ai_confidence   FLOAT,      -- 0.0 to 1.0
  
  -- Status lifecycle: pending → approved/rejected/edited → sent
  status          TEXT        NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'approved', 'rejected', 'sent', 'edited')),
  
  -- Edit / approval tracking
  edited_body     TEXT,       -- Founder-edited version (if edited before sending)
  sent_at         TIMESTAMPTZ,
  approved_by     TEXT,       -- 'founder' | 'auto' | user email
  
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE inbox_drafts IS 'AI-drafted email replies awaiting founder approval — never auto-sent';
COMMENT ON COLUMN inbox_drafts.ai_confidence IS 'Model confidence score. High-confidence (>0.85) drafts are highlighted in CEO-001';
COMMENT ON COLUMN inbox_drafts.edited_body IS 'If the founder edited the draft before sending, the final version is stored here';


-- ─── INDEXES ──────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_inbox_emails_status       ON inbox_emails(status);
CREATE INDEX IF NOT EXISTS idx_inbox_emails_from_email   ON inbox_emails(from_email);
CREATE INDEX IF NOT EXISTS idx_inbox_emails_received_at  ON inbox_emails(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_inbox_emails_urgency      ON inbox_emails(urgency);
CREATE INDEX IF NOT EXISTS idx_inbox_emails_intent       ON inbox_emails(intent);
CREATE INDEX IF NOT EXISTS idx_inbox_emails_lead_id      ON inbox_emails(lead_id);
CREATE INDEX IF NOT EXISTS idx_inbox_drafts_status       ON inbox_drafts(status);
CREATE INDEX IF NOT EXISTS idx_inbox_drafts_email_id     ON inbox_drafts(inbox_email_id);
CREATE INDEX IF NOT EXISTS idx_inbox_drafts_sent_at      ON inbox_drafts(sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_inbox_drafts_confidence   ON inbox_drafts(ai_confidence DESC);


-- ─── UPDATED_AT TRIGGER ───────────────────────────────────────────────────────

-- Generic trigger function (may already exist from earlier migrations)
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to inbox_emails
DROP TRIGGER IF EXISTS inbox_emails_updated_at ON inbox_emails;
CREATE TRIGGER inbox_emails_updated_at
  BEFORE UPDATE ON inbox_emails
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ─── ROW LEVEL SECURITY ───────────────────────────────────────────────────────

-- Enable RLS on both tables
ALTER TABLE inbox_emails ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbox_drafts ENABLE ROW LEVEL SECURITY;

-- Service role has full access (used by BAYU backend)
CREATE POLICY IF NOT EXISTS "service_role_full_inbox_emails"
  ON inbox_emails FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY IF NOT EXISTS "service_role_full_inbox_drafts"
  ON inbox_drafts FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Authenticated users (CEO-001 panel) can read and update (for approval actions)
CREATE POLICY IF NOT EXISTS "authed_read_inbox_emails"
  ON inbox_emails FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY IF NOT EXISTS "authed_read_inbox_drafts"
  ON inbox_drafts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY IF NOT EXISTS "authed_update_inbox_drafts"
  ON inbox_drafts FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (status IN ('approved', 'rejected', 'sent', 'edited'));


-- ─── REALTIME ─────────────────────────────────────────────────────────────────
-- Enable Realtime for CEO-001 panel live updates

ALTER PUBLICATION supabase_realtime ADD TABLE inbox_emails;
ALTER PUBLICATION supabase_realtime ADD TABLE inbox_drafts;


-- ─── VERIFICATION QUERY ───────────────────────────────────────────────────────
-- Run this to verify migration succeeded:
-- SELECT table_name FROM information_schema.tables
-- WHERE table_schema = 'public'
-- AND table_name IN ('inbox_emails', 'inbox_drafts');
