-- 006_telemetry_and_chat.sql
-- Formalize telemetry_log and add chat_sessions for BAYU learning
-- Applied to shared BAYU Supabase project

-- ── Telemetry Log (formalize existing table) ──
CREATE TABLE IF NOT EXISTS telemetry_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action TEXT NOT NULL,
  domain TEXT DEFAULT 'website',
  compute_seconds NUMERIC(12,2) DEFAULT 0,
  data_volume_mb NUMERIC(12,2) DEFAULT 0,
  credits_consumed NUMERIC(12,4) DEFAULT 0,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_telemetry_action ON telemetry_log(action);
CREATE INDEX IF NOT EXISTS idx_telemetry_created ON telemetry_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_domain ON telemetry_log(domain);

-- ── Chat Sessions (BAYU conversation history for learning) ──
CREATE TABLE IF NOT EXISTS chat_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source TEXT DEFAULT 'website' CHECK (source IN ('website', 'desktop_client')),
  user_identifier TEXT,
  messages JSONB DEFAULT '[]',
  message_count INTEGER DEFAULT 0,
  first_message_at TIMESTAMPTZ DEFAULT NOW(),
  last_message_at TIMESTAMPTZ DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_chat_sessions_source ON chat_sessions(source);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_last_msg ON chat_sessions(last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user ON chat_sessions(user_identifier);

-- ── Add hardware_hash column to trials if not exists ──
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'trials' AND column_name = 'hardware_hash'
  ) THEN
    ALTER TABLE trials ADD COLUMN hardware_hash TEXT;
  END IF;
END $$;

-- ── Stripe payment records ──
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID REFERENCES organizations(id),
  lead_id UUID REFERENCES leads(id),
  stripe_session_id TEXT UNIQUE,
  stripe_payment_intent TEXT,
  tier TEXT NOT NULL,
  product TEXT DEFAULT 'cahaya',
  amount_cents INTEGER NOT NULL,
  currency TEXT DEFAULT 'usd',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  customer_email TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payments_org ON payments(org_id);
CREATE INDEX IF NOT EXISTS idx_payments_stripe ON payments(stripe_session_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);

-- ── RLS Policies ──
ALTER TABLE telemetry_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Service role has full access (all website API calls use service role key)
CREATE POLICY "Service role full access to telemetry"
ON telemetry_log FOR ALL
USING (true)
WITH CHECK (true);

CREATE POLICY "Service role full access to chat_sessions"
ON chat_sessions FOR ALL
USING (true)
WITH CHECK (true);

CREATE POLICY "Service role full access to payments"
ON payments FOR ALL
USING (true)
WITH CHECK (true);
