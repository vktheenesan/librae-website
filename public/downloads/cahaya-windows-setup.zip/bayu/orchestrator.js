/**
 * BAYU Orchestrator — Master Cron Scheduler
 * ==========================================
 * Single process that runs all 10 BAYU layers on schedule.
 * 
 * Schedule:
 *   Every 10 min  → Agentic Inbox (new layer)
 *   Every 15 min  → Target discovery (Layer 1)
 *   Every 30 min  → Founder outbound (Layer 2)
 *   Hourly        → Nurture loop (Layer 3), Learning sync
 *   Daily 08:00   → Trial monitoring (Layer 6)
 *   Daily 09:00   → Customer success reports (Layer 9)
 *   Weekly Mon     → Renewal scanner (Layer 10)
 *   Weekly Fri     → CEO-001 digest (Layer 4)
 *   On-demand     → Trial activation, Payment, Proposals (Layers 5, 7, 8)
 * 
 * Usage: node bayu/orchestrator.js
 */

import cron from 'node-cron';
import { fileURLToPath } from 'url';
import path from 'path';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, '../.env') });

// Import all BAYU layers
import { bayuClient } from './lib/supabase.js';
import { startInboxWatcher } from './lib/agentic_inbox.js';

// Dynamic imports for each layer (lazy-loaded to avoid circular deps)
async function runLayer(name, importPath, fnName) {
  const timestamp = new Date().toISOString().substring(11, 19);
  console.log(`\n⏰ [${timestamp}] BAYU ORCHESTRATOR → Starting: ${name}`);
  console.log('─'.repeat(60));
  
  try {
    const module = await import(importPath);
    if (module[fnName]) {
      await module[fnName]();
      console.log(`✅ [${timestamp}] ${name} — completed successfully`);
    } else {
      console.warn(`⚠️ Function ${fnName} not found in ${importPath}`);
    }
  } catch (error) {
    console.error(`❌ [${timestamp}] ${name} — FAILED:`, error.message);
    // Log failure to Supabase for monitoring
    try {
      await bayuClient.from('learning_db').insert({
        category: 'industry_pattern',
        content: `Orchestrator failure: ${name} — ${error.message}`,
        industry: 'system',
        domain: 'bayu_ops'
      });
    } catch (logErr) {
      // Silently fail logging
    }
  }
}

// ============================================================================
// CRON SCHEDULE DEFINITIONS
// ============================================================================

console.log('');
console.log('╔══════════════════════════════════════════════════════════════╗');
console.log('║              BAYU ORCHESTRATOR v2.0 — STARTING              ║');
console.log('║          11-Layer Commercial Operating System               ║');
console.log('╚══════════════════════════════════════════════════════════════╝');
console.log('');
console.log('📅 Registered Schedules:');
console.log('   continuous     → Agentic Inbox: Email Watch (every 10 min)');
console.log('   */15 * * * *  → Layer 1: Target Discovery');
console.log('   */30 * * * *  → Layer 2: Founder Outbound');
console.log('   0 * * * *     → Layer 3: Nurture Loop');
console.log('   0 8 * * *     → Layer 6: Trial Monitoring');
console.log('   0 9 * * *     → Layer 9: Customer Success');
console.log('   0 10 * * 1    → Layer 10: Renewal Scanner');
console.log('   0 18 * * 5    → CEO-001: Weekly Digest');
console.log('');

// Layer 1: Target Discovery — every 15 minutes
cron.schedule('*/15 * * * *', () => {
  runLayer(
    'Layer 1: Target Discovery',
    './scripts/target_discovery.js',
    'runDiscovery'
  );
});

// Layer 2: Founder Outbound — every 30 minutes
cron.schedule('*/30 * * * *', () => {
  runLayer(
    'Layer 2: Founder Outbound v3',
    './scripts/founder_outbound_v3.js',
    'executeFounderOutreach'
  );
});

// Layer 3: Nurture Loop — hourly
cron.schedule('0 * * * *', () => {
  runLayer(
    'Layer 3: Nurture Loop',
    './scripts/nurture_loop.js',
    'runNurtureLoop'
  );
});

// Layer 6: Trial Monitoring — daily at 08:00
cron.schedule('0 8 * * *', () => {
  runLayer(
    'Layer 6: Trial Monitor',
    './scripts/trial_monitor.js',
    'monitorAllTrials'
  );
});

// Layer 9: Customer Success — daily at 09:00
cron.schedule('0 9 * * *', () => {
  runLayer(
    'Layer 9: Customer Success',
    './scripts/customer_success.js',
    'runCustomerSuccess'
  );
});

// Layer 10: Renewal Scanner — weekly Monday at 10:00
cron.schedule('0 10 * * 1', () => {
  runLayer(
    'Layer 10: Renewal Engine',
    './scripts/renewal_engine.js',
    'scanRenewals'
  );
});

// CEO-001: Weekly Digest — Friday at 18:00
cron.schedule('0 18 * * 5', () => {
  runLayer(
    'CEO-001: Weekly Approvals Digest',
    './scripts/ceo_001.js',
    'sendPendingApprovalsDigest'
  );
});

// SWIFT Audit — daily at 07:00 (check for overnight wires)
cron.schedule('0 7 * * *', () => {
  runLayer(
    'Finance: SWIFT Audit',
    './scripts/swift_audit.js',
    'runSwiftAudit'
  );
});

// Sync LENUDA Signals — every 2 hours
cron.schedule('0 */2 * * *', () => {
  runLayer(
    'Sync: LENUDA Signals',
    './scripts/sync_lenuda_signals.js',
    'syncSignals'
  );
});

// ============================================================================
// AGENTIC INBOX WATCHER — Continuous background process
// ============================================================================

// Start inbox watcher as a persistent background process
// Polls IMAP every 10 minutes with exponential backoff on errors
let inboxWatcher = null;

try {
  inboxWatcher = startInboxWatcher();

  inboxWatcher.emitter.on('new_email', ({ emailId, email }) => {
    const ts = new Date().toISOString().substring(11, 19);
    console.log(`\n📬 [${ts}] INBOX → New email from ${email.from_email}: "${email.subject?.substring(0, 60)}"`);
  });

  inboxWatcher.emitter.on('triage_complete', ({ emailId, email, triage }) => {
    const ts = new Date().toISOString().substring(11, 19);
    const urgencyEmoji = triage.urgency === 'high' ? '🔴' : triage.urgency === 'medium' ? '🟡' : '🟢';
    console.log(`   ${urgencyEmoji} [${ts}] TRIAGE → ${triage.intent} | urgency: ${triage.urgency} | confidence: ${(triage.ai_confidence * 100).toFixed(0)}%`);
  });

  inboxWatcher.emitter.on('draft_ready', async ({ emailId, draftId, email, triage, isHighUrgency }) => {
    const ts = new Date().toISOString().substring(11, 19);
    console.log(`   📝 [${ts}] DRAFT READY → ${draftId} (${isHighUrgency ? '🔴 HIGH URGENCY — Founder alert triggered' : 'queued for review'})`);

    // Log all inbox activity to BAYU learning DB for telemetry
    try {
      await bayuClient.from('learning_db').insert({
        category: 'inbox_activity',
        content: `Inbox draft ready: ${triage.intent} from ${email.from_email} — urgency: ${triage.urgency}`,
        industry: 'system',
        domain: 'bayu_inbox'
      });
    } catch (_) { /* Non-fatal */ }
  });

  console.log('✅ Agentic Inbox Watcher started — monitoring theenesanvk@librae.work');
} catch (err) {
  console.error(`⚠️  Agentic Inbox Watcher failed to start: ${err.message}`);
  console.error('   Ensure INBOX_IMAP_HOST and INBOX_IMAP_PASS are set in .env');
}

// Gracefully stop inbox watcher on shutdown
process.on('SIGTERM', () => {
  inboxWatcher?.stop();
});

// ============================================================================
// STARTUP: Run immediate health check
// ============================================================================

async function healthCheck() {
  console.log('🏥 Running startup health check...\n');
  
  const checks = [
    { name: 'BAYU Supabase', test: async () => {
      const { data } = await bayuClient.from('organizations').select('id').limit(1);
      return data && data.length > 0;
    }},
    { name: 'OpenAI API Key',   test: async () => !!process.env.OPENAI_API_KEY },
    { name: 'Inbox IMAP Host',  test: async () => !!process.env.INBOX_IMAP_HOST },
    { name: 'Inbox IMAP Pass',  test: async () => !!process.env.INBOX_IMAP_PASS },
    { name: 'Inbox SMTP Pass',  test: async () => !!process.env.INBOX_SMTP_PASS },
    { name: 'Gemini API Key', test: async () => !!process.env.GEMINI_API_KEY },
    { name: 'Claude API Key', test: async () => !!process.env.ANTHROPIC_API_KEY },
    { name: 'Qwen API Key', test: async () => !!process.env.ALIBABA_MODEL_STUDIO_API_KEY },
    { name: 'Stripe Key', test: async () => !!process.env.STRIPE_RESTRICTED_KEY },
    { name: 'Unipile Key', test: async () => !!process.env.UNIPILE_API_KEY },
    { name: 'Resend Key', test: async () => !!process.env.RESEND_API_KEY },
    { name: 'Meeting BaaS Key', test: async () => !!process.env.MEETING_BAAS_API_KEY },
  ];
  
  for (const check of checks) {
    try {
      const ok = await check.test();
      console.log(`   ${ok ? '✅' : '⚠️'} ${check.name}: ${ok ? 'OK' : 'NOT CONFIGURED'}`);
    } catch (e) {
      console.log(`   ❌ ${check.name}: ERROR — ${e.message}`);
    }
  }
  
  console.log('\n🚀 BAYU Orchestrator is running. Waiting for scheduled triggers...\n');
}

healthCheck();

// Keep process alive
process.on('SIGINT', () => {
  console.log('\n🛑 BAYU Orchestrator shutting down gracefully...');
  process.exit(0);
});

process.on('uncaughtException', (err) => {
  console.error('🚨 Uncaught Exception:', err.message);
  // Don't exit — keep the orchestrator running
});

process.on('unhandledRejection', (err) => {
  console.error('🚨 Unhandled Rejection:', err);
  // Don't exit — keep the orchestrator running
});
