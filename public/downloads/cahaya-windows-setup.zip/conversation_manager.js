/**
 * =============================================================================
 * CAHAYA SOVEREIGN — ConversationManager
 * =============================================================================
 * Production-quality, dependency-free conversation manager for the CAHAYA
 * Sovereign AI workspace. Exposes window.ConversationManager with a full
 * IndexedDB persistence layer, AI Library management, connection registry,
 * and a fully self-contained sidebar renderer (all styles injected via JS).
 *
 * Architecture:
 *   - IIFE (Immediately Invoked Function Expression), strict mode
 *   - No ES modules, no external dependencies
 *   - IndexedDB: 'cahaya_workspace_db', version 1
 *   - Stores: conversations | ai_library | connections
 *
 * @file        conversation_manager.js
 * @version     1.0.0
 * @license     Proprietary — CAHAYA Sovereign Platform
 * =============================================================================
 */

(function () {
  'use strict';

  /* ============================================================
   * SECTION 0 — Private State
   * ============================================================ */

  /**
   * Cached IDBDatabase instance. Null until first _openDB() call resolves.
   * We use a single shared connection across all operations.
   * @type {IDBDatabase|null}
   */
  var _db = null;

  /**
   * Promise that resolves to the open IDBDatabase. Prevents race conditions
   * where multiple callers hit _openDB() simultaneously before _db is set.
   * @type {Promise<IDBDatabase>|null}
   */
  var _dbPromise = null;

  /**
   * IndexedDB database name used throughout the application.
   * Changing this value constitutes a breaking change (data migration needed).
   * @type {string}
   */
  var DB_NAME = 'cahaya_workspace_db';

  /**
   * IndexedDB schema version.
   * Increment this integer whenever the object store schema changes.
   * @type {number}
   */
  var DB_VERSION = 2;

  /**
   * Object store names — centralised to avoid typo bugs.
   */
  var STORE_CONVERSATIONS = 'conversations';
  var STORE_AI_LIBRARY    = 'ai_library';
  var STORE_CONNECTIONS   = 'connections';
  var STORE_LEARNED_METHODOLOGIES = 'learned_methodologies';

  /**
   * Maximum character length for the AI context string returned by
   * buildAIContext(). Keeps prompt sizes within reasonable bounds.
   * @type {number}
   */
  var AI_CONTEXT_MAX_CHARS = 8000;

  /* ============================================================
   * SECTION 1 — General Utilities
   * ============================================================ */

  /**
   * Returns the current date-time as an ISO 8601 string.
   * Uses the system clock — callers should not cache this value.
   *
   * @returns {string}  e.g. "2026-06-17T00:00:00.000Z"
   */
  function _now() {
    return new Date().toISOString();
  }

  /**
   * Generates a RFC-4122 version-4 UUID using the Web Crypto API.
   * Falls back to a Math.random-based UUID when crypto.randomUUID is
   * unavailable (very old browsers / non-secure contexts).
   *
   * @returns {string}  e.g. "550e8400-e29b-41d4-a716-446655440000"
   */
  function _uuid() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    // Fallback — not cryptographically strong but functionally unique enough
    // for UI-level identifiers in a single-user offline workspace.
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (Math.random() * 16) | 0;
      var v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  /**
   * Creates a debounced version of `fn` that delays invocation by `wait` ms.
   * Each call within the delay window resets the timer. Useful for search
   * inputs and other high-frequency event sources.
   *
   * @param  {Function} fn    The function to debounce.
   * @param  {number}   wait  Delay in milliseconds.
   * @returns {Function}       Debounced function.
   */
  function _debounce(fn, wait) {
    var timer = null;
    return function () {
      var ctx  = this;
      var args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () {
        fn.apply(ctx, args);
      }, wait);
    };
  }

  /**
   * Formats a date as a short relative / absolute time label for the sidebar.
   * Examples:
   *   "Just now"   – within the last 60 seconds
   *   "5m ago"     – within the last hour
   *   "3h ago"     – same day, more than an hour ago
   *   "Mon 14:32"  – within the current week
   *   "12 Jun"     – this year, older than a week
   *   "12 Jun 25"  – previous year
   *
   * @param  {string|Date} dateInput  ISO string or Date object.
   * @returns {string}                Human-readable label.
   */
  function _formatRelativeTime(dateInput) {
    var date  = dateInput instanceof Date ? dateInput : new Date(dateInput);
    var now   = new Date();
    var delta = (now - date) / 1000; // seconds

    if (delta < 60) {
      return 'Just now';
    }
    if (delta < 3600) {
      return Math.floor(delta / 60) + 'm ago';
    }

    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var d     = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    if (d.getTime() === today.getTime()) {
      // Same calendar day — show hours ago
      var hours = Math.floor(delta / 3600);
      return hours + 'h ago';
    }

    // Within this week — show day name + time
    var weekAgo = new Date(today.getTime() - 6 * 86400000);
    if (d >= weekAgo) {
      var days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      var hh   = String(date.getHours()).padStart(2, '0');
      var mm   = String(date.getMinutes()).padStart(2, '0');
      return days[date.getDay()] + ' ' + hh + ':' + mm;
    }

    // Older — show date
    var months = ['Jan','Feb','Mar','Apr','May','Jun',
                  'Jul','Aug','Sep','Oct','Nov','Dec'];
    var label = date.getDate() + ' ' + months[date.getMonth()];
    if (date.getFullYear() !== now.getFullYear()) {
      label += ' ' + String(date.getFullYear()).slice(2);
    }
    return label;
  }

  /**
   * Groups an array of conversation objects into named buckets for sidebar
   * display: Pinned, Today, Yesterday, This Week, Earlier.
   * Buckets with zero items are omitted from the result.
   *
   * @param  {Array<Object>} conversations  Conversation objects (sorted desc).
   * @returns {Array<{label:string, items:Array<Object>}>}  Ordered groups.
   */
  function _groupConversationsByDate(conversations) {
    var now       = new Date();
    var today     = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var yesterday = new Date(today.getTime() - 86400000);
    var weekAgo   = new Date(today.getTime() - 6 * 86400000);

    var groups = {
      pinned:    { label: '📌 Pinned',    items: [] },
      today:     { label: 'Today',        items: [] },
      yesterday: { label: 'Yesterday',    items: [] },
      thisWeek:  { label: 'This Week',    items: [] },
      earlier:   { label: 'Earlier',      items: [] }
    };

    conversations.forEach(function (conv) {
      // Pinned conversations go to their own group regardless of date
      if (conv.pinned) {
        groups.pinned.items.push(conv);
        return;
      }

      var updated = new Date(conv.updatedAt);
      var day     = new Date(updated.getFullYear(), updated.getMonth(), updated.getDate());

      if (day.getTime() === today.getTime()) {
        groups.today.items.push(conv);
      } else if (day.getTime() === yesterday.getTime()) {
        groups.yesterday.items.push(conv);
      } else if (day >= weekAgo) {
        groups.thisWeek.items.push(conv);
      } else {
        groups.earlier.items.push(conv);
      }
    });

    // Return only non-empty groups in display order
    var order = ['pinned', 'today', 'yesterday', 'thisWeek', 'earlier'];
    return order
      .filter(function (key) { return groups[key].items.length > 0; })
      .map(function (key) { return groups[key]; });
  }

  /* ============================================================
   * SECTION 2 — IndexedDB Infrastructure
   * ============================================================ */

  /**
   * Opens (or returns the cached) IDBDatabase connection.
   * On first call, creates the object stores and indexes if they do not exist
   * (runs inside the `onupgradeneeded` handler at DB_VERSION).
   *
   * Caches the resulting promise so concurrent callers share one open request.
   *
   * @returns {Promise<IDBDatabase>}  Resolves with the open database instance.
   */
  function _openDB() {
    // Return existing resolved promise if DB is already open
    if (_db) {
      return Promise.resolve(_db);
    }
    // Return in-flight promise to prevent duplicate open requests
    if (_dbPromise) {
      return _dbPromise;
    }

    _dbPromise = new Promise(function (resolve, reject) {
      var request = indexedDB.open(DB_NAME, DB_VERSION);

      /**
       * Schema setup — runs when the database is first created or when
       * DB_VERSION is incremented. All object stores and indexes are
       * created here idempotently (checking existence before creation).
       */
      request.onupgradeneeded = function (event) {
        var db = event.target.result;

        /* ---- conversations store ---- */
        if (!db.objectStoreNames.contains(STORE_CONVERSATIONS)) {
          var convStore = db.createObjectStore(STORE_CONVERSATIONS, { keyPath: 'id' });
          // Index for fast domain-filtered queries
          convStore.createIndex('domain',    'domain',    { unique: false });
          // Index for sorting by most-recently-updated
          convStore.createIndex('updatedAt', 'updatedAt', { unique: false });
          // Index for alphabetical title lookup / autocomplete
          convStore.createIndex('title',     'title',     { unique: false });
        }

        /* ---- ai_library store ---- */
        if (!db.objectStoreNames.contains(STORE_AI_LIBRARY)) {
          var libStore = db.createObjectStore(STORE_AI_LIBRARY, { keyPath: 'id' });
          // Index for sorting by upload date
          libStore.createIndex('uploadedAt', 'uploadedAt', { unique: false });
        }

        /* ---- connections store ---- */
        if (!db.objectStoreNames.contains(STORE_CONNECTIONS)) {
          db.createObjectStore(STORE_CONNECTIONS, { keyPath: 'id' });
        }

        /* ---- learned_methodologies store ---- */
        if (!db.objectStoreNames.contains(STORE_LEARNED_METHODOLOGIES)) {
          var methodStore = db.createObjectStore(STORE_LEARNED_METHODOLOGIES, { keyPath: 'id' });
          methodStore.createIndex('domain', 'domain', { unique: false });
        }
      };

      request.onsuccess = function (event) {
        _db = event.target.result;

        // Automatically reset our cached promise if the DB is closed externally
        _db.onclose = function () {
          _db        = null;
          _dbPromise = null;
        };

        // Handle version change events (another tab opened the DB at a higher version)
        _db.onversionchange = function () {
          _db.close();
          _db        = null;
          _dbPromise = null;
          console.warn('[ConversationManager] DB version changed — connection closed. Reload recommended.');
        };

        resolve(_db);
      };

      request.onerror = function (event) {
        _dbPromise = null; // Allow retry on next call
        reject(new Error('[ConversationManager] Failed to open IndexedDB: ' + event.target.error));
      };

      request.onblocked = function () {
        console.warn('[ConversationManager] IndexedDB open is blocked — close other tabs using this database.');
      };
    });

    return _dbPromise;
  }

  /**
   * Low-level helper that wraps a single IndexedDB object-store operation
   * inside a Promise. This is the canonical pattern used by all higher-level
   * CRUD helpers below.
   *
   * `fn` receives the IDBObjectStore and should return:
   *   - An IDBRequest whose result will be used to resolve the promise, OR
   *   - Nothing (undefined) if the operation's result should come from
   *     the transaction's oncomplete event.
   *
   * @param  {string}   storeName  Object store name constant.
   * @param  {string}   mode       'readonly' | 'readwrite'
   * @param  {Function} fn         Receives (IDBObjectStore) → IDBRequest|void
   * @returns {Promise<any>}
   */
  function _withStore(storeName, mode, fn) {
    return _openDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx    = db.transaction([storeName], mode);
        var store = tx.objectStore(storeName);

        // Execute the caller's IDB operation
        var req = fn(store);

        if (req && typeof req.onsuccess !== 'undefined') {
          // Caller returned an IDBRequest — wire up its handlers
          req.onsuccess = function () {
            resolve(req.result);
          };
          req.onerror = function () {
            reject(new Error('[ConversationManager] IDB request error: ' + req.error));
          };
        }

        // Transaction-level handlers (covers put/delete that resolve on oncomplete)
        tx.oncomplete = function () {
          if (!req || typeof req.onsuccess === 'undefined') {
            // No IDBRequest result — resolve without value
            resolve(undefined);
          }
        };

        tx.onerror = function () {
          reject(new Error('[ConversationManager] IDB transaction error: ' + tx.error));
        };

        tx.onabort = function () {
          reject(new Error('[ConversationManager] IDB transaction aborted: ' + tx.error));
        };
      });
    });
  }

  /* ---- Typed IDB operation wrappers ---- */

  /**
   * Reads a single record by its primary key.
   *
   * @param  {string} storeName  Object store name.
   * @param  {string} id         Primary key value.
   * @returns {Promise<Object|undefined>}
   */
  function _idbGet(storeName, id) {
    return _withStore(storeName, 'readonly', function (store) {
      return store.get(id);
    });
  }

  /**
   * Inserts or updates a record (full replace semantics).
   *
   * @param  {string} storeName  Object store name.
   * @param  {Object} record     Record to persist. Must include keyPath field.
   * @returns {Promise<string>}   Resolves with the stored record's key.
   */
  function _idbPut(storeName, record) {
    return _withStore(storeName, 'readwrite', function (store) {
      return store.put(record);
    });
  }

  /**
   * Deletes a record by its primary key.
   *
   * @param  {string} storeName  Object store name.
   * @param  {string} id         Primary key value.
   * @returns {Promise<undefined>}
   */
  function _idbDelete(storeName, id) {
    return _withStore(storeName, 'readwrite', function (store) {
      return store.delete(id);
    });
  }

  /**
   * Returns all records in the specified object store.
   * For large stores, consider cursor-based iteration instead.
   *
   * @param  {string} storeName  Object store name.
   * @returns {Promise<Array<Object>>}
   */
  function _idbGetAll(storeName) {
    return _withStore(storeName, 'readonly', function (store) {
      return store.getAll();
    });
  }

  /* ============================================================
   * SECTION 3 — Core Conversation Functions
   * ============================================================ */

  /**
   * Initialises the ConversationManager by ensuring the IndexedDB connection
   * is open. Should be called once at application startup, but safe to call
   * multiple times (subsequent calls are no-ops due to caching).
   *
   * @returns {Promise<IDBDatabase>}  The open database instance.
   */
  function init() {
    return _openDB();
  }

  /**
   * Creates a new conversation object with default values and persists it.
   *
   * The conversation is initialised with:
   *   - A UUID id
   *   - Title 'Untitled' (updated later by autoTitle)
   *   - The provided domain string
   *   - Empty messages, projectFiles, and tags arrays
   *   - pinned: false
   *
   * @param  {string} domain  Domain key (e.g. 'legal', 'finance', 'general').
   * @returns {Promise<string>}  Resolves with the new conversation's id.
   */
  function createConversation(domain) {
    var now  = _now();
    var conv = {
      id:           _uuid(),
      title:        'Untitled',
      domain:       domain || 'general',
      createdAt:    now,
      updatedAt:    now,
      messages:     [],
      projectFiles: [],
      tags:         [],
      pinned:       false
    };
    return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
      return conv.id;
    });
  }

  /**
   * Retrieves a single conversation by its primary key id.
   *
   * @param  {string} id  The conversation UUID.
   * @returns {Promise<Object|undefined>}  The conversation object, or undefined if not found.
   */
  function getConversation(id) {
    return _idbGet(STORE_CONVERSATIONS, id);
  }

  /**
   * Returns all conversations, optionally filtered to a specific domain,
   * sorted by updatedAt descending (most recently active first).
   *
   * @param  {string} [domain]  If provided, only conversations with this domain are returned.
   * @returns {Promise<Array<Object>>}
   */
  function listConversations(domain) {
    return _idbGetAll(STORE_CONVERSATIONS).then(function (all) {
      var filtered = domain
        ? all.filter(function (c) { return c.domain === domain; })
        : all;

      // Sort descending by updatedAt timestamp string (ISO strings are lexicographically sortable)
      filtered.sort(function (a, b) {
        return b.updatedAt.localeCompare(a.updatedAt);
      });

      return filtered;
    });
  }

  /**
   * Appends a new message to an existing conversation's messages array and
   * updates the conversation's updatedAt timestamp.
   *
   * @param  {string} convId                     Target conversation UUID.
   * @param  {Object} opts                        Message parameters.
   * @param  {string} opts.role                   'user' | 'assistant'
   * @param  {string} opts.content                Message text content.
   * @param  {Array}  [opts.attachments=[]]       Optional file attachment metadata.
   * @returns {Promise<Object>}                   The updated conversation object.
   * @throws  Will reject if conversation not found.
   */
  function saveMessage(convId, opts) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] saveMessage: conversation not found — ' + convId));
      }

      var message = {
        id:          _uuid(),
        role:        opts.role,
        content:     opts.content,
        timestamp:   _now(),
        attachments: Array.isArray(opts.attachments) ? opts.attachments : []
      };

      conv.messages.push(message);
      conv.updatedAt = _now();

      return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
        return conv;
      });
    });
  }

  /**
   * Automatically sets the conversation title based on the first 6 words of
   * an AI response, but only if the conversation is still titled 'Untitled'.
   *
   * This is meant to be called after the first AI assistant response is
   * received, so that conversations get meaningful names without requiring
   * the user to manually rename them.
   *
   * @param  {string} convId         Target conversation UUID.
   * @param  {string} aiResponseText Full AI response text.
   * @returns {Promise<Object|null>}  Updated conversation, or null if title was already set.
   */
  function autoTitle(convId, aiResponseText) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] autoTitle: conversation not found — ' + convId));
      }

      // Only auto-title conversations still at their default 'Untitled' state
      if (conv.title !== 'Untitled') {
        return null;
      }

      // Extract the first 6 non-empty words from the AI response text
      var words = (aiResponseText || '')
        .replace(/\s+/g, ' ')
        .trim()
        .split(' ')
        .filter(function (w) { return w.length > 0; })
        .slice(0, 6);

      if (words.length === 0) {
        return null;
      }

      var newTitle = words.join(' ');
      // Append ellipsis if the response was longer than 6 words
      if ((aiResponseText || '').trim().split(/\s+/).length > 6) {
        newTitle += '…';
      }

      conv.title     = newTitle;
      conv.updatedAt = _now();

      return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
        return conv;
      });
    });
  }

  /**
   * Renames a conversation by setting a new title string and updating its
   * updatedAt timestamp.
   *
   * @param  {string} convId    Target conversation UUID.
   * @param  {string} newTitle  New display title for the conversation.
   * @returns {Promise<Object>}  The updated conversation object.
   */
  function renameConversation(convId, newTitle) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] renameConversation: conversation not found — ' + convId));
      }

      conv.title     = String(newTitle).trim() || 'Untitled';
      conv.updatedAt = _now();

      return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
        return conv;
      });
    });
  }

  /**
   * Permanently deletes a conversation from the database.
   * This action is irreversible — callers should confirm with the user first.
   *
   * @param  {string} convId  Target conversation UUID.
   * @returns {Promise<undefined>}
   */
  function deleteConversation(convId) {
    return _idbDelete(STORE_CONVERSATIONS, convId);
  }

  /**
   * Performs a case-insensitive substring search across all conversations,
   * matching the query against both the conversation title and the textual
   * content of every message. Optionally filters to a specific domain.
   *
   * Results are sorted by updatedAt descending.
   *
   * @param  {string} query           Search string (fuzzy — substring match).
   * @param  {string} [domain]        Optional domain filter.
   * @returns {Promise<Array<Object>>} Matching conversations.
   */
  function searchConversations(query, domain) {
    return _idbGetAll(STORE_CONVERSATIONS).then(function (all) {
      var q = (query || '').toLowerCase().trim();

      var filtered = all.filter(function (conv) {
        // Apply domain filter first (fast path)
        if (domain && conv.domain !== domain) {
          return false;
        }

        if (!q) {
          // Empty query — return all (in domain)
          return true;
        }

        // Match against title
        if (conv.title && conv.title.toLowerCase().indexOf(q) !== -1) {
          return true;
        }

        // Match against any message content
        if (Array.isArray(conv.messages)) {
          for (var i = 0; i < conv.messages.length; i++) {
            var msg = conv.messages[i];
            if (msg.content && msg.content.toLowerCase().indexOf(q) !== -1) {
              return true;
            }
          }
        }

        return false;
      });

      // Sort descending by updatedAt
      filtered.sort(function (a, b) {
        return b.updatedAt.localeCompare(a.updatedAt);
      });

      return filtered;
    });
  }

  /**
   * Adds a project file object to a conversation's projectFiles array.
   * Project files are documents, images, or other assets uploaded by the user
   * to contextualise the conversation.
   *
   * @param  {string} convId   Target conversation UUID.
   * @param  {Object} fileObj  File metadata: {name, type, size, dataUrl, uploadedAt}
   * @returns {Promise<Object>}  The updated conversation object.
   */
  function addProjectFile(convId, fileObj) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] addProjectFile: conversation not found — ' + convId));
      }

      var file = {
        name:       fileObj.name       || 'unknown',
        type:       fileObj.type       || 'application/octet-stream',
        size:       fileObj.size       || 0,
        dataUrl:    fileObj.dataUrl    || null,
        uploadedAt: fileObj.uploadedAt || _now()
      };

      if (!Array.isArray(conv.projectFiles)) {
        conv.projectFiles = [];
      }
      conv.projectFiles.push(file);
      conv.updatedAt = _now();

      return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
        return conv;
      });
    });
  }

  /**
   * Removes a project file from a conversation's projectFiles array.
   *
   * @param  {string} convId  Target conversation UUID.
   * @param  {number} index   Index of the file to remove.
   * @returns {Promise<Object>} The updated conversation object.
   */
  function removeProjectFile(convId, index) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] removeProjectFile: conversation not found — ' + convId));
      }
      if (Array.isArray(conv.projectFiles)) {
        conv.projectFiles.splice(index, 1);
      }
      conv.updatedAt = _now();
      return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
        return conv;
      });
    });
  }

  /**
   * Exports a conversation as a pretty-printed JSON file download.
   * Triggers the browser's native file save dialog via a temporary anchor
   * element with a blob: object URL.
   *
   * The file is named: "conversation-{id}.json"
   *
   * @param  {string} convId  Target conversation UUID.
   * @returns {Promise<Object>}  The exported conversation object.
   */
  function exportConversation(convId) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] exportConversation: conversation not found — ' + convId));
      }

      // Serialise to human-readable JSON
      var json = JSON.stringify(conv, null, 2);
      var blob = new Blob([json], { type: 'application/json' });
      var url  = URL.createObjectURL(blob);

      // Create a temporary anchor element to trigger the download
      var a      = document.createElement('a');
      a.href     = url;
      a.download = 'conversation-' + convId + '.json';
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();

      // Clean up the object URL and anchor after a brief delay
      setTimeout(function () {
        URL.revokeObjectURL(url);
        if (a.parentNode) {
          a.parentNode.removeChild(a);
        }
      }, 1000);

      return conv;
    });
  }

  /**
   * Sets the pinned state of a conversation.
   * Pinned conversations are displayed at the top of the sidebar regardless
   * of their updatedAt timestamp.
   *
   * @param  {string}  convId  Target conversation UUID.
   * @param  {boolean} pinned  true to pin, false to unpin.
   * @returns {Promise<Object>}  The updated conversation object.
   */
  function pinConversation(convId, pinned) {
    return getConversation(convId).then(function (conv) {
      if (!conv) {
        return Promise.reject(new Error('[ConversationManager] pinConversation: conversation not found — ' + convId));
      }

      conv.pinned    = Boolean(pinned);
      conv.updatedAt = _now();

      return _idbPut(STORE_CONVERSATIONS, conv).then(function () {
        return conv;
      });
    });
  }

  /* ============================================================
   * SECTION 4 — AI Library Functions
   * ============================================================ */

  /**
   * Adds a document to the persistent AI Library store.
   * Documents in the library are injected into every AI prompt via
   * buildAIContext(), providing always-available company knowledge.
   *
   * @param  {Object} opts               Document metadata.
   * @param  {string} opts.name          Human-readable filename.
   * @param  {string} opts.type          MIME type (e.g. 'application/pdf').
   * @param  {string} opts.extractedText Plain text extracted from the document.
   * @param  {string} [opts.dataUrl]     Optional base64 data URL of the file.
   * @returns {Promise<string>}           Resolves with the new document's id.
   */
  function addToLibrary(opts) {
    var doc = {
      id:            _uuid(),
      name:          opts.name          || 'Unnamed Document',
      type:          opts.type          || 'application/octet-stream',
      extractedText: opts.extractedText || '',
      dataUrl:       opts.dataUrl       || null,
      uploadedAt:    _now()
    };

    return _idbPut(STORE_AI_LIBRARY, doc).then(function () {
      return doc.id;
    });
  }

  /**
   * Returns all AI Library documents, sorted by uploadedAt descending
   * (most recently uploaded first).
   *
   * @returns {Promise<Array<Object>>}
   */
  function getLibraryDocs() {
    return _idbGetAll(STORE_AI_LIBRARY).then(function (docs) {
      docs.sort(function (a, b) {
        return b.uploadedAt.localeCompare(a.uploadedAt);
      });
      return docs;
    });
  }

  /**
   * Removes a document from the AI Library by its primary key.
   *
   * @param  {string} id  The document UUID to remove.
   * @returns {Promise<undefined>}
   */
  function removeFromLibrary(id) {
    return _idbDelete(STORE_AI_LIBRARY, id);
  }

  /**
   * Constructs a single AI context string from all AI Library documents.
   * The context is prefixed with a header and truncated to AI_CONTEXT_MAX_CHARS
   * to avoid exceeding prompt size limits.
   *
   * Format:
   *   COMPANY AI LIBRARY:
   *   --- [filename] ---
   *   [extracted text]
   *   ...
   *
   * @returns {Promise<string>}  The AI context string (max 8000 chars).
   */
  function buildAIContext() {
    return getLibraryDocs().then(function (docs) {
      if (!docs || docs.length === 0) {
        return '';
      }

      var sections = docs.map(function (doc) {
        return '--- ' + (doc.name || 'Document') + ' ---\n' + (doc.extractedText || '');
      });

      var body    = sections.join('\n\n');
      var full    = 'COMPANY AI LIBRARY:\n' + body;

      // Truncate to protect against over-sized prompts
      if (full.length > AI_CONTEXT_MAX_CHARS) {
        full = full.slice(0, AI_CONTEXT_MAX_CHARS) + '\n[...truncated]';
      }

      return full;
    });
  }

  /* ============================================================
   * SECTION 5 — Connections Functions
   * ============================================================ */

  /**
   * Saves (inserts or replaces) a connection profile in the connections store.
   * If the provided object does not include an id, one is auto-generated.
   *
   * Connection profiles describe external AI model endpoints that the
   * CAHAYA workspace can route requests to.
   *
   * @param  {Object} conn            Connection object.
   * @param  {string} [conn.id]       UUID — auto-generated if omitted.
   * @param  {string} conn.name       Display name (e.g. "GPT-4o Production").
   * @param  {string} conn.apiKey     API key for authentication.
   * @param  {string} conn.endpoint   Full URL of the model API endpoint.
   * @param  {string} [conn.status]   'online' | 'offline' | 'error' | 'unknown'
   * @returns {Promise<string>}        Resolves with the connection's id.
   */
  function saveConnection(conn) {
    var record = {
      id:       conn.id       || _uuid(),
      name:     conn.name     || 'Unnamed Connection',
      apiKey:   conn.apiKey   || '',
      endpoint: conn.endpoint || '',
      status:   conn.status   || 'unknown'
    };

    return _idbPut(STORE_CONNECTIONS, record).then(function () {
      return record.id;
    });
  }

  /**
   * Returns all saved connection profiles.
   *
   * @returns {Promise<Array<Object>>}
   */
  function getConnections() {
    return _idbGetAll(STORE_CONNECTIONS);
  }

  /**
   * Deletes a connection profile by its primary key.
   *
   * @param  {string} id  Connection UUID.
   * @returns {Promise<undefined>}
   */
  function deleteConnection(id) {
    return _idbDelete(STORE_CONNECTIONS, id);
  }

  /* ============================================================
   * SECTION 6 — Learned Methodologies functions
   * ============================================================ */

  /**
   * Saves a learned methodology metric.
   *
   * @param  {Object} metricObj  The metric object containing id, name, formula, range, purpose, standard, thresholds, etc.
   * @param  {string} domain     The domain this methodology belongs to.
   * @returns {Promise<string>}   Resolves with the metric ID.
   */
  function saveLearnedMethodology(metricObj, domain) {
    if (!metricObj || !metricObj.id) {
      return Promise.reject(new Error('[ConversationManager] saveLearnedMethodology: metricObj must have a unique id.'));
    }
    var record = Object.assign({}, metricObj, {
      domain: domain || metricObj.domain || 'agriculture',
      learnedAt: metricObj.learnedAt || _now()
    });
    return _idbPut(STORE_LEARNED_METHODOLOGIES, record).then(function () {
      return record.id;
    });
  }

  /**
   * Retrieves all learned methodologies for a given domain.
   *
   * @param  {string} domain  The industry domain (e.g. "agriculture").
   * @returns {Promise<Array<Object>>}
   */
  function getLearnedMethodologies(domain) {
    return _idbGetAll(STORE_LEARNED_METHODOLOGIES).then(function (all) {
      return all.filter(function (m) {
        return m.domain === domain;
      });
    });
  }

  /**
   * Returns all learned methodologies across all domains.
   *
   * @returns {Promise<Array<Object>>}
   */
  function listLearnedMethodologies() {
    return _idbGetAll(STORE_LEARNED_METHODOLOGIES);
  }

  /**
   * Deletes a learned methodology by its ID.
   *
   * @param  {string} id  The metric ID.
   * @returns {Promise<undefined>}
   */
  function deleteLearnedMethodology(id) {
    return _idbDelete(STORE_LEARNED_METHODOLOGIES, id);
  }

  /**
   * Tests a connection profile by checking if the endpoint responds.a GET request with the stored
   * API key in the Authorization header. Measures latency and updates the
   * connection's status field in the database.
   *
   * @param  {string} id  Connection UUID.
   * @returns {Promise<{success:boolean, latency:number|null, error:string|null}>}
   */
  function testConnection(id) {
    return _idbGet(STORE_CONNECTIONS, id).then(function (conn) {
      if (!conn) {
        return Promise.reject(new Error('[ConversationManager] testConnection: connection not found — ' + id));
      }

      var startTime = Date.now();

      return fetch(conn.endpoint, {
        method:  'GET',
        headers: {
          'Authorization': 'Bearer ' + conn.apiKey,
          'Accept':        'application/json'
        }
      }).then(function (response) {
        var latency = Date.now() - startTime;
        var success = response.ok;

        conn.status = success ? 'online' : 'error';
        return _idbPut(STORE_CONNECTIONS, conn).then(function () {
          return {
            success: success,
            latency: latency,
            error:   success ? null : 'HTTP ' + response.status + ' ' + response.statusText
          };
        });

      }).catch(function (err) {
        var latency = Date.now() - startTime;
        conn.status = 'error';
        return _idbPut(STORE_CONNECTIONS, conn).then(function () {
          return {
            success: false,
            latency: latency,
            error:   err && err.message ? err.message : String(err)
          };
        });
      });
    });
  }

  /* ============================================================
   * SECTION 6 — Sidebar Renderer
   * ============================================================ */

  /**
   * Renders a full conversation sidebar into the specified DOM container.
   * All visual styles are injected directly via JavaScript — no external
   * CSS file or class names from a stylesheet are required.
   *
   * The sidebar includes:
   *   - A debounced full-text search input
   *   - A "+ New Conversation" button
   *   - Grouped conversation list (Pinned / Today / Yesterday / This Week / Earlier)
   *   - Right-click context menus per item (Rename, Pin/Unpin, Export, Delete)
   *
   * @param {string} containerId                      ID of the DOM element to render into.
   * @param {Object} opts                             Configuration options.
   * @param {string} [opts.activeDomain]              Domain to filter conversations by.
   * @param {Function} [opts.onSelect]                Called with (convId) when an item is clicked.
   * @param {Function} [opts.onNew]                   Called when '+ New Conversation' is clicked.
   * @param {string} [opts.activeConvId]              Currently active conversation UUID (highlighted).
   */
  function renderSidebar(containerId, opts) {
    opts = opts || {};
    var activeDomain  = opts.activeDomain  || null;
    var onSelect      = typeof opts.onSelect === 'function' ? opts.onSelect : function () {};
    var onNew         = typeof opts.onNew   === 'function' ? opts.onNew   : function () {};
    var activeConvId  = opts.activeConvId  || null;

    /* ---- Locate container ---- */
    var container = document.getElementById(containerId);
    if (!container) {
      console.error('[ConversationManager] renderSidebar: container not found — #' + containerId);
      return;
    }

    /* ---- Clear existing content ---- */
    container.innerHTML = '';

    /* ---- Apply base container styles ---- */
    container.style.display        = 'flex';
    container.style.flexDirection  = 'column';
    container.style.height         = '100%';
    container.style.overflowY      = 'auto';
    container.style.padding        = '8px';
    container.style.boxSizing      = 'border-box';
    container.style.scrollbarWidth = 'thin';
    container.style.scrollbarColor = 'rgba(255,255,255,0.1) transparent';

    /* ----------------------------------------------------------------
     * Context menu state — only one menu open at a time.
     * Stored here in closure scope so all item renderers share it.
     * ---------------------------------------------------------------- */
    var _activeMenu = null;

    /** Dismisses and removes the active context menu from the DOM. */
    function _closeContextMenu() {
      if (_activeMenu && _activeMenu.parentNode) {
        _activeMenu.parentNode.removeChild(_activeMenu);
      }
      _activeMenu = null;
    }

    // Global click-outside listener — dismisses any open context menu
    document.addEventListener('click', _closeContextMenu);

    /* ----------------------------------------------------------------
     * Inner re-render function. Called initially and after any mutation
     * (rename, delete, pin, etc.) to refresh the entire sidebar.
     * ---------------------------------------------------------------- */
    function _render(conversations) {
      /* ---- Clear and re-apply base styles ---- */
      container.innerHTML = '';

      /* ---- Search Input ---- */
      var searchInput                  = document.createElement('input');
      searchInput.type                 = 'text';
      searchInput.placeholder          = '🔍 Search conversations...';
      searchInput.style.width          = '100%';
      searchInput.style.boxSizing      = 'border-box';
      searchInput.style.background     = 'rgba(255,255,255,0.05)';
      searchInput.style.border         = '1px solid rgba(255,255,255,0.1)';
      searchInput.style.borderRadius   = '8px';
      searchInput.style.padding        = '8px 12px';
      searchInput.style.color          = 'white';
      searchInput.style.fontSize       = '13px';
      searchInput.style.outline        = 'none';
      searchInput.style.fontFamily     = 'Inter, system-ui, sans-serif';
      searchInput.style.marginBottom   = '8px';
      searchInput.style.display        = 'block';
      searchInput.style.transition     = 'border-color 0.2s';

      // Focus highlight
      searchInput.addEventListener('focus', function () {
        searchInput.style.borderColor = 'rgba(99,102,241,0.5)';
      });
      searchInput.addEventListener('blur', function () {
        searchInput.style.borderColor = 'rgba(255,255,255,0.1)';
      });

      // Debounced search handler — fires search after 300ms of inactivity
      var _handleSearch = _debounce(function () {
        var q = searchInput.value.trim();
        searchConversations(q, activeDomain).then(function (results) {
          _renderList(results);
        }).catch(function (err) {
          console.error('[ConversationManager] Search error:', err);
        });
      }, 300);

      searchInput.addEventListener('input', _handleSearch);
      container.appendChild(searchInput);

      /* ---- "+ New Conversation" Button ---- */
      var newBtn                    = document.createElement('button');
      newBtn.textContent            = '+ New Conversation';
      newBtn.style.width            = '100%';
      newBtn.style.background       = 'rgba(99,102,241,0.2)';
      newBtn.style.border           = '1px solid rgba(99,102,241,0.4)';
      newBtn.style.borderRadius     = '8px';
      newBtn.style.color            = 'rgba(255,255,255,0.8)';
      newBtn.style.padding          = '8px 12px';
      newBtn.style.cursor           = 'pointer';
      newBtn.style.fontSize         = '13px';
      newBtn.style.marginBottom     = '12px';
      newBtn.style.fontFamily       = 'Inter, system-ui, sans-serif';
      newBtn.style.transition       = 'background 0.2s, border-color 0.2s';
      newBtn.style.display          = 'block';
      newBtn.style.textAlign        = 'center';

      // Hover effects
      newBtn.addEventListener('mouseenter', function () {
        newBtn.style.background   = 'rgba(99,102,241,0.35)';
        newBtn.style.borderColor  = 'rgba(99,102,241,0.7)';
      });
      newBtn.addEventListener('mouseleave', function () {
        newBtn.style.background   = 'rgba(99,102,241,0.2)';
        newBtn.style.borderColor  = 'rgba(99,102,241,0.4)';
      });

      newBtn.addEventListener('click', function () {
        onNew();
      });
      container.appendChild(newBtn);

      /* ---- Conversation list wrapper ---- */
      var listWrapper              = document.createElement('div');
      listWrapper.style.flex       = '1';
      listWrapper.style.overflowY  = 'auto';
      container.appendChild(listWrapper);

      /**
       * Renders grouped conversation items into listWrapper.
       * Called initially with all conversations, and again after search.
       *
       * @param {Array<Object>} convs  Conversations to display.
       */
      function _renderList(convs) {
        listWrapper.innerHTML = '';

        if (!convs || convs.length === 0) {
          var empty              = document.createElement('div');
          empty.textContent      = 'No conversations yet.';
          empty.style.color      = 'rgba(255,255,255,0.25)';
          empty.style.fontSize   = '12px';
          empty.style.textAlign  = 'center';
          empty.style.padding    = '24px 8px';
          empty.style.fontFamily = 'Inter, system-ui, sans-serif';
          listWrapper.appendChild(empty);
          return;
        }

        var groups = _groupConversationsByDate(convs);

        groups.forEach(function (group) {
          /* ---- Group header ---- */
          var header                       = document.createElement('div');
          header.textContent               = group.label;
          header.style.fontSize            = '10px';
          header.style.textTransform       = 'uppercase';
          header.style.color               = 'rgba(255,255,255,0.3)';
          header.style.letterSpacing       = '1.5px';
          header.style.margin              = '12px 0 4px 8px';
          header.style.fontFamily          = 'Inter, system-ui, sans-serif';
          header.style.userSelect          = 'none';
          header.style.webkitUserSelect    = 'none';
          listWrapper.appendChild(header);

          /* ---- Group items ---- */
          group.items.forEach(function (conv) {
            var isActive = conv.id === activeConvId;

            /* -- Item container -- */
            var item                      = document.createElement('div');
            item.style.padding            = isActive ? '8px 12px 8px 9px' : '8px 12px';
            item.style.borderRadius       = '10px';
            item.style.cursor             = 'pointer';
            item.style.fontFamily         = 'Inter, system-ui, sans-serif';
            item.style.display            = 'flex';
            item.style.flexDirection      = 'column';
            item.style.position           = 'relative';
            item.style.marginBottom       = '2px';
            item.style.transition         = 'background 0.15s';
            item.style.background         = isActive ? 'rgba(99,102,241,0.15)' : 'transparent';
            item.style.borderLeft         = isActive ? '3px solid #6366f1' : '3px solid transparent';
            item.setAttribute('data-conv-id', conv.id);

            /* -- Hover effects (skip for active item) -- */
            if (!isActive) {
              item.addEventListener('mouseenter', function () {
                item.style.background = 'rgba(255,255,255,0.06)';
              });
              item.addEventListener('mouseleave', function () {
                item.style.background = 'transparent';
              });
            }

            /* -- Title row -- */
            var titleRow              = document.createElement('div');
            titleRow.style.display   = 'flex';
            titleRow.style.alignItems = 'center';
            titleRow.style.gap        = '4px';

            /* Pin indicator emoji */
            if (conv.pinned) {
              var pinIcon            = document.createElement('span');
              pinIcon.textContent    = '📌';
              pinIcon.style.fontSize = '10px';
              pinIcon.style.flexShrink = '0';
              titleRow.appendChild(pinIcon);
            }

            var titleEl                 = document.createElement('div');
            titleEl.textContent         = conv.title || 'Untitled';
            titleEl.style.fontSize      = '13px';
            titleEl.style.color         = 'rgba(255,255,255,0.8)';
            titleEl.style.overflow      = 'hidden';
            titleEl.style.textOverflow  = 'ellipsis';
            titleEl.style.whiteSpace    = 'nowrap';
            titleEl.style.maxWidth      = 'calc(100% - 40px)';
            titleEl.style.flex          = '1';
            titleRow.appendChild(titleEl);
            item.appendChild(titleRow);

            /* -- Time label -- */
            var timeEl               = document.createElement('div');
            timeEl.textContent       = _formatRelativeTime(conv.updatedAt);
            timeEl.style.fontSize    = '10px';
            timeEl.style.color       = 'rgba(255,255,255,0.3)';
            timeEl.style.marginTop   = '2px';
            item.appendChild(timeEl);

            /* -- Left-click: select conversation -- */
            item.addEventListener('click', function (e) {
              // Ignore right-click
              if (e.button !== 0) return;
              e.stopPropagation();
              onSelect(conv.id);
            });

            /* -- Right-click: context menu -- */
            item.addEventListener('contextmenu', function (e) {
              e.preventDefault();
              e.stopPropagation();

              // Close any existing menu
              _closeContextMenu();

              /* ---- Build context menu ---- */
              var menu                    = document.createElement('div');
              menu.style.position         = 'fixed';
              menu.style.left             = e.clientX + 'px';
              menu.style.top              = e.clientY + 'px';
              menu.style.background       = '#1a1f35';
              menu.style.border           = '1px solid rgba(255,255,255,0.1)';
              menu.style.borderRadius     = '8px';
              menu.style.padding          = '4px';
              menu.style.zIndex           = '10000';
              menu.style.boxShadow        = '0 8px 32px rgba(0,0,0,0.5)';
              menu.style.minWidth         = '160px';
              menu.style.fontFamily       = 'Inter, system-ui, sans-serif';
              menu.style.fontSize         = '13px';

              /**
               * Creates a single menu option item.
               *
               * @param {string}   label      Display text.
               * @param {string}   [emoji]    Leading emoji icon.
               * @param {Function} handler    Click handler.
               * @param {boolean}  [danger]   If true, colour the label red.
               * @returns {HTMLElement}
               */
              function _menuOption(label, emoji, handler, danger) {
                var opt                    = document.createElement('div');
                opt.style.padding          = '7px 12px';
                opt.style.borderRadius     = '6px';
                opt.style.cursor           = 'pointer';
                opt.style.color            = danger ? '#ef4444' : 'rgba(255,255,255,0.8)';
                opt.style.display          = 'flex';
                opt.style.alignItems       = 'center';
                opt.style.gap              = '8px';
                opt.style.transition       = 'background 0.1s';
                opt.style.userSelect       = 'none';
                opt.style.webkitUserSelect = 'none';

                if (emoji) {
                  var emojiSpan          = document.createElement('span');
                  emojiSpan.textContent  = emoji;
                  emojiSpan.style.width  = '16px';
                  opt.appendChild(emojiSpan);
                }

                var labelSpan         = document.createElement('span');
                labelSpan.textContent = label;
                opt.appendChild(labelSpan);

                opt.addEventListener('mouseenter', function () {
                  opt.style.background = danger
                    ? 'rgba(239,68,68,0.1)'
                    : 'rgba(255,255,255,0.07)';
                });
                opt.addEventListener('mouseleave', function () {
                  opt.style.background = 'transparent';
                });

                opt.addEventListener('click', function (ev) {
                  ev.stopPropagation();
                  _closeContextMenu();
                  handler();
                });

                return opt;
              }

              /* ---- Rename option ---- */
              menu.appendChild(_menuOption('Rename', '✏️', function () {
                var current  = conv.title || 'Untitled';
                var newName  = window.prompt('Rename conversation:', current);
                if (newName !== null && newName.trim() !== '') {
                  renameConversation(conv.id, newName.trim()).then(function () {
                    _refresh();
                  }).catch(function (err) {
                    console.error('[ConversationManager] Rename failed:', err);
                  });
                }
              }));

              /* ---- Pin / Unpin option ---- */
              var pinLabel = conv.pinned ? 'Unpin' : 'Pin';
              var pinEmoji = conv.pinned ? '📌' : '📌';
              menu.appendChild(_menuOption(pinLabel, pinEmoji, function () {
                pinConversation(conv.id, !conv.pinned).then(function () {
                  _refresh();
                }).catch(function (err) {
                  console.error('[ConversationManager] Pin toggle failed:', err);
                });
              }));

              /* ---- Export option ---- */
              menu.appendChild(_menuOption('Export', '⬇️', function () {
                exportConversation(conv.id).catch(function (err) {
                  console.error('[ConversationManager] Export failed:', err);
                });
              }));

              /* ---- Separator ---- */
              var sep                   = document.createElement('div');
              sep.style.height          = '1px';
              sep.style.background      = 'rgba(255,255,255,0.08)';
              sep.style.margin          = '4px 0';
              menu.appendChild(sep);

              /* ---- Delete option ---- */
              menu.appendChild(_menuOption('Delete', '🗑️', function () {
                var confirmed = window.confirm(
                  'Delete "' + (conv.title || 'this conversation') + '"? This cannot be undone.'
                );
                if (confirmed) {
                  deleteConversation(conv.id).then(function () {
                    _refresh();
                  }).catch(function (err) {
                    console.error('[ConversationManager] Delete failed:', err);
                  });
                }
              }, true /* danger */));

              document.body.appendChild(menu);
              _activeMenu = menu;

              /* Adjust menu position so it never overflows the viewport */
              var menuRect = menu.getBoundingClientRect();
              if (menuRect.right > window.innerWidth) {
                menu.style.left = (e.clientX - menuRect.width) + 'px';
              }
              if (menuRect.bottom > window.innerHeight) {
                menu.style.top = (e.clientY - menuRect.height) + 'px';
              }
            });

            listWrapper.appendChild(item);
          }); // end group.items.forEach
        }); // end groups.forEach
      } // end _renderList

      // Initial list render
      _renderList(conversations);
    } // end _render

    /**
     * Reloads conversations from the database and re-renders the full sidebar.
     * Called after any mutation (rename, pin, delete).
     */
    function _refresh() {
      listConversations(activeDomain).then(function (convs) {
        _render(convs);
      }).catch(function (err) {
        console.error('[ConversationManager] Sidebar refresh error:', err);
      });
    }

    // Kick off the initial data load and render
    listConversations(activeDomain).then(function (convs) {
      _render(convs);
    }).catch(function (err) {
      console.error('[ConversationManager] Sidebar initial load error:', err);
      container.innerHTML = '<div style="color:rgba(255,255,255,0.3);font-size:12px;padding:16px;font-family:Inter,sans-serif;">Failed to load conversations.</div>';
    });

    // Return a cleanup function that removes the global click listener
    return function destroy() {
      document.removeEventListener('click', _closeContextMenu);
      _closeContextMenu();
    };
  } // end renderSidebar

  /* ============================================================
   * SECTION 7 — Public API Export
   * ============================================================ */

  /**
   * The ConversationManager public API.
   * Exposes all conversation, AI library, connection, and UI functions.
   *
   * Attach to window so it is globally accessible to other scripts
   * on the CAHAYA Sovereign page without requiring import/require.
   *
   * @namespace window.ConversationManager
   */
  window.ConversationManager = {
    /* ---- DB Lifecycle ---- */
    init: init,

    /* ---- Conversations ---- */
    createConversation:  createConversation,
    getConversation:     getConversation,
    listConversations:   listConversations,
    saveMessage:         saveMessage,
    autoTitle:           autoTitle,
    renameConversation:  renameConversation,
    deleteConversation:  deleteConversation,
    searchConversations: searchConversations,
    addProjectFile:      addProjectFile,
    removeProjectFile:   removeProjectFile,
    exportConversation:  exportConversation,
    pinConversation:     pinConversation,

    /* ---- AI Library ---- */
    addToLibrary:   addToLibrary,
    getLibraryDocs: getLibraryDocs,
    removeFromLibrary: removeFromLibrary,
    buildAIContext: buildAIContext,

    /* ---- Connections ---- */
    saveConnection:  saveConnection,
    getConnections:  getConnections,
    deleteConnection: deleteConnection,
    testConnection:  testConnection,

    /* ---- Learned Methodologies ---- */
    saveLearnedMethodology:   saveLearnedMethodology,
    getLearnedMethodologies:  getLearnedMethodologies,
    listLearnedMethodologies: listLearnedMethodologies,
    deleteLearnedMethodology: deleteLearnedMethodology,

    /* ---- Sidebar UI ---- */
    renderSidebar: renderSidebar
  };

  // Signal successful initialisation
  console.info('[ConversationManager] ✅ CAHAYA Sovereign ConversationManager loaded. Version 1.0.0');

})();
