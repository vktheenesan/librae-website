@echo off
rem =============================================================================
rem CAHAYA Sovereign Workspace - Windows Root Install Entry Point
rem Version 3.0.0 | Librae AI Labs Sdn Bhd
rem =============================================================================
rem Launches install progress server, opens browser UI, runs wizard in background.
rem The user NEVER sees a terminal - browser is the installer window.
rem =============================================================================

setlocal EnableDelayedExpansion

set "SCRIPT_DIR=%~dp0"
set "INSTALLER_DIR=%SCRIPT_DIR%installer"
set "LOG_DIR=%USERPROFILE%\.cahaya"
set "LOG=%LOG_DIR%\install.log"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
echo [%DATE% %TIME%] CAHAYA install.bat entry point started >> "%LOG%"

rem =============================================================================
rem Check for Python
rem =============================================================================

where python >nul 2>nul
if %errorlevel% neq 0 (
    where python3 >nul 2>nul
    if %errorlevel% neq 0 (
        rem No Python - launch wizard directly (it handles Python install)
        echo [%DATE% %TIME%] Python not found - launching wizard directly >> "%LOG%"
        start "" "%INSTALLER_DIR%\install_wizard.bat"
        exit /b 0
    ) else (
        set "PYTHON_CMD=python3"
    )
) else (
    set "PYTHON_CMD=python"
)

echo [%DATE% %TIME%] Python found: %PYTHON_CMD% >> "%LOG%"

rem =============================================================================
rem Install FastAPI silently if needed
rem =============================================================================

%PYTHON_CMD% -c "import fastapi, uvicorn" >nul 2>nul
if %errorlevel% neq 0 (
    echo [%DATE% %TIME%] Installing FastAPI... >> "%LOG%"
    %PYTHON_CMD% -m pip install fastapi uvicorn aiofiles --quiet --disable-pip-version-check >> "%LOG%" 2>&1
)

rem =============================================================================
rem Start Install Progress Server
rem =============================================================================

if exist "%INSTALLER_DIR%\install_server.py" (
    echo [%DATE% %TIME%] Starting install progress server on port 8765... >> "%LOG%"
    start /B "" %PYTHON_CMD% "%INSTALLER_DIR%\install_server.py" --port 8765 >> "%LOG_DIR%\install_server.log" 2>&1

    rem Wait up to 5 seconds for server to start
    set COUNT=0
    :WAIT_SERVER
    timeout /t 1 /nobreak >nul
    curl -s http://127.0.0.1:8765/health >nul 2>nul
    if %errorlevel% equ 0 goto SERVER_READY
    set /A COUNT+=1
    if %COUNT% lss 5 goto WAIT_SERVER
    :SERVER_READY
    echo [%DATE% %TIME%] Install server ready >> "%LOG%"
)

rem =============================================================================
rem Open Installer UI in Default Browser
rem =============================================================================

echo [%DATE% %TIME%] Opening installer UI in browser... >> "%LOG%"
start "" "http://127.0.0.1:8765"

rem Small delay to let browser open
timeout /t 2 /nobreak >nul

rem =============================================================================
rem Run Install Wizard in Background
rem =============================================================================

if exist "%INSTALLER_DIR%\install_wizard.bat" (
    echo [%DATE% %TIME%] Launching install wizard... >> "%LOG%"
    start /B "" cmd /c "%INSTALLER_DIR%\install_wizard.bat" >> "%LOG%" 2>&1
    echo [%DATE% %TIME%] Install wizard launched >> "%LOG%"
) else (
    rem Fallback: run legacy install
    echo [%DATE% %TIME%] Running legacy install sequence... >> "%LOG%"

    if not exist "%LOG_DIR%\venv" (
        %PYTHON_CMD% -m venv "%LOG_DIR%\venv"
    )

    call "%LOG_DIR%\venv\Scripts\activate.bat"

    %PYTHON_CMD% -m pip install --upgrade pip -q >> "%LOG%" 2>&1

    if exist "%SCRIPT_DIR%backend\requirements.txt" (
        pip install -r "%SCRIPT_DIR%backend\requirements.txt" -q >> "%LOG%" 2>&1
    ) else (
        pip install fastapi uvicorn cryptography PyJWT python-dotenv httpx -q >> "%LOG%" 2>&1
    )

    rem Keys
    if not exist "%SCRIPT_DIR%crypto" mkdir "%SCRIPT_DIR%crypto"
    if not exist "%SCRIPT_DIR%crypto\private.pem" (
        %PYTHON_CMD% "%SCRIPT_DIR%crypto\generate_keypair.py" >> "%LOG%" 2>&1
    )

    rem Signal complete
    curl -s -X POST "http://127.0.0.1:8765/install-complete" ^
        -H "Content-Type: application/json" ^
        -d "{\"tier\":\"EDGE\",\"version\":\"3.0.0\"}" >nul 2>nul

    rem Start CAHAYA backend
    start /B "" uvicorn backend.main:app --host 127.0.0.1 --port 8000 >> "%LOG_DIR%\cahaya.log" 2>&1
    timeout /t 4 /nobreak >nul
    start "" "http://127.0.0.1:8000"
)

echo [%DATE% %TIME%] install.bat complete >> "%LOG%"
endlocal
