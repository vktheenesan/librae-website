/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  CAHAYA / LENUDA — First-Launch Onboarding & Hardware Detection ║
 * ║  Plain JS — no module, no external CSS dependency               ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * Load via: <script src="onboarding.js"></script>
 *
 * Exports on window:
 *   window.showOnboardingWizard()
 *   window.detectHardwareProfile()
 *   window.getOrgProfile()
 */

(function () {
  'use strict';

  /* ────────────────────────────────────────────────────────────────
   * 0.  INDUSTRY DEFINITIONS
   * ──────────────────────────────────────────────────────────────── */
  var INDUSTRIES = [
    { id: 'agriculture',          label: 'Agriculture',          icon: '🌾', desc: 'Precision farming & crop analytics' },
    { id: 'mining',               label: 'Mining',               icon: '⛏️', desc: 'Sub-surface mapping & extraction' },
    { id: 'urban_planning',       label: 'Urban Planning',       icon: '🏙️', desc: 'City-scale digital twins' },
    { id: 'defense',              label: 'Defense',              icon: '🛡️', desc: 'Tactical geospatial intelligence' },
    { id: 'maritime',             label: 'Maritime',             icon: '🚢', desc: 'Coastal & oceanic monitoring' },
    { id: 'environmental',        label: 'Environmental',        icon: '🌿', desc: 'Ecosystem health & conservation' },
    { id: 'energy',               label: 'Energy',               icon: '⚡', desc: 'Grid planning & resource siting' },
    { id: 'infrastructure',       label: 'Infrastructure',       icon: '🏗️', desc: 'Roads, bridges & structural health' },
    { id: 'forestry',             label: 'Forestry',             icon: '🌲', desc: 'Forest inventory & fire risk' },
    { id: 'emergency_response',   label: 'Emergency Response',   icon: '🚨', desc: 'Disaster mapping & SAR ops' }
  ];

  var DATA_SOURCES = [
    { id: 'gee',          label: 'Google Earth Engine' },
    { id: 'esri',         label: 'ESRI ArcGIS' },
    { id: 'sentinel_hub', label: 'Sentinel Hub' },
    { id: 'planet_labs',  label: 'Planet Labs' },
    { id: 'custom_api',   label: 'Custom API' }
  ];

  var COORD_SYSTEMS = ['WGS84', 'UTM', 'Local Grid'];

  /* ────────────────────────────────────────────────────────────────
   * 1.  INLINE STYLES (injected once)
   * ──────────────────────────────────────────────────────────────── */
  var STYLE_ID = 'cahaya-onboarding-styles';

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = '\
/* ── Overlay ───────────────────────────────── */\
#cahaya-onboarding-overlay {\
  position: fixed; inset: 0; z-index: 99999;\
  background: rgba(10,15,29,0.97);\
  display: flex; align-items: center; justify-content: center;\
  opacity: 0; transition: opacity .4s ease;\
  font-family: "Inter", sans-serif;\
  color: #e0e6f0;\
}\
#cahaya-onboarding-overlay.visible { opacity: 1; }\
\
/* ── Wizard card ──────────────────────────── */\
.cow-card {\
  width: min(720px, 92vw);\
  max-height: 88vh;\
  overflow-y: auto;\
  background: rgba(255,255,255,0.03);\
  border: 1px solid rgba(255,255,255,0.08);\
  border-radius: 20px;\
  padding: 40px 36px 32px;\
  backdrop-filter: blur(28px);\
  -webkit-backdrop-filter: blur(28px);\
  box-shadow: 0 24px 80px rgba(0,0,0,.55);\
  transform: translateY(20px) scale(.97);\
  transition: transform .45s cubic-bezier(.22,1,.36,1), opacity .45s ease;\
  opacity: 0;\
}\
#cahaya-onboarding-overlay.visible .cow-card { transform: translateY(0) scale(1); opacity: 1; }\
\
/* scrollbar */\
.cow-card::-webkit-scrollbar { width: 5px; }\
.cow-card::-webkit-scrollbar-track { background: transparent; }\
.cow-card::-webkit-scrollbar-thumb { background: rgba(255,183,3,.25); border-radius: 4px; }\
\
/* ── Step dots ────────────────────────────── */\
.cow-dots { display: flex; gap: 10px; justify-content: center; margin-bottom: 32px; }\
.cow-dot {\
  width: 10px; height: 10px; border-radius: 50%;\
  background: rgba(255,255,255,0.12);\
  transition: background .3s, box-shadow .3s, transform .3s;\
}\
.cow-dot.active {\
  background: #ffb703;\
  box-shadow: 0 0 10px rgba(255,183,3,.45);\
  transform: scale(1.25);\
}\
.cow-dot.done { background: rgba(255,183,3,.35); }\
\
/* ── Headings ─────────────────────────────── */\
.cow-title {\
  font-family: "Outfit", sans-serif;\
  font-size: 1.55rem; font-weight: 700;\
  text-align: center; margin: 0 0 6px;\
  background: linear-gradient(135deg, #ffffff 30%, #ffb703 100%);\
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;\
  background-clip: text;\
}\
.cow-subtitle {\
  text-align: center; font-size: .88rem;\
  color: rgba(255,255,255,.45); margin: 0 0 28px;\
}\
\
/* ── Industry cards grid ──────────────────── */\
.cow-grid {\
  display: grid;\
  grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));\
  gap: 12px; margin-bottom: 28px;\
}\
.cow-industry {\
  background: rgba(255,255,255,0.04);\
  border: 1px solid rgba(255,255,255,0.08);\
  border-radius: 14px;\
  padding: 18px 10px 14px;\
  text-align: center; cursor: pointer;\
  transition: border-color .25s, background .25s, transform .2s, box-shadow .25s;\
  user-select: none;\
}\
.cow-industry:hover {\
  background: rgba(255,255,255,0.07);\
  border-color: rgba(255,183,3,.25);\
  transform: translateY(-2px);\
}\
.cow-industry.selected {\
  background: rgba(255,183,3,0.08);\
  border-color: #ffb703;\
  box-shadow: 0 0 18px rgba(255,183,3,.18);\
  transform: translateY(-2px);\
}\
.cow-industry-icon { font-size: 1.75rem; margin-bottom: 6px; display: block; }\
.cow-industry-label {\
  font-family: "Outfit", sans-serif;\
  font-size: .82rem; font-weight: 600;\
  color: #e0e6f0;\
}\
.cow-industry-desc {\
  font-size: .68rem; color: rgba(255,255,255,.35);\
  margin-top: 3px; line-height: 1.25;\
}\
\
/* ── Form fields ──────────────────────────── */\
.cow-field { margin-bottom: 18px; }\
.cow-label {\
  display: block; font-size: .78rem;\
  font-weight: 600; color: rgba(255,255,255,.55);\
  margin-bottom: 6px; text-transform: uppercase;\
  letter-spacing: .06em;\
}\
.cow-input, .cow-select {\
  width: 100%; box-sizing: border-box;\
  padding: 11px 14px; font-size: .9rem;\
  color: #e0e6f0;\
  background: rgba(255,255,255,0.04);\
  border: 1px solid rgba(255,255,255,0.1);\
  border-radius: 10px; outline: none;\
  font-family: "Inter", sans-serif;\
  transition: border-color .25s, box-shadow .25s;\
}\
.cow-input:focus, .cow-select:focus {\
  border-color: #ffb703;\
  box-shadow: 0 0 0 3px rgba(255,183,3,.12);\
}\
.cow-select option { background: #0e1424; color: #e0e6f0; }\
\
/* logo upload */\
.cow-logo-upload {\
  display: flex; align-items: center; gap: 14px;\
}\
.cow-logo-preview {\
  width: 52px; height: 52px; border-radius: 12px;\
  background: rgba(255,255,255,.06);\
  border: 1px dashed rgba(255,255,255,.15);\
  display: flex; align-items: center; justify-content: center;\
  font-size: .65rem; color: rgba(255,255,255,.3);\
  overflow: hidden; flex-shrink: 0;\
}\
.cow-logo-preview img { width: 100%; height: 100%; object-fit: cover; border-radius: 12px; }\
.cow-logo-btn {\
  padding: 8px 16px; font-size: .78rem;\
  background: rgba(255,255,255,.06);\
  border: 1px solid rgba(255,255,255,.12);\
  border-radius: 8px; color: #ccc;\
  cursor: pointer; transition: background .2s;\
  font-family: "Inter", sans-serif;\
}\
.cow-logo-btn:hover { background: rgba(255,183,3,.12); border-color: rgba(255,183,3,.3); }\
\
/* ── Checkboxes ───────────────────────────── */\
.cow-checks { display: flex; flex-direction: column; gap: 10px; margin-bottom: 28px; }\
.cow-check-item {\
  display: flex; align-items: center; gap: 10px;\
  padding: 12px 16px;\
  background: rgba(255,255,255,0.04);\
  border: 1px solid rgba(255,255,255,0.08);\
  border-radius: 10px; cursor: pointer;\
  transition: border-color .25s, background .25s;\
  user-select: none;\
}\
.cow-check-item:hover { background: rgba(255,255,255,.07); }\
.cow-check-item.checked {\
  border-color: #ffb703;\
  background: rgba(255,183,3,.06);\
}\
.cow-check-box {\
  width: 20px; height: 20px; border-radius: 5px;\
  border: 2px solid rgba(255,255,255,.2);\
  flex-shrink: 0; display: flex;\
  align-items: center; justify-content: center;\
  transition: border-color .2s, background .2s;\
}\
.cow-check-item.checked .cow-check-box {\
  border-color: #ffb703; background: #ffb703;\
}\
.cow-check-item.checked .cow-check-box::after {\
  content: "✓"; color: #0a0f1d;\
  font-size: .75rem; font-weight: 700;\
}\
.cow-check-label { font-size: .88rem; color: #d0d6e0; }\
\
/* ── Buttons ──────────────────────────────── */\
.cow-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 8px; }\
.cow-btn {\
  padding: 11px 28px; border-radius: 10px; font-size: .88rem;\
  font-family: "Outfit", sans-serif; font-weight: 600;\
  cursor: pointer; border: none; transition: all .25s;\
}\
.cow-btn-back {\
  background: rgba(255,255,255,.06);\
  color: rgba(255,255,255,.55);\
  border: 1px solid rgba(255,255,255,.1);\
}\
.cow-btn-back:hover { background: rgba(255,255,255,.1); color: #fff; }\
.cow-btn-next {\
  background: linear-gradient(135deg, #ffb703, #fb8500);\
  color: #0a0f1d;\
  box-shadow: 0 4px 18px rgba(255,183,3,.25);\
}\
.cow-btn-next:hover {\
  box-shadow: 0 6px 26px rgba(255,183,3,.4);\
  transform: translateY(-1px);\
}\
.cow-btn-next:disabled {\
  opacity: .35; cursor: not-allowed;\
  transform: none; box-shadow: none;\
}\
\
/* ── Hardware badge ───────────────────────── */\
#cahaya-hw-badge {\
  display: inline-flex; align-items: center; gap: 6px;\
  padding: 4px 12px 4px 8px;\
  background: rgba(255,255,255,0.04);\
  border: 1px solid rgba(255,255,255,0.08);\
  border-radius: 8px; font-size: .7rem;\
  font-family: "JetBrains Mono", monospace;\
  color: rgba(255,255,255,.55);\
  cursor: default; user-select: none;\
  transition: border-color .3s;\
}\
#cahaya-hw-badge:hover { border-color: rgba(255,183,3,.3); }\
.hw-badge-dot {\
  width: 7px; height: 7px; border-radius: 50%;\
}\
.hw-tier-lite   .hw-badge-dot { background: #6c757d; box-shadow: 0 0 6px #6c757d; }\
.hw-tier-standard .hw-badge-dot { background: #00b4d8; box-shadow: 0 0 6px #00b4d8; }\
.hw-tier-pro    .hw-badge-dot { background: #ffb703; box-shadow: 0 0 6px #ffb703; }\
\
/* ── Animations ───────────────────────────── */\
@keyframes cow-fadeSlide {\
  from { opacity: 0; transform: translateY(14px); }\
  to   { opacity: 1; transform: translateY(0); }\
}\
.cow-step-body { animation: cow-fadeSlide .35s ease forwards; }\
';
    document.head.appendChild(s);
  }

  /* ────────────────────────────────────────────────────────────────
   * 2.  ONBOARDING WIZARD
   * ──────────────────────────────────────────────────────────────── */
  var wizardState = {
    step: 0,
    industry: null,
    orgName: '',
    logoBase64: null,
    coordSystem: 'WGS84',
    dataSources: []
  };

  function buildOverlay() {
    var el = document.createElement('div');
    el.id = 'cahaya-onboarding-overlay';
    el.innerHTML = '<div class="cow-card" id="cow-card"></div>';
    document.body.appendChild(el);
    return el;
  }

  function renderDots(step) {
    var html = '<div class="cow-dots">';
    for (var i = 0; i < 3; i++) {
      var cls = i === step ? 'active' : (i < step ? 'done' : '');
      html += '<div class="cow-dot ' + cls + '"></div>';
    }
    html += '</div>';
    return html;
  }

  /* ---------- Step 1: Industry ---------- */
  function renderStep1() {
    var html = renderDots(0);
    html += '<h2 class="cow-title">Select Your Industry</h2>';
    html += '<p class="cow-subtitle">Choose your primary operational domain for tailored analytics</p>';
    html += '<div class="cow-grid">';
    INDUSTRIES.forEach(function (ind) {
      var sel = wizardState.industry === ind.id ? ' selected' : '';
      html += '<div class="cow-industry' + sel + '" data-industry="' + ind.id + '">';
      html += '  <span class="cow-industry-icon">' + ind.icon + '</span>';
      html += '  <div class="cow-industry-label">' + ind.label + '</div>';
      html += '  <div class="cow-industry-desc">' + ind.desc + '</div>';
      html += '</div>';
    });
    html += '</div>';
    html += '<div class="cow-actions">';
    html += '  <button class="cow-btn cow-btn-next" id="cow-next-1" ' + (wizardState.industry ? '' : 'disabled') + '>Continue</button>';
    html += '</div>';
    return html;
  }

  function bindStep1() {
    var cards = document.querySelectorAll('.cow-industry');
    cards.forEach(function (c) {
      c.addEventListener('click', function () {
        cards.forEach(function (x) { x.classList.remove('selected'); });
        c.classList.add('selected');
        wizardState.industry = c.getAttribute('data-industry');
        var btn = document.getElementById('cow-next-1');
        if (btn) btn.disabled = false;
      });
    });
    var btn = document.getElementById('cow-next-1');
    if (btn) btn.addEventListener('click', function () {
      if (wizardState.industry) { wizardState.step = 1; renderCurrentStep(); }
    });
  }

  /* ---------- Step 2: Organisation ---------- */
  function renderStep2() {
    var html = renderDots(1);
    html += '<h2 class="cow-title">Organisation Profile</h2>';
    html += '<p class="cow-subtitle">Set up your workspace identity</p>';
    html += '<div class="cow-step-body">';

    // Org name
    html += '<div class="cow-field">';
    html += '  <label class="cow-label">Organisation Name</label>';
    html += '  <input class="cow-input" id="cow-org-name" type="text" placeholder="e.g. Nusantara GeoTech" value="' + escHtml(wizardState.orgName) + '">';
    html += '</div>';

    // Logo upload
    html += '<div class="cow-field">';
    html += '  <label class="cow-label">Logo (optional)</label>';
    html += '  <div class="cow-logo-upload">';
    html += '    <div class="cow-logo-preview" id="cow-logo-preview">';
    if (wizardState.logoBase64) {
      html += '<img src="' + wizardState.logoBase64 + '" alt="logo">';
    } else {
      html += 'No file';
    }
    html += '    </div>';
    html += '    <button class="cow-logo-btn" id="cow-logo-btn" type="button">Upload Logo</button>';
    html += '    <input type="file" id="cow-logo-input" accept="image/*" style="display:none">';
    html += '  </div>';
    html += '</div>';

    // Coordinate system
    html += '<div class="cow-field">';
    html += '  <label class="cow-label">Coordinate System</label>';
    html += '  <select class="cow-select" id="cow-coord">';
    COORD_SYSTEMS.forEach(function (cs) {
      var sel = wizardState.coordSystem === cs ? ' selected' : '';
      html += '<option value="' + cs + '"' + sel + '>' + cs + '</option>';
    });
    html += '  </select>';
    html += '</div>';

    html += '</div>'; // .cow-step-body

    html += '<div class="cow-actions">';
    html += '  <button class="cow-btn cow-btn-back" id="cow-back-2">Back</button>';
    html += '  <button class="cow-btn cow-btn-next" id="cow-next-2" ' + (wizardState.orgName.trim() ? '' : 'disabled') + '>Continue</button>';
    html += '</div>';
    return html;
  }

  function bindStep2() {
    var nameInput = document.getElementById('cow-org-name');
    var nextBtn = document.getElementById('cow-next-2');

    nameInput.addEventListener('input', function () {
      wizardState.orgName = nameInput.value;
      nextBtn.disabled = !nameInput.value.trim();
    });

    // Logo upload
    var logoBtn = document.getElementById('cow-logo-btn');
    var logoInput = document.getElementById('cow-logo-input');
    logoBtn.addEventListener('click', function () { logoInput.click(); });
    logoInput.addEventListener('change', function () {
      var file = logoInput.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function (e) {
        wizardState.logoBase64 = e.target.result;
        var preview = document.getElementById('cow-logo-preview');
        preview.innerHTML = '<img src="' + e.target.result + '" alt="logo">';
      };
      reader.readAsDataURL(file);
    });

    // Coord system
    var coordSel = document.getElementById('cow-coord');
    coordSel.addEventListener('change', function () {
      wizardState.coordSystem = coordSel.value;
    });

    // Back
    document.getElementById('cow-back-2').addEventListener('click', function () {
      wizardState.step = 0; renderCurrentStep();
    });
    // Next
    nextBtn.addEventListener('click', function () {
      if (wizardState.orgName.trim()) { wizardState.step = 2; renderCurrentStep(); }
    });
  }

  /* ---------- Step 3: Data Sources ---------- */
  function renderStep3() {
    var html = renderDots(2);
    html += '<h2 class="cow-title">Connect Data Sources</h2>';
    html += '<p class="cow-subtitle">Select the geospatial platforms you plan to integrate</p>';
    html += '<div class="cow-step-body">';
    html += '<div class="cow-checks">';
    DATA_SOURCES.forEach(function (ds) {
      var checked = wizardState.dataSources.indexOf(ds.id) !== -1 ? ' checked' : '';
      html += '<div class="cow-check-item' + checked + '" data-source="' + ds.id + '">';
      html += '  <div class="cow-check-box"></div>';
      html += '  <span class="cow-check-label">' + ds.label + '</span>';
      html += '</div>';
    });
    html += '</div></div>';

    html += '<div class="cow-actions">';
    html += '  <button class="cow-btn cow-btn-back" id="cow-back-3">Back</button>';
    html += '  <button class="cow-btn cow-btn-next" id="cow-finish">Launch CAHAYA</button>';
    html += '</div>';
    return html;
  }

  function bindStep3() {
    var items = document.querySelectorAll('.cow-check-item');
    items.forEach(function (item) {
      item.addEventListener('click', function () {
        var src = item.getAttribute('data-source');
        var idx = wizardState.dataSources.indexOf(src);
        if (idx === -1) {
          wizardState.dataSources.push(src);
          item.classList.add('checked');
        } else {
          wizardState.dataSources.splice(idx, 1);
          item.classList.remove('checked');
        }
      });
    });

    document.getElementById('cow-back-3').addEventListener('click', function () {
      wizardState.step = 1; renderCurrentStep();
    });
    document.getElementById('cow-finish').addEventListener('click', completeOnboarding);
  }

  /* ---------- Router ---------- */
  function renderCurrentStep() {
    var card = document.getElementById('cow-card');
    if (!card) return;
    var renderers = [renderStep1, renderStep2, renderStep3];
    var binders   = [bindStep1,  bindStep2,  bindStep3];
    card.innerHTML = renderers[wizardState.step]();
    binders[wizardState.step]();
  }

  /* ---------- Complete ---------- */
  function completeOnboarding() {
    var profile = {
      industry:     wizardState.industry,
      orgName:      wizardState.orgName.trim(),
      logoBase64:   wizardState.logoBase64,
      coordSystem:  wizardState.coordSystem,
      dataSources:  wizardState.dataSources,
      createdAt:    new Date().toISOString()
    };

    try {
      localStorage.setItem('cahaya_org_profile', JSON.stringify(profile));
      localStorage.setItem('cahaya_onboarded', 'true');
    } catch (e) {
      console.warn('[Onboarding] localStorage write failed:', e);
    }

    // Close overlay
    var overlay = document.getElementById('cahaya-onboarding-overlay');
    if (overlay) {
      overlay.classList.remove('visible');
      setTimeout(function () { overlay.remove(); }, 450);
    }

    // Dispatch custom event
    window.dispatchEvent(new CustomEvent('onboarding-complete', { detail: profile }));
    console.log('[CAHAYA] Onboarding complete:', profile);
  }

  /* ---------- Public: showOnboardingWizard ---------- */
  function showOnboardingWizard() {
    injectStyles();

    // Reset state
    wizardState.step = 0;
    wizardState.industry = null;
    wizardState.orgName = '';
    wizardState.logoBase64 = null;
    wizardState.coordSystem = 'WGS84';
    wizardState.dataSources = [];

    // Remove existing overlay if any
    var existing = document.getElementById('cahaya-onboarding-overlay');
    if (existing) existing.remove();

    var overlay = buildOverlay();
    renderCurrentStep();

    // Trigger CSS transition
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        overlay.classList.add('visible');
      });
    });
  }

  /* ---------- Public: getOrgProfile ---------- */
  function getOrgProfile() {
    try {
      var raw = localStorage.getItem('cahaya_org_profile');
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  /* ────────────────────────────────────────────────────────────────
   * 3.  HARDWARE DETECTION
   * ──────────────────────────────────────────────────────────────── */

  function detectHardwareProfile() {
    return new Promise(function (resolve) {
      var result = {
        gpu: 'Unknown',
        vram_estimate: 'Unknown',
        ram_gb: 0,
        storage_gb: 0,
        webgpu: false,
        recommended_tier: 'lite'
      };

      var hasWebGL2 = false;

      // ── WebGL detection ──
      try {
        var canvas = document.createElement('canvas');
        var gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
        if (gl) {
          hasWebGL2 = !!canvas.getContext('webgl2');
          var ext = gl.getExtension('WEBGL_debug_renderer_info');
          if (ext) {
            result.gpu = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || 'Unknown';
          }
          // VRAM estimate from MAX_TEXTURE_SIZE heuristic
          var maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE);
          if (maxTex >= 16384) result.vram_estimate = '≥4 GB';
          else if (maxTex >= 8192) result.vram_estimate = '~2 GB';
          else result.vram_estimate = '≤1 GB';
        }
      } catch (e) { /* swallow */ }

      // ── RAM ──
      result.ram_gb = navigator.deviceMemory || 0;

      // ── Storage + WebGPU (async) ──
      var promises = [];

      // Storage
      if (navigator.storage && navigator.storage.estimate) {
        promises.push(
          navigator.storage.estimate().then(function (est) {
            result.storage_gb = parseFloat(((est.quota || 0) / (1024 * 1024 * 1024)).toFixed(1));
          }).catch(function () {})
        );
      }

      // WebGPU
      if (navigator.gpu && navigator.gpu.requestAdapter) {
        promises.push(
          navigator.gpu.requestAdapter().then(function (adapter) {
            result.webgpu = !!adapter;
          }).catch(function () {
            result.webgpu = false;
          })
        );
      }

      Promise.all(promises).then(function () {
        // ── Tier recommendation ──
        if (result.ram_gb >= 8 && result.webgpu) {
          result.recommended_tier = 'pro';
        } else if (result.ram_gb >= 4 && hasWebGL2) {
          result.recommended_tier = 'standard';
        } else {
          result.recommended_tier = 'lite';
        }

        // Persist
        try {
          localStorage.setItem('cahaya_hw_profile', JSON.stringify(result));
        } catch (e) { /* swallow */ }

        // Render badge
        renderHardwareBadge(result);

        resolve(result);
      });
    });
  }

  function renderHardwareBadge(profile) {
    injectStyles();

    // Remove old badge
    var old = document.getElementById('cahaya-hw-badge');
    if (old) old.remove();

    var tierLabel = profile.recommended_tier.charAt(0).toUpperCase() + profile.recommended_tier.slice(1);
    var badge = document.createElement('div');
    badge.id = 'cahaya-hw-badge';
    badge.className = 'hw-tier-' + profile.recommended_tier;
    badge.innerHTML = '<span class="hw-badge-dot"></span>' + tierLabel + ' · ' + (profile.gpu.length > 32 ? profile.gpu.substring(0, 30) + '…' : profile.gpu);
    badge.title = 'GPU: ' + profile.gpu +
                  '\nVRAM: ' + profile.vram_estimate +
                  '\nRAM: ' + (profile.ram_gb || '?') + ' GB' +
                  '\nStorage: ' + profile.storage_gb + ' GB' +
                  '\nWebGPU: ' + (profile.webgpu ? 'Yes' : 'No') +
                  '\nTier: ' + tierLabel;

    // Attempt to inject into existing header
    var header = document.querySelector('.app-header .header-right')
              || document.querySelector('.app-header .header-left')
              || document.querySelector('.app-header')
              || document.querySelector('header');

    if (header) {
      header.appendChild(badge);
    } else {
      // Fallback: fixed position top-right
      badge.style.position = 'fixed';
      badge.style.top = '12px';
      badge.style.right = '12px';
      badge.style.zIndex = '9990';
      document.body.appendChild(badge);
    }
  }

  /* ────────────────────────────────────────────────────────────────
   * 4.  UTILITIES
   * ──────────────────────────────────────────────────────────────── */

  function escHtml(str) {
    var d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  /* ────────────────────────────────────────────────────────────────
   * 5.  AUTO-INIT ON PAGE LOAD
   * ──────────────────────────────────────────────────────────────── */

  function init() {
    // Hardware badge — always run
    detectHardwareProfile().catch(function (e) {
      console.warn('[CAHAYA] Hardware detection failed:', e);
    });

    // Onboarding — only on first launch
    if (!localStorage.getItem('cahaya_onboarded')) {
      // Small delay to let main page render first
      setTimeout(function () { showOnboardingWizard(); }, 600);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* ────────────────────────────────────────────────────────────────
   * 6.  EXPORT ON WINDOW
   * ──────────────────────────────────────────────────────────────── */
  window.showOnboardingWizard = showOnboardingWizard;
  window.detectHardwareProfile = detectHardwareProfile;
  window.getOrgProfile = getOrgProfile;

})();
