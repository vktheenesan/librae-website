#!/usr/bin/env python3
"""
CAHAYA Hardware Detection Module
Version 3.0.0 | Librae AI Labs Sdn Bhd

Detects system hardware and selects the optimal AI model tier.
Outputs JSON: {"tier": "EDGE|STANDARD|SOVEREIGN", "cpu_cores": N, "ram_gb": N,
               "gpu": "...", "vram_gb": N, "disk_free_gb": N}
"""

import json
import os
import platform
import subprocess
import sys
from pathlib import Path


def get_cpu_info() -> dict:
    """Detect CPU cores and frequency."""
    info = {"cores": 4, "ghz": 0.0, "name": "Unknown CPU"}
    try:
        import psutil
        info["cores"] = psutil.cpu_count(logical=True) or 4
        freq = psutil.cpu_freq()
        if freq:
            info["ghz"] = round(freq.max / 1000, 2)
    except ImportError:
        try:
            if platform.system() == "Darwin":
                result = subprocess.run(
                    ["sysctl", "-n", "hw.logicalcpu"],
                    capture_output=True, text=True, timeout=5
                )
                info["cores"] = int(result.stdout.strip()) if result.returncode == 0 else 4
                brand = subprocess.run(
                    ["sysctl", "-n", "machdep.cpu.brand_string"],
                    capture_output=True, text=True, timeout=5
                )
                info["name"] = brand.stdout.strip() if brand.returncode == 0 else "Apple CPU"
            elif platform.system() == "Linux":
                with open("/proc/cpuinfo") as f:
                    cpuinfo = f.read()
                cores = cpuinfo.count("processor\t:")
                info["cores"] = cores if cores > 0 else 4
                for line in cpuinfo.split("\n"):
                    if "model name" in line:
                        info["name"] = line.split(":", 1)[1].strip()
                        break
            elif platform.system() == "Windows":
                result = subprocess.run(
                    ["wmic", "cpu", "get", "NumberOfLogicalProcessors,MaxClockSpeed,Name", "/format:csv"],
                    capture_output=True, text=True, timeout=10
                )
                lines = [l.strip() for l in result.stdout.strip().split("\n")
                         if l.strip() and not l.startswith("Node")]
                if lines:
                    parts = lines[0].split(",")
                    if len(parts) >= 3:
                        info["ghz"] = round(int(parts[0]) / 1000, 2) if parts[0].isdigit() else 0.0
                        info["cores"] = int(parts[1]) if parts[1].isdigit() else 4
                        info["name"] = parts[2] if len(parts) > 2 else "CPU"
        except Exception:
            pass
    return info


def get_ram_gb() -> float:
    """Detect total system RAM in GB."""
    try:
        import psutil
        return round(psutil.virtual_memory().total / (1024 ** 3), 1)
    except ImportError:
        pass

    try:
        system = platform.system()
        if system == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                return round(int(result.stdout.strip()) / (1024 ** 3), 1)
        elif system == "Linux":
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        kb = int(line.split()[1])
                        return round(kb / (1024 ** 2), 1)
        elif system == "Windows":
            result = subprocess.run(
                ["wmic", "computersystem", "get", "TotalPhysicalMemory", "/format:csv"],
                capture_output=True, text=True, timeout=10
            )
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if line and not line.startswith("Node") and "," in line:
                    parts = line.split(",")
                    if parts[-1].isdigit():
                        return round(int(parts[-1]) / (1024 ** 3), 1)
    except Exception:
        pass
    return 8.0


def get_gpu_info() -> dict:
    """Detect GPU name and VRAM."""
    info = {"name": "Unknown GPU", "vram_gb": 0, "gpu_type": "CPU_ONLY"}
    system = platform.system()

    # Try PyTorch (most accurate)
    try:
        import torch
        if torch.cuda.is_available():
            info["name"] = torch.cuda.get_device_name(0)
            info["vram_gb"] = round(
                torch.cuda.get_device_properties(0).total_memory / (1024 ** 3), 1
            )
            info["gpu_type"] = "NVIDIA_CUDA"
            return info
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            import subprocess as sp
            chip = sp.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True
            ).stdout.strip()
            info["name"] = chip or "Apple Silicon"
            info["gpu_type"] = "APPLE_MPS"
            try:
                mem = sp.run(
                    ["sysctl", "-n", "hw.memsize"],
                    capture_output=True, text=True
                ).stdout.strip()
                info["vram_gb"] = round(int(mem) / (1024 ** 3), 1)
            except Exception:
                info["vram_gb"] = get_ram_gb()
            return info
    except ImportError:
        pass

    # Fallback: nvidia-smi
    try:
        name_result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10
        )
        vram_result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10
        )
        if name_result.returncode == 0:
            info["name"] = name_result.stdout.strip().split("\n")[0]
            info["gpu_type"] = "NVIDIA"
        if vram_result.returncode == 0:
            vram_mb = int(vram_result.stdout.strip().split("\n")[0].strip())
            info["vram_gb"] = round(vram_mb / 1024, 1)
        if info["gpu_type"] == "NVIDIA":
            return info
    except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
        pass

    # Fallback: Apple Silicon via sysctl
    if system == "Darwin":
        try:
            chip_result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True, timeout=5
            )
            chip = chip_result.stdout.strip()
            if not chip:
                sp_result = subprocess.run(
                    ["system_profiler", "SPHardwareDataType"],
                    capture_output=True, text=True, timeout=10
                )
                for line in sp_result.stdout.split("\n"):
                    if "Chip" in line or "Processor" in line:
                        chip = line.split(":", 1)[-1].strip()
                        break

            if "Apple" in chip:
                info["name"] = chip
                info["gpu_type"] = "APPLE_SILICON"
                mem_result = subprocess.run(
                    ["sysctl", "-n", "hw.memsize"],
                    capture_output=True, text=True, timeout=5
                )
                if mem_result.returncode == 0:
                    info["vram_gb"] = round(int(mem_result.stdout.strip()) / (1024 ** 3), 1)
                return info

            # Discrete/Intel GPU via system_profiler
            sp_result = subprocess.run(
                ["system_profiler", "SPDisplaysDataType"],
                capture_output=True, text=True, timeout=10
            )
            for line in sp_result.stdout.split("\n"):
                if "Chipset Model" in line:
                    info["name"] = line.split(":", 1)[-1].strip()
                    info["gpu_type"] = "DISCRETE"
                elif "VRAM" in line:
                    vram_str = line.split(":", 1)[-1].strip()
                    parts = vram_str.split()
                    if len(parts) >= 2:
                        val = float(parts[0])
                        unit = parts[1].upper()
                        info["vram_gb"] = round(val / 1024 if "MB" in unit else val, 1)
        except Exception:
            pass

    # Fallback: Windows wmic
    elif system == "Windows":
        try:
            result = subprocess.run(
                ["wmic", "path", "win32_VideoController",
                 "get", "Name,AdapterRAM", "/format:csv"],
                capture_output=True, text=True, timeout=10
            )
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if line and not line.startswith("Node") and "," in line:
                    parts = line.split(",")
                    if len(parts) >= 3 and parts[1].isdigit():
                        vram_bytes = int(parts[1])
                        info["name"] = parts[2]
                        info["vram_gb"] = round(vram_bytes / (1024 ** 3), 1)
                        info["gpu_type"] = "DISCRETE"
                        break
        except Exception:
            pass

    # Fallback: Linux lspci
    elif system == "Linux":
        try:
            result = subprocess.run(
                ["lspci"], capture_output=True, text=True, timeout=10
            )
            for line in result.stdout.split("\n"):
                if any(k in line.lower() for k in ["vga", "3d", "display"]):
                    info["name"] = line.split(":", 2)[-1].strip()
                    info["gpu_type"] = "INTEGRATED"
                    break
        except Exception:
            pass

    return info


def get_disk_free_gb(path: str = "/") -> float:
    """Get free disk space in GB for given path."""
    try:
        import shutil
        stat = shutil.disk_usage(path)
        return round(stat.free / (1024 ** 3), 1)
    except Exception:
        try:
            import ctypes
            if platform.system() == "Windows":
                free_bytes = ctypes.c_ulonglong(0)
                ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                    ctypes.c_wchar_p("C:\\"), None, None, ctypes.pointer(free_bytes)
                )
                return round(free_bytes.value / (1024 ** 3), 1)
        except Exception:
            pass
        return 0.0


def select_tier(ram_gb: float, vram_gb: float) -> str:
    """Select installation tier based on hardware."""
    if ram_gb >= 64 or vram_gb >= 48:
        return "SOVEREIGN"
    elif ram_gb >= 16 or vram_gb >= 8:
        return "STANDARD"
    else:
        return "EDGE"


def get_tier_config(tier: str) -> dict:
    """Return model config for selected tier."""
    configs = {
        "SOVEREIGN": {
            "model_name": "cahaya-72b-q4_k_m.gguf",
            "model_size": "72B",
            "model_size_gb": 45,
            "description": "Full sovereign intelligence — maximum capability"
        },
        "STANDARD": {
            "model_name": "cahaya-32b-q4_k_m.gguf",
            "model_size": "32B",
            "model_size_gb": 20,
            "description": "Professional grade — balanced performance"
        },
        "EDGE": {
            "model_name": "cahaya-7b-q4_k_m.gguf",
            "model_size": "7B",
            "model_size_gb": 5,
            "description": "Edge optimized — fast and lightweight"
        }
    }
    return configs.get(tier, configs["EDGE"])


def detect_all() -> dict:
    """Run full hardware detection and return structured results."""
    cpu = get_cpu_info()
    ram_gb = get_ram_gb()
    gpu = get_gpu_info()
    disk_free_gb = get_disk_free_gb(str(Path.home()))
    tier = select_tier(ram_gb, gpu["vram_gb"])
    tier_config = get_tier_config(tier)

    return {
        "tier": tier,
        "tier_config": tier_config,
        "cpu_cores": cpu["cores"],
        "cpu_ghz": cpu["ghz"],
        "cpu_name": cpu["name"],
        "ram_gb": ram_gb,
        "gpu": gpu["name"],
        "gpu_type": gpu["gpu_type"],
        "vram_gb": gpu["vram_gb"],
        "disk_free_gb": disk_free_gb,
        "platform": platform.system(),
        "arch": platform.machine(),
        "python_version": sys.version.split()[0],
        "message": (
            f"Your system has been detected as {tier} class. "
            f"CAHAYA will configure optimally for your hardware."
        )
    }


if __name__ == "__main__":
    result = detect_all()
    print(json.dumps(result, indent=2))
