#!/usr/bin/env python3
"""
CAHAYA Install Progress Server
Version 3.0.0 | Librae AI Labs Sdn Bhd

Tiny FastAPI server running on port 8765 during installation.
Provides real-time progress updates to the installer_ui.html page.
"""

import json
import os
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Optional

try:
    from fastapi import FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import HTMLResponse, JSONResponse
    import uvicorn
except ImportError:
    print("Installing server dependencies...")
    import subprocess
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "fastapi", "uvicorn", "aiofiles"],
        check=True
    )
    from fastapi import FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import HTMLResponse, JSONResponse
    import uvicorn


# ─── App Setup ────────────────────────────────────────────────────────────────
app = FastAPI(title="CAHAYA Install Server", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── State ────────────────────────────────────────────────────────────────────
INSTALL_STATE = {
    "step": 1,
    "step_name": "Welcome",
    "progress": 0,
    "message": "Initializing installer...",
    "tier": "DETECTING",
    "complete": False,
    "error": None,
    "started_at": time.time(),
    "logs": [],
    "hardware": {}
}

SHUTDOWN_EVENT = threading.Event()


# ─── HTML Loader ──────────────────────────────────────────────────────────────
def load_ui_html() -> str:
    """Load installer_ui.html from same directory as this script."""
    ui_path = Path(__file__).parent / "installer_ui.html"
    if ui_path.exists():
        return ui_path.read_text(encoding="utf-8")
    return """<!DOCTYPE html>
<html><head><title>CAHAYA Installer</title>
<style>body{background:#000A1A;color:#ffb703;font-family:Inter,sans-serif;
text-align:center;padding:100px;margin:0}</style></head>
<body>
<h1>CAHAYA™ Installer</h1>
<p>Loading installer interface...</p>
<script>setTimeout(() => location.reload(), 2000)</script>
</body></html>"""


# ─── Routes ───────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    """Serve the installer UI HTML page."""
    return HTMLResponse(content=load_ui_html())


@app.get("/install-status")
async def get_install_status():
    """Return current installation status."""
    return JSONResponse(content={
        "step": INSTALL_STATE["step"],
        "step_name": INSTALL_STATE["step_name"],
        "progress": INSTALL_STATE["progress"],
        "message": INSTALL_STATE["message"],
        "tier": INSTALL_STATE["tier"],
        "complete": INSTALL_STATE["complete"],
        "error": INSTALL_STATE["error"],
        "elapsed_seconds": round(time.time() - INSTALL_STATE["started_at"], 1),
        "logs": INSTALL_STATE["logs"][-20:],
        "hardware": INSTALL_STATE["hardware"]
    })


@app.post("/install-status")
async def post_install_status(request: Request):
    """Update installation status from the installer script."""
    try:
        data = await request.json()
        INSTALL_STATE["step"] = data.get("step", INSTALL_STATE["step"])
        INSTALL_STATE["step_name"] = data.get("step_name", INSTALL_STATE["step_name"])
        INSTALL_STATE["progress"] = data.get("progress", INSTALL_STATE["progress"])
        INSTALL_STATE["message"] = data.get("message", INSTALL_STATE["message"])
        INSTALL_STATE["tier"] = data.get("tier", INSTALL_STATE["tier"])

        if "hardware" in data:
            INSTALL_STATE["hardware"] = data["hardware"]

        INSTALL_STATE["logs"].append({
            "time": round(time.time() - INSTALL_STATE["started_at"], 1),
            "step": INSTALL_STATE["step"],
            "message": INSTALL_STATE["message"]
        })

        return JSONResponse(content={"ok": True})
    except Exception as e:
        return JSONResponse(content={"ok": False, "error": str(e)}, status_code=400)


@app.post("/install-complete")
async def install_complete(request: Request):
    """Called by installer when installation finishes. Schedules server shutdown."""
    try:
        data = await request.json()
        INSTALL_STATE["complete"] = True
        INSTALL_STATE["step"] = 6
        INSTALL_STATE["step_name"] = "Launch"
        INSTALL_STATE["progress"] = 100
        INSTALL_STATE["message"] = "CAHAYA is ready! Your AI workspace is launching..."
        INSTALL_STATE["tier"] = data.get("tier", INSTALL_STATE["tier"])
        INSTALL_STATE["logs"].append({
            "time": round(time.time() - INSTALL_STATE["started_at"], 1),
            "step": 6,
            "message": "Installation complete!"
        })

        # Schedule shutdown after 30 seconds so user can see the done screen
        def shutdown_later():
            time.sleep(30)
            SHUTDOWN_EVENT.set()
            os.kill(os.getpid(), signal.SIGTERM)

        t = threading.Thread(target=shutdown_later, daemon=True)
        t.start()

        return JSONResponse(content={
            "ok": True,
            "message": "Installation marked complete. Server shuts down in 30s."
        })
    except Exception as e:
        return JSONResponse(content={"ok": False, "error": str(e)}, status_code=400)


@app.post("/install-error")
async def install_error(request: Request):
    """Called by installer when an error occurs."""
    try:
        data = await request.json()
        INSTALL_STATE["error"] = data.get("error", "Unknown error occurred")
        INSTALL_STATE["message"] = f"Error: {INSTALL_STATE['error']}"
        return JSONResponse(content={"ok": True})
    except Exception as e:
        return JSONResponse(content={"ok": False, "error": str(e)}, status_code=400)


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return JSONResponse(content={"status": "ok", "service": "cahaya-install-server"})


@app.get("/hardware-detect")
async def run_hardware_detect():
    """Run hardware detection and return results."""
    try:
        detect_script = Path(__file__).parent / "detect_hardware.py"
        if detect_script.exists():
            import subprocess
            result = subprocess.run(
                [sys.executable, str(detect_script)],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                hw_data = json.loads(result.stdout)
                INSTALL_STATE["hardware"] = hw_data
                INSTALL_STATE["tier"] = hw_data.get("tier", "EDGE")
                return JSONResponse(content=hw_data)
    except Exception:
        pass

    import platform
    return JSONResponse(content={
        "tier": "EDGE",
        "cpu_cores": 4,
        "ram_gb": 8,
        "gpu": "Unknown",
        "vram_gb": 0,
        "disk_free_gb": 50,
        "platform": platform.system(),
        "message": (
            "Your system has been detected as EDGE class. "
            "CAHAYA will configure optimally for your hardware."
        )
    })


# ─── Main ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CAHAYA Install Progress Server")
    parser.add_argument("--port", type=int, default=8765, help="Port to run on")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host to bind")
    args = parser.parse_args()

    print(f"CAHAYA Install Server → http://{args.host}:{args.port}")
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
