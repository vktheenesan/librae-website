@echo off
setlocal EnableDelayedExpansion
rem =============================================================================
rem CAHAYA Sovereign Workspace - Windows Smart Installer Wizard
rem Version 3.0.0 | Librae AI Labs Sdn Bhd
rem =============================================================================
rem All interaction via Windows Forms / PowerShell dialogs. No terminal shown.
rem =============================================================================

set "INSTALL_DIR=%USERPROFILE%\.cahaya"
set "SERVER_PORT=8765"
set "APP_PORT=8000"
set "SCRIPT_DIR=%~dp0"
set "LOG=%INSTALL_DIR%\install.log"

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
echo [%DATE% %TIME%] CAHAYA Installer started >> "%LOG%"

rem =============================================================================
rem STEP 1: Welcome Dialog (PowerShell Windows Forms)
rem =============================================================================

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"Add-Type -AssemblyName System.Windows.Forms,System.Drawing; ^
$f = New-Object System.Windows.Forms.Form; ^
$f.Text = 'CAHAYA Sovereign Workspace - Installer'; ^
$f.Size = New-Object System.Drawing.Size(660,540); ^
$f.StartPosition = 'CenterScreen'; ^
$f.BackColor = [System.Drawing.Color]::FromArgb(0,10,26); ^
$f.FormBorderStyle = 'FixedDialog'; ^
$f.MaximizeBox = $false; ^
$lbl = New-Object System.Windows.Forms.Label; ^
$lbl.Text = 'CAHAYA  SOVEREIGN  WORKSPACE'; ^
$lbl.Font = New-Object System.Drawing.Font('Segoe UI',17,[System.Drawing.FontStyle]::Bold); ^
$lbl.ForeColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$lbl.Location = New-Object System.Drawing.Point(30,28); ^
$lbl.Size = New-Object System.Drawing.Size(600,44); ^
$lbl.TextAlign = 'MiddleCenter'; $f.Controls.Add($lbl); ^
$sub = New-Object System.Windows.Forms.Label; ^
$sub.Text = 'Librae AI Labs Sdn Bhd  |  Version 3.0.0  |  librae.work/cahaya'; ^
$sub.Font = New-Object System.Drawing.Font('Segoe UI',9); ^
$sub.ForeColor = [System.Drawing.Color]::FromArgb(120,160,200); ^
$sub.Location = New-Object System.Drawing.Point(30,74); ^
$sub.Size = New-Object System.Drawing.Size(600,20); ^
$sub.TextAlign = 'MiddleCenter'; $f.Controls.Add($sub); ^
$sep = New-Object System.Windows.Forms.Panel; ^
$sep.BackColor = [System.Drawing.Color]::FromArgb(60,40,0); ^
$sep.Location = New-Object System.Drawing.Point(30,102); ^
$sep.Size = New-Object System.Drawing.Size(600,1); $f.Controls.Add($sep); ^
$tc = New-Object System.Windows.Forms.RichTextBox; ^
$tc.Text = 'TERMS OF USE' + [char]13 + [char]10 + [char]13 + [char]10 + 'By proceeding, you agree to the CAHAYA End-User License Agreement. CAHAYA is licensed for personal and commercial use subject to the terms at librae.work/eula.' + [char]13 + [char]10 + [char]13 + [char]10 + 'PRIVACY: All AI models run entirely on your local device. No data is sent to external servers without your explicit consent.' + [char]13 + [char]10 + [char]13 + [char]10 + 'This installer will:' + [char]13 + [char]10 + '  * Detect your hardware configuration' + [char]13 + [char]10 + '  * Select the optimal AI model tier (EDGE / STANDARD / SOVEREIGN)' + [char]13 + [char]10 + '  * Download required components (5 - 45 GB depending on tier)' + [char]13 + [char]10 + '  * Create a Desktop shortcut' + [char]13 + [char]10 + '  * Launch CAHAYA in your default browser' + [char]13 + [char]10 + [char]13 + [char]10 + 'System Requirements:' + [char]13 + [char]10 + '  * Windows 10 / 11 (64-bit)' + [char]13 + [char]10 + '  * 8 GB RAM minimum (16 GB recommended)' + [char]13 + [char]10 + '  * 10 GB free disk space minimum' + [char]13 + [char]10 + '  * Internet connection for initial download'; ^
$tc.Font = New-Object System.Drawing.Font('Segoe UI',9.5); ^
$tc.BackColor = [System.Drawing.Color]::FromArgb(4,18,38); ^
$tc.ForeColor = [System.Drawing.Color]::FromArgb(190,210,235); ^
$tc.Location = New-Object System.Drawing.Point(30,116); ^
$tc.Size = New-Object System.Drawing.Size(600,280); ^
$tc.ReadOnly = $true; ^
$tc.BorderStyle = 'None'; $f.Controls.Add($tc); ^
$btnI = New-Object System.Windows.Forms.Button; ^
$btnI.Text = 'Install CAHAYA'; ^
$btnI.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); ^
$btnI.BackColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$btnI.ForeColor = [System.Drawing.Color]::Black; ^
$btnI.Location = New-Object System.Drawing.Point(400,460); ^
$btnI.Size = New-Object System.Drawing.Size(180,46); ^
$btnI.FlatStyle = 'Flat'; ^
$btnI.DialogResult = 'OK'; $f.Controls.Add($btnI); ^
$btnC = New-Object System.Windows.Forms.Button; ^
$btnC.Text = 'Cancel'; ^
$btnC.Font = New-Object System.Drawing.Font('Segoe UI',10); ^
$btnC.BackColor = [System.Drawing.Color]::FromArgb(18,28,48); ^
$btnC.ForeColor = [System.Drawing.Color]::Silver; ^
$btnC.Location = New-Object System.Drawing.Point(260,460); ^
$btnC.Size = New-Object System.Drawing.Size(120,46); ^
$btnC.FlatStyle = 'Flat'; ^
$btnC.DialogResult = 'Cancel'; $f.Controls.Add($btnC); ^
$f.AcceptButton = $btnI; $f.CancelButton = $btnC; ^
exit ($f.ShowDialog() -eq 'OK' ? 0 : 1)" 2>> "%LOG%"

if errorlevel 1 (
    echo User cancelled at welcome screen >> "%LOG%"
    exit /b 0
)

echo [%DATE% %TIME%] User accepted T^&C >> "%LOG%"

rem =============================================================================
rem STEP 2: Hardware Detection
rem =============================================================================

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"$ErrorActionPreference = 'Continue'; ^
Add-Type -AssemblyName System.Windows.Forms,System.Drawing; ^
$cpuCores = (Get-WmiObject Win32_Processor | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum; ^
$ramGB = [math]::Round((Get-WmiObject Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 0); ^
$gpuInfo = Get-WmiObject -Class Win32_VideoController | Where-Object { $_.Name -notlike '*Basic*' -and $_.Name -notlike '*Remote*' } | Select-Object -First 1; ^
$gpuName = if ($gpuInfo) { $gpuInfo.Name } else { 'Unknown GPU' }; ^
$vramGB = if ($gpuInfo -and $gpuInfo.AdapterRAM -gt 0) { [math]::Round($gpuInfo.AdapterRAM / 1GB, 0) } else { 0 }; ^
try { $nv = (nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>$null); if ($nv) { $vramGB = [math]::Round([int]($nv.Trim()) / 1024, 0) } } catch {} ^
if ($ramGB -ge 64 -or $vramGB -ge 48) { $tier = 'SOVEREIGN'; $modelSz = '72B'; $modelGB = 45 } ^
elseif ($ramGB -ge 16 -or $vramGB -ge 8)  { $tier = 'STANDARD'; $modelSz = '32B'; $modelGB = 20 } ^
else                                       { $tier = 'EDGE';     $modelSz = '7B';  $modelGB = 5 } ^
\"CPU_CORES=$cpuCores`nRAM_GB=$ramGB`nGPU_NAME=$gpuName`nVRAM_GB=$vramGB`nTIER=$tier`nMODEL_SIZE=$modelSz`nMODEL_GB=$modelGB\" | Set-Content '%INSTALL_DIR%\hw_detect.txt'; ^
$f = New-Object System.Windows.Forms.Form; ^
$f.Text = 'CAHAYA - Hardware Analysis'; ^
$f.Size = New-Object System.Drawing.Size(580,440); ^
$f.StartPosition = 'CenterScreen'; ^
$f.BackColor = [System.Drawing.Color]::FromArgb(0,10,26); ^
$f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; ^
$l = New-Object System.Windows.Forms.Label; ^
$l.Text = 'Hardware Analysis Complete'; ^
$l.Font = New-Object System.Drawing.Font('Segoe UI',15,[System.Drawing.FontStyle]::Bold); ^
$l.ForeColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$l.Location = New-Object System.Drawing.Point(30,28); ^
$l.Size = New-Object System.Drawing.Size(520,38); $f.Controls.Add($l); ^
$info = New-Object System.Windows.Forms.RichTextBox; ^
$info.Text = \"CPU Cores: $cpuCores`r`nRAM: $ramGB GB`r`nGPU: $gpuName`r`nVRAM: $vramGB GB`r`n`r`n────────────────────────────────`r`nYour system has been detected as $tier class. CAHAYA will configure optimally for your hardware.`r`n`r`nSelected AI Model: $modelSz Parameter Model`r`nEstimated Download: ~${modelGB} GB`r`n────────────────────────────────\"; ^
$info.Font = New-Object System.Drawing.Font('Segoe UI',10.5); ^
$info.BackColor = [System.Drawing.Color]::FromArgb(4,18,38); ^
$info.ForeColor = [System.Drawing.Color]::FromArgb(190,210,235); ^
$info.Location = New-Object System.Drawing.Point(30,76); ^
$info.Size = New-Object System.Drawing.Size(520,250); ^
$info.ReadOnly = $true; $info.BorderStyle = 'None'; $f.Controls.Add($info); ^
$btn = New-Object System.Windows.Forms.Button; ^
$btn.Text = 'Continue Installation'; ^
$btn.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); ^
$btn.BackColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$btn.ForeColor = [System.Drawing.Color]::Black; ^
$btn.Location = New-Object System.Drawing.Point(330,366); ^
$btn.Size = New-Object System.Drawing.Size(200,46); ^
$btn.FlatStyle = 'Flat'; $btn.DialogResult = 'OK'; $f.Controls.Add($btn); ^
$btnC = New-Object System.Windows.Forms.Button; ^
$btnC.Text = 'Cancel'; ^
$btnC.Font = New-Object System.Drawing.Font('Segoe UI',10); ^
$btnC.BackColor = [System.Drawing.Color]::FromArgb(18,28,48); ^
$btnC.ForeColor = [System.Drawing.Color]::Silver; ^
$btnC.Location = New-Object System.Drawing.Point(190,366); ^
$btnC.Size = New-Object System.Drawing.Size(120,46); ^
$btnC.FlatStyle = 'Flat'; $btnC.DialogResult = 'Cancel'; $f.Controls.Add($btnC); ^
exit ($f.ShowDialog() -eq 'OK' ? 0 : 2)" 2>> "%LOG%"

if errorlevel 2 (
    echo User cancelled at hardware screen >> "%LOG%"
    exit /b 0
)

rem Read hardware results
for /f "tokens=1,2 delims==" %%a in (%INSTALL_DIR%\hw_detect.txt) do (
    set %%a=%%b
)

echo [%DATE% %TIME%] RAM=%RAM_GB%GB GPU=%GPU_NAME% VRAM=%VRAM_GB%GB TIER=%TIER% >> "%LOG%"

rem =============================================================================
rem STEP 3: Python Install + Dependencies (with Progress Window)
rem =============================================================================

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"Add-Type -AssemblyName System.Windows.Forms,System.Drawing; ^
$f = New-Object System.Windows.Forms.Form; ^
$f.Text = 'CAHAYA - Installing Components'; ^
$f.Size = New-Object System.Drawing.Size(580,400); ^
$f.StartPosition = 'CenterScreen'; ^
$f.BackColor = [System.Drawing.Color]::FromArgb(0,10,26); ^
$f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.ControlBox = $false; ^
$lbl = New-Object System.Windows.Forms.Label; ^
$lbl.Text = 'Installing CAHAYA Components'; ^
$lbl.Font = New-Object System.Drawing.Font('Segoe UI',15,[System.Drawing.FontStyle]::Bold); ^
$lbl.ForeColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$lbl.Location = New-Object System.Drawing.Point(30,28); ^
$lbl.Size = New-Object System.Drawing.Size(520,38); $f.Controls.Add($lbl); ^
$status = New-Object System.Windows.Forms.Label; ^
$status.Text = 'Preparing installation...'; ^
$status.Font = New-Object System.Drawing.Font('Segoe UI',10); ^
$status.ForeColor = [System.Drawing.Color]::FromArgb(170,200,230); ^
$status.Location = New-Object System.Drawing.Point(30,76); ^
$status.Size = New-Object System.Drawing.Size(520,26); $f.Controls.Add($status); ^
$pb = New-Object System.Windows.Forms.ProgressBar; ^
$pb.Location = New-Object System.Drawing.Point(30,112); ^
$pb.Size = New-Object System.Drawing.Size(520,28); ^
$pb.Style = 'Continuous'; $f.Controls.Add($pb); ^
$log = New-Object System.Windows.Forms.RichTextBox; ^
$log.Font = New-Object System.Drawing.Font('Consolas',8.5); ^
$log.BackColor = [System.Drawing.Color]::FromArgb(2,10,22); ^
$log.ForeColor = [System.Drawing.Color]::FromArgb(80,200,120); ^
$log.Location = New-Object System.Drawing.Point(30,152); ^
$log.Size = New-Object System.Drawing.Size(520,196); ^
$log.ReadOnly = $true; $log.BorderStyle = 'None'; $f.Controls.Add($log); ^
$f.Show(); $f.Refresh(); ^
function upd($p,$m,$d) { ^
    $pb.Value = $p; $status.Text = $m; ^
    $log.AppendText('[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $d + \"`r`n\"); ^
    $log.ScrollToCaret(); $f.Refresh(); ^
    [System.Windows.Forms.Application]::DoEvents() ^
} ^
upd 5 'Checking Python...' 'Scanning for Python 3.x runtime'; ^
$py = (Get-Command python -ErrorAction SilentlyContinue); ^
if (-not $py) { ^
    upd 8 'Downloading Python 3.12...' 'Python not found - downloading installer'; ^
    Invoke-WebRequest 'https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe' -OutFile \"$env:TEMP\py_inst.exe\" -UseBasicParsing; ^
    upd 14 'Installing Python 3.12...' 'Running silent installer'; ^
    Start-Process -Wait \"$env:TEMP\py_inst.exe\" -ArgumentList '/quiet InstallAllUsers=1 PrependPath=1'; ^
    $env:PATH += ';C:\Program Files\Python312' ^
} ^
upd 22 'Creating virtual environment...' 'python -m venv .cahaya\venv'; ^
$vd = \"$env:USERPROFILE\.cahaya\venv\"; ^
& python -m venv $vd 2>&1 | ForEach-Object { upd 28 'Setting up venv...' $_ }; ^
upd 34 'Upgrading pip...' 'pip install --upgrade pip'; ^
& \"$vd\Scripts\pip.exe\" install --upgrade pip -q 2>&1 | Out-Null; ^
upd 40 'Installing web framework...' 'fastapi uvicorn aiofiles'; ^
& \"$vd\Scripts\pip.exe\" install fastapi uvicorn cryptography PyJWT python-dotenv httpx aiofiles -q 2>&1 | ForEach-Object { upd 52 'Installing packages...' $_ }; ^
upd 60 'Installing AI runtime (llama-cpp-python)...' 'This may take several minutes...'; ^
& \"$vd\Scripts\pip.exe\" install llama-cpp-python 2>&1 | ForEach-Object { upd 75 'Installing AI runtime...' $_ }; ^
upd 82 'Copying application files...' 'Installing CAHAYA app'; ^
$appDir = \"$env:USERPROFILE\.cahaya\app\"; ^
if (-not (Test-Path $appDir)) { New-Item -ItemType Directory -Path $appDir -Force | Out-Null }; ^
Copy-Item -Path '%SCRIPT_DIR%..\*' -Destination $appDir -Recurse -Force -ErrorAction SilentlyContinue; ^
upd 90 'Writing configuration...' 'Tier: %TIER% | Model: %MODEL_SIZE%'; ^
@{ tier='%TIER%'; model_size='%MODEL_SIZE%'; gpu='%GPU_NAME%'; ram_gb=%RAM_GB%; cpu_cores=%CPU_CORES%; version='3.0.0'; install_date=(Get-Date -Format 'o') } | ConvertTo-Json | Set-Content \"$env:USERPROFILE\.cahaya\cahaya.config.json\"; ^
upd 96 'Creating Desktop shortcut...' 'Adding CAHAYA shortcut to Desktop'; ^
$ws = New-Object -ComObject WScript.Shell; ^
$sc = $ws.CreateShortcut(\"$env:USERPROFILE\Desktop\CAHAYA.lnk\"); ^
$sc.TargetPath = \"$vd\Scripts\uvicorn.exe\"; ^
$sc.Arguments = 'backend.main:app --host 127.0.0.1 --port 8000'; ^
$sc.WorkingDirectory = $appDir; ^
$sc.Description = 'CAHAYA Sovereign Workspace — Librae AI Labs'; $sc.Save(); ^
upd 100 'Installation Complete!' 'All components installed successfully.'; ^
Start-Sleep 2; $f.Close()" 2>> "%LOG%"

rem =============================================================================
rem STEP 4: Launch CAHAYA
rem =============================================================================

echo [%DATE% %TIME%] Starting CAHAYA backend >> "%LOG%"

set "VENV_DIR=%USERPROFILE%\.cahaya\venv"
set "APP_DIR=%USERPROFILE%\.cahaya\app"

start /B "" "%VENV_DIR%\Scripts\uvicorn.exe" backend.main:app --host 127.0.0.1 --port %APP_PORT% >> "%LOG%" 2>&1

timeout /t 4 /nobreak >nul

rem Open in browser
start "" "http://127.0.0.1:%APP_PORT%"

rem Done dialog
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"Add-Type -AssemblyName System.Windows.Forms,System.Drawing; ^
$f = New-Object System.Windows.Forms.Form; ^
$f.Text = 'CAHAYA - Ready!'; ^
$f.Size = New-Object System.Drawing.Size(520,320); ^
$f.StartPosition = 'CenterScreen'; ^
$f.BackColor = [System.Drawing.Color]::FromArgb(0,10,26); ^
$f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; ^
$ico = New-Object System.Windows.Forms.Label; ^
$ico.Text = '✦'; ^
$ico.Font = New-Object System.Drawing.Font('Segoe UI',52); ^
$ico.ForeColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$ico.Location = New-Object System.Drawing.Point(200,28); ^
$ico.Size = New-Object System.Drawing.Size(120,80); ^
$ico.TextAlign = 'MiddleCenter'; $f.Controls.Add($ico); ^
$lbl = New-Object System.Windows.Forms.Label; ^
$lbl.Text = 'CAHAYA is ready!'; ^
$lbl.Font = New-Object System.Drawing.Font('Segoe UI',18,[System.Drawing.FontStyle]::Bold); ^
$lbl.ForeColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$lbl.Location = New-Object System.Drawing.Point(30,118); ^
$lbl.Size = New-Object System.Drawing.Size(460,40); ^
$lbl.TextAlign = 'MiddleCenter'; $f.Controls.Add($lbl); ^
$sub = New-Object System.Windows.Forms.Label; ^
$sub.Text = 'Your AI workspace is launching...' + [char]13 + [char]10 + 'Tier: %TIER%  |  Model: %MODEL_SIZE%  |  http://127.0.0.1:%APP_PORT%'; ^
$sub.Font = New-Object System.Drawing.Font('Segoe UI',10); ^
$sub.ForeColor = [System.Drawing.Color]::FromArgb(150,180,220); ^
$sub.Location = New-Object System.Drawing.Point(30,162); ^
$sub.Size = New-Object System.Drawing.Size(460,52); ^
$sub.TextAlign = 'MiddleCenter'; $f.Controls.Add($sub); ^
$btn = New-Object System.Windows.Forms.Button; ^
$btn.Text = 'Open CAHAYA'; ^
$btn.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); ^
$btn.BackColor = [System.Drawing.Color]::FromArgb(255,183,3); ^
$btn.ForeColor = [System.Drawing.Color]::Black; ^
$btn.Location = New-Object System.Drawing.Point(175,232); ^
$btn.Size = New-Object System.Drawing.Size(170,46); ^
$btn.FlatStyle = 'Flat'; ^
$btn.Add_Click({ Start-Process 'http://127.0.0.1:%APP_PORT%'; $f.Close() }); ^
$f.Controls.Add($btn); $f.ShowDialog()" 2>> "%LOG%"

echo [%DATE% %TIME%] Installation complete. Tier=%TIER% >> "%LOG%"
endlocal
