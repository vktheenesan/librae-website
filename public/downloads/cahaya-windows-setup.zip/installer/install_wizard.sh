#!/usr/bin/env bash
# =============================================================================
# CAHAYA Sovereign Workspace — macOS/Linux Smart Installer Wizard
# Version 3.0.0 | Librae AI Labs Sdn Bhd
# =============================================================================
# NEVER shows a terminal to the user. All interaction via osascript / zenity.
# =============================================================================

set -euo pipefail

# ─── Constants ────────────────────────────────────────────────────────────────
INSTALL_DIR="$HOME/.cahaya"
INSTALL_LOG="$INSTALL_DIR/install.log"
SERVER_PORT=8765
APP_PORT=8000
BASE_URL="https://cdn.librae.work/cahaya/v3"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$INSTALL_DIR"
exec > >(tee -a "$INSTALL_LOG") 2>&1
echo "[$(date)] CAHAYA Installer started"

OS_TYPE="$(uname -s)"

# ─── Dialog helpers ───────────────────────────────────────────────────────────
dialog_alert() {
    local title="$1" msg="$2"
    if [[ "$OS_TYPE" == "Darwin" ]]; then
        osascript -e "display dialog \"$msg\" with title \"$title\" buttons {\"OK\"} default button \"OK\" with icon note" 2>/dev/null || true
    else
        zenity --info --title="$title" --text="$msg" --width=480 2>/dev/null || echo "$msg"
    fi
}

dialog_question() {
    local title="$1" msg="$2" btn1="$3" btn2="$4"
    if [[ "$OS_TYPE" == "Darwin" ]]; then
        local result
        result=$(osascript -e "display dialog \"$msg\" with title \"$title\" buttons {\"$btn2\", \"$btn1\"} default button \"$btn1\"" 2>&1) || return 1
        echo "$result" | grep -q "$btn1" && return 0 || return 1
    else
        zenity --question --title="$title" --text="$msg" --ok-label="$btn1" --cancel-label="$btn2" --width=480 2>/dev/null
    fi
}

dialog_error() {
    local title="$1" msg="$2"
    if [[ "$OS_TYPE" == "Darwin" ]]; then
        osascript -e "display dialog \"$msg\" with title \"$title\" buttons {\"Quit\"} default button \"Quit\" with icon stop" 2>/dev/null || true
    else
        zenity --error --title="$title" --text="$msg" --width=480 2>/dev/null || echo "ERROR: $msg"
    fi
}

post_status() {
    local step="$1" step_name="$2" progress="$3" message="$4" tier="${5:-DETECTING}"
    curl -s -X POST "http://127.0.0.1:$SERVER_PORT/install-status" \
        -H "Content-Type: application/json" \
        -d "{\"step\": $step, \"step_name\": \"$step_name\", \"progress\": $progress, \"message\": \"$message\", \"tier\": \"$tier\"}" \
        2>/dev/null || true
}

# ─── STEP 1: Welcome ──────────────────────────────────────────────────────────
WELCOME_MSG="CAHAYA Sovereign Workspace

Publisher: Librae AI Labs Sdn Bhd
Version: 3.0.0

TERMS OF USE

By proceeding, you agree to the CAHAYA End-User License Agreement.
CAHAYA is licensed for personal and commercial use at librae.work/eula.

All AI models run locally on your device.
No data is sent externally without your consent.

This installer will:
* Detect your hardware configuration
* Select the optimal AI model tier
* Download required components
* Create a Desktop launcher (CAHAYA.app)

Click 'Install CAHAYA' to continue."

post_status 1 "Welcome" 0 "Waiting for user confirmation" "DETECTING"

if ! dialog_question "CAHAYA Installer — Librae AI Labs" "$WELCOME_MSG" "Install CAHAYA" "Cancel"; then
    echo "[$(date)] User cancelled at welcome screen"
    exit 0
fi

echo "[$(date)] User accepted T&C"
post_status 1 "Welcome" 100 "Terms accepted" "DETECTING"

# ─── STEP 2: Hardware Detection ───────────────────────────────────────────────
post_status 2 "Hardware Scan" 10 "Scanning CPU..." "DETECTING"

CPU_CORES=$(sysctl -n hw.logicalcpu 2>/dev/null || nproc 2>/dev/null || echo 4)

if [[ "$OS_TYPE" == "Darwin" ]]; then
    RAM_BYTES=$(sysctl -n hw.memsize 2>/dev/null || echo 8589934592)
    RAM_GB=$(( RAM_BYTES / 1073741824 ))
else
    RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    RAM_GB=$(( RAM_KB / 1048576 ))
fi

post_status 2 "Hardware Scan" 30 "Scanning GPU..." "DETECTING"

GPU_NAME="Unknown"
VRAM_GB=0
GPU_TYPE="CPU_ONLY"

if [[ "$OS_TYPE" == "Darwin" ]]; then
    CHIP=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo "")
    if echo "$CHIP" | grep -qi "Apple"; then
        GPU_TYPE="APPLE_SILICON"
        VRAM_GB=$RAM_GB
        if echo "$CHIP" | grep -qi "M4"; then GPU_NAME="Apple M4"
        elif echo "$CHIP" | grep -qi "M3"; then GPU_NAME="Apple M3"
        elif echo "$CHIP" | grep -qi "M2"; then GPU_NAME="Apple M2"
        elif echo "$CHIP" | grep -qi "M1"; then GPU_NAME="Apple M1"
        else GPU_NAME="Apple Silicon"; fi
    else
        GPU_NAME=$(system_profiler SPDisplaysDataType 2>/dev/null | grep "Chipset Model" | head -1 | awk -F: '{print $2}' | xargs || echo "Intel/AMD GPU")
        GPU_TYPE="DISCRETE"
    fi
else
    if command -v nvidia-smi &>/dev/null; then
        GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1 || echo "NVIDIA GPU")
        VRAM_MB=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ' || echo "0")
        VRAM_GB=$(( VRAM_MB / 1024 ))
        GPU_TYPE="NVIDIA"
    elif command -v lspci &>/dev/null; then
        GPU_NAME=$(lspci | grep -i 'vga\|3d\|display' | head -1 | cut -d: -f3 | xargs || echo "Integrated GPU")
        GPU_TYPE="INTEGRATED"
    fi
fi

post_status 2 "Hardware Scan" 60 "Analyzing hardware tier..." "DETECTING"

# ─── Tier Selection ───────────────────────────────────────────────────────────
if [[ $RAM_GB -ge 64 ]] || [[ $VRAM_GB -ge 48 ]]; then
    TIER="SOVEREIGN"; MODEL_SIZE="72B"; MODEL_FILE="cahaya-72b-q4_k_m.gguf"; MODEL_SIZE_GB=45
elif [[ $RAM_GB -ge 16 ]] || [[ $VRAM_GB -ge 8 ]]; then
    TIER="STANDARD"; MODEL_SIZE="32B"; MODEL_FILE="cahaya-32b-q4_k_m.gguf"; MODEL_SIZE_GB=20
else
    TIER="EDGE"; MODEL_SIZE="7B"; MODEL_FILE="cahaya-7b-q4_k_m.gguf"; MODEL_SIZE_GB=5
fi

post_status 2 "Hardware Scan" 100 "Tier detected: $TIER" "$TIER"

DETECT_MSG="Hardware Analysis Complete

CPU Cores: $CPU_CORES
RAM: ${RAM_GB} GB
GPU: $GPU_NAME
VRAM: ${VRAM_GB} GB

Your system has been detected as $TIER class.
CAHAYA will configure optimally for your hardware.

Selected AI Model: $MODEL_SIZE Parameter Model
Estimated download: ~${MODEL_SIZE_GB} GB

Click 'Continue' to proceed with installation."

if ! dialog_question "CAHAYA — Hardware Detected" "$DETECT_MSG" "Continue" "Cancel"; then
    echo "[$(date)] User cancelled at hardware detection"
    exit 0
fi

echo "[$(date)] Hardware: RAM=${RAM_GB}GB GPU=$GPU_NAME VRAM=${VRAM_GB}GB TIER=$TIER"

# ─── STEP 3: Prerequisites ────────────────────────────────────────────────────
post_status 3 "Prerequisites" 10 "Checking Python..." "$TIER"

if ! command -v python3 &>/dev/null; then
    dialog_alert "CAHAYA Installer" "Python 3 is required. The installer will download and install it now."
    if [[ "$OS_TYPE" == "Darwin" ]]; then
        if command -v brew &>/dev/null; then
            brew install python3 2>&1 | tee -a "$INSTALL_LOG"
        else
            PYTHON_PKG="$INSTALL_DIR/python3_installer.pkg"
            curl -L "https://www.python.org/ftp/python/3.12.0/python-3.12.0-macos11.pkg" -o "$PYTHON_PKG"
            sudo installer -pkg "$PYTHON_PKG" -target /
        fi
    else
        sudo apt-get update -qq && sudo apt-get install -y python3 python3-pip python3-venv 2>&1 | tee -a "$INSTALL_LOG" || \
        sudo yum install -y python3 python3-pip 2>&1 | tee -a "$INSTALL_LOG" || true
    fi
fi

post_status 3 "Prerequisites" 30 "Setting up virtual environment..." "$TIER"

VENV_DIR="$INSTALL_DIR/venv"
if [[ ! -d "$VENV_DIR" ]]; then
    python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"

post_status 3 "Prerequisites" 50 "Installing Python packages..." "$TIER"

pip install --upgrade pip -q 2>&1 | tee -a "$INSTALL_LOG"
pip install fastapi uvicorn cryptography PyJWT python-dotenv httpx aiofiles -q 2>&1 | tee -a "$INSTALL_LOG"

post_status 3 "Prerequisites" 80 "Installing AI runtime (llama-cpp-python)..." "$TIER"

if [[ "$GPU_TYPE" == "APPLE_SILICON" || "$GPU_TYPE" == "APPLE_MPS" ]]; then
    CMAKE_ARGS="-DLLAMA_METAL=on" pip install llama-cpp-python --force-reinstall 2>&1 | tee -a "$INSTALL_LOG" || \
    pip install llama-cpp-python 2>&1 | tee -a "$INSTALL_LOG"
elif [[ "$GPU_TYPE" == "NVIDIA" ]]; then
    CMAKE_ARGS="-DLLAMA_CUDA=on" pip install llama-cpp-python --force-reinstall 2>&1 | tee -a "$INSTALL_LOG" || \
    pip install llama-cpp-python 2>&1 | tee -a "$INSTALL_LOG"
else
    pip install llama-cpp-python 2>&1 | tee -a "$INSTALL_LOG"
fi

post_status 3 "Prerequisites" 100 "Runtime ready" "$TIER"

# ─── STEP 4: Copy App Files ───────────────────────────────────────────────────
post_status 4 "Installing" 10 "Copying application files..." "$TIER"

mkdir -p "$INSTALL_DIR/app"
cp -r "$SCRIPT_DIR"/../* "$INSTALL_DIR/app/" 2>/dev/null || true

post_status 4 "Installing" 30 "Creating model directory..." "$TIER"
mkdir -p "$INSTALL_DIR/models"

# ─── STEP 4b: Download AI Model ───────────────────────────────────────────────
post_status 4 "Downloading AI Model" 35 "Starting model download: $MODEL_FILE" "$TIER"

MODEL_PATH="$INSTALL_DIR/models/$MODEL_FILE"

if [[ ! -f "$MODEL_PATH" ]]; then
    echo "[$(date)] Downloading $MODEL_FILE (~${MODEL_SIZE_GB}GB)"
    MODEL_URL="$BASE_URL/models/$MODEL_FILE"
    curl -L --progress-bar "$MODEL_URL" -o "$MODEL_PATH" 2>&1 | \
    while IFS= read -r line; do
        if [[ "$line" =~ ([0-9]+)% ]]; then
            PCT="${BASH_REMATCH[1]}"
            SCALED=$(( 35 + (PCT * 50 / 100) ))
            post_status 4 "Downloading AI Model" "$SCALED" "Downloading $MODEL_FILE: ${PCT}%" "$TIER"
        fi
    done || {
        echo "[$(date)] WARNING: Model download failed. Will complete on first launch."
        dialog_alert "CAHAYA Installer" "Model download will complete on first launch.\nYou can also download from: librae.work/cahaya/models"
    }
fi

post_status 4 "Downloading AI Model" 85 "Finalizing download..." "$TIER"

# ─── STEP 5: Write Config ─────────────────────────────────────────────────────
post_status 5 "Finalizing" 10 "Writing configuration..." "$TIER"

cat > "$INSTALL_DIR/cahaya.config.json" <<EOF
{
  "tier": "$TIER",
  "model": "$MODEL_FILE",
  "model_size": "$MODEL_SIZE",
  "gpu": "$GPU_NAME",
  "gpu_type": "$GPU_TYPE",
  "vram_gb": $VRAM_GB,
  "ram_gb": $RAM_GB,
  "cpu_cores": $CPU_CORES,
  "install_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "version": "3.0.0"
}
EOF

post_status 5 "Finalizing" 50 "Creating Desktop shortcut..." "$TIER"

DESKTOP="$HOME/Desktop"

if [[ "$OS_TYPE" == "Darwin" ]]; then
    APP_BUNDLE="$DESKTOP/CAHAYA.app"
    mkdir -p "$APP_BUNDLE/Contents/MacOS"
    mkdir -p "$APP_BUNDLE/Contents/Resources"

    # Launcher script inside the .app bundle
    cat > "$APP_BUNDLE/Contents/MacOS/CAHAYA" <<'APPSCRIPT'
#!/usr/bin/env bash
INSTALL_DIR="$HOME/.cahaya"
VENV_DIR="$INSTALL_DIR/venv"
APP_DIR="$INSTALL_DIR/app"
LOG="$INSTALL_DIR/cahaya.log"
source "$VENV_DIR/bin/activate"
cd "$APP_DIR" && uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload >> "$LOG" 2>&1 &
echo $! > "$INSTALL_DIR/backend.pid"
sleep 3
open "http://127.0.0.1:8000"
APPSCRIPT

    chmod +x "$APP_BUNDLE/Contents/MacOS/CAHAYA"

    cat > "$APP_BUNDLE/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key><string>CAHAYA</string>
    <key>CFBundleIdentifier</key><string>work.librae.cahaya</string>
    <key>CFBundleName</key><string>CAHAYA</string>
    <key>CFBundleDisplayName</key><string>CAHAYA</string>
    <key>CFBundleVersion</key><string>3.0.0</string>
    <key>CFBundleShortVersionString</key><string>3.0.0</string>
    <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST
    echo "[$(date)] Created CAHAYA.app at $APP_BUNDLE"
else
    # Linux .desktop file
    DESKTOP_FILE="$DESKTOP/CAHAYA.desktop"
    cat > "$DESKTOP_FILE" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=CAHAYA
Comment=CAHAYA Sovereign Workspace by Librae AI Labs
Exec=bash -c 'source $HOME/.cahaya/venv/bin/activate && cd $HOME/.cahaya/app && uvicorn backend.main:app --host 127.0.0.1 --port 8000 & sleep 3 && xdg-open http://127.0.0.1:8000'
Icon=$HOME/.cahaya/app/icons/cahaya_icon.png
Terminal=false
Categories=Office;Science;
StartupNotify=true
DESKTOP
    chmod +x "$DESKTOP_FILE"
    echo "[$(date)] Created CAHAYA.desktop at $DESKTOP_FILE"
fi

post_status 5 "Finalizing" 100 "Installation complete!" "$TIER"

# ─── STEP 6: Launch CAHAYA ────────────────────────────────────────────────────
post_status 6 "Launching" 50 "Starting CAHAYA..." "$TIER"

source "$VENV_DIR/bin/activate"
cd "$INSTALL_DIR/app" 2>/dev/null || cd "$SCRIPT_DIR/.."

uvicorn backend.main:app --host 127.0.0.1 --port "$APP_PORT" --reload >> "$INSTALL_DIR/cahaya.log" 2>&1 &
BACKEND_PID=$!
echo "$BACKEND_PID" > "$INSTALL_DIR/backend.pid"

# Wait for backend
for i in {1..15}; do
    if curl -s "http://127.0.0.1:$APP_PORT/health" &>/dev/null; then break; fi
    sleep 1
done

# Open browser
if [[ "$OS_TYPE" == "Darwin" ]]; then
    open "http://127.0.0.1:$APP_PORT"
else
    xdg-open "http://127.0.0.1:$APP_PORT" 2>/dev/null || \
    firefox "http://127.0.0.1:$APP_PORT" 2>/dev/null || true
fi

post_status 6 "Launching" 100 "CAHAYA is ready!" "$TIER"

# Signal install server to shut down
curl -s -X POST "http://127.0.0.1:$SERVER_PORT/install-complete" \
    -H "Content-Type: application/json" \
    -d "{\"tier\": \"$TIER\", \"version\": \"3.0.0\"}" 2>/dev/null || true

# ─── Done dialog ──────────────────────────────────────────────────────────────
dialog_alert "CAHAYA — Ready!" \
"CAHAYA is ready! Your AI workspace is launching...

Tier: $TIER
Model: $MODEL_SIZE Parameters
URL: http://127.0.0.1:$APP_PORT

A Desktop shortcut (CAHAYA.app) has been created.

Librae AI Labs Sdn Bhd"

echo "[$(date)] Installation complete. Tier=$TIER"
