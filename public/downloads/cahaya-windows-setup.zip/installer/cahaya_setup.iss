; =============================================================================
; CAHAYA Sovereign Workspace — Inno Setup Script
; Version 3.0.0 | Librae AI Labs Sdn Bhd
; =============================================================================
; Compile with Inno Setup 6.x: https://jrsoftware.org/isinfo.php
; Output: CAHAYA_Setup_3.0.0.exe
; =============================================================================

#define AppName "CAHAYA Sovereign Workspace"
#define AppVersion "3.0.0"
#define AppPublisher "Librae AI Labs Sdn Bhd"
#define AppURL "https://librae.work/cahaya"
#define AppSupportURL "https://librae.work/support"
#define AppExeName "CAHAYA.exe"
#define AppId "{{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}"

[Setup]
; Basic info
AppId={#AppId}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppSupportURL}
AppUpdatesURL={#AppURL}
AppCopyright=Copyright (C) 2024-2026 Librae AI Labs Sdn Bhd. All rights reserved.

; Installation paths
DefaultDirName={autopf}\CAHAYA
DefaultGroupName={#AppName}
AllowNoIcons=no
DisableDirPage=no
DisableProgramGroupPage=yes

; Output
OutputDir=.\dist
OutputBaseFilename=CAHAYA_Setup_{#AppVersion}
SetupIconFile=.\resources\cahaya_icon.ico
UninstallDisplayIcon={app}\cahaya_icon.ico

; Compression
Compression=lzma2/ultra64
SolidCompression=yes
LZMAUseSeparateProcess=yes

; Wizard appearance
WizardStyle=modern
WizardSizePercent=130
WizardImageFile=.\resources\installer_banner.bmp
WizardSmallImageFile=.\resources\installer_icon_small.bmp
WizardImageStretch=no

; Privileges
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

; Minimum Windows version: Windows 10
MinVersion=10.0.17763

; Architecture
ArchitecturesInstallIn64BitMode=x64compatible

; License
LicenseFile=.\resources\LICENSE.rtf

; Misc
ShowLanguageDialog=no
CloseApplications=yes
RestartApplications=no
UsePreviousAppDir=yes
CreateUninstallRegKey=yes
Uninstallable=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";     Description: "{cm:CreateDesktopIcon}";      GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce
Name: "startmenuicon";  Description: "Create Start Menu shortcut";    GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce
Name: "autostart";      Description: "Launch CAHAYA on system startup"; GroupDescription: "Startup options"; Flags: unchecked

[Files]
; Main application files
Source: "..\*";                         DestDir: "{app}";         Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.pyc,__pycache__,venv,.git,.env"

; Installer wizard scripts
Source: ".\install_wizard.bat";         DestDir: "{app}\installer"; Flags: ignoreversion
Source: ".\detect_hardware.py";         DestDir: "{app}\installer"; Flags: ignoreversion
Source: ".\install_server.py";          DestDir: "{app}\installer"; Flags: ignoreversion
Source: ".\installer_ui.html";          DestDir: "{app}\installer"; Flags: ignoreversion

; Resources
Source: ".\resources\cahaya_icon.ico";  DestDir: "{app}";         Flags: ignoreversion
Source: ".\resources\LICENSE.rtf";      DestDir: "{app}";         Flags: ignoreversion

[Icons]
; Desktop shortcut
Name: "{autodesktop}\CAHAYA";                         Filename: "{app}\launcher\CAHAYA.exe";       IconFilename: "{app}\cahaya_icon.ico"; Tasks: desktopicon; Comment: "CAHAYA Sovereign Workspace — Librae AI Labs"

; Start Menu
Name: "{group}\CAHAYA Sovereign Workspace";           Filename: "{app}\launcher\CAHAYA.exe";       IconFilename: "{app}\cahaya_icon.ico"; Tasks: startmenuicon; Comment: "CAHAYA Sovereign Workspace"
Name: "{group}\CAHAYA — Support";                     Filename: "{#AppSupportURL}";
Name: "{group}\Uninstall CAHAYA";                     Filename: "{uninstallexe}";

[Registry]
; File association (optional — .cahaya workspace files)
Root: HKCU; Subkey: "Software\LibraeAI\CAHAYA"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\LibraeAI\CAHAYA"; ValueType: string; ValueName: "Version";     ValueData: "{#AppVersion}"
Root: HKCU; Subkey: "Software\LibraeAI\CAHAYA"; ValueType: string; ValueName: "Tier";        ValueData: "DETECTING"

; Auto-start (only if task selected)
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "CAHAYA"; ValueData: """{app}\launcher\CAHAYA.exe"" --minimized"; Tasks: autostart; Flags: uninsdeletevalue

[Run]
; Run install wizard after files are copied
Filename: "powershell.exe"; \
    Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\install_wizard.bat"""; \
    WorkingDir: "{app}"; \
    Description: "Complete CAHAYA setup (hardware detection + AI model download)"; \
    Flags: nowait postinstall skipifsilent; \
    StatusMsg: "Configuring CAHAYA for your hardware..."

; Open CAHAYA after install
Filename: "powershell.exe"; \
    Parameters: "-Command ""Start-Process 'http://127.0.0.1:8000'"""; \
    Description: "Open CAHAYA Workspace in browser"; \
    Flags: nowait postinstall skipifsilent shellexec; \
    StatusMsg: "Launching CAHAYA..."

[UninstallRun]
; Kill any running CAHAYA processes on uninstall
Filename: "powershell.exe"; \
    Parameters: "-Command ""Get-Process -Name 'uvicorn','python' -ErrorAction SilentlyContinue | Stop-Process -Force"""; \
    RunOnceId: "KillCAHAYA"

[UninstallDelete]
; Clean up user data directory (optional — ask first via wizard)
Type: dirifempty; Name: "{app}"

; ─── Custom Wizard Pages ──────────────────────────────────────────────────────
[Code]
var
  HardwarePage: TNewNotebookPage;
  HardwareLabel: TLabel;
  TierLabel: TLabel;
  ScanProgress: TProgressBar;
  LicensePage: TNewNotebookPage;
  LicenseKeyEdit: TEdit;
  TrialButton: TButton;

procedure InitializeWizard;
begin
  // Nothing required — custom pages added via WizardForm
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;

  // License key page validation (Page 6 = custom)
  if CurPageID = wpSelectDir then begin
    // Pre-install: launch the progress server in background
    ShellExec(
      'open',
      ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
      ExpandConstant(
        '-NoProfile -ExecutionPolicy Bypass -Command ' +
        '"Start-Process python -ArgumentList ''' +
        '{app}\installer\install_server.py'' -WindowStyle Hidden"'
      ),
      '', SW_HIDE, ewNoWait, Result
    );
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then begin
    // Open installer UI in browser
    ShellExec(
      'open',
      'http://127.0.0.1:8765',
      '', '', SW_SHOWNORMAL, ewNoWait, Integer(True)
    );
  end;
end;

function InitializeSetup(): Boolean;
var
  WinVer: TWindowsVersion;
begin
  GetWindowsVersionEx(WinVer);
  if WinVer.Major < 10 then begin
    MsgBox(
      'CAHAYA requires Windows 10 or later.' + #13#10 +
      'Please upgrade your operating system and try again.',
      mbError, MB_OK
    );
    Result := False;
  end else begin
    Result := True;
  end;
end;

procedure DeinitializeSetup;
begin
  // Cleanup on cancel — stop install server if running
  Exec(
    ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    '-Command "Get-Process python -ErrorAction SilentlyContinue | Stop-Process -Force"',
    '', SW_HIDE, ewNoWait, Integer(True)
  );
end;
