# CAHAYA Installer System
### Version 3.0.0 · Librae AI Labs Sdn Bhd

> [!IMPORTANT]
> The CAHAYA installer is designed for **non-technical users**. It **never shows a terminal**. All interaction happens through native OS dialogs or a browser-based GUI.

---

## Architecture Overview

```mermaid
graph TD
    A["User double-clicks install.sh / install.bat"] --> B["Root entry point\ninstall.sh · install.bat"]
    B --> C["Launches install_server.py\n(FastAPI on port 8765)"]
    B --> D["Opens http://127.0.0.1:8765\nin default browser"]
    B --> E["Runs install_wizard.sh / .bat\nin background"]
    C --> F["Serves installer_ui.html"]
    E --> G["Posts progress to\n/install-status endpoint"]
    F --> H["Browser polls /install-status\nevery 1.5 seconds"]
    E --> I["detect_hardware.py\nTier selection"]
    I --> J{"Tier?"}
    J --> K["EDGE: 7B GGUF model"]
    J --> L["STANDARD: 32B GGUF model"]
    J --> M["SOVEREIGN: 72B GGUF model"]
```

---

## File Reference

| File | Purpose | Platform |
|------|---------|----------|
| [`install.sh`](../install.sh) | Root entry point — starts server, opens browser, launches wizard | macOS / Linux |
| [`install.bat`](../install.bat) | Root entry point (Windows) | Windows 10/11 |
| [`installer/install_wizard.sh`](install_wizard.sh) | Main installer logic with `osascript`/`zenity` dialogs | macOS / Linux |
| [`installer/install_wizard.bat`](install_wizard.bat) | Main installer logic with PowerShell Windows Forms dialogs | Windows 10/11 |
| [`installer/detect_hardware.py`](detect_hardware.py) | Hardware detection module — outputs JSON tier config | Cross-platform |
| [`installer/install_server.py`](install_server.py) | FastAPI progress server on port 8765 | Cross-platform |
| [`installer/installer_ui.html`](installer_ui.html) | Browser-based installer UI (6-step wizard) | All browsers |
| [`installer/cahaya_setup.iss`](cahaya_setup.iss) | Inno Setup script for building Windows `.exe` installer | Inno Setup 6.x |

---

## Hardware Tier Logic

CAHAYA automatically selects the optimal AI model based on detected hardware:

| Tier | RAM Threshold | VRAM Threshold | Model | Size |
|------|--------------|----------------|-------|------|
| **EDGE** | < 16 GB | < 8 GB | `cahaya-7b-q4_k_m.gguf` | ~5 GB |
| **STANDARD** | 16–63 GB | 8–47 GB | `cahaya-32b-q4_k_m.gguf` | ~20 GB |
| **SOVEREIGN** | 64 GB+ | 48 GB+ | `cahaya-72b-q4_k_m.gguf` | ~45 GB |

### GPU Acceleration
- **Apple M1/M2/M3/M4**: `llama-cpp-python` compiled with Metal (`-DLLAMA_METAL=on`)
- **NVIDIA**: Compiled with CUDA (`-DLLAMA_CUDA=on`)
- **CPU Only**: Standard llama-cpp-python (slower but functional)

### Detection Methods (in priority order)
1. PyTorch (`torch.cuda`, `torch.backends.mps`)
2. `nvidia-smi` subprocess
3. macOS: `sysctl` + `system_profiler`
4. Linux: `/proc/meminfo`, `lspci`
5. Windows: `wmic` / `Win32_VideoController`

---

## Install Flow (Detailed)

### Step 1 — Welcome & T&C
- macOS: `osascript display dialog` with T&C text
- Linux: `zenity --question`
- Windows: PowerShell `System.Windows.Forms` dialog
- Browser: Panel 1 of `installer_ui.html`

### Step 2 — Hardware Scan
- Calls `detect_hardware.py` (or inline shell commands)
- Posts results to `http://127.0.0.1:8765/install-status`
- Browser UI animates hardware cards and reveals the tier badge
- Shows: *"Your system has been detected as [TIER] class. CAHAYA will configure optimally for your hardware."*

### Step 3 — License Key
- Browser UI collects key (format: `CAHAYA-XXXXX-XXXXX-XXXXX`)
- Or activates 30-day trial
- Key validation via POST to `/verify-license` (when API is live)

### Step 4 — Component Download
- Python Runtime: checks / installs Python 3.12
- AI Weights: downloads GGUF model from `cdn.librae.work`
- Map Engine: MapLibre GL JS assets
- 3D Engine: Three.js / spatial rendering assets
- Progress posted to server every ~1% of download

### Step 5 — Finalizing
- Writes `~/.cahaya/cahaya.config.json`
- Generates RSA keypairs in `crypto/`
- Creates Desktop shortcut:
  - **macOS**: `~/Desktop/CAHAYA.app` (full `.app` bundle)
  - **Linux**: `~/Desktop/CAHAYA.desktop`
  - **Windows**: `%USERPROFILE%\Desktop\CAHAYA.lnk`

### Step 6 — Launch
- Starts `uvicorn backend.main:app` on port 8000
- Opens `http://127.0.0.1:8000` in default browser
- Posts `/install-complete` to shut down install server (30s grace)
- Shows: *"CAHAYA is ready! Your AI workspace is launching..."*

---

## Building a Windows EXE Installer

1. Install [Inno Setup 6.x](https://jrsoftware.org/isinfo.php)
2. Add required resources to `installer/resources/`:
   - `cahaya_icon.ico` — Application icon
   - `installer_banner.bmp` — 497×315 px wizard sidebar image
   - `installer_icon_small.bmp` — 55×58 px wizard top-right icon
   - `LICENSE.rtf` — License text in RTF format
3. Compile:
   ```
   "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" cahaya_setup.iss
   ```
4. Output: `installer/dist/CAHAYA_Setup_3.0.0.exe`

---

## install_server.py API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Serves `installer_ui.html` |
| `/health` | GET | Health check |
| `/install-status` | GET | Returns current install state |
| `/install-status` | POST | Updates install state from wizard script |
| `/install-complete` | POST | Marks install done, schedules server shutdown |
| `/install-error` | POST | Records an installation error |
| `/hardware-detect` | GET | Runs `detect_hardware.py` and returns JSON |

### Status JSON Schema
```json
{
  "step": 4,
  "step_name": "Downloading AI Model",
  "progress": 67,
  "message": "Downloading cahaya-32b-q4_k_m.gguf: 67%",
  "tier": "STANDARD",
  "complete": false,
  "error": null,
  "elapsed_seconds": 142.3,
  "logs": [...],
  "hardware": {
    "cpu_cores": 10,
    "ram_gb": 32,
    "gpu": "Apple M3 Pro",
    "vram_gb": 32,
    "gpu_type": "APPLE_SILICON"
  }
}
```

---

## detect_hardware.py Usage

```bash
# Run standalone — outputs JSON
python3 installer/detect_hardware.py

# Example output
{
  "tier": "STANDARD",
  "cpu_cores": 10,
  "cpu_ghz": 3.49,
  "cpu_name": "Apple M3 Pro",
  "ram_gb": 18.0,
  "gpu": "Apple M3 Pro",
  "gpu_type": "APPLE_SILICON",
  "vram_gb": 18.0,
  "disk_free_gb": 234.7,
  "platform": "Darwin",
  "arch": "arm64",
  "message": "Your system has been detected as STANDARD class. CAHAYA will configure optimally for your hardware."
}
```

---

## Design Language

| Token | Value | Usage |
|-------|-------|-------|
| Background | `#000A1A` | Main background |
| Card | `rgba(0,28,60,0.7)` | Glassmorphism cards |
| Amber | `#FFB703` | Primary accent, CTAs, highlights |
| Amber Glow | `#FFD60A` | Gradient text, headings |
| Green OK | `#00E5A0` | Completed states |
| Red Error | `#FF4560` | Error states |
| Font | Inter (Google Fonts) | All typography |

---

## Troubleshooting

**Install server won't start**
- Ensure Python 3.8+ is installed
- Run `python3 -m pip install fastapi uvicorn` manually

**Model download fails**
- Check internet connection
- Verify `cdn.librae.work` is accessible
- Model can be downloaded manually from `librae.work/cahaya/models`

**CAHAYA.app won't open on macOS**
- Run: `xattr -cr ~/Desktop/CAHAYA.app`
- Or: System Settings → Privacy & Security → "Open Anyway"

**NVIDIA GPU not detected**
- Ensure CUDA drivers are installed
- Verify `nvidia-smi` is in PATH
- Try: `CMAKE_ARGS="-DLLAMA_CUDA=on" pip install llama-cpp-python --force-reinstall`

---

*CAHAYA™ Sovereign Workspace · Librae AI Labs Sdn Bhd · [librae.work](https://librae.work)*
