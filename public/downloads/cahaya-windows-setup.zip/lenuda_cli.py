#!/usr/bin/env python3
import sys
import os
import json
import argparse
import time
from datetime import datetime, timedelta

LICENSE_FILE = "cahaya_secure.json"
DEFAULT_HARDWARE_LOCK = "194FADC8-C831-5A4E-BCD4-2E31571D575F"

def load_license():
    if not os.path.exists(LICENSE_FILE):
        default_lic = {
            "active_invoice": "NONE",
            "tier": "UNLICENSED",
            "active_domain": "unlicensed",
            "cahaya_model_tier": "unlicensed",
            "vllm_args": "none",
            "model_image": "none",
            "hardware_lock": DEFAULT_HARDWARE_LOCK,
            "last_activation_date": "NONE",
            "contract_expires_at": "NONE",
            "verification_hash": "NONE"
        }
        save_license(default_lic)
        return default_lic
    try:
        with open(LICENSE_FILE, 'r') as f:
            return json.load(f)
    except Exception:
        return {}

def save_license(lic_data):
    with open(LICENSE_FILE, 'w') as f:
        json.dump(lic_data, f, indent=2)

def print_banner():
    print("=========================================================")
    print("   LENUDA SOVEREIGN LOCAL (.sl) COMMAND LINE UTILITY     ")
    print("       Cahaya Engine vLLM Allocation Coordinator          ")
    print("=========================================================")

def handle_status(args):
    print_banner()
    lic = load_license()
    print(f"🔒 SYSTEM HARDWARE LOCK:  {lic.get('hardware_lock')}")
    print(f"💼 ACTIVE LICENSE TIER:   {lic.get('tier')}")
    print(f"🌍 LICENSED ACTIVE DOMAIN: {lic.get('active_domain', 'unlicensed').upper()}")
    print(f"🧠 CAHAYA MODEL TIER:     {lic.get('cahaya_model_tier', 'unlicensed').upper()}")
    print(f"🤖 CAHAYA MODEL IMAGE:    {lic.get('model_image', 'none')}")
    print(f"⚙️ vLLM CONFIG ARGS:      {lic.get('vllm_args', 'none')}")
    print(f"📅 LAST ACTIVATION:       {lic.get('last_activation_date', 'NONE')}")
    print(f"⏳ CONTRACT EXPIRATION:   {lic.get('contract_expires_at', 'NONE')}")
    
    if lic.get("contract_expires_at") != "NONE":
        try:
            exp_date = datetime.fromisoformat(lic.get("contract_expires_at"))
            if datetime.now() > exp_date:
                print("\n❌ ALERT: License expired! Run with --activate <TOKEN> to renew.")
            else:
                days_left = (exp_date - datetime.now()).days
                print(f"\n✅ LICENSE ACTIVE: {days_left} days remaining until annual renewal.")
        except Exception:
            print("\n⚠️ WARNING: License date format corrupted.")
    else:
        print("\n❌ SYSTEM UNLICENSED: Please activate with a valid sovereign annual token.")

def handle_activate(args):
    print_banner()
    token = args.activate
    print(f"🔑 Verifying annual license token: {token}...")
    time.sleep(1.0)
    
    # Validation tokens mapping
    tokens_map = {
        "SECURE-TOKEN-EDGE-AGRI-2026": {
            "tier": "EDGE",
            "active_domain": "agriculture",
            "cahaya_model_tier": "edge",
            "model_image": "qwen/qwen2.5-7b-instruct-gptq-int4",
            "vllm_args": "--quantization gptq --max-model-len 32768 --tensor-parallel-size 1"
        },
        "SECURE-TOKEN-STANDARD-MINING-2026": {
            "tier": "STANDARD",
            "active_domain": "mining",
            "cahaya_model_tier": "standard",
            "model_image": "qwen/qwen2.5-32b-instruct-awq",
            "vllm_args": "--quantization awq --max-model-len 65536 --tensor-parallel-size 1"
        },
        "SECURE-TOKEN-SOVEREIGN-DEFENSE-2026": {
            "tier": "SOVEREIGN",
            "active_domain": "defense",
            "cahaya_model_tier": "sovereign",
            "model_image": "qwen/qwen2.5-72b-instruct",
            "vllm_args": "--max-model-len 131072 --tensor-parallel-size 2"
        },
        "SECURE-ANNUAL-TOKEN-2026": {
            "tier": "SOVEREIGN",
            "active_domain": "agriculture",
            "cahaya_model_tier": "sovereign",
            "model_image": "qwen/qwen2.5-72b-instruct",
            "vllm_args": "--max-model-len 131072 --tensor-parallel-size 2"
        }
    }
    
    if token not in tokens_map:
        # Dynamic token validation fallback
        if token.startswith("SECURE-TOKEN-") and token.endswith("-2026"):
            parts = token.split("-")
            if len(parts) >= 5:
                t_str = parts[2].upper()
                d_str = parts[3].lower()
                
                valid_tiers = ["EDGE", "STANDARD", "SOVEREIGN"]
                valid_domains = ["agriculture", "mining", "disaster", "urban", "utilities", "logistics", "defense", "environmental", "infrastructure", "emergency"]
                
                if t_str in valid_tiers and d_str in valid_domains:
                    tokens_map[token] = {
                        "tier": t_str,
                        "active_domain": d_str,
                        "cahaya_model_tier": t_str.lower(),
                        "model_image": "qwen/qwen2.5-7b-instruct-gptq-int4" if t_str == "EDGE" else ("qwen/qwen2.5-32b-instruct-awq" if t_str == "STANDARD" else "qwen/qwen2.5-72b-instruct"),
                        "vllm_args": "--quantization gptq --max-model-len 32768 --tensor-parallel-size 1" if t_str == "EDGE" else ("--quantization awq --max-model-len 65536 --tensor-parallel-size 1" if t_str == "STANDARD" else "--max-model-len 131072 --tensor-parallel-size 2")
                    }
                    
    if token not in tokens_map:
        print("\n❌ ERROR: Invalid token. Verification failed. System unlicensed.")
        sys.exit(1)
        
    config = tokens_map[token]
    lic = load_license()
    
    lic["tier"] = config["tier"]
    lic["active_domain"] = config["active_domain"]
    lic["cahaya_model_tier"] = config["cahaya_model_tier"]
    lic["model_image"] = config["model_image"]
    lic["vllm_args"] = config["vllm_args"]
    lic["active_invoice"] = "INV-" + token.split("-")[-2] if len(token.split("-")) > 2 else "INV-DEV-2026"
    lic["last_activation_date"] = datetime.now().isoformat()
    lic["contract_expires_at"] = (datetime.now() + timedelta(days=365)).isoformat()
    
    import hashlib
    lic["verification_hash"] = hashlib.sha256(token.encode()).hexdigest()
    
    save_license(lic)
    print("\n✅ LICENSE ACTIVATED SUCCESSFULLY!")
    print(f"   Tier:          {lic['tier']} Local")
    print(f"   Active Domain: {lic['active_domain'].upper()}")
    print(f"   Model Image:   {lic['model_image']}")
    print(f"   vLLM Config:   {lic['vllm_args']}")
    print(f"   Expiration:    {lic['contract_expires_at']}")
    print(f"   Hardware signature bound. Database registry lock sealed.")

def handle_download(args):
    print_banner()
    lic = load_license()
    if lic.get("tier") == "UNLICENSED":
        print("\n❌ ERROR: Active license required to download packages. Run --activate first.")
        sys.exit(1)
        
    print("📡 Connecting to Lenuda Distribution Hub...")
    time.sleep(0.8)
    
    model_image = lic.get("model_image")
    print(f"📦 Found active licensed model package: {model_image}")
    
    packages = [
      ("turbovec-4bit-weights", 1400),
      ("opendataloader-pdf-spec", 240),
      (model_image, 15000 if "72b" in model_image else (6500 if "32b" in model_image else 2200)),
      ("crucix-osint-streamer", 420)
    ]
    
    for pkg, size in packages:
        print(f"\nDownloading {pkg} ({size} MB)...")
        for i in range(11):
            progress = i * 10
            bar = "#" * i + "-" * (10 - i)
            sys.stdout.write(f"\r[{bar}] {progress}% Complete")
            sys.stdout.flush()
            time.sleep(0.15)
        print("\n   ✓ Verified signature check-seal.")
        
    print("\n✅ ALL ASSETS DOWNLOADED AND LOADED NATIVELY.")
    print("   Run './cahaya_init.sh' to start air-gapped system container.")

def handle_update(args):
    print_banner()
    print("🔄 Checking for system CLI updates...")
    time.sleep(1.0)
    print("Base coordination script is up to date. (Current version: 2.0.4)")

def main():
    parser = argparse.ArgumentParser(description="Lenuda Sovereign Local CLI (.sl)")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--status", action="store_true", help="View current license activation status")
    group.add_argument("--activate", type=str, help="Activate local machine using annual token")
    group.add_argument("--download", action="store_true", help="Download stack updates from distribution network")
    group.add_argument("--update", action="store_true", help="Check and apply CLI tools updates")
    
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
        
    args = parser.parse_args()
    if args.status:
        handle_status(args)
    elif args.activate:
        handle_activate(args)
    elif args.download:
        handle_download(args)
    elif args.update:
        handle_update(args)

if __name__ == "__main__":
    main()
